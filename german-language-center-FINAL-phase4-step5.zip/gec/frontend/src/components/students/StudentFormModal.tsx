import { useEffect, useState } from "react";
import type { FormEvent } from "react";
import FormInput from "../FormInput";
import Modal from "../Modal";
import StatusBadge from "../StatusBadge";
import { useToast } from "../../contexts/ToastContext";
import { parseError } from "../../services/api";
import { customerService } from "../../services/customerService";
import type { Customer, Enrollment } from "../../types";
import { statusTone } from "../../utils/format";
import { useIdempotencyKey } from "../../utils/idempotency";
import { usePreferences } from "../../contexts/PreferencesContext";

interface Props { open: boolean; student: Customer | null; onClose: () => void; onSaved: () => void }

const PHONE = /^[0-9+()\-\s]{6,30}$/;
const EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export default function StudentFormModal({ open, student, onClose, onSaved }: Props) {
  const { t, tf } = usePreferences();
  const toast = useToast();
  const idem = useIdempotencyKey();
  const editing = student !== null;
  const [fullName, setFullName] = useState("");
  const [phone, setPhone] = useState("");
  const [email, setEmail] = useState("");
  const [area, setArea] = useState("");
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [busy, setBusy] = useState(false);
  const [courses, setCourses] = useState<Enrollment[] | null>(null);

  useEffect(() => {
    if (!open) return;
    idem.renew(); // a newly opened form is a new intent: it gets its own key
    setFullName(student?.fullName ?? "");
    setPhone(student?.phone ?? "");
    setEmail(student?.email ?? "");
    setArea(student?.area ?? "");
    setErrors({});
    // Editing: load every course this student is registered in (not just a count).
    setCourses(null);
    if (student) {
      let cancelled = false;
      customerService.get(student.customerId).then((d) => { if (!cancelled) setCourses(d.enrollments); }).catch(() => { if (!cancelled) setCourses([]); });
      return () => { cancelled = true; };
    }
  }, [open, student]);

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (busy) return; // a second click while saving is ignored (the server is protected as well)
    const errs: Record<string, string> = {};
    if (fullName.trim().length < 2) errs.fullName = t("ui.full_name_must_be_at");
    if (!phone.trim()) errs.phone = t("ui.phone_number_is_required");
    else if (!PHONE.test(phone.trim())) errs.phone = t("ui.phone_number_is_not_valid");
    if (email.trim() && !EMAIL.test(email.trim())) errs.email = t("ui.email_address_is_not_valid");
    if (area.trim().length > 100) errs.area = t("ui.area_is_too_long");
    setErrors(errs);
    if (Object.keys(errs).length) return;

    const body = { fullName: fullName.trim(), phone: phone.trim(), email: email.trim() || undefined, address: student?.address ?? undefined, area: area.trim() || undefined }; // the form has no Address field; an existing address is kept
    setBusy(true);
    try {
      if (student) {
        const before = student;
        await customerService.update(before.customerId, body);
        onSaved();
        toast.success(t("ui.student_updated_successfully"), {
          undo: async () => {
            await customerService.update(before.customerId, {
              fullName: before.fullName, phone: before.phone ?? "", email: before.email ?? undefined, address: before.address ?? undefined, area: before.area ?? undefined
            });
            onSaved();
          }
        });
      } else {
        const created = await customerService.create(body, idem.current());
        idem.renew();
        onSaved();
        toast.success(tf("ui.student_created", { code: created.studentCode }));
      }
      onClose();
    } catch (err) {
      toast.error(parseError(err).message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <Modal open={open} title={editing ? t("ui.edit_student") : t("ui.add_student_2")} onClose={onClose}>
      <form onSubmit={submit} noValidate className="space-y-4">
        <div className="rounded-lg bg-gray-50 px-3 py-2 text-sm">
          <span className="text-gray-500">{t("ui.student_id")} </span>
          {student ? <span className="font-mono font-semibold text-gray-900">{student.studentCode}</span>
                   : <span className="text-gray-500">{t("ui.generated_automatically_when_saved")}</span>}
        </div>
        <FormInput label={t("ui.full_name")} value={fullName} onChange={(e) => setFullName(e.target.value)} error={errors.fullName} autoFocus />
        <FormInput label={t("students.phone")} value={phone} onChange={(e) => setPhone(e.target.value)} error={errors.phone} inputMode="tel" />
        <FormInput label={t("students.email")} type="email" value={email} onChange={(e) => setEmail(e.target.value)} error={errors.email} />
        <FormInput label={t("flow.area")} placeholder={t("ui.e_g_girga")} value={area} onChange={(e) => setArea(e.target.value)} error={errors.area} />
        {editing && (
          <div className="space-y-1.5">
            <p className="text-sm font-medium text-gray-700">{t("nav.courses")}</p>
            {courses === null ? <p className="text-sm text-gray-500">{t("common.loading")}</p>
              : courses.length === 0 ? <p className="rounded-lg bg-gray-50 px-3 py-2 text-sm text-gray-500">{t("ui.not_registered_in_any_course")}</p>
              : (
                <ul className="divide-y divide-gray-100 rounded-lg border border-gray-200">
                  {courses.map((c) => (
                    <li key={c.enrollmentId} className="flex items-center justify-between gap-3 px-3 py-2 text-sm">
                      <span><span className="font-mono font-semibold text-gray-900">{c.courseCode}</span> <span className="text-gray-500">—</span> <span className="text-gray-800">{c.courseName}</span></span>
                      <StatusBadge tone={statusTone(c.status)}>{t(`st.${c.status}`, c.status)}</StatusBadge>
                    </li>
                  ))}
                </ul>
              )}
          </div>
        )}
        <div className="flex justify-end gap-2 pt-2">
          <button type="button" onClick={onClose} className="rounded-lg border border-gray-300 px-4 py-2 text-sm hover:bg-gray-50">{t("dataGate.cancel")}</button>
          <button type="submit" disabled={busy} className="rounded-lg bg-orange-500 px-4 py-2 text-sm font-medium text-white hover:bg-orange-600 disabled:opacity-60">{busy ? t("ui.saving") : t("account.save")}</button>
        </div>
      </form>
    </Modal>
  );
}
