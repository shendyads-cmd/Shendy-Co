import { usePreferences } from "../contexts/PreferencesContext";
export interface FilterOption<T extends string> { value: T; label: string; count?: number }

interface Props<T extends string> { options: FilterOption<T>[]; value: T; onChange: (v: T) => void }

/** Small segmented filter for a short list of values (for example All / Active / Inactive). */
export default function StatusFilter<T extends string>({ options, value, onChange }: Props<T>) {
  const { t } = usePreferences();
  return (
    <div className="inline-flex rounded-lg bg-gray-100 p-1" role="group" aria-label={t("ui.status_filter")}>
      {options.map((o) => (
        <button key={o.value} onClick={() => onChange(o.value)} aria-pressed={value === o.value}
                className={`rounded-md px-3 py-1.5 text-sm font-medium transition ${value === o.value ? "bg-white text-orange-700 shadow-sm" : "text-gray-600 hover:text-gray-900"}`}>
          {o.label}{o.count !== undefined && <span className="ms-1.5 text-xs text-gray-400">{o.count}</span>}
        </button>
      ))}
    </div>
  );
}
