import { useEffect } from "react";
import type { ReactNode } from "react";
import { X } from "lucide-react";
import { usePreferences } from "../contexts/PreferencesContext";

interface Props { open: boolean; title: string; onClose: () => void; children: ReactNode; wide?: boolean; xl?: boolean }

export default function Modal({ open, title, onClose, children, wide, xl }: Props) {
  const { t } = usePreferences();
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, onClose]);

  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4" onMouseDown={onClose}>
      <div role="dialog" aria-modal="true" aria-label={title}
           className={`max-h-[92vh] w-full overflow-y-auto ${xl ? "max-w-3xl" : wide ? "max-w-xl" : "max-w-md"} rounded-2xl bg-white p-6 shadow-xl`} onMouseDown={(e) => e.stopPropagation()}>
        <div className="mb-4 flex items-center justify-between">
          <h2 className="text-lg font-semibold text-gray-900">{title}</h2>
          <button onClick={onClose} aria-label={t("notif.close")} className="rounded-lg p-1 text-gray-500 hover:bg-gray-100"><X className="h-5 w-5" /></button>
        </div>
        {children}
      </div>
    </div>
  );
}
