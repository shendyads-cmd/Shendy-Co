import type { InputHTMLAttributes, ReactNode } from "react";

interface Props extends InputHTMLAttributes<HTMLInputElement> {
  label: string;
  error?: string;
  right?: ReactNode;
}

export default function FormInput({ label, error, right, id, className = "", ...rest }: Props) {
  const inputId = id ?? rest.name ?? label;
  return (
    <div className="space-y-1">
      <label htmlFor={inputId} className="block text-sm font-medium text-gray-700">{label}</label>
      <div className="relative">
        <input
          id={inputId}
          {...rest}
          className={`w-full rounded-lg border px-3 py-2 text-sm text-gray-900 outline-none transition focus:ring-2 focus:ring-orange-300 ${
            error ? "border-red-400" : "border-gray-300 focus:border-orange-500"
          } ${right ? "pe-10" : ""} ${className}`}
        />
        {right && <div className="absolute inset-y-0 end-0 flex items-center pe-3">{right}</div>}
      </div>
      {error && <p className="text-xs text-red-600">{error}</p>}
    </div>
  );
}
