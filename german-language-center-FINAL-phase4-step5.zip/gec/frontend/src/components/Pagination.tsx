import { ChevronLeft, ChevronRight } from "lucide-react";
import { usePreferences } from "../contexts/PreferencesContext";

interface Props { page: number; pageSize: number; total: number; onPage: (p: number) => void }

export default function Pagination({ page, pageSize, total, onPage }: Props) {
  const { t } = usePreferences();
  const pages = Math.max(1, Math.ceil(total / pageSize));
  const from = total === 0 ? 0 : (page - 1) * pageSize + 1;
  const to = Math.min(page * pageSize, total);
  const btn = "rounded-lg border border-gray-300 p-1.5 text-gray-600 hover:bg-gray-50 disabled:cursor-not-allowed disabled:opacity-40";
  return (
    <div className="flex flex-wrap items-center justify-between gap-2 border-t border-gray-100 px-4 py-3 text-sm text-gray-600">
      <span>{from}-{to} of {total}</span>
      <div className="flex items-center gap-2">
        <button className={btn} disabled={page <= 1} onClick={() => onPage(page - 1)} aria-label={t("ui.previous_page")}><ChevronLeft className="h-4 w-4 rtl:rotate-180" /></button>
        <span>{t("ui.page")} {page} / {pages}</span>
        <button className={btn} disabled={page >= pages} onClick={() => onPage(page + 1)} aria-label={t("ui.next_page")}><ChevronRight className="h-4 w-4 rtl:rotate-180" /></button>
      </div>
    </div>
  );
}
