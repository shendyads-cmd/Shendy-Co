import { useCallback, useEffect, useState } from "react";
import { DatabaseBackup, History, RotateCcw, ShieldAlert } from "lucide-react";
import EmptyState from "../EmptyState";
import FormInput from "../FormInput";
import LoadingSpinner from "../LoadingSpinner";
import Modal from "../Modal";
import { useAuth } from "../../contexts/AuthContext";
import { usePreferences } from "../../contexts/PreferencesContext";
import { useToast } from "../../contexts/ToastContext";
import { parseError } from "../../services/api";
import { backupService } from "../../services/backupService";
import type { BackupInfo } from "../../types";
import { formatDate } from "../../utils/format";
import { useIdempotencyKey } from "../../utils/idempotency";

const mb = (n: number) => `${(n / (1024 * 1024)).toFixed(1)} MB`;

/** Data > Backup and Restore (Admin only; the API enforces it). Restore replaces ALL current data, so it asks for the word RESTORE and the admin's password. */
export default function BackupSection() {
  const { t } = usePreferences();
  const toast = useToast();
  const idem = useIdempotencyKey();
  const [items, setItems] = useState<BackupInfo[]>([]);
  const [loading, setLoading] = useState(true);
  const [creating, setCreating] = useState(false);
  const [target, setTarget] = useState<BackupInfo | null>(null);

  const load = useCallback(() => {
    setLoading(true);
    backupService.list().then(setItems).catch((e) => toast.error(parseError(e).message)).finally(() => setLoading(false));
    // toast is stable
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  useEffect(load, [load]);

  const create = async () => {
    if (creating) return;
    setCreating(true);
    try {
      await backupService.create(idem.current());
      idem.renew();
      toast.success(t("backup.created"));
      load();
    } catch (e) { toast.error(parseError(e).message); }
    finally { setCreating(false); }
  };

  return (
    <section className="mt-6 space-y-4 rounded-2xl border border-gray-200 bg-white p-5 shadow-sm">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h2 className="flex items-center gap-2 text-lg font-semibold text-gray-900"><DatabaseBackup className="h-5 w-5 text-orange-500" /> {t("backup.title")}</h2>
          <p className="text-sm text-gray-500">{t("backup.help")}</p>
        </div>
        <button onClick={create} disabled={creating} className="inline-flex items-center gap-2 rounded-lg bg-orange-500 px-3 py-2 text-sm font-medium text-white hover:bg-orange-600 disabled:opacity-60">
          <DatabaseBackup className="h-4 w-4" /> {creating ? t("backup.creating") : t("backup.create")}
        </button>
      </div>
      {loading ? <LoadingSpinner /> : items.length === 0 ? (
        <EmptyState icon={History} title={t("backup.none")} text={t("backup.noneText")} />
      ) : (
        <div className="overflow-x-auto rounded-xl border border-gray-200">
          <table className="w-full text-start text-sm">
            <thead className="bg-gray-50 text-xs uppercase text-gray-500">
              <tr><th className="px-3 py-3 text-start">{t("backup.col.date")}</th><th className="px-3 py-3 text-start">{t("backup.col.size")}</th><th className="px-3 py-3 text-start">{t("backup.col.file")}</th><th className="px-3 py-3 text-end">{t("common.actions")}</th></tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {items.map((b) => (
                <tr key={b.backupId} className="hover:bg-orange-50/40">
                  <td className="whitespace-nowrap px-3 py-3 text-gray-700">{formatDate(b.createdAt)} <span className="text-gray-500" dir="ltr">{b.createdAt.slice(11, 16)}</span></td>
                  <td className="whitespace-nowrap px-3 py-3 text-gray-700">{mb(b.sizeBytes)}</td>
                  <td className="max-w-md break-all px-3 py-3 text-xs text-gray-500" dir="ltr">{b.filePath}</td>
                  <td className="px-3 py-3"><div className="flex justify-end">
                    <button onClick={() => setTarget(b)} className="inline-flex items-center gap-1 rounded-lg border border-red-300 px-2.5 py-1 text-xs font-medium text-red-700 hover:bg-red-50"><RotateCcw className="h-3.5 w-3.5" /> {t("backup.restore")}</button>
                  </div></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      {target && <RestoreDialog backup={target} onClose={() => setTarget(null)} />}
    </section>
  );
}

function RestoreDialog({ backup, onClose }: { backup: BackupInfo; onClose: () => void }) {
  const { t } = usePreferences();
  const { logout } = useAuth();
  const toast = useToast();
  const [word, setWord] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const ready = word === "RESTORE" && password.length > 0;

  const run = async () => {
    if (!ready || busy) return;
    setBusy(true); setError("");
    try {
      await backupService.restore(backup.backupId, word, password);
      toast.success(t("backup.restored"));
      logout(); // the data was replaced: everyone signs in again
    } catch (e) { setError(parseError(e).message); setBusy(false); }
  };

  return (
    <Modal open title={t("backup.restoreTitle")} onClose={busy ? () => undefined : onClose} wide>
      <div className="space-y-4">
        <div className="flex gap-3 rounded-xl bg-red-50 p-3 text-sm text-red-800">
          <ShieldAlert className="mt-0.5 h-5 w-5 shrink-0" />
          <div className="space-y-1">
            <p className="font-semibold">{t("backup.warnTitle")}</p>
            <p>{t("backup.warn1")}</p><p>{t("backup.warn2")}</p><p>{t("backup.warn3")}</p>
          </div>
        </div>
        <p className="text-sm text-gray-700"><span className="font-medium">{t("backup.col.file")}:</span> <span className="break-all text-xs" dir="ltr">{backup.filePath}</span> ({formatDate(backup.createdAt)})</p>
        <FormInput label={t("backup.typeWord")} value={word} onChange={(e) => setWord(e.target.value)} autoComplete="off" disabled={busy} />
        <FormInput label={t("account.accountPassword")} type="password" autoComplete="current-password" value={password} onChange={(e) => setPassword(e.target.value)} error={error} disabled={busy} />
        <div className="flex justify-end gap-2">
          <button onClick={onClose} disabled={busy} className="rounded-lg border border-gray-300 px-4 py-2 text-sm hover:bg-gray-50">{t("dataGate.cancel")}</button>
          <button onClick={run} disabled={!ready || busy} className="rounded-lg bg-red-600 px-4 py-2 text-sm font-medium text-white hover:bg-red-700 disabled:opacity-50">{busy ? t("backup.restoring") : t("backup.restoreNow")}</button>
        </div>
      </div>
    </Modal>
  );
}
