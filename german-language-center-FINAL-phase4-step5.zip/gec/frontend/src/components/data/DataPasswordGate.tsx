import { useState } from "react";
import type { FormEvent } from "react";
import { useNavigate } from "react-router-dom";
import { Lock } from "lucide-react";
import FormInput from "../FormInput";
import { usePreferences } from "../../contexts/PreferencesContext";
import { parseError } from "../../services/api";
import { dataAccessService } from "../../services/dataAccessService";
import { setDataToken } from "../../utils/dataAccess";

/** Shown to staff before Data opens. The password is checked by the API; nothing about it exists in this code. */
export default function DataPasswordGate({ onUnlocked }: { onUnlocked: () => void }) {
  const { t } = usePreferences();
  const navigate = useNavigate();
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (busy) return;
    if (!password) { setError(t("dataGate.required")); return; }
    setBusy(true); setError("");
    try {
      const res = await dataAccessService.unlock(password);
      if (res.token && res.expiresAtUtc) setDataToken(res.token, res.expiresAtUtc);
      setPassword("");
      onUnlocked();
    } catch (err) {
      const p = parseError(err);
      setError(p.code === "DATA_PASSWORD_INVALID" ? t("dataGate.invalid") : p.message);
      setPassword("");
    } finally { setBusy(false); }
  };

  return (
    <div className="mx-auto mt-10 max-w-sm rounded-2xl border border-gray-200 bg-white p-6 shadow-sm">
      <div className="mx-auto mb-3 w-fit rounded-full bg-orange-50 p-3"><Lock className="h-6 w-6 text-orange-500" /></div>
      <h1 className="text-center text-lg font-semibold text-gray-900">{t("dataGate.title")}</h1>
      <p className="mb-4 mt-1 text-center text-sm text-gray-500">{t("dataGate.text")}</p>
      <form onSubmit={submit} className="space-y-4" noValidate>
        <FormInput label={t("dataGate.password")} type="password" autoComplete="off" autoFocus value={password}
                   onChange={(e) => { setPassword(e.target.value); setError(""); }} error={error} disabled={busy} />
        <div className="flex justify-end gap-2">
          <button type="button" onClick={() => navigate("/students")} disabled={busy} className="rounded-lg border border-gray-300 px-4 py-2 text-sm hover:bg-gray-50">{t("dataGate.cancel")}</button>
          <button type="submit" disabled={busy} className="rounded-lg bg-orange-500 px-4 py-2 text-sm font-medium text-white hover:bg-orange-600 disabled:opacity-60">
            {busy ? t("common.loading") : t("dataGate.unlock")}
          </button>
        </div>
      </form>
    </div>
  );
}
