type Tone = "green" | "red" | "yellow" | "gray" | "orange";

const tones: Record<Tone, string> = {
  green: "bg-green-100 text-green-700",
  red: "bg-red-100 text-red-700",
  yellow: "bg-yellow-100 text-yellow-800",
  gray: "bg-gray-100 text-gray-700",
  orange: "bg-orange-100 text-orange-700"
};

export default function StatusBadge({ tone, children }: { tone: Tone; children: string }) {
  return <span className={`inline-flex rounded-full px-2.5 py-0.5 text-xs font-medium ${tones[tone]}`}>{children}</span>;
}
