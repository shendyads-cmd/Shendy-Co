import { tr } from "../i18n/translateServer";
import { useEffect, useState } from "react";
import type { ReactNode } from "react";
import Modal from "./Modal";
import { usePreferences } from "../contexts/PreferencesContext";

interface Props {
  open: boolean;
  title: string;
  /** Identifies what is being deleted (for example the Student ID and name). */
  subject: ReactNode;
  /** Explains what deleting does. */
  description: string;
  suggestions: string[];
  busy?: boolean;
  onConfirm: (reason: string) => void;
  onCancel: () => void;
}

/** Confirmation + free-text reason, shared by the student and course delete actions. */
export default function DeleteReasonDialog({ open, title, subject, description, suggestions, busy, onConfirm, onCancel }: Props) {
  const { t } = usePreferences();
  const [reason, setReason] = useState("");
  const [error, setError] = useState("");

  useEffect(() => { if (open) { setReason(""); setError(""); } }, [open]);

  const submit = () => {
    const value = reason.trim();
    if (value.length < 2) { setError(tr("ui.please_enter_a_reason")); return; }
    onConfirm(value);
  };

  return (
    <Modal open={open} title={title} onClose={onCancel}>
      <div className="space-y-4">
        <div className="rounded-lg border border-red-200 bg-red-50 px-3 py-2 text-sm font-medium text-red-800">{subject}</div>
        <p className="text-sm text-gray-600">{description}</p>
        <div className="space-y-2">
          <label htmlFor="delete-reason" className="block text-sm font-medium text-gray-700">{t("ui.reason_for_deleting")}</label>
          <textarea id="delete-reason" rows={3} maxLength={500} value={reason} autoFocus
                    onChange={(e) => { setReason(e.target.value); setError(""); }}
                    placeholder={t("ui.write_any_reason")}
                    className={`w-full rounded-lg border px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-orange-300 ${error ? "border-red-400" : "border-gray-300 focus:border-orange-500"}`} />
          {error && <p className="text-xs text-red-600">{error}</p>}
          <div className="flex flex-wrap gap-2">
            {suggestions.map((s) => (
              <button key={s} type="button" onClick={() => { setReason(s); setError(""); }}
                      className="rounded-full border border-gray-300 px-2.5 py-1 text-xs text-gray-600 hover:border-orange-400 hover:bg-orange-50 hover:text-orange-700">{s}</button>
            ))}
          </div>
        </div>
        <div className="flex justify-end gap-2 pt-1">
          <button onClick={onCancel} className="rounded-lg border border-gray-300 px-4 py-2 text-sm hover:bg-gray-50">{t("dataGate.cancel")}</button>
          <button onClick={submit} disabled={busy} className="rounded-lg bg-red-600 px-4 py-2 text-sm font-medium text-white hover:bg-red-700 disabled:opacity-60">{busy ? t("ui.deleting") : t("ui.delete")}</button>
        </div>
      </div>
    </Modal>
  );
}
