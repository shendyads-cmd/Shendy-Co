import { Moon, Sun } from "lucide-react";
import { usePreferences } from "../contexts/PreferencesContext";

/** Two small icons, always visible in the top bar. Clicking switches the theme at once and the choice is saved. */
export default function ThemeToggle() {
  const { theme, setTheme, t } = usePreferences();
  return (
    <div className="flex items-center gap-1" role="group" aria-label={t("ui.theme")}>
      <button onClick={() => setTheme("light")} aria-pressed={theme === "light"} title={t("top.light")} aria-label={t("top.light")} className="icon-btn"><Sun className="h-4 w-4" /></button>
      <button onClick={() => setTheme("dark")} aria-pressed={theme === "dark"} title={t("top.dark")} aria-label={t("top.dark")} className="icon-btn"><Moon className="h-4 w-4" /></button>
    </div>
  );
}
