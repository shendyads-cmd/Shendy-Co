import type { Language } from "../i18n/translations";

/** Small inline SVG flags. (Flag emoji do not render on Windows, so real graphics are used.) */
export default function Flag({ language, className = "h-4 w-6" }: { language: Language; className?: string }) {
  const common = { viewBox: "0 0 30 20", className: `${className} shrink-0 rounded-[2px] border border-black/10`, "aria-hidden": true } as const;
  if (language === "ar") {
    return (
      <svg {...common}><rect width="30" height="6.67" fill="#CE1126" /><rect y="6.67" width="30" height="6.66" fill="#fff" /><rect y="13.33" width="30" height="6.67" fill="#000" />
        <path d="M15 7.4l1.6 2.6-1.6 2.6-1.6-2.6z" fill="#C09300" /></svg>
    );
  }
  if (language === "de") {
    return <svg {...common}><rect width="30" height="6.67" fill="#000" /><rect y="6.67" width="30" height="6.66" fill="#DD0000" /><rect y="13.33" width="30" height="6.67" fill="#FFCE00" /></svg>;
  }
  const stripes = Array.from({ length: 7 }, (_, i) => <rect key={i} y={i * (20 / 7)} width="30" height={20 / 7} fill={i % 2 === 0 ? "#B22234" : "#fff"} />);
  const stars = Array.from({ length: 12 }, (_, i) => <circle key={i} cx={2 + (i % 4) * 2.6} cy={2 + Math.floor(i / 4) * 2.8} r="0.55" fill="#fff" />);
  return <svg {...common}>{stripes}<rect width="12.5" height="10.8" fill="#3C3B6E" />{stars}</svg>;
}
