import { Search } from "lucide-react";
import { usePreferences } from "../contexts/PreferencesContext";

interface Props {
  value: string;
  onChange: (v: string) => void;
  /** Runs when the user presses Enter OR clicks the magnifier. Both go through the same form submit. */
  onSearch: () => void;
  placeholder?: string;
}

export default function SearchBox({ value, onChange, onSearch, placeholder }: Props) {
  const { t } = usePreferences();
  return (
    <form role="search" onSubmit={(e) => { e.preventDefault(); onSearch(); }} className="flex w-full max-w-sm items-center gap-2">
      <input value={value} onChange={(e) => onChange(e.target.value)} placeholder={placeholder ?? t("ui.search")} aria-label={t("ui.search_2")}
             className="min-w-0 flex-1 rounded-lg border border-gray-300 px-3 py-2 text-sm outline-none focus:border-orange-500 focus:ring-2 focus:ring-orange-300" />
      <button type="submit" title={t("ui.search_2")} aria-label={t("ui.search_2")}
              className="icon-btn">
        <Search className="h-4 w-4" />
      </button>
    </form>
  );
}
