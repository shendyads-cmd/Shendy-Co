import { useEffect, useState } from "react";
import type { FormEvent } from "react";
import FormInput from "../FormInput";
import StatusBadge from "../StatusBadge";
import { usePreferences } from "../../contexts/PreferencesContext";
import { useToast } from "../../contexts/ToastContext";
import { parseError } from "../../services/api";
import { dataAccessService } from "../../services/dataAccessService";

/**
 * Admin only (the API enforces it): the fixed password staff must enter before Data opens.
 * It is stored hashed on the server and is never shown or returned; here it can only be replaced.
 * Replacing it signs every staff member out of Data at once.
 */
export default function DataPasswordSection() {
  const { t } = usePreferences();
  const toast = useToast();
  const [configured, setConfigured] = useState<boolean | null>(null);
  const [account, setAccount] = useState("");
  const [next, setNext] = useState("");
  const [confirm, setConfirm] = useState("");
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [busy, setBusy] = useState(false);

  useEffect(() => { dataAccessService.status().then((s) => setConfigured(s.passwordConfigured)).catch(() => setConfigured(null)); }, []);

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (busy) return;
    const errs: Record<string, string> = {};
    if (!account) errs.account = t("account.required");
    if (next.length < 8) errs.next = t("account.min8");
    if (confirm !== next) errs.confirm = t("account.mismatch");
    setErrors(errs);
    if (Object.keys(errs).length) return;
    setBusy(true);
    try {
      await dataAccessService.changePassword(account, next);
      setAccount(""); setNext(""); setConfirm(""); setConfigured(true);
      toast.success(t("account.dataPasswordSaved"));
    } catch (err) {
      const p = parseError(err);
      setErrors(p.code === "ACCOUNT_PASSWORD_INVALID" ? { account: p.message } : { next: p.message });
    } finally { setBusy(false); }
  };

  return (
    <form onSubmit={submit} className="max-w-md space-y-4" noValidate>
      <div>
        <h2 className="text-lg font-semibold text-gray-900">{t("account.dataPassword")}</h2>
        <p className="text-sm text-gray-500">{t("account.dataPasswordHelp")}</p>
      </div>
      {configured !== null && (
        <StatusBadge tone={configured ? "green" : "red"}>{configured ? t("account.dataPasswordSet") : t("account.dataPasswordNotSet")}</StatusBadge>
      )}
      <FormInput label={t("account.accountPassword")} type="password" autoComplete="current-password" value={account} onChange={(e) => setAccount(e.target.value)} error={errors.account} disabled={busy} />
      <FormInput label={t("account.newDataPassword")} type="password" autoComplete="new-password" value={next} onChange={(e) => setNext(e.target.value)} error={errors.next} disabled={busy} />
      <FormInput label={t("account.confirmPassword")} type="password" autoComplete="new-password" value={confirm} onChange={(e) => setConfirm(e.target.value)} error={errors.confirm} disabled={busy} />
      <button type="submit" disabled={busy} className="rounded-lg bg-orange-500 px-4 py-2 text-sm font-medium text-white hover:bg-orange-600 disabled:opacity-60">
        {busy ? t("common.loading") : t("account.saveDataPassword")}
      </button>
    </form>
  );
}
