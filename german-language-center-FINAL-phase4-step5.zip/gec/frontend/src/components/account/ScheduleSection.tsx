import { useCallback, useEffect, useMemo, useState } from "react";
import { CalendarClock, Pencil, Plus, Trash2 } from "lucide-react";
import ConfirmDialog from "../ConfirmDialog";
import DateRangePicker from "../DateRangePicker";
import type { DateRange } from "../DateRangePicker";
import EmptyState from "../EmptyState";
import FormInput from "../FormInput";
import LoadingSpinner from "../LoadingSpinner";
import Modal from "../Modal";
import { usePreferences } from "../../contexts/PreferencesContext";
import { useToast } from "../../contexts/ToastContext";
import { parseError } from "../../services/api";
import { scheduleService } from "../../services/scheduleService";
import type { ScheduleEntry } from "../../types";
import { formatDate, todayInput, toDateInput } from "../../utils/format";

/** The logged-in user's own schedule. Other users (including admins) can never see or change these entries: the API filters by the JWT. */
export default function ScheduleSection() {
  const { t } = usePreferences();
  const toast = useToast();
  const [range, setRange] = useState<DateRange>({ from: todayInput() });
  const [items, setItems] = useState<ScheduleEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [form, setForm] = useState<{ entry: ScheduleEntry | null } | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<ScheduleEntry | null>(null);
  const [busy, setBusy] = useState(false);

  const load = useCallback(() => {
    setLoading(true);
    scheduleService.list({ fromDate: range.from, toDate: range.to })
      .then(setItems).catch((e) => toast.error(parseError(e).message)).finally(() => setLoading(false));
    // toast is stable; the date range is the only input
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [range.from, range.to]);
  useEffect(load, [load]);

  const groups = useMemo(() => {
    const map = new Map<string, ScheduleEntry[]>();
    items.forEach((e) => { const k = toDateInput(e.entryDate); map.set(k, [...(map.get(k) ?? []), e]); });
    return [...map.entries()];
  }, [items]);

  const remove = async () => {
    if (!deleteTarget || busy) return;
    setBusy(true);
    try { await scheduleService.remove(deleteTarget.entryId); toast.success(t("sched.deleted")); setDeleteTarget(null); load(); }
    catch (e) { toast.error(parseError(e).message); setDeleteTarget(null); load(); }
    finally { setBusy(false); }
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h2 className="text-lg font-semibold text-gray-900">{t("sched.title")}</h2>
          <p className="text-sm text-gray-500">{t("sched.help")}</p>
        </div>
        <button onClick={() => setForm({ entry: null })} className="inline-flex items-center gap-2 rounded-lg bg-orange-500 px-3 py-2 text-sm font-medium text-white hover:bg-orange-600"><Plus className="h-4 w-4" /> {t("sched.new")}</button>
      </div>
      <div className="flex flex-wrap items-center gap-2">
        <DateRangePicker value={range} onChange={setRange} />
        <span className="text-sm text-gray-600">{range.from || range.to ? `${range.from ?? "…"} → ${range.to ?? "…"}` : t("rep.allDates")}</span>
        <button onClick={() => setRange({})} className="text-sm font-medium text-orange-700 hover:underline">{t("sched.showAll")}</button>
        <button onClick={() => setRange({ from: todayInput() })} className="text-sm font-medium text-orange-700 hover:underline">{t("sched.upcoming")}</button>
      </div>

      {loading ? <LoadingSpinner /> : groups.length === 0 ? (
        <EmptyState icon={CalendarClock} title={t("sched.empty")} text={t("sched.emptyText")} />
      ) : (
        <div className="space-y-4">
          {groups.map(([day, entries]) => (
            <section key={day} className="rounded-xl border border-gray-200">
              <h3 className="border-b border-gray-100 bg-gray-50 px-4 py-2 text-sm font-semibold text-gray-800">{formatDate(day)}</h3>
              <ul className="divide-y divide-gray-100">
                {entries.map((e) => (
                  <li key={e.entryId} className="flex items-start justify-between gap-3 px-4 py-3">
                    <div className="flex gap-3">
                      <span className="rounded-lg bg-orange-50 px-2 py-1 text-sm font-semibold text-orange-700" dir="ltr">{e.entryTime}</span>
                      <div><p className="font-medium text-gray-900">{e.title}</p>{e.description && <p className="text-sm text-gray-500">{e.description}</p>}</div>
                    </div>
                    <div className="flex shrink-0 gap-1">
                      <button onClick={() => setForm({ entry: e })} className="icon-btn" title={t("sched.edit")} aria-label={t("sched.edit")}><Pencil className="h-4 w-4" /></button>
                      <button onClick={() => setDeleteTarget(e)} className="icon-btn" title={t("sched.deleteTitle")} aria-label={t("sched.deleteTitle")}><Trash2 className="h-4 w-4" /></button>
                    </div>
                  </li>
                ))}
              </ul>
            </section>
          ))}
        </div>
      )}

      {form && <ScheduleForm entry={form.entry} onClose={() => setForm(null)} onSaved={load} />}
      <ConfirmDialog open={deleteTarget !== null} busy={busy} danger title={t("sched.deleteTitle")} confirmLabel={t("sched.deleteTitle")}
        message={deleteTarget ? `${deleteTarget.title} - ${formatDate(deleteTarget.entryDate)} ${deleteTarget.entryTime}. ${t("sched.deleteMsg")}` : ""}
        onConfirm={remove} onCancel={() => setDeleteTarget(null)} />
    </div>
  );
}

function ScheduleForm({ entry, onClose, onSaved }: { entry: ScheduleEntry | null; onClose: () => void; onSaved: () => void }) {
  const { t } = usePreferences();
  const toast = useToast();
  const [title, setTitle] = useState(entry?.title ?? "");
  const [date, setDate] = useState(entry ? toDateInput(entry.entryDate) : todayInput());
  const [time, setTime] = useState(entry?.entryTime ?? "09:00");
  const [description, setDescription] = useState(entry?.description ?? "");
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [busy, setBusy] = useState(false);

  const submit = async () => {
    if (busy) return;
    const errs: Record<string, string> = {};
    if (title.trim().length < 2) errs.title = t("sched.titleRequired");
    if (!date) errs.date = t("sched.dateRequired");
    if (!/^([01]\d|2[0-3]):[0-5]\d$/.test(time)) errs.time = t("sched.timeRequired");
    if (description.length > 500) errs.description = t("sched.descTooLong");
    setErrors(errs);
    if (Object.keys(errs).length) return;
    setBusy(true);
    const body = { title: title.trim(), entryDate: date, entryTime: time, description: description.trim() || undefined };
    try {
      if (entry) await scheduleService.update(entry.entryId, body); else await scheduleService.create(body);
      toast.success(t("sched.saved"));
      onSaved(); onClose();
    } catch (e) { setErrors({ form: parseError(e).message }); }
    finally { setBusy(false); }
  };

  return (
    <Modal open title={entry ? t("sched.edit") : t("sched.new")} onClose={onClose} wide>
      <div className="space-y-4">
        <FormInput label={t("sched.fieldTitle")} value={title} maxLength={150} onChange={(e) => setTitle(e.target.value)} error={errors.title} disabled={busy} autoFocus />
        <div className="grid gap-4 sm:grid-cols-2">
          <FormInput label={t("sched.date")} type="date" value={date} onChange={(e) => setDate(e.target.value)} error={errors.date} disabled={busy} />
          <FormInput label={t("sched.time")} type="time" value={time} onChange={(e) => setTime(e.target.value)} error={errors.time} disabled={busy} />
        </div>
        <div className="space-y-1">
          <label htmlFor="sched-desc" className="block text-sm font-medium text-gray-700">{t("sched.details")}</label>
          <textarea id="sched-desc" rows={3} maxLength={500} value={description} onChange={(e) => setDescription(e.target.value)} disabled={busy}
                    className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm outline-none focus:border-orange-500 focus:ring-2 focus:ring-orange-300" />
          {errors.description && <p className="text-xs text-red-600">{errors.description}</p>}
        </div>
        {errors.form && <p className="rounded-lg bg-red-50 px-3 py-2 text-sm text-red-700">{errors.form}</p>}
        <div className="flex justify-end gap-2">
          <button onClick={onClose} disabled={busy} className="rounded-lg border border-gray-300 px-4 py-2 text-sm hover:bg-gray-50">{t("dataGate.cancel")}</button>
          <button onClick={submit} disabled={busy} className="rounded-lg bg-orange-500 px-4 py-2 text-sm font-medium text-white hover:bg-orange-600 disabled:opacity-60">{busy ? t("common.loading") : t("account.save")}</button>
        </div>
      </div>
    </Modal>
  );
}
