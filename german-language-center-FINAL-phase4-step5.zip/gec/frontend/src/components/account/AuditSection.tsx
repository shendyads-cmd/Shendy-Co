import { useEffect, useState } from "react";
import { ScrollText } from "lucide-react";
import DateRangePicker from "../DateRangePicker";
import type { DateRange } from "../DateRangePicker";
import EmptyState from "../EmptyState";
import LoadingSpinner from "../LoadingSpinner";
import Pagination from "../Pagination";
import SearchBox from "../SearchBox";
import SelectInput from "../SelectInput";
import StatusBadge from "../StatusBadge";
import { usePreferences } from "../../contexts/PreferencesContext";
import { usePagedList } from "../../hooks/usePagedList";
import { auditService } from "../../services/auditService";
import { formatDate } from "../../utils/format";

interface Filters { fromDate?: string; toDate?: string; actionType?: string }

const TONE: Record<string, "green" | "orange" | "gray" | "red" | "yellow"> = {
  Auth: "gray", Create: "green", Update: "yellow", Delete: "red", Restore: "orange", Financial: "orange", Data: "red", Admin: "gray"
};

const timeOf = (iso: string) => iso.slice(11, 16);

/** Admin only (the API enforces it). Read-only: there is no button and no endpoint that edits or deletes an audit record. */
export default function AuditSection() {
  const { t } = usePreferences();
  const list = usePagedList<import("../../types").AuditRow, Filters>(auditService.list, {}, { sortBy: "date", sortDir: "desc" }, 20);
  const [types, setTypes] = useState<string[]>([]);
  const range: DateRange = { from: list.filters.fromDate, to: list.filters.toDate };

  useEffect(() => { auditService.types().then(setTypes).catch(() => setTypes([])); }, []);

  return (
    <div className="space-y-4">
      <div>
        <h2 className="text-lg font-semibold text-gray-900">{t("audit.title")}</h2>
        <p className="text-sm text-gray-500">{t("audit.help")}</p>
      </div>
      <div className="flex flex-wrap items-end gap-2">
        <SearchBox value={list.search} onChange={list.setSearch} onSearch={list.submitSearch} placeholder={t("audit.search")} />
        <DateRangePicker value={range} onChange={(r) => list.setFilters({ fromDate: r.from, toDate: r.to })} />
        <div className="w-44">
          <SelectInput label={t("audit.col.type")} value={list.filters.actionType ?? ""} onChange={(e) => list.setFilters({ actionType: e.target.value || undefined })}>
            <option value="">{t("audit.allTypes")}</option>
            {types.map((x) => <option key={x} value={x}>{t(`audit.type.${x}`)}</option>)}
          </SelectInput>
        </div>
      </div>
      {list.loading ? <LoadingSpinner /> : list.data.items.length === 0 ? (
        <EmptyState icon={ScrollText} title={t("audit.empty")} text={t("audit.emptyText")} />
      ) : (
        <div className="overflow-x-auto rounded-xl border border-gray-200">
          <table className="w-full text-start text-sm">
            <thead className="bg-gray-50 text-xs uppercase text-gray-500">
              <tr>
                <th className="px-3 py-3 text-start">{t("audit.col.when")}</th><th className="px-3 py-3 text-start">{t("audit.col.user")}</th>
                <th className="px-3 py-3 text-start">{t("audit.col.type")}</th><th className="px-3 py-3 text-start">{t("audit.col.action")}</th>
                <th className="px-3 py-3 text-start">{t("audit.col.reference")}</th><th className="px-3 py-3 text-start">{t("audit.col.details")}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {list.data.items.map((a) => (
                <tr key={a.auditId} className="align-top hover:bg-orange-50/40">
                  <td className="whitespace-nowrap px-3 py-3 text-gray-700">{formatDate(a.createdAt)} <span className="text-gray-500" dir="ltr">{timeOf(a.createdAt)}</span></td>
                  <td className="px-3 py-3 text-gray-900">{a.username || "-"}</td>
                  <td className="px-3 py-3"><StatusBadge tone={TONE[a.actionType] ?? "gray"}>{t(`audit.type.${a.actionType}`)}</StatusBadge></td>
                  <td className="px-3 py-3 text-gray-700" dir="ltr">{a.action}</td>
                  <td className="px-3 py-3 text-gray-700">{a.reference || "-"}</td>
                  <td className="max-w-xs break-words px-3 py-3 text-xs text-gray-500" dir="ltr">{a.details || "-"}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      <Pagination page={list.page} pageSize={list.pageSize} total={list.data.total} onPage={list.setPage} />
    </div>
  );
}
