import { useState } from "react";
import type { FormEvent } from "react";
import FormInput from "../FormInput";
import StatusBadge from "../StatusBadge";
import { useAuth } from "../../contexts/AuthContext";
import { usePreferences } from "../../contexts/PreferencesContext";
import { useToast } from "../../contexts/ToastContext";
import { parseError } from "../../services/api";
import { accountService } from "../../services/accountService";

/** Every user: the display name. Username and role are shown but only an Admin can change them (Users section). */
export default function ProfileSection() {
  const { user, updateUser } = useAuth();
  const { t } = usePreferences();
  const toast = useToast();
  const [name, setName] = useState(user?.fullName ?? "");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  if (!user) return null;

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (busy) return;
    const value = name.trim();
    if (value.length < 2 || value.length > 150) { setError(t("account.nameInvalid")); return; }
    setBusy(true); setError("");
    try {
      updateUser(await accountService.updateProfile(value));
      toast.success(t("account.nameSaved"));
    } catch (err) { setError(parseError(err).message); }
    finally { setBusy(false); }
  };

  return (
    <form onSubmit={submit} className="max-w-md space-y-4" noValidate>
      <div>
        <h2 className="text-lg font-semibold text-gray-900">{t("account.profile")}</h2>
        <p className="text-sm text-gray-500">{t("account.profileHelp")}</p>
      </div>
      <FormInput label={t("account.username")} value={user.username} readOnly disabled />
      <div className="space-y-1">
        <span className="block text-sm font-medium text-gray-700">{t("account.role")}</span>
        <StatusBadge tone="orange">{t(`role.${user.role}`)}</StatusBadge>
      </div>
      <FormInput label={t("account.displayName")} value={name} maxLength={150} onChange={(e) => { setName(e.target.value); setError(""); }} error={error} disabled={busy} />
      <button type="submit" disabled={busy} className="rounded-lg bg-orange-500 px-4 py-2 text-sm font-medium text-white hover:bg-orange-600 disabled:opacity-60">
        {busy ? t("common.loading") : t("account.save")}
      </button>
    </form>
  );
}
