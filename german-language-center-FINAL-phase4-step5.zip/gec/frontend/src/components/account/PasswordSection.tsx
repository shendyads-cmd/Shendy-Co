import { useState } from "react";
import type { FormEvent } from "react";
import FormInput from "../FormInput";
import { usePreferences } from "../../contexts/PreferencesContext";
import { useToast } from "../../contexts/ToastContext";
import { parseError } from "../../services/api";
import { accountService } from "../../services/accountService";

/** Admin only (the API enforces it): change the own login password. */
export default function PasswordSection() {
  const { t } = usePreferences();
  const toast = useToast();
  const [current, setCurrent] = useState("");
  const [next, setNext] = useState("");
  const [confirm, setConfirm] = useState("");
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [busy, setBusy] = useState(false);

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (busy) return;
    const errs: Record<string, string> = {};
    if (!current) errs.current = t("account.required");
    if (next.length < 8) errs.next = t("account.min8");
    if (confirm !== next) errs.confirm = t("account.mismatch");
    setErrors(errs);
    if (Object.keys(errs).length) return;
    setBusy(true);
    try {
      await accountService.changePassword(current, next);
      setCurrent(""); setNext(""); setConfirm("");
      toast.success(t("account.passwordChanged"));
    } catch (err) {
      const p = parseError(err);
      setErrors(p.code === "ACCOUNT_PASSWORD_INVALID" ? { current: p.message } : { next: p.message });
    } finally { setBusy(false); }
  };

  return (
    <form onSubmit={submit} className="max-w-md space-y-4" noValidate>
      <div>
        <h2 className="text-lg font-semibold text-gray-900">{t("account.password")}</h2>
        <p className="text-sm text-gray-500">{t("account.passwordHelp")}</p>
      </div>
      <FormInput label={t("account.currentPassword")} type="password" autoComplete="current-password" value={current} onChange={(e) => setCurrent(e.target.value)} error={errors.current} disabled={busy} />
      <FormInput label={t("account.newPassword")} type="password" autoComplete="new-password" value={next} onChange={(e) => setNext(e.target.value)} error={errors.next} disabled={busy} />
      <FormInput label={t("account.confirmPassword")} type="password" autoComplete="new-password" value={confirm} onChange={(e) => setConfirm(e.target.value)} error={errors.confirm} disabled={busy} />
      <button type="submit" disabled={busy} className="rounded-lg bg-orange-500 px-4 py-2 text-sm font-medium text-white hover:bg-orange-600 disabled:opacity-60">
        {busy ? t("common.loading") : t("account.changePassword")}
      </button>
    </form>
  );
}
