import { useEffect, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import { ChevronDown, LogOut, Menu, User, UserCog } from "lucide-react";
import LanguageSelector from "./LanguageSelector";
import NotificationBell from "./notifications/NotificationBell";
import ThemeToggle from "./ThemeToggle";
import { useAuth } from "../contexts/AuthContext";
import { usePreferences } from "../contexts/PreferencesContext";

/**
 * Top bar, right side, in this order:  [ flag CODE v ]  [ sun | moon ]  [ bell ]  [ User Name v ]
 * There is no Settings button and no Data button here (Data is in the sidebar). The user menu has exactly two entries.
 */
export default function Topbar({ onMenu }: { onMenu: () => void }) {
  const { user, logout } = useAuth();
  const { t } = usePreferences();
  const navigate = useNavigate();
  const [userMenu, setUserMenu] = useState(false);
  const userRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const close = (e: MouseEvent) => {
      if (!userRef.current?.contains(e.target as Node)) setUserMenu(false);
    };
    document.addEventListener("mousedown", close);
    return () => document.removeEventListener("mousedown", close);
  }, []);

  if (!user) return null;
  const display = user.fullName || user.username;

  return (
    <header className="flex h-16 items-center justify-between gap-2 border-b border-gray-200 bg-white px-3 md:px-6">
      <button onClick={onMenu} className="icon-btn lg:hidden" aria-label={t("ui.open_menu")}><Menu className="h-5 w-5" /></button>
      <div className="hidden lg:block" />

      <div className="flex items-center gap-2">
        <LanguageSelector />
        <ThemeToggle />
        <NotificationBell />

        <div ref={userRef} className="relative">
          <button onClick={() => setUserMenu((v) => !v)} aria-haspopup="menu" aria-expanded={userMenu}
                  className="flex items-center gap-2 rounded-lg border border-gray-200 bg-white px-3 py-1.5 text-sm font-medium text-gray-700 hover:bg-orange-50 hover:text-orange-700">
            <User className="h-4 w-4 text-orange-500" />
            <span className="hidden max-w-[10rem] truncate sm:inline">{display}</span>
            <ChevronDown className="h-3.5 w-3.5" />
          </button>
          {userMenu && (
            <div role="menu" className="absolute end-0 z-30 mt-2 w-52 rounded-xl border border-gray-200 bg-white p-1 shadow-lg">
              <button role="menuitem" onClick={() => { setUserMenu(false); navigate("/account"); }}
                      className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-sm text-gray-800 hover:bg-orange-50">
                <UserCog className="h-4 w-4 text-orange-500" /> {t("top.account")}
              </button>
              <button role="menuitem" onClick={logout}
                      className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-sm text-gray-800 hover:bg-orange-50">
                <LogOut className="h-4 w-4 text-orange-500" /> {t("common.logout")}
              </button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}
