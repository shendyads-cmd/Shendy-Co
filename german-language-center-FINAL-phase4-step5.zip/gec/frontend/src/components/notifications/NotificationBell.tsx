import { useCallback, useEffect, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Bell, CheckCheck } from "lucide-react";
import Modal from "../Modal";
import { usePreferences } from "../../contexts/PreferencesContext";
import { notificationService } from "../../services/notificationService";
import type { AppNotification } from "../../types";

const POLL_MS = 30_000;
const LOCALES = { en: "en-US", ar: "ar-EG", de: "de-DE" } as const;

/** "99+" above 99. The badge is not drawn at all for 0. */
export const badgeText = (count: number) => (count > 99 ? "99+" : String(count));

/**
 * The bell: a small RED CIRCLE with a WHITE number sits on the upper-right corner of the bell icon (never beside or under it).
 * The number is the real unread count of the CURRENT user, taken from the server. Clicking the bell opens the panel,
 * clicking a notification marks it read (for this user only) and opens its details.
 */
export default function NotificationBell() {
  const { t, language } = usePreferences();
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);
  const [items, setItems] = useState<AppNotification[]>([]);
  const [unread, setUnread] = useState(0);
  const [loaded, setLoaded] = useState(false);
  const [failed, setFailed] = useState(false);
  const [detail, setDetail] = useState<AppNotification | null>(null);
  const [marking, setMarking] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  const load = useCallback(async () => {
    try {
      const data = await notificationService.list(50);
      setItems(data.items);
      setUnread(data.unreadCount);
      setFailed(false);
    } catch { setFailed(true); }
    finally { setLoaded(true); }
  }, []);

  // first load + refresh every 30 seconds while the tab is visible + when the tab becomes visible again
  useEffect(() => {
    void load();
    const timer = window.setInterval(() => { if (!document.hidden) void load(); }, POLL_MS);
    const onVisible = () => { if (!document.hidden) void load(); };
    document.addEventListener("visibilitychange", onVisible);
    return () => { window.clearInterval(timer); document.removeEventListener("visibilitychange", onVisible); };
  }, [load]);

  useEffect(() => {
    const close = (e: MouseEvent) => { if (!ref.current?.contains(e.target as Node)) setOpen(false); };
    document.addEventListener("mousedown", close);
    return () => document.removeEventListener("mousedown", close);
  }, []);

  const toggle = () => { setOpen((v) => !v); if (!open) void load(); };

  // ---- text in the user's language (falls back to the English text stored with the notification)
  const fill = (template: string, values: Record<string, unknown>) =>
    template.replace(/\{(\w+)\}/g, (_, k: string) => (values[k] === undefined || values[k] === null ? "" : String(values[k])));
  const values = (n: AppNotification): Record<string, unknown> => {
    try { return n.paramsJson ? JSON.parse(n.paramsJson) : {}; } catch { return {}; }
  };
  const titleOf = (n: AppNotification) => fill(t(`notif.${n.type}.title`, n.title), values(n));
  const messageOf = (n: AppNotification) => fill(t(`notif.${n.type}.message`, n.message), values(n));
  const sourceOf = (n: AppNotification) => t(`notif.source.${n.source}`, n.source);
  const dateOf = (n: AppNotification) => new Date(n.createdAt).toLocaleDateString(LOCALES[language], { year: "numeric", month: "short", day: "numeric" });
  const timeOf = (n: AppNotification) => new Date(n.createdAt).toLocaleTimeString(LOCALES[language], { hour: "2-digit", minute: "2-digit" });

  const openItem = async (n: AppNotification) => {
    setDetail(n);
    setOpen(false);
    if (n.isRead) return;
    // show it as read at once; the server answer (the real count) replaces the guess
    setItems((list) => list.map((x) => (x.notificationId === n.notificationId ? { ...x, isRead: true } : x)));
    setUnread((c) => Math.max(0, c - 1));
    try { setUnread((await notificationService.markRead(n.notificationId)).unreadCount); }
    catch { void load(); }
  };

  const markAll = async () => {
    if (marking || unread === 0) return;
    setMarking(true);
    setItems((list) => list.map((x) => ({ ...x, isRead: true })));
    setUnread(0);
    try { setUnread((await notificationService.markAllRead()).unreadCount); }
    catch { void load(); }
    finally { setMarking(false); }
  };

  const viewDetails = (n: AppNotification) => {
    setDetail(null);
    if (n.linkPath) navigate(n.linkPath);
  };

  return (
    <div ref={ref} className="relative">
      <div className="relative inline-flex">
        <button onClick={toggle} aria-expanded={open} aria-haspopup="dialog" className="icon-btn"
                aria-label={unread > 0 ? `${t("notif.title")} (${unread})` : t("notif.title")} title={t("notif.title")}>
          <Bell className="h-4 w-4" />
        </button>
        {unread > 0 && (
          <span data-testid="notification-badge" aria-hidden="true"
                className="pointer-events-none absolute -end-2 -top-2 flex h-5 min-w-[1.25rem] items-center justify-center rounded-full bg-red-600 px-1 text-[11px] font-bold leading-none text-white ring-2 ring-white">
            {badgeText(unread)}
          </span>
        )}
      </div>

      {open && (
        <div role="dialog" aria-label={t("notif.title")}
             className="absolute end-0 z-30 mt-2 w-[22rem] max-w-[calc(100vw-1.5rem)] rounded-xl border border-gray-200 bg-white shadow-lg">
          <div className="flex items-center justify-between gap-2 border-b border-gray-100 px-4 py-3">
            <h3 className="text-sm font-semibold text-gray-900">{t("notif.title")}</h3>
            <button onClick={markAll} disabled={unread === 0 || marking}
                    className="flex items-center gap-1 rounded-lg px-2 py-1 text-xs font-medium text-orange-700 hover:bg-orange-50 disabled:cursor-not-allowed disabled:opacity-40">
              <CheckCheck className="h-3.5 w-3.5" /> {t("notif.markAll")}
            </button>
          </div>
          <div className="max-h-96 overflow-y-auto">
            {!loaded ? <p className="px-4 py-6 text-center text-sm text-gray-500">{t("common.loading")}</p>
              : failed && items.length === 0 ? <p className="px-4 py-6 text-center text-sm text-gray-500">{t("notif.loadError")}</p>
              : items.length === 0 ? <p className="px-4 py-6 text-center text-sm text-gray-500">{t("notif.empty")}</p>
              : (
                <ul className="divide-y divide-gray-100">
                  {items.map((n) => (
                    <li key={n.notificationId}>
                      <button onClick={() => void openItem(n)} data-read={n.isRead}
                              className={`flex w-full items-start gap-3 px-4 py-3 text-start hover:bg-gray-50 ${n.isRead ? "" : "bg-orange-50"}`}>
                        <span className="text-lg leading-none" aria-label={n.isRead ? t("notif.read") : t("notif.unread")}>{n.isRead ? "📭" : "📬"}</span>
                        <span className="min-w-0 flex-1">
                          <span className={`block truncate text-sm ${n.isRead ? "font-normal text-gray-700" : "font-bold text-gray-900"}`}>{titleOf(n)}</span>
                          <span className="block text-xs text-gray-500">{sourceOf(n)}</span>
                          <span className={`mt-0.5 block text-xs ${n.isRead ? "text-gray-500" : "text-gray-700"}`}>{messageOf(n)}</span>
                          <span className="mt-1 block text-[11px] text-gray-400">{dateOf(n)} · {timeOf(n)}</span>
                        </span>
                      </button>
                    </li>
                  ))}
                </ul>
              )}
          </div>
        </div>
      )}

      <Modal open={detail !== null} title={detail ? titleOf(detail) : ""} onClose={() => setDetail(null)}>
        {detail && (
          <div className="space-y-3 text-sm">
            <dl className="grid grid-cols-[auto,1fr] gap-x-4 gap-y-1.5">
              <dt className="text-gray-500">{t("notif.source")}</dt><dd className="font-medium text-gray-900">{sourceOf(detail)}</dd>
              <dt className="text-gray-500">{t("notif.date")}</dt><dd className="text-gray-900">{dateOf(detail)}</dd>
              <dt className="text-gray-500">{t("notif.time")}</dt><dd className="text-gray-900">{timeOf(detail)}</dd>
            </dl>
            <div className="rounded-lg bg-gray-50 px-3 py-2">
              <p className="mb-1 text-xs font-medium uppercase text-gray-500">{t("notif.details")}</p>
              <p className="text-gray-800">{messageOf(detail)}</p>
            </div>
            <div className="flex justify-end gap-2 pt-1">
              <button onClick={() => setDetail(null)} className="rounded-lg border border-gray-300 px-4 py-2 text-sm hover:bg-gray-50">{t("notif.close")}</button>
              {detail.linkPath && (
                <button onClick={() => viewDetails(detail)} className="rounded-lg bg-orange-500 px-4 py-2 text-sm font-medium text-white hover:bg-orange-600">{t("notif.view")}</button>
              )}
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
}
