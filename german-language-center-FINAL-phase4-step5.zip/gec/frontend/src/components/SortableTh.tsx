import { ChevronDown, ChevronUp } from "lucide-react";

interface Props {
  label: string;
  col: string;
  sort: { sortBy: string; sortDir: "asc" | "desc" };
  onSort: (col: string) => void;
  className?: string;
}

export default function SortableTh({ label, col, sort, onSort, className = "" }: Props) {
  const active = sort.sortBy === col;
  return (
    <th className={`px-4 py-3 ${className}`}>
      <button onClick={() => onSort(col)} className="flex items-center gap-1 uppercase hover:text-orange-600">
        {label}
        {active && (sort.sortDir === "asc" ? <ChevronUp className="h-3 w-3" /> : <ChevronDown className="h-3 w-3" />)}
      </button>
    </th>
  );
}
