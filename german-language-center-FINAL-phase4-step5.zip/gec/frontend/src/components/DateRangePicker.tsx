import { useEffect, useMemo, useRef, useState } from "react";
import { Calendar, ChevronLeft, ChevronRight, X } from "lucide-react";
import { usePreferences } from "../contexts/PreferencesContext";
import { formatDate, parseIsoDate, toIsoDate } from "../utils/format";

export interface DateRange { from?: string; to?: string }

interface Props {
  value: DateRange;
  onChange: (range: DateRange) => void;
  /** Which edge of the button the popup lines up with. */
  align?: "left" | "right";
}

const LOCALES = { en: "en-US", ar: "ar-EG", de: "de-DE" } as const;
const startOfMonth = (d: Date) => new Date(d.getFullYear(), d.getMonth(), 1);

/**
 * Calendar icon -> popup with FROM / TO and a month calendar. Dates are picked with clicks only (no typing); APPLY sends the range.
 * Reusable for Students, Invoices, Expenses and later Payments, Transactions, Reports and Dashboard.
 */
export default function DateRangePicker({ value, onChange, align = "left" }: Props) {
  const { t, language } = usePreferences();
  const locale = LOCALES[language];
  const [open, setOpen] = useState(false);
  const [draft, setDraft] = useState<DateRange>(value);
  const [editing, setEditing] = useState<"from" | "to">("from");
  const [month, setMonth] = useState<Date>(() => startOfMonth(parseIsoDate(value.from) ?? new Date()));
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const close = (e: MouseEvent) => { if (!ref.current?.contains(e.target as Node)) setOpen(false); };
    document.addEventListener("mousedown", close);
    return () => document.removeEventListener("mousedown", close);
  }, []);

  const active = Boolean(value.from || value.to);

  const openPopup = () => {
    setDraft(value);
    setEditing("from");
    setMonth(startOfMonth(parseIsoDate(value.from) ?? new Date()));
    setOpen((v) => !v);
  };

  const days = useMemo(() => {
    const first = startOfMonth(month);
    const start = new Date(first.getFullYear(), first.getMonth(), 1 - first.getDay());
    return Array.from({ length: 42 }, (_, i) => new Date(start.getFullYear(), start.getMonth(), start.getDate() + i));
  }, [month]);

  const weekdays = useMemo(() => {
    const f = new Intl.DateTimeFormat(locale, { weekday: "narrow" });
    return Array.from({ length: 7 }, (_, i) => f.format(new Date(2024, 0, 7 + i))); // 2024-01-07 is a Sunday
  }, [locale]);

  const pick = (day: Date) => {
    const iso = toIsoDate(day);
    if (editing === "from") {
      setDraft((d) => ({ from: iso, to: d.to && d.to < iso ? undefined : d.to }));
      setEditing("to");
    } else if (draft.from && iso < draft.from) {
      setDraft({ from: iso, to: undefined });
    } else {
      setDraft((d) => ({ ...d, to: iso }));
    }
  };

  const apply = () => { onChange(draft); setOpen(false); };
  const clear = () => { setDraft({}); onChange({}); setOpen(false); };

  const todayIso = toIsoDate(new Date());
  const edge = (label: string, field: "from" | "to") => (
    <button type="button" onClick={() => setEditing(field)}
            className={`flex-1 rounded-lg border px-3 py-2 text-start ${editing === field ? "border-orange-500 bg-orange-50" : "border-gray-200"}`}>
      <span className="block text-[10px] font-semibold uppercase text-gray-500">{label}</span>
      <span className="block text-sm font-medium text-gray-900">{draft[field] ? formatDate(draft[field]) : "—"}</span>
    </button>
  );

  return (
    <div ref={ref} className="relative flex items-center gap-1">
      <button type="button" onClick={openPopup} aria-haspopup="dialog" aria-expanded={open} title={t("dates.filter")} aria-label={t("dates.filter")} className={`icon-btn ${active ? "is-active" : ""}`}>
        <Calendar className="h-4 w-4" />
        {active && <span className="hidden whitespace-nowrap text-xs sm:inline">{value.from ? formatDate(value.from) : "…"} – {value.to ? formatDate(value.to) : "…"}</span>}
      </button>
      {active && <button type="button" onClick={clear} title={t("dates.clear")} aria-label={t("dates.clear")} className="icon-btn"><X className="h-4 w-4" /></button>}

      {open && (
        <div role="dialog" aria-label={t("dates.filter")}
             className={`absolute top-full z-40 mt-2 w-[19rem] max-w-[calc(100vw-2rem)] rounded-2xl border border-gray-200 bg-white p-4 shadow-xl ${align === "right" ? "end-0" : "start-0"}`}>
          <div className="mb-3 flex gap-2">{edge(t("dates.from"), "from")}{edge(t("dates.to"), "to")}</div>

          <div className="mb-2 flex items-center justify-between">
            <button type="button" onClick={() => setMonth(new Date(month.getFullYear(), month.getMonth() - 1, 1))} className="icon-btn" aria-label={t("ui.previous_month")}><ChevronLeft className="h-4 w-4 rtl:rotate-180" /></button>
            <span className="text-sm font-semibold capitalize text-gray-900">{new Intl.DateTimeFormat(locale, { month: "long", year: "numeric" }).format(month)}</span>
            <button type="button" onClick={() => setMonth(new Date(month.getFullYear(), month.getMonth() + 1, 1))} className="icon-btn" aria-label={t("ui.next_month")}><ChevronRight className="h-4 w-4 rtl:rotate-180" /></button>
          </div>

          <div className="grid grid-cols-7 gap-y-1 text-center text-xs">
            {weekdays.map((w, i) => <span key={i} className="py-1 font-medium text-gray-500">{w}</span>)}
            {days.map((d) => {
              const iso = toIsoDate(d);
              const isEdge = iso === draft.from || iso === draft.to;
              const inRange = draft.from && draft.to && iso > draft.from && iso < draft.to;
              const otherMonth = d.getMonth() !== month.getMonth();
              return (
                <button key={iso} type="button" onClick={() => pick(d)}
                        className={`mx-auto flex h-8 w-8 items-center justify-center rounded-full text-sm transition
                          ${isEdge ? "bg-orange-500 font-semibold text-white" : inRange ? "bg-orange-100 text-gray-900" : otherMonth ? "text-gray-300 hover:bg-gray-100" : "text-gray-800 hover:bg-orange-50"}
                          ${iso === todayIso && !isEdge ? "ring-1 ring-orange-400" : ""}`}>
                  {d.getDate()}
                </button>
              );
            })}
          </div>

          <div className="mt-4 flex justify-between">
            <button type="button" onClick={clear} className="rounded-lg border border-gray-300 px-3 py-1.5 text-sm hover:bg-gray-50">{t("dates.clear")}</button>
            <button type="button" onClick={apply} disabled={!draft.from && !draft.to} className="rounded-lg bg-orange-500 px-4 py-1.5 text-sm font-medium text-white hover:bg-orange-600 disabled:opacity-50">{t("dates.apply")}</button>
          </div>
        </div>
      )}
    </div>
  );
}
