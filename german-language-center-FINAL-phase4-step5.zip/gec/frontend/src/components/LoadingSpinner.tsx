import { Loader2 } from "lucide-react";
import { usePreferences } from "../contexts/PreferencesContext";

export default function LoadingSpinner({ label }: { label?: string }) {
  const { t } = usePreferences();
  return (
    <div className="flex items-center justify-center gap-2 py-16 text-gray-500" role="status">
      <Loader2 className="h-5 w-5 animate-spin" /> {label ?? t("common.loading")}
    </div>
  );
}
