import type { LucideIcon } from "lucide-react";
import StatusBadge from "../StatusBadge";
import { usePreferences } from "../../contexts/PreferencesContext";
import type { CourseRow } from "../../types";
import { formatMoney } from "../../utils/format";

/** Colours used by the charts: the orange identity plus neutral dark and green/red for in/out. */
export const COLORS = { orange: "#f97316", orangeLight: "#fdba74", dark: "#374151", green: "#16a34a", red: "#dc2626" };

export function KpiCard({ icon: Icon, label, value, hint, tone = "default" }: { icon: LucideIcon; label: string; value: string; hint?: string; tone?: "default" | "positive" | "negative" }) {
  const color = tone === "positive" ? "text-green-700" : tone === "negative" ? "text-red-600" : "text-gray-900";
  return (
    <div className="rounded-2xl border border-gray-200 bg-white p-4 shadow-sm">
      <div className="flex items-center justify-between">
        <span className="text-sm text-gray-500">{label}</span>
        <span className="rounded-lg bg-orange-50 p-2"><Icon className="h-4 w-4 text-orange-500" /></span>
      </div>
      <p className={`mt-2 text-xl font-semibold ${color}`}>{value}</p>
      {hint && <p className="mt-0.5 text-xs text-gray-500">{hint}</p>}
    </div>
  );
}

export function ChartCard({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section className="rounded-2xl border border-gray-200 bg-white p-4 shadow-sm">
      <h2 className="mb-3 text-sm font-semibold text-gray-800">{title}</h2>
      {/* charts keep left-to-right axes (numbers and dates) in every language; the card around them follows the page direction */}
      <div dir="ltr">{children}</div>
    </section>
  );
}

export const money = (n: number) => formatMoney(n);

/** Course / invoice status text in the selected language (unknown values are shown as they are). */
export function useStatusText() {
  const { t } = usePreferences();
  return (status: string) => t(`st.${status}`, status);
}

export function courseTone(status: string): "green" | "orange" | "gray" | "red" | "yellow" {
  return status === "Open" ? "green" : status === "Full" ? "orange" : status === "Complete" ? "gray" : status === "Deleted" ? "red" : "yellow";
}

export function invoiceTone(status: string): "green" | "orange" | "gray" | "red" | "yellow" {
  return status === "Paid" ? "green" : status === "Partially Paid" ? "yellow" : status === "Unpaid" ? "red" : "gray";
}

/** Course performance table shared by the Dashboard (top courses) and the Reports (all courses). */
export function CourseTable({ rows, footer }: { rows: CourseRow[]; footer?: { revenue: number; paid: number; remaining: number } }) {
  const { t } = usePreferences();
  const st = useStatusText();
  return (
    <div className="overflow-x-auto">
      <table className="w-full text-start text-sm">
        <thead className="bg-gray-50 text-xs uppercase text-gray-500">
          <tr>
            <th className="px-3 py-3">#</th><th className="px-3 py-3">{t("rep.col.course")}</th><th className="px-3 py-3">{t("rep.col.code")}</th>
            <th className="px-3 py-3 text-end">{t("rep.col.capacity")}</th><th className="px-3 py-3 text-end">{t("rep.col.enrolled")}</th>
            <th className="px-3 py-3 text-end">{t("rep.col.occupancy")}</th><th className="px-3 py-3 text-end">{t("rep.col.revenue")}</th>
            <th className="px-3 py-3 text-end">{t("rep.col.paid")}</th><th className="px-3 py-3 text-end">{t("rep.col.remaining")}</th><th className="px-3 py-3">{t("common.status")}</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-gray-100">
          {rows.map((c) => (
            <tr key={c.courseId} className={c.rank > 0 && c.rank <= 3 ? "bg-orange-50/50" : ""}>
              <td className="px-3 py-3 text-gray-500">{c.rank > 0 ? c.rank : "-"}</td>
              <td className="px-3 py-3 font-medium text-gray-900">{c.name}</td>
              <td className="px-3 py-3 text-gray-700">{c.code}</td>
              <td className="px-3 py-3 text-end text-gray-700">{c.capacity}</td>
              <td className="px-3 py-3 text-end text-gray-700">{c.enrolled}</td>
              <td className="px-3 py-3 text-end text-gray-700">{c.occupancyPercent.toFixed(1)}%</td>
              <td className="px-3 py-3 text-end font-semibold text-gray-900">{money(c.revenue)}</td>
              <td className="px-3 py-3 text-end text-gray-700">{money(c.paid)}</td>
              <td className="px-3 py-3 text-end text-gray-700">{money(c.remaining)}</td>
              <td className="px-3 py-3"><StatusBadge tone={courseTone(c.status)}>{st(c.status)}</StatusBadge></td>
            </tr>
          ))}
        </tbody>
        {footer && (
          <tfoot className="bg-gray-50 font-semibold text-gray-900">
            <tr><td className="px-3 py-3" colSpan={6}>{t("rep.totals")}</td><td className="px-3 py-3 text-end">{money(footer.revenue)}</td><td className="px-3 py-3 text-end">{money(footer.paid)}</td><td className="px-3 py-3 text-end">{money(footer.remaining)}</td><td /></tr>
          </tfoot>
        )}
      </table>
    </div>
  );
}
