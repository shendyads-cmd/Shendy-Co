import { NavLink } from "react-router-dom";
import { GraduationCap } from "lucide-react";
import { useAuth } from "../contexts/AuthContext";
import { usePreferences } from "../contexts/PreferencesContext";
import { navItems } from "../utils/navigation";

export default function Sidebar({ open, onClose }: { open: boolean; onClose: () => void }) {
  const { user } = useAuth();
  const { t } = usePreferences();
  const items = navItems.filter((i) => user && i.roles.includes(user.role));
  const main = items.filter((i) => !i.bottom);
  const bottom = items.filter((i) => i.bottom);
  const link = ({ isActive }: { isActive: boolean }) =>
    `flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition ${isActive ? "bg-orange-500 text-white shadow-sm" : "text-gray-700 hover:bg-orange-50 hover:text-orange-700"}`;

  return (
    <>
      {open && <div className="fixed inset-0 z-30 bg-black/40 lg:hidden" onClick={onClose} />}
      <aside className={`fixed inset-y-0 start-0 z-40 flex w-64 flex-col border-e border-gray-200 bg-white transition-transform lg:static lg:translate-x-0 ${open ? "translate-x-0" : "-translate-x-full rtl:translate-x-full"}`}>
        <div className="flex h-16 items-center gap-2 border-b border-gray-200 px-5">
          <div className="rounded-lg bg-orange-500 p-1.5 text-white"><GraduationCap className="h-5 w-5" /></div>
          <div className="leading-tight">
            <p className="text-sm font-bold text-gray-900">{t("ui.german_language")}</p>
            <p className="text-xs text-gray-500">{t("ui.center_management")}</p>
          </div>
        </div>
        <nav className="flex-1 space-y-1 overflow-y-auto p-3">
          {main.map(({ path, label, icon: Icon }) => (
            <NavLink key={path} to={path} onClick={onClose} className={link}><Icon className="h-4 w-4" />{t(`nav.${path.slice(1)}`, label)}</NavLink>
          ))}
        </nav>
        {bottom.length > 0 && (
          <div className="space-y-1 border-t border-gray-200 p-3">
            {bottom.map(({ path, label, icon: Icon }) => (
              <NavLink key={path} to={path} onClick={onClose} className={link}><Icon className="h-4 w-4" />{t(`nav.${path.slice(1)}`, label)}</NavLink>
            ))}
          </div>
        )}
      </aside>
    </>
  );
}
