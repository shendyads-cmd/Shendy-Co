import type { ReactNode } from "react";
import { Navigate, useLocation } from "react-router-dom";
import { useAuth } from "../contexts/AuthContext";
import type { Role } from "../types";
import { homePath } from "../utils/navigation";
import LoadingSpinner from "./LoadingSpinner";
import { usePreferences } from "../contexts/PreferencesContext";

export default function ProtectedRoute({ roles, children }: { roles?: Role[]; children: ReactNode }) {
  const { t } = usePreferences();
  const { user, loading } = useAuth();
  const location = useLocation();

  if (loading) return <LoadingSpinner label={t("ui.checking_session")} />;
  if (!user) return <Navigate to="/login" replace state={{ from: location.pathname }} />;
  if (roles && !roles.includes(user.role)) return <Navigate to={homePath(user.role)} replace />;
  return <>{children}</>;
}
