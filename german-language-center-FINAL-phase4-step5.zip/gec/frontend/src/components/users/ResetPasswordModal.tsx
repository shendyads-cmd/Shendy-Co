import { tr } from "../../i18n/translateServer";
import { useEffect, useState } from "react";
import type { FormEvent } from "react";
import FormInput from "../FormInput";
import Modal from "../Modal";
import { useToast } from "../../contexts/ToastContext";
import { parseError } from "../../services/api";
import { userService } from "../../services/userService";
import type { UserDto } from "../../types";
import { usePreferences } from "../../contexts/PreferencesContext";

interface Props { user: UserDto | null; onClose: () => void }

export default function ResetPasswordModal({ user, onClose }: Props) {
  const { t } = usePreferences();
  const toast = useToast();
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => { setPassword(""); setConfirm(""); setError(""); }, [user]);

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (!user) return;
    if (password.length < 8) return setError(tr("ui.password_must_be_at_least"));
    if (password !== confirm) return setError(tr("ui.passwords_do_not_match"));

    setBusy(true);
    try {
      await userService.resetPassword(user.userId, password);
      toast.success(t("ui.password_updated"));
      onClose();
    } catch (err) {
      toast.error(parseError(err).message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <Modal open={user !== null} title={`${t("ui.reset_password")}${user ? ` - ${user.username}` : ""}`} onClose={onClose}>
      <form onSubmit={submit} noValidate className="space-y-4">
        <FormInput label={t("account.newPassword")} type="password" autoComplete="new-password" value={password} onChange={(e) => setPassword(e.target.value)} />
        <FormInput label={t("ui.confirm_password")} type="password" autoComplete="new-password" value={confirm} onChange={(e) => setConfirm(e.target.value)} error={error} />
        <div className="flex justify-end gap-2 pt-2">
          <button type="button" onClick={onClose} className="rounded-lg border border-gray-300 px-4 py-2 text-sm hover:bg-gray-50">{t("dataGate.cancel")}</button>
          <button type="submit" disabled={busy} className="rounded-lg bg-orange-500 px-4 py-2 text-sm font-medium text-white hover:bg-orange-600 disabled:opacity-60">
            {busy ? t("ui.saving") : t("ui.update_password")}
          </button>
        </div>
      </form>
    </Modal>
  );
}
