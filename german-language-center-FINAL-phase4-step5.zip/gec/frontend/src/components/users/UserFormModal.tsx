import { useEffect, useState } from "react";
import type { FormEvent } from "react";
import FormInput from "../FormInput";
import Modal from "../Modal";
import { useToast } from "../../contexts/ToastContext";
import { parseError } from "../../services/api";
import { userService } from "../../services/userService";
import type { Role, UserDto } from "../../types";
import { usePreferences } from "../../contexts/PreferencesContext";

interface Props { open: boolean; user: UserDto | null; onClose: () => void; onSaved: () => void }

export default function UserFormModal({ open, user, onClose, onSaved }: Props) {
  const { t } = usePreferences();
  const toast = useToast();
  const editing = user !== null;
  const [username, setUsername] = useState("");
  const [fullName, setFullName] = useState("");
  const [role, setRole] = useState<Role>("Employee");
  const [password, setPassword] = useState("");
  const [isActive, setIsActive] = useState(true);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (!open) return;
    setUsername(user?.username ?? "");
    setFullName(user?.fullName ?? "");
    setRole(user?.role ?? "Employee");
    setIsActive(user?.isActive ?? true);
    setPassword("");
    setErrors({});
  }, [open, user]);

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    const errs: Record<string, string> = {};
    if (!editing) {
      if (username.trim().length < 3) errs.username = t("ui.username_must_be_at_least");
      if (password.length < 8) errs.password = t("ui.password_must_be_at_least");
    }
    setErrors(errs);
    if (Object.keys(errs).length) return;

    setBusy(true);
    try {
      if (editing) {
        await userService.update(user.userId, { fullName: fullName.trim() || undefined, role, isActive });
        toast.success(t("ui.user_updated"));
      } else {
        await userService.create({ username: username.trim(), fullName: fullName.trim() || undefined, role, password });
        toast.success(t("ui.user_created"));
      }
      onSaved();
      onClose();
    } catch (err) {
      toast.error(parseError(err).message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <Modal open={open} title={editing ? t("ui.edit_user") : t("ui.add_user")} onClose={onClose}>
      <form onSubmit={submit} noValidate className="space-y-4">
        <FormInput label={t("account.username")} value={username} disabled={editing} onChange={(e) => setUsername(e.target.value)} error={errors.username} />
        <FormInput label={t("ui.full_name")} value={fullName} onChange={(e) => setFullName(e.target.value)} />
        <div className="space-y-1">
          <label htmlFor="role" className="block text-sm font-medium text-gray-700">{t("account.role")}</label>
          <select id="role" value={role} onChange={(e) => setRole(e.target.value as Role)}
                  className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm outline-none focus:border-orange-500 focus:ring-2 focus:ring-orange-300">
            <option value="Employee">{t("role.Employee")}</option>
            <option value="Admin">{t("role.Admin")}</option>
          </select>
        </div>
        {!editing && (
          <FormInput label={t("account.password")} type="password" autoComplete="new-password" value={password}
                     onChange={(e) => setPassword(e.target.value)} error={errors.password} />
        )}
        {editing && (
          <label className="flex items-center gap-2 text-sm text-gray-700">
            <input type="checkbox" checked={isActive} onChange={(e) => setIsActive(e.target.checked)} className="h-4 w-4 accent-orange-500" />
            {t("ui.account_is_active")}
          </label>
        )}
        <div className="flex justify-end gap-2 pt-2">
          <button type="button" onClick={onClose} className="rounded-lg border border-gray-300 px-4 py-2 text-sm hover:bg-gray-50">{t("dataGate.cancel")}</button>
          <button type="submit" disabled={busy} className="rounded-lg bg-orange-500 px-4 py-2 text-sm font-medium text-white hover:bg-orange-600 disabled:opacity-60">
            {busy ? t("ui.saving") : t("account.save")}
          </button>
        </div>
      </form>
    </Modal>
  );
}
