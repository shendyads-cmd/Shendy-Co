import { useEffect, useRef, useState } from "react";
import { Check, ChevronDown } from "lucide-react";
import Flag from "./Flags";
import { usePreferences } from "../contexts/PreferencesContext";
import type { Language } from "../i18n/translations";

/** Flag + short code only: Egypt (Arabic) EG, United States (English) US, Germany (German) DE. */
export const languageCodes: Record<Language, string> = { ar: "EG", en: "US", de: "DE" };
const OPTIONS: Language[] = ["ar", "en", "de"];

/** The choice is saved by PreferencesContext (browser storage), so it survives navigation, refresh, logout and login. */
export default function LanguageSelector() {
  const { language, setLanguage, t } = usePreferences();
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const close = (e: MouseEvent) => { if (!ref.current?.contains(e.target as Node)) setOpen(false); };
    document.addEventListener("mousedown", close);
    return () => document.removeEventListener("mousedown", close);
  }, []);

  return (
    <div ref={ref} className="relative">
      <button onClick={() => setOpen((v) => !v)} aria-haspopup="menu" aria-expanded={open} aria-label={t("top.language")} title={t("top.language")}
              className="flex items-center gap-2 rounded-lg border border-gray-200 bg-white px-3 py-1.5 text-sm font-medium text-gray-700 hover:bg-orange-50 hover:text-orange-700">
        <Flag language={language} /> <span>{languageCodes[language]}</span> <ChevronDown className="h-3.5 w-3.5" />
      </button>
      {open && (
        <div role="menu" className="absolute end-0 z-30 mt-2 w-32 rounded-xl border border-gray-200 bg-white p-1 shadow-lg">
          {OPTIONS.map((code) => (
            <button key={code} role="menuitem" onClick={() => { setLanguage(code); setOpen(false); }}
                    className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-sm font-medium text-gray-800 hover:bg-orange-50">
              <Flag language={code} /> <span className="flex-1 text-start">{languageCodes[code]}</span>
              {language === code && <Check className="h-4 w-4 text-orange-500" />}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
