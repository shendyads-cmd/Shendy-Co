import { useEffect, useMemo, useState } from "react";
import { Plus, Search, Trash2 } from "lucide-react";
import FormInput from "../FormInput";
import LoadingSpinner from "../LoadingSpinner";
import Modal from "../Modal";
import SelectInput from "../SelectInput";
import StudentCard, { emptyFields, validateStudent } from "./StudentCard";
import type { StudentErrors, StudentFields } from "./StudentCard";
import { useToast } from "../../contexts/ToastContext";
import { parseError } from "../../services/api";
import { courseService } from "../../services/courseService";
import { customerService } from "../../services/customerService";
import { invoiceService } from "../../services/invoiceService";
import type { Course, InvoiceDetails } from "../../types";
import { formatMoney } from "../../utils/format";
import { usePreferences } from "../../contexts/PreferencesContext";

interface Member { customerId: number; studentCode: string; fullName: string }
interface NewCard { key: number; fields: StudentFields; errors: StudentErrors }

const round2 = (n: number) => Math.round((n + Number.EPSILON) * 100) / 100;

interface Props { id: number; onClose: () => void; onSaved: () => void }

/** Edits the SAME invoice: students, course and discount. Totals are recalculated (and checked again by the API). */
export default function InvoiceEditModal({ id, onClose, onSaved }: Props) {
  const { t, tf } = usePreferences();
  const toast = useToast();
  const [data, setData] = useState<InvoiceDetails | null>(null);
  const [courses, setCourses] = useState<Course[]>([]);
  const [members, setMembers] = useState<Member[]>([]);
  const [added, setAdded] = useState<Member[]>([]);
  const [cards, setCards] = useState<NewCard[]>([]);
  const [nextKey, setNextKey] = useState(1);
  const [courseId, setCourseId] = useState("");
  const [discount, setDiscount] = useState("0");
  const [query, setQuery] = useState("");
  const [results, setResults] = useState<Member[]>([]);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    let cancelled = false;
    Promise.all([invoiceService.get(id), courseService.list({ page: 1, pageSize: 100, sortBy: "code", sortDir: "asc", status: "open" })])
      .then(([d, list]) => {
        if (cancelled) return;
        setData(d);
        setMembers(d.students.map((s) => ({ customerId: s.customerId, studentCode: s.studentCode, fullName: s.fullName })));
        setCourseId(String(d.items[0]?.courseId ?? ""));
        setDiscount(String(d.discountPercent));
        setCourses(list.items);
      })
      .catch((err) => { toast.error(parseError(err).message); onClose(); });
    return () => { cancelled = true; };
    // toast and onClose are stable for this modal.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  // search among existing students to add them to this invoice
  useEffect(() => {
    if (query.trim().length < 2) { setResults([]); return; }
    let cancelled = false;
    const timer = setTimeout(() => {
      customerService.list({ search: query.trim(), page: 1, pageSize: 6, sortBy: "name", sortDir: "asc", isActive: true })
        .then((r) => { if (!cancelled) setResults(r.items.map((c) => ({ customerId: c.customerId, studentCode: c.studentCode, fullName: c.fullName }))); })
        .catch(() => { if (!cancelled) setResults([]); });
    }, 250);
    return () => { cancelled = true; clearTimeout(timer); };
  }, [query]);

  const current = data?.items[0];
  const selected = courses.find((c) => String(c.courseId) === courseId);
  const unitPrice = current && courseId === String(current.courseId) ? current.unitPrice : selected?.price ?? 0;
  const count = members.length + added.length + cards.length;

  const money = useMemo(() => {
    const pct = Math.min(100, Math.max(0, Number(discount) || 0));
    const subtotal = round2(unitPrice * count);
    const discountAmount = round2((subtotal * pct) / 100);
    return { subtotal, discountAmount, total: round2(subtotal - discountAmount) };
  }, [unitPrice, count, discount]);

  const takenIds = new Set([...members, ...added].map((m) => m.customerId));

  const save = async () => {
    if (!data) return;
    const pct = Number(discount);
    if (discount.trim() === "" || Number.isNaN(pct) || pct < 0 || pct > 100) { toast.error(t("ui.invalid_discount_percentage")); return; }
    if (count < 1) { toast.error(t("ui.add_at_least_one_student")); return; }
    const checked = cards.map((c) => ({ ...c, errors: validateStudent(c.fields) }));
    setCards(checked);
    if (checked.some((c) => Object.keys(c.errors).length > 0)) return;
    if (data.amountPaid > money.total) { toast.error(tf("ui.payments_exceed_total", { amount: formatMoney(data.amountPaid) })); return; }

    setBusy(true);
    try {
      await invoiceService.update(id, {
        courseId: Number(courseId),
        discountPercent: pct,
        students: [
          ...members.map((m) => ({ customerId: m.customerId })),
          ...added.map((m) => ({ customerId: m.customerId })),
          ...checked.map((c) => ({ fullName: c.fields.fullName.trim(), email: c.fields.email.trim() || undefined, phone: c.fields.phone.trim(), area: c.fields.area.trim() || undefined }))
        ]
      });
      toast.success(t("ui.invoice_updated_successfully"));
      onSaved();
      onClose();
    } catch (err) {
      toast.error(parseError(err).message);
    } finally {
      setBusy(false);
    }
  };

  const readOnly = "rounded-lg border border-gray-200 bg-gray-50 px-3 py-2 text-sm font-medium text-gray-900";
  const field = (label: string, value: string) => <div className="space-y-1"><span className="block text-sm font-medium text-gray-700">{label}</span><div className={readOnly}>{value}</div></div>;
  const row = (m: Member, onRemove: () => void) => (
    <li key={m.customerId} className="flex items-center justify-between gap-3 px-3 py-2 text-sm">
      <span><span className="me-2 font-mono text-xs font-semibold text-gray-500">{m.studentCode}</span><span className="text-gray-900">{m.fullName}</span></span>
      <button onClick={onRemove} className="icon-btn icon-btn-danger" aria-label={`${t("ui.remove")} ${m.fullName}`} title={t("ui.remove")}><Trash2 className="h-4 w-4" /></button>
    </li>
  );

  return (
    <Modal open title={data ? `${t("ui.edit_invoice")} #${data.invoiceNumber}` : t("ui.edit_invoice")} onClose={onClose} xl>
      {!data ? <LoadingSpinner /> : !data.canEdit ? (
        <div className="space-y-4">
          <p className="text-sm text-gray-600">{t("ui.this_invoice_cannot_be_edited")}</p>
          <div className="flex justify-end"><button onClick={onClose} className="rounded-lg bg-orange-500 px-4 py-2 text-sm font-medium text-white hover:bg-orange-600">{t("notif.close")}</button></div>
        </div>
      ) : (
        <div className="space-y-4">
          <SelectInput label={t("rep.col.course")} value={courseId} onChange={(e) => setCourseId(e.target.value)}>
            {current && !courses.some((c) => c.courseId === current.courseId) && <option value={current.courseId}>{current.courseCode} - {current.courseName} ({t("ui.current")})</option>}
            {courses.map((c) => <option key={c.courseId} value={c.courseId}>{c.courseCode} - {c.courseName} ({c.enrolledCount}/{c.maxCapacity})</option>)}
          </SelectInput>

          <div className="rounded-xl border border-gray-200">
            <div className="border-b border-gray-100 px-4 py-2 text-sm font-semibold text-gray-900">{t("ui.students")}{count})</div>
            <ul className="divide-y divide-gray-100">
              {members.map((m) => row(m, () => setMembers((l) => l.filter((x) => x.customerId !== m.customerId))))}
              {added.map((m) => row(m, () => setAdded((l) => l.filter((x) => x.customerId !== m.customerId))))}
            </ul>
            <div className="space-y-3 border-t border-gray-100 p-4">
              {cards.map((c, i) => (
                <StudentCard key={c.key} title={`${t("ui.new_student")} ${i + 1}`} value={c.fields} errors={c.errors}
                             onChange={(f) => setCards((l) => l.map((x) => (x.key === c.key ? { ...x, fields: f, errors: {} } : x)))}
                             onRemove={() => setCards((l) => l.filter((x) => x.key !== c.key))} />
              ))}
              <div className="flex flex-wrap items-start gap-3">
                <button type="button" onClick={() => { setCards((l) => [...l, { key: nextKey, fields: emptyFields(), errors: {} }]); setNextKey((k) => k + 1); }}
                        className="flex items-center gap-2 rounded-lg border border-orange-300 px-3 py-2 text-sm font-medium text-orange-600 hover:bg-orange-50"><Plus className="h-4 w-4" /> {t("ui.add_student")}</button>
                <div className="relative min-w-[14rem] flex-1">
                  <Search className="pointer-events-none absolute start-3 top-2.5 h-4 w-4 text-gray-400" />
                  <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder={t("ui.add_an_existing_student_name")} aria-label={t("ui.search_existing_students")}
                         className="w-full rounded-lg border border-gray-300 py-2 ps-9 pe-3 text-sm outline-none focus:border-orange-500 focus:ring-2 focus:ring-orange-300" />
                  {results.filter((r) => !takenIds.has(r.customerId)).length > 0 && (
                    <ul className="absolute z-10 mt-1 w-full rounded-lg border border-gray-200 bg-white shadow-lg">
                      {results.filter((r) => !takenIds.has(r.customerId)).map((r) => (
                        <li key={r.customerId}><button type="button" onClick={() => { setAdded((l) => [...l, r]); setQuery(""); setResults([]); }} className="flex w-full justify-between px-3 py-2 text-start text-sm hover:bg-orange-50"><span>{r.fullName}</span><span className="font-mono text-xs text-gray-500">{r.studentCode}</span></button></li>
                      ))}
                    </ul>
                  )}
                </div>
              </div>
            </div>
          </div>

          <div className="grid gap-4 sm:grid-cols-4">
            <FormInput label={t("ui.discount")} type="number" min="0" max="100" step="0.01" value={discount} onChange={(e) => setDiscount(e.target.value)} />
            {field(t("rep.col.subtotal"), formatMoney(money.subtotal))}
            {field(t("ui.discount_amount"), formatMoney(money.discountAmount))}
            {field(t("ui.grand_total"), formatMoney(money.total))}
          </div>
          <p className="text-xs text-gray-500">{t("ui.already_paid")} {formatMoney(data.amountPaid)}{t("ui.payments_are_not_changed_by")}</p>

          <div className="flex justify-end gap-2">
            <button onClick={onClose} disabled={busy} className="rounded-lg border border-gray-300 px-4 py-2 text-sm hover:bg-gray-50">{t("dataGate.cancel")}</button>
            <button onClick={save} disabled={busy} className="rounded-lg bg-orange-500 px-4 py-2 text-sm font-medium text-white hover:bg-orange-600 disabled:opacity-60">{busy ? t("ui.saving") : t("ui.save_changes")}</button>
          </div>
        </div>
      )}
    </Modal>
  );
}
