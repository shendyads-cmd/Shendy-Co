import { useEffect, useState } from "react";
import { Pencil, Printer, Wallet } from "lucide-react";
import AddPaymentModal from "../finance/AddPaymentModal";
import InvoiceDocument, { docFromDetails } from "./InvoiceDocument";
import LoadingSpinner from "../LoadingSpinner";
import Modal from "../Modal";
import { usePreferences } from "../../contexts/PreferencesContext";
import { useToast } from "../../contexts/ToastContext";
import { parseError } from "../../services/api";
import { invoiceService } from "../../services/invoiceService";
import type { InvoiceDetails } from "../../types";
import { formatDate, formatMoney, formatTime } from "../../utils/format";

interface Props { id: number; onClose: () => void; onEdit: (id: number) => void; /** Called after a payment was recorded so the list behind the dialog refreshes. */ onChanged?: () => void }

/** Full invoice details with a small pencil next to the invoice number (opens the edit form) and a Print button. */
export default function InvoiceViewModal({ id, onClose, onEdit, onChanged }: Props) {
  const { t } = usePreferences();
  const toast = useToast();
  const [data, setData] = useState<InvoiceDetails | null>(null);
  const [paying, setPaying] = useState(false);
  const [reloadTick, setReloadTick] = useState(0);

  useEffect(() => {
    let cancelled = false;
    invoiceService.get(id).then((d) => { if (!cancelled) setData(d); }).catch((err) => { toast.error(parseError(err).message); onClose(); });
    return () => { cancelled = true; };
    // toast and onClose are stable for this modal.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id, reloadTick]);

  return (
    <Modal open title={t("rep.col.invoice")} onClose={onClose} xl>
      {!data ? <LoadingSpinner /> : (
        <div className="space-y-4">
          <div className="no-print flex items-center gap-2">
            <h3 className="font-mono text-lg font-semibold text-gray-900">{t("ui.invoice")}{data.invoiceNumber}</h3>
            {data.canEdit && <button onClick={() => onEdit(data.invoiceId)} className="icon-btn" title={t("invoices.edit")} aria-label={t("invoices.edit")}><Pencil className="h-4 w-4" /></button>}
          </div>
          <InvoiceDocument data={docFromDetails(data)} />
          {data.payments.length > 0 && (
            <div className="no-print rounded-xl border border-gray-200 p-4">
              <h4 className="mb-2 text-sm font-semibold text-gray-900">{t("kpi.payments")}</h4>
              <ul className="divide-y divide-gray-100 text-sm">
                {data.payments.map((p) => (
                  <li key={p.paymentId} className="flex justify-between gap-4 py-1.5">
                    <span className="text-gray-600">{formatDate(p.paymentDate)} {formatTime(p.paymentDate)} - {t(`method.${p.paymentMethod}`, p.paymentMethod)}{p.paymentMethodOther ? ` (${p.paymentMethodOther})` : ""}{p.hasProof ? t("ui.proof_attached") : ""}</span>
                    <span className="font-medium text-gray-900">{formatMoney(p.amount)}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}
          <div className="no-print flex justify-end gap-2">
            {data.remaining > 0 && data.paymentStatus !== "Cancelled" && (
              <button onClick={() => setPaying(true)} className="flex items-center gap-2 rounded-lg border border-orange-300 px-4 py-2 text-sm font-medium text-orange-700 hover:bg-orange-50"><Wallet className="h-4 w-4" /> {t("pay.title")}</button>
            )}
            <button onClick={() => window.print()} className="flex items-center gap-2 rounded-lg border border-gray-300 px-4 py-2 text-sm hover:bg-gray-50"><Printer className="h-4 w-4" /> {t("invoices.print")}</button>
            <button onClick={onClose} className="rounded-lg bg-orange-500 px-4 py-2 text-sm font-medium text-white hover:bg-orange-600">{t("flow.close")}</button>
          </div>
        </div>
      )}
      {paying && data && (
        <AddPaymentModal invoice={{ invoiceId: data.invoiceId, invoiceNumber: data.invoiceNumber, grandTotal: data.grandTotal, amountPaid: data.amountPaid }}
                         onClose={() => setPaying(false)} onSaved={() => { setReloadTick((n) => n + 1); onChanged?.(); }} />
      )}
    </Modal>
  );
}
