import StatusBadge from "../StatusBadge";
import type { InvoiceDetails, InvoicePreview } from "../../types";
import { formatDate, formatMoney, formatTime } from "../../utils/format";
import { usePreferences } from "../../contexts/PreferencesContext";

export interface DocData {
  invoiceNumber?: string | null;
  issueDate: string;
  type: "Student" | "Offer";
  studentNames: string[];
  courseCode: string;
  courseName: string;
  quantity: number;
  unitPrice: number;
  subtotal: number;
  discountPercent: number;
  discountAmount: number;
  grandTotal: number;
  amountPaid: number;
  remaining: number;
  paymentStatus: string;
  paymentMethod?: string | null;
  /** A preview that has not been saved yet. */
  draft?: boolean;
}

export const docFromDetails = (d: InvoiceDetails): DocData => {
  const item = d.items[0];
  const first = d.payments[0];
  return {
    invoiceNumber: d.invoiceNumber, issueDate: d.issueDate, type: d.type, studentNames: d.students.map((s) => s.fullName),
    courseCode: item?.courseCode ?? "-", courseName: item?.courseName ?? "-", quantity: item?.quantity ?? d.students.length, unitPrice: item?.unitPrice ?? 0,
    subtotal: d.subtotal, discountPercent: d.discountPercent, discountAmount: d.discountAmount, grandTotal: d.grandTotal,
    amountPaid: d.amountPaid, remaining: d.remaining, paymentStatus: d.paymentStatus,
    paymentMethod: first ? (first.paymentMethod === "Other" && first.paymentMethodOther ? `Other - ${first.paymentMethodOther}` : first.paymentMethod) : null
  };
};

export const docFromPreview = (p: InvoicePreview): DocData => ({
  invoiceNumber: null, issueDate: p.previewDate, type: p.type, studentNames: p.studentNames, courseCode: p.courseCode, courseName: p.courseName,
  quantity: p.quantity, unitPrice: p.unitPrice, subtotal: p.subtotal, discountPercent: p.discountPercent, discountAmount: p.discountAmount,
  grandTotal: p.grandTotal, amountPaid: p.amountPaid, remaining: p.remaining, paymentStatus: p.paymentStatus,
  paymentMethod: p.paymentMethod ? (p.paymentMethod === "Other" && p.paymentMethodOther ? `Other - ${p.paymentMethodOther}` : p.paymentMethod) : null, draft: true
});

const tone = (s: string) => (s === "Paid" ? "green" : s === "Partially Paid" ? "orange" : "red");

/** The printable invoice. Only one element with id="print-area" may be on the page at a time (see the print rules in index.css). */
export default function InvoiceDocument({ data, printId = true }: { data: DocData; printId?: boolean }) {
  const { t, tf } = usePreferences();
  const row = (label: string, value: string, strong = false) => (
    <div className={`flex justify-between gap-6 py-1.5 text-sm ${strong ? "border-t border-gray-300 pt-2 text-base font-semibold text-gray-900" : "text-gray-700"}`}><span>{label}</span><span>{value}</span></div>
  );
  return (
    <div id={printId ? "print-area" : undefined} className="rounded-xl border border-gray-200 bg-white p-6 text-gray-900">
      <div className="flex flex-wrap items-start justify-between gap-4 border-b border-gray-200 pb-4">
        <div>
          <p className="text-xl font-bold text-orange-600">{t("ui.german_language_center")}</p>
          <p className="text-xs uppercase tracking-wide text-gray-500">{t("rep.col.invoice")}</p>
        </div>
        <div className="text-end text-sm">
          <p className="font-mono text-base font-semibold">{data.invoiceNumber ? `${t("ui.invoice")} #${data.invoiceNumber}` : t("ui.invoice_number_assigned_on_save")}</p>
          <p className="text-gray-600">{t("ui.date")} {formatDate(data.issueDate)}</p>
          <p className="text-gray-600">{t("ui.time")} {formatTime(data.issueDate)}</p>
          {data.draft && <p className="mt-1 inline-block rounded bg-yellow-100 px-2 py-0.5 text-xs font-semibold text-yellow-800">{t("ui.not_saved_yet")}</p>}
        </div>
      </div>

      <div className="py-4 text-sm">
        <p className="text-xs uppercase text-gray-500">{data.type === "Offer" ? tf("ui.offer_n_students", { n: data.studentNames.length }) : t("flow.student")}</p>
        <ul className="mt-1 space-y-0.5 font-medium">{data.studentNames.map((n, i) => <li key={i}>{data.studentNames.length > 1 ? `${i + 1}. ` : ""}{n}</li>)}</ul>
      </div>

      <table className="w-full text-start text-sm">
        <thead className="border-y border-gray-200 text-xs uppercase text-gray-500">
          <tr><th className="py-2">{t("rep.col.course")}</th><th className="py-2 text-end">{t("ui.quantity")}</th><th className="py-2 text-end">{t("ui.unit_price")}</th><th className="py-2 text-end">{t("rep.col.subtotal")}</th></tr>
        </thead>
        <tbody>
          <tr><td className="py-2">{data.courseCode} - {data.courseName}</td><td className="py-2 text-end">{data.quantity}</td><td className="py-2 text-end">{formatMoney(data.unitPrice)}</td><td className="py-2 text-end">{formatMoney(data.subtotal)}</td></tr>
        </tbody>
      </table>

      <div className="ms-auto mt-4 max-w-xs">
        {row(t("rep.col.subtotal"), formatMoney(data.subtotal))}
        {row(tf("ui.discount_pct_paren", { p: data.discountPercent }), `- ${formatMoney(data.discountAmount)}`)}
        {row(t("ui.grand_total"), formatMoney(data.grandTotal), true)}
        {row(t("ui.amount_paid"), formatMoney(data.amountPaid))}
        {row(t("pay.remaining"), formatMoney(data.remaining))}
        {data.paymentMethod && row(t("pay.method"), data.paymentMethod.startsWith("Other - ") ? `${t("method.Other")} - ${data.paymentMethod.slice(8)}` : t(`method.${data.paymentMethod}`, data.paymentMethod))}
      </div>

      <div className="mt-4 flex items-center justify-between border-t border-gray-200 pt-3 text-sm">
        <span className="text-gray-500">{t("ui.payment_status")}</span>
        <StatusBadge tone={tone(data.paymentStatus)}>{t(`st.${data.paymentStatus}`, data.paymentStatus)}</StatusBadge>
      </div>
    </div>
  );
}
