import { useEffect, useMemo, useState } from "react";
import { CheckCircle2, Plus, User, Users } from "lucide-react";
import FormInput from "../FormInput";
import Modal from "../Modal";
import SelectInput from "../SelectInput";
import StatusBadge from "../StatusBadge";
import InvoiceDocument, { docFromDetails, docFromPreview } from "./InvoiceDocument";
import StudentCard, { emptyFields, validateStudent } from "./StudentCard";
import type { StudentErrors, StudentFields } from "./StudentCard";
import { usePreferences } from "../../contexts/PreferencesContext";
import { useToast } from "../../contexts/ToastContext";
import { parseError } from "../../services/api";
import { courseService } from "../../services/courseService";
import { invoiceService } from "../../services/invoiceService";
import type { Course, Customer, InvoiceDetails, InvoiceDraft, InvoicePreview, InvoiceType, PaymentMethod } from "../../types";
import { formatMoney } from "../../utils/format";
import { useIdempotencyKey } from "../../utils/idempotency";

type Step = "type" | "students" | "course" | "preview" | "saved";
interface Card { key: number; fields: StudentFields; errors: StudentErrors }

// New payments: Cash and InstaPay only. Older payments (Visa, Vodafone Cash, Other...) are still shown in history.
const METHODS: PaymentMethod[] = ["Cash", "InstaPay"];
const PROOF_EXTENSIONS = [".jpg", ".jpeg", ".png", ".pdf"];
const round2 = (n: number) => Math.round((n + Number.EPSILON) * 100) / 100;

interface Props {
  open: boolean;
  onClose: () => void;
  /** Called after an invoice was saved so the page behind can refresh. */
  onSaved: () => void;
  /** Add Course for a student who already exists: the Type and Students steps are skipped. */
  presetStudent?: Customer | null;
}

/**
 * New Student -> Student or Offer -> student cards -> course, discount, payment -> invoice preview -> SAVE.
 * PRINT in the preview never saves, and the screen stays open. The price always comes from the course (server side too).
 */
export default function NewInvoiceFlow({ open, onClose, onSaved, presetStudent = null }: Props) {
  const { t, tf } = usePreferences();
  const toast = useToast();
  const idem = useIdempotencyKey();
  const [step, setStep] = useState<Step>("type");
  const [type, setType] = useState<InvoiceType>("Student");
  const [cards, setCards] = useState<Card[]>([]);
  const [nextKey, setNextKey] = useState(1);
  const [courses, setCourses] = useState<Course[] | null>(null);
  const [courseId, setCourseId] = useState("");
  const [discount, setDiscount] = useState("0");
  const [paid, setPaid] = useState("0");
  const [method, setMethod] = useState<PaymentMethod>("Cash");
  const [proof, setProof] = useState<File | null>(null);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [preview, setPreview] = useState<InvoicePreview | null>(null);
  const [saved, setSaved] = useState<InvoiceDetails | null>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (!open) return;
    idem.renew(); // a newly opened flow is a new intent: it gets its own key
    setType("Student"); setCards([{ key: 1, fields: emptyFields(), errors: {} }]); setNextKey(2);
    setCourses(null); setCourseId(""); setDiscount("0"); setPaid("0"); setMethod("Cash"); setProof(null);
    setErrors({}); setPreview(null); setSaved(null);
    setStep(presetStudent ? "course" : "type");
  }, [open, presetStudent]);

  // open courses only (active, with a free seat, not completed); an existing student never sees a course they already attend
  useEffect(() => {
    if (!open || step !== "course" || courses !== null) return;
    let cancelled = false;
    courseService.list({ page: 1, pageSize: 100, sortBy: "code", sortDir: "asc", status: "open", availableForStudent: presetStudent?.customerId })
      .then((r) => { if (!cancelled) setCourses(r.items); })
      .catch((err) => { if (!cancelled) { setCourses([]); toast.error(parseError(err).message); } });
    return () => { cancelled = true; };
    // toast is stable.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, step, courses, presetStudent]);

  const studentCount = presetStudent ? 1 : cards.length;
  const course = courses?.find((c) => String(c.courseId) === courseId) ?? null;

  const money = useMemo(() => {
    const unit = course?.price ?? 0;
    const pct = Math.min(100, Math.max(0, Number(discount) || 0));
    const subtotal = round2(unit * studentCount);
    const discountAmount = round2((subtotal * pct) / 100);
    const grandTotal = round2(subtotal - discountAmount);
    const amountPaid = Math.max(0, Number(paid) || 0);
    return { unit, pct, subtotal, discountAmount, grandTotal, amountPaid, remaining: round2(grandTotal - amountPaid) };
  }, [course, discount, paid, studentCount]);

  const proofAllowed = method === "InstaPay";

  const draft = (): InvoiceDraft => ({
    type: presetStudent ? "Student" : type,
    students: presetStudent
      ? [{ customerId: presetStudent.customerId }]
      : cards.map((c) => ({ fullName: c.fields.fullName.trim(), email: c.fields.email.trim() || undefined, phone: c.fields.phone.trim(), area: c.fields.area.trim() || undefined })),
    courseId: Number(courseId),
    discountPercent: Number(discount) || 0,
    amountPaid: round2(Number(paid) || 0),
    paymentMethod: method
  });

  const choose = (next: InvoiceType) => {
    setType(next);
    setCards(next === "Student" ? [{ key: 1, fields: emptyFields(), errors: {} }] : [{ key: 1, fields: emptyFields(), errors: {} }, { key: 2, fields: emptyFields(), errors: {} }]);
    setNextKey(3);
    setStep("students");
  };

  const updateCard = (key: number, fields: StudentFields) => setCards((l) => l.map((c) => (c.key === key ? { ...c, fields, errors: {} } : c)));
  const addCard = () => { setCards((l) => [...l, { key: nextKey, fields: emptyFields(), errors: {} }]); setNextKey((k) => k + 1); };
  const removeCard = (key: number) => setCards((l) => (l.length > 2 ? l.filter((c) => c.key !== key) : l));

  const goCourse = () => {
    const checked = cards.map((c) => ({ ...c, errors: validateStudent(c.fields) }));
    const phones = new Map<string, number>();
    checked.forEach((c, i) => {
      const p = c.fields.phone.trim();
      if (p && phones.has(p)) c.errors = { ...c.errors, phone: t("ui.this_phone_number_is_used") };
      else if (p) phones.set(p, i);
    });
    setCards(checked);
    if (checked.some((c) => Object.keys(c.errors).length > 0)) return;
    setStep("course");
  };

  const validateCourseStep = (): boolean => {
    const errs: Record<string, string> = {};
    if (!course) errs.course = t("ui.select_a_course");
    const pct = Number(discount);
    if (discount.trim() === "" || Number.isNaN(pct) || pct < 0 || pct > 100) errs.discount = t("ui.invalid_discount_percentage");
    const amount = Number(paid);
    if (paid.trim() === "" || Number.isNaN(amount) || amount < 0) errs.paid = t("ui.enter_the_amount_paid_0");
    else if (!errs.discount && round2(amount) > money.grandTotal) errs.paid = tf("ui.paid_exceeds_total", { amount: formatMoney(money.grandTotal) });
    if (proof && proofAllowed) {
      const lower = proof.name.toLowerCase();
      if (!PROOF_EXTENSIONS.some((x) => lower.endsWith(x))) errs.proof = t("ui.use_a_jpg_jpeg_png");
      else if (proof.size > 5 * 1024 * 1024) errs.proof = t("ui.the_file_is_too_large");
      else if (!errs.paid && amount <= 0) errs.proof = t("ui.enter_the_amount_paid_before");
    }
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const goPreview = async () => {
    if (!validateCourseStep()) return;
    setBusy(true);
    try {
      setPreview(await invoiceService.preview(draft())); // the server validates and calculates; the numbers shown come from it
      setStep("preview");
    } catch (err) {
      toast.error(parseError(err).message);
    } finally {
      setBusy(false);
    }
  };

  const save = async () => {
    if (busy) return; // a second click while saving is ignored (the server is protected as well)
    setBusy(true);
    try {
      const result = await invoiceService.create(draft(), proofAllowed ? proof : null, idem.current());
      idem.renew();
      setSaved(result);
      setStep("saved");
      onSaved();
      toast.success(t("ui.invoice_saved_successfully"));
    } catch (err) {
      toast.error(parseError(err).message);
    } finally {
      setBusy(false);
    }
  };

  const steps = presetStudent ? ["course", "preview"] : ["type", "students", "course", "preview"];
  const labels: Record<string, string> = { type: t("ui.type"), students: t("nav.students"), course: t("ui.course_discount"), preview: t("rep.col.invoice") };
  const current = step === "saved" ? "preview" : step;

  const stepper = (
    <ol className="mb-5 flex flex-wrap items-center gap-x-4 gap-y-2 text-sm" aria-label={t("ui.progress")}>
      {steps.map((s, i) => {
        const done = steps.indexOf(current) > i || step === "saved";
        return (
          <li key={s} className="flex items-center gap-2" aria-current={current === s ? "step" : undefined}>
            <span className={`flex h-6 w-6 items-center justify-center rounded-full text-xs font-semibold ${done ? "bg-green-500 text-white" : current === s ? "bg-orange-500 text-white" : "bg-gray-200 text-gray-600"}`}>{i + 1}</span>
            <span className={current === s ? "font-semibold text-gray-900" : "text-gray-500"}>{labels[s]}</span>
          </li>
        );
      })}
    </ol>
  );

  const readOnly = "rounded-lg border border-gray-200 bg-gray-50 px-3 py-2 text-sm font-medium text-gray-900";
  const field = (label: string, value: string) => <div className="space-y-1"><span className="block text-sm font-medium text-gray-700">{label}</span><div className={readOnly}>{value}</div></div>;
  const status = money.grandTotal === 0 ? "Paid" : money.amountPaid === 0 ? "Unpaid" : money.amountPaid >= money.grandTotal ? "Paid" : "Partially Paid";

  const title = step === "saved" ? t("ui.invoice_saved") : presetStudent ? `${t("flow.addCourseFor")} ${presetStudent.fullName}` : t("flow.title");

  return (
    <Modal open={open} title={title} onClose={onClose} xl>
      {stepper}

      {step === "type" && (
        <div className="space-y-4">
          <p className="text-sm text-gray-600">{t("flow.title")}</p>
          <div className="grid gap-4 sm:grid-cols-2">
            {([["Student", User, t("flow.student"), t("flow.studentHelp")], ["Offer", Users, t("flow.offer"), t("flow.offerHelp")]] as const).map(([value, Icon, label, help]) => (
              <button key={value} onClick={() => choose(value)} className="flex flex-col items-start gap-2 rounded-2xl border-2 border-gray-200 p-5 text-start transition hover:border-orange-500 hover:bg-orange-50">
                <span className="rounded-lg bg-orange-100 p-2 text-orange-600"><Icon className="h-6 w-6" /></span>
                <span className="text-lg font-semibold text-gray-900">{label}</span>
                <span className="text-sm text-gray-500">{help}</span>
              </button>
            ))}
          </div>
          <div className="flex justify-end"><button onClick={onClose} className="rounded-lg border border-gray-300 px-4 py-2 text-sm hover:bg-gray-50">{t("flow.close")}</button></div>
        </div>
      )}

      {step === "students" && (
        <div className="space-y-4">
          {cards.map((c, i) => (
            <StudentCard key={c.key} title={type === "Offer" ? `${t("flow.student")} ${i + 1}` : undefined} value={c.fields} errors={c.errors}
                         onChange={(f) => updateCard(c.key, f)} onRemove={type === "Offer" && cards.length > 2 ? () => removeCard(c.key) : undefined} />
          ))}
          {type === "Offer" && (
            <button type="button" onClick={addCard} className="flex w-full items-center justify-center gap-2 rounded-xl border-2 border-dashed border-orange-300 py-3 text-sm font-medium text-orange-600 hover:bg-orange-50">
              <Plus className="h-4 w-4" /> {t("flow.addStudent")}
            </button>
          )}
          <div className="flex justify-end gap-2">
            <button onClick={() => setStep("type")} className="rounded-lg border border-gray-300 px-4 py-2 text-sm hover:bg-gray-50">{t("flow.back")}</button>
            <button onClick={goCourse} className="rounded-lg bg-orange-500 px-4 py-2 text-sm font-medium text-white hover:bg-orange-600">{t("flow.next")}</button>
          </div>
        </div>
      )}

      {step === "course" && (
        <div className="space-y-4">
          <SelectInput label={t("rep.col.course")} value={courseId} onChange={(e) => setCourseId(e.target.value)} error={errors.course} disabled={courses === null}>
            <option value="">{courses === null ? t("ui.loading_courses") : courses.length === 0 ? t("ui.no_open_courses_available") : t("ui.select_a_course_2")}</option>
            {courses?.map((c) => <option key={c.courseId} value={c.courseId}>{c.courseCode} - {c.courseName} ({c.enrolledCount}/{c.maxCapacity})</option>)}
          </SelectInput>

          <div className="grid gap-4 sm:grid-cols-3">
            {field(t("data.price"), course ? formatMoney(course.price) : t("ui.select_a_course_2"))}
            {field(t("nav.students"), String(studentCount))}
            {field(t("rep.col.subtotal"), formatMoney(money.subtotal))}
          </div>
          <div className="grid gap-4 sm:grid-cols-3">
            <FormInput label={t("ui.discount")} type="number" min="0" max="100" step="0.01" value={discount} onChange={(e) => setDiscount(e.target.value)} error={errors.discount} />
            {field(t("ui.discount_amount"), formatMoney(money.discountAmount))}
            {field(t("ui.grand_total"), formatMoney(money.grandTotal))}
          </div>

          <div className="rounded-xl border border-gray-200 p-4">
            <h3 className="mb-3 text-sm font-semibold text-gray-900">{t("ui.payment")}</h3>
            <div className="grid gap-4 sm:grid-cols-3">
              <FormInput label={t("ui.amount_paid")} type="number" min="0" step="0.01" value={paid} onChange={(e) => setPaid(e.target.value)} error={errors.paid} />
              <div className="space-y-1">
                <span className="block text-sm font-medium text-gray-700">{t("rep.col.remaining")}</span>
                <div className={`${readOnly} flex items-center justify-between ${money.remaining < 0 ? "border-red-300 text-red-700" : ""}`}>
                  <span>{formatMoney(money.remaining)}</span>
                  <StatusBadge tone={status === "Paid" ? "green" : status === "Partially Paid" ? "orange" : "red"}>{t(`st.${status}`)}</StatusBadge>
                </div>
              </div>
              <SelectInput label={t("rep.col.method")} value={method} onChange={(e) => setMethod(e.target.value as PaymentMethod)}>
                {METHODS.map((m) => <option key={m} value={m}>{t(`method.${m}`)}</option>)}
              </SelectInput>
            </div>
            {proofAllowed && (
              <div className="mt-4 space-y-1">
                <label htmlFor="proof" className="block text-sm font-medium text-gray-700">{t("ui.payment_proof_optional")}</label>
                <input id="proof" type="file" accept=".jpg,.jpeg,.png,.pdf,image/jpeg,image/png,application/pdf" onChange={(e) => setProof(e.target.files?.[0] ?? null)}
                       className="block w-full text-sm text-gray-600 file:me-3 file:rounded-lg file:border-0 file:bg-orange-50 file:px-3 file:py-2 file:text-sm file:font-medium file:text-orange-700 hover:file:bg-orange-100" />
                <p className="text-xs text-gray-500">{t("ui.jpg_jpeg_png_or_pdf")}</p>
                {errors.proof && <p className="text-xs text-red-600">{errors.proof}</p>}
              </div>
            )}
          </div>

          <div className="flex justify-end gap-2">
            {!presetStudent && <button onClick={() => setStep("students")} disabled={busy} className="rounded-lg border border-gray-300 px-4 py-2 text-sm hover:bg-gray-50">{t("flow.back")}</button>}
            {presetStudent && <button onClick={onClose} disabled={busy} className="rounded-lg border border-gray-300 px-4 py-2 text-sm hover:bg-gray-50">{t("flow.close")}</button>}
            <button onClick={goPreview} disabled={busy || !course} className="rounded-lg bg-orange-500 px-4 py-2 text-sm font-medium text-white hover:bg-orange-600 disabled:opacity-60">{busy ? "..." : t("flow.preview")}</button>
          </div>
        </div>
      )}

      {step === "preview" && preview && (
        <div className="space-y-4">
          <InvoiceDocument data={docFromPreview(preview)} />
          <p className="no-print text-xs text-gray-500">{t("ui.printing_does_not_save_the")}</p>
          <div className="no-print flex flex-wrap justify-end gap-2">
            <button onClick={() => setStep("course")} disabled={busy} className="rounded-lg border border-gray-300 px-4 py-2 text-sm hover:bg-gray-50">{t("flow.back")}</button>
            <button onClick={() => window.print()} disabled={busy} className="rounded-lg border border-gray-300 px-4 py-2 text-sm hover:bg-gray-50">{t("flow.print")}</button>
            <button onClick={save} disabled={busy} className="rounded-lg bg-orange-500 px-5 py-2 text-sm font-medium text-white hover:bg-orange-600 disabled:opacity-60">{busy ? t("ui.saving") : t("flow.save")}</button>
          </div>
        </div>
      )}

      {step === "saved" && saved && (
        <div className="space-y-4">
          <div className="no-print flex items-center gap-2 rounded-lg border border-green-300 bg-green-50 px-3 py-2 text-sm font-medium text-green-800"><CheckCircle2 className="h-4 w-4" /> {t("ui.invoice_saved_successfully")}</div>
          <InvoiceDocument data={docFromDetails(saved)} />
          <div className="no-print flex justify-end gap-2">
            <button onClick={() => window.print()} className="rounded-lg border border-gray-300 px-4 py-2 text-sm hover:bg-gray-50">{t("flow.print")}</button>
            <button onClick={onClose} className="rounded-lg bg-orange-500 px-4 py-2 text-sm font-medium text-white hover:bg-orange-600">{t("flow.close")}</button>
          </div>
        </div>
      )}
    </Modal>
  );
}
