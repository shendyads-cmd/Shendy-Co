import { useEffect, useState } from "react";
import InvoiceDocument, { docFromDetails } from "./InvoiceDocument";
import { useToast } from "../../contexts/ToastContext";
import { parseError } from "../../services/api";
import { invoiceService } from "../../services/invoiceService";
import type { InvoiceDetails } from "../../types";

/** Prints a saved invoice straight from a list: loads it, renders it off-screen, opens the print dialog, then disappears. */
export default function InvoicePrintHost({ id, onDone }: { id: number; onDone: () => void }) {
  const toast = useToast();
  const [data, setData] = useState<InvoiceDetails | null>(null);

  useEffect(() => {
    let cancelled = false;
    invoiceService.get(id).then((d) => { if (!cancelled) setData(d); }).catch((err) => { toast.error(parseError(err).message); onDone(); });
    return () => { cancelled = true; };
    // toast and onDone are stable for the life of this host.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  useEffect(() => {
    if (!data) return;
    const timer = setTimeout(() => { window.print(); onDone(); }, 150);
    return () => clearTimeout(timer);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [data]);

  return data ? <div className="print-host"><InvoiceDocument data={docFromDetails(data)} /></div> : null;
}
