import { tr } from "../../i18n/translateServer";
import { Trash2 } from "lucide-react";
import FormInput from "../FormInput";
import { usePreferences } from "../../contexts/PreferencesContext";

export interface StudentFields { fullName: string; email: string; phone: string; area: string }
export type StudentErrors = Partial<Record<keyof StudentFields, string>>;

export const emptyFields = (): StudentFields => ({ fullName: "", email: "", phone: "", area: "" });

const PHONE = /^[0-9+()\-\s]{6,30}$/;
const EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

/** Client-side check (the API validates again). Area replaces the old Address field. */
export function validateStudent(f: StudentFields): StudentErrors {
  const e: StudentErrors = {};
  if (f.fullName.trim().length < 2) e.fullName = tr("ui.enter_the_full_name");
  if (!f.phone.trim()) e.phone = tr("ui.phone_number_is_required");
  else if (!PHONE.test(f.phone.trim())) e.phone = tr("ui.phone_number_is_not_valid");
  if (f.email.trim() && !EMAIL.test(f.email.trim())) e.email = tr("ui.email_address_is_not_valid");
  if (f.area.trim().length > 100) e.area = tr("ui.area_is_too_long");
  return e;
}

interface Props {
  title?: string;
  value: StudentFields;
  errors?: StudentErrors;
  onChange: (next: StudentFields) => void;
  onRemove?: () => void;
}

/** One wide rectangular student card: Full Name, Email, Phone, Area. */
export default function StudentCard({ title, value, errors = {}, onChange, onRemove }: Props) {
  const { t } = usePreferences();
  const set = (key: keyof StudentFields) => (e: { target: { value: string } }) => onChange({ ...value, [key]: e.target.value });
  return (
    <div className="rounded-xl border border-gray-200 bg-white p-4 shadow-sm">
      {(title || onRemove) && (
        <div className="mb-3 flex items-center justify-between">
          <h3 className="text-sm font-semibold text-gray-900">{title}</h3>
          {onRemove && <button type="button" onClick={onRemove} className="icon-btn icon-btn-danger" aria-label={t("ui.remove_student")} title={t("ui.remove")}><Trash2 className="h-4 w-4" /></button>}
        </div>
      )}
      <div className="grid gap-3 sm:grid-cols-2">
        <FormInput label={t("flow.fullName")} value={value.fullName} onChange={set("fullName")} error={errors.fullName} />
        <FormInput label={t("flow.email")} type="email" value={value.email} onChange={set("email")} error={errors.email} />
        <FormInput label={t("flow.phone")} value={value.phone} onChange={set("phone")} error={errors.phone} inputMode="tel" />
        <FormInput label={t("flow.area")} placeholder={t("ui.e_g_girga")} value={value.area} onChange={set("area")} error={errors.area} />
      </div>
    </div>
  );
}
