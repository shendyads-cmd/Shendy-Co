import { useCallback, useEffect, useRef, useState } from "react";
import { ArrowLeft, ChevronDown, Database, Download, ExternalLink, FileSpreadsheet, History, Trash2 } from "lucide-react";
import EmptyState from "../EmptyState";
import LoadingSpinner from "../LoadingSpinner";
import Modal from "../Modal";
import Pagination from "../Pagination";
import SearchBox from "../SearchBox";
import StatusBadge from "../StatusBadge";
import StatusFilter from "../StatusFilter";
import { usePreferences } from "../../contexts/PreferencesContext";
import { useToast } from "../../contexts/ToastContext";
import { usePagedList } from "../../hooks/usePagedList";
import { parseError } from "../../services/api";
import { dataService } from "../../services/dataService";
import type { ExportKind } from "../../services/dataService";
import type { CompletedCourse, CompletedCourseDetails, HistoricalStudentDetails } from "../../types";
import { formatDate, formatMoney } from "../../utils/format";

const payTone = (s: string) => (s === "Paid" ? "green" : s === "Partially Paid" ? "orange" : s === "Unpaid" ? "red" : "gray");

/** Data (Admin only; the API enforces it too). Read-only history of completed courses, exports and the permanent clean-up. */
export default function DataSection() {
  const { t } = usePreferences();
  const toast = useToast();
  const list = usePagedList<CompletedCourse, Record<string, never>>(dataService.listCompleted, {}, { sortBy: "completed", sortDir: "desc" });
  const [selected, setSelected] = useState<number | null>(null);
  const [menuOpen, setMenuOpen] = useState(false);
  const [exporting, setExporting] = useState<ExportKind | null>(null);
  const menuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const close = (e: MouseEvent) => { if (!menuRef.current?.contains(e.target as Node)) setMenuOpen(false); };
    document.addEventListener("mousedown", close);
    return () => document.removeEventListener("mousedown", close);
  }, []);

  const runExport = async (kind: ExportKind) => {
    setMenuOpen(false);
    setExporting(kind);
    try {
      await dataService.exportData(kind);
      toast.success(kind === "sql" ? t("ui.sql_file_downloaded_successfully") : t("ui.excel_file_downloaded_successfully"));
    } catch (err) {
      toast.error(parseError(err).message);
    } finally {
      setExporting(null);
    }
  };

  if (selected !== null) {
    return <CourseHistory id={selected} onBack={() => setSelected(null)} onDeleted={() => { setSelected(null); list.reload(); }} />;
  }

  return (
    <div className="space-y-4">
      <div>
        <h2 className="text-lg font-semibold text-gray-900">{t("data.title")}</h2>
        <p className="text-sm text-gray-500">{t("data.subtitle")}</p>
      </div>

      {/* One toolbar: search on the main side, Export Data on the other. Wraps on small screens. */}
      <div className="flex flex-wrap items-center gap-3">
        <div className="min-w-[14rem] flex-1">
          <SearchBox value={list.search} onChange={list.setSearch} onSearch={list.submitSearch} placeholder={t("data.search")} />
        </div>
        <div ref={menuRef} className="relative">
          <button onClick={() => setMenuOpen((v) => !v)} disabled={exporting !== null} aria-haspopup="menu" aria-expanded={menuOpen}
                  className="flex items-center gap-2 rounded-lg bg-orange-500 px-4 py-2 text-sm font-medium text-white hover:bg-orange-600 disabled:opacity-60">
            <Download className="h-4 w-4" /> {exporting ? "..." : t("data.export")} <ChevronDown className="h-4 w-4" />
          </button>
          {menuOpen && (
            <div role="menu" className="absolute end-0 z-20 mt-2 w-48 rounded-xl border border-gray-200 bg-white p-1 shadow-lg">
              <button role="menuitem" onClick={() => runExport("sql")} className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-sm text-gray-800 hover:bg-orange-50">
                <Database className="h-4 w-4 text-orange-500" /> {t("data.sql")}
              </button>
              <button role="menuitem" onClick={() => runExport("excel")} className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-sm text-gray-800 hover:bg-orange-50">
                <FileSpreadsheet className="h-4 w-4 text-orange-500" /> {t("data.excel")}
              </button>
            </div>
          )}
        </div>
      </div>

      <div className="rounded-2xl border border-gray-200 bg-white shadow-sm">
        {list.loading ? <LoadingSpinner /> : list.data.items.length === 0 ? (
          <EmptyState icon={History} title={t("data.empty")} text={t("data.emptyText")} />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-start text-sm">
              <thead className="bg-gray-50 text-xs uppercase text-gray-500">
                <tr>
                  <th className="px-4 py-3">{t("data.id")}</th><th className="px-4 py-3">{t("common.name")}</th><th className="px-4 py-3">{t("courses.code")}</th>
                  <th className="px-4 py-3">{t("data.completedOn")}</th><th className="px-4 py-3">{t("data.students")}</th>
                  <th className="px-4 py-3 text-end">{t("rep.col.revenue")}</th><th className="px-4 py-3 text-end">{t("rep.col.paid")}</th><th className="px-4 py-3 text-end">{t("rep.col.remaining")}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {list.data.items.map((c) => (
                  <tr key={c.courseId} onClick={() => setSelected(c.courseId)} className="cursor-pointer hover:bg-orange-50/40">
                    <td className="px-4 py-3 text-gray-700">{c.courseId}</td>
                    <td className="px-4 py-3 font-medium text-gray-900">{c.courseName}</td>
                    <td className="px-4 py-3 font-mono font-semibold text-gray-900">{c.courseCode}</td>
                    <td className="px-4 py-3 text-gray-500">{formatDate(c.completedAt)}</td>
                    <td className="px-4 py-3 text-gray-700">{c.studentCount}</td>
                    <td className="px-4 py-3 text-end text-gray-700">{c.financial ? formatMoney(c.financial.totalAmount) : "-"}</td>
                    <td className="px-4 py-3 text-end text-gray-700">{c.financial ? formatMoney(c.financial.totalPaid) : "-"}</td>
                    <td className="px-4 py-3 text-end text-gray-700">{c.financial ? formatMoney(c.financial.totalRemaining) : "-"}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
        <Pagination page={list.page} pageSize={list.pageSize} total={list.data.total} onPage={list.setPage} />
      </div>
    </div>
  );
}

type PayFilter = "all" | "paid" | "partial" | "unpaid";

function CourseHistory({ id, onBack, onDeleted }: { id: number; onBack: () => void; onDeleted: () => void }) {
  const { t } = usePreferences();
  const toast = useToast();
  const [data, setData] = useState<CompletedCourseDetails | null>(null);
  const [filter, setFilter] = useState<PayFilter>("all");
  const [student, setStudent] = useState<number | null>(null);
  const [deleteOpen, setDeleteOpen] = useState(false);

  const load = useCallback(() => {
    dataService.getCompleted(id, filter === "all" ? undefined : filter)
      .then(setData)
      .catch((err) => { toast.error(parseError(err).message); onBack(); });
  }, [id, filter, toast, onBack]);
  useEffect(() => { load(); }, [load]);

  if (student !== null) return <StudentHistory courseId={id} customerId={student} onBack={() => setStudent(null)} />;
  if (!data) return <LoadingSpinner />;

  const { course, students } = data;
  const fin = course.financial;
  const field = (label: string, value: string) => (
    <div><dt className="text-xs uppercase text-gray-500">{label}</dt><dd className="mt-0.5 text-sm text-gray-900">{value}</dd></div>
  );
  const card = (label: string, value: string) => (
    <div className="rounded-xl border border-gray-200 p-3"><p className="text-xs uppercase text-gray-500">{label}</p><p className="mt-1 text-lg font-semibold text-gray-900">{value}</p></div>
  );

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <button onClick={onBack} className="inline-flex items-center gap-1 text-sm text-gray-600 hover:text-orange-600"><ArrowLeft className="h-4 w-4 rtl:rotate-180" /> {t("data.back")}</button>
        <button onClick={() => setDeleteOpen(true)} className="inline-flex items-center gap-2 rounded-lg border border-red-500 px-3 py-2 text-sm font-medium text-red-600 hover:bg-red-50"><Trash2 className="h-4 w-4" /> {t("ui.delete_course_data")}</button>
      </div>

      <div className="rounded-2xl border border-gray-200 p-5">
        <p className="font-mono text-sm font-semibold text-orange-600">{course.courseCode}</p>
        <h3 className="text-xl font-semibold text-gray-900">{course.courseName}</h3>
        <dl className="mt-4 grid gap-4 sm:grid-cols-3 lg:grid-cols-6">
          {field(t("data.id"), String(course.courseId))}
          {field(t("data.price"), formatMoney(course.price))}
          {field(t("data.capacity"), String(course.maxCapacity))}
          {field(t("data.students"), String(course.studentCount))}
          {field(t("data.completedOn"), formatDate(course.completedAt))}
          {field(t("common.status").charAt(0) + t("common.status").slice(1).toLowerCase(), course.status)}
        </dl>
      </div>

      {fin ? (
        <div className="grid gap-3 sm:grid-cols-3 lg:grid-cols-6">
          {card(t("ui.total_revenue"), formatMoney(fin.totalAmount))}
          {card(t("ui.total_paid"), formatMoney(fin.totalPaid))}
          {card(t("ui.total_remaining"), formatMoney(fin.totalRemaining))}
          {card(t("ui.paid_students"), String(fin.paidCount))}
          {card(t("ui.partially_paid_2"), String(fin.partialCount))}
          {card(t("ui.unpaid_students"), String(fin.unpaidCount))}
        </div>
      ) : <p className="rounded-lg bg-gray-50 px-3 py-2 text-sm text-gray-500">{t("ui.the_financial_summary_is_not")}</p>}

      <div className="rounded-2xl border border-gray-200">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-gray-100 px-5 py-3">
          <h3 className="font-semibold text-gray-900">{t("data.studentsIn")}</h3>
          <StatusFilter<PayFilter> value={filter} onChange={setFilter}
            options={[{ value: "all", label: t("common.all") }, { value: "paid", label: t("rep.col.paid") }, { value: "partial", label: t("ui.partial_remaining") }, { value: "unpaid", label: t("st.Unpaid") }]} />
        </div>
        {students.length === 0 ? <EmptyState title={t("ui.no_students")} /> : (
          <div className="overflow-x-auto">
            <table className="w-full text-start text-sm">
              <thead className="bg-gray-50 text-xs uppercase text-gray-500"><tr><th className="px-4 py-3">{t("common.name")}</th><th className="px-4 py-3">{t("ui.payment_status")}</th></tr></thead>
              <tbody className="divide-y divide-gray-100">
                {students.map((s) => (
                  <tr key={s.customerId} onClick={() => setStudent(s.customerId)} className="cursor-pointer hover:bg-orange-50/40">
                    <td className="px-4 py-3 text-gray-900"><span className="me-2 font-mono text-xs font-semibold text-gray-500">{s.studentCode}</span>{s.fullName}</td>
                    <td className="px-4 py-3"><StatusBadge tone={payTone(s.paymentStatus)}>{t(`st.${s.paymentStatus}`, s.paymentStatus)}</StatusBadge></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      <DeleteCourseDataDialog open={deleteOpen} course={course} onClose={() => setDeleteOpen(false)} onDeleted={onDeleted} />
    </div>
  );
}

/** Read-only: nothing on this screen can change a financial record. */
function StudentHistory({ courseId, customerId, onBack }: { courseId: number; customerId: number; onBack: () => void }) {
  const { t } = usePreferences();
  const toast = useToast();
  const [data, setData] = useState<HistoricalStudentDetails | null>(null);

  useEffect(() => {
    let cancelled = false;
    dataService.getStudentHistory(courseId, customerId).then((d) => { if (!cancelled) setData(d); }).catch((err) => { toast.error(parseError(err).message); onBack(); });
    return () => { cancelled = true; };
    // toast and onBack are stable for this view.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [courseId, customerId]);

  if (!data) return <LoadingSpinner />;
  const inv = data.invoice;
  const field = (label: string, value?: string | null) => (
    <div><dt className="text-xs uppercase text-gray-500">{label}</dt><dd className="mt-0.5 text-sm text-gray-900">{value || "-"}</dd></div>
  );
  const section = (title: string, body: React.ReactNode) => (
    <div className="rounded-2xl border border-gray-200 p-5"><h4 className="mb-3 font-semibold text-gray-900">{title}</h4>{body}</div>
  );

  return (
    <div className="space-y-4">
      <button onClick={onBack} className="inline-flex items-center gap-1 text-sm text-gray-600 hover:text-orange-600"><ArrowLeft className="h-4 w-4 rtl:rotate-180" /> {data.courseCode} - {data.courseName}</button>
      <div>
        <p className="font-mono text-sm font-semibold text-orange-600">{data.studentCode}</p>
        <h3 className="text-xl font-semibold text-gray-900">{data.fullName}</h3>
      </div>
      {section(t("flow.student"), <dl className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">{field(t("ui.full_name"), data.fullName)}{field(t("students.phone"), data.phone)}{field(t("students.email"), data.email)}{field(t("ui.address"), data.address)}{field(t("flow.area"), data.area)}</dl>)}
      {section(t("ui.enrollment"), <dl className="grid gap-4 sm:grid-cols-2 lg:grid-cols-5">{field(t("rep.col.course"), data.courseName)}{field(t("data.id"), String(data.courseId))}{field(t("ui.course_code_2"), data.courseCode)}{field(t("ui.enrollment_date"), formatDate(data.enrollmentDate))}{field(t("ui.status"), data.enrollmentStatus)}</dl>)}
      {section(t("rep.col.invoice"), inv ? (
        <dl className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {field(t("ui.invoice_number"), inv.invoiceNumber)}{field(t("data.price"), formatMoney(inv.coursePrice))}{field(t("ui.discount"), `${inv.discountPercent}%`)}{field(t("ui.discount_amount"), formatMoney(inv.discountAmount))}
          {field(t("rep.col.final"), formatMoney(inv.finalAmount))}{field(t("ui.amount_paid"), formatMoney(inv.amountPaid))}{field(t("rep.col.remaining"), formatMoney(inv.remaining))}
          <div><dt className="text-xs uppercase text-gray-500">{t("ui.payment_status")}</dt><dd className="mt-0.5"><StatusBadge tone={payTone(inv.status)}>{inv.status}</StatusBadge></dd></div>
        </dl>
      ) : <p className="text-sm text-gray-500">{t("ui.no_invoice_was_created_for")}</p>)}
      {inv && section(t("kpi.payments"), data.payments.length === 0 ? <p className="text-sm text-gray-500">{t("ui.no_payment_was_received")}</p> : (
        <div className="overflow-x-auto">
          <table className="w-full text-start text-sm">
            <thead className="text-xs uppercase text-gray-500"><tr><th className="py-1 pe-4">{t("rep.col.date")}</th><th className="py-1 pe-4">{t("ui.method")}</th><th className="py-1 pe-4">{t("rep.col.amount")}</th><th className="py-1">{t("ui.proof")}</th></tr></thead>
            <tbody>
              {data.payments.map((p) => (
                <tr key={p.paymentId} className="border-t border-gray-100">
                  <td className="py-2 pe-4 text-gray-700">{formatDate(p.paymentDate)}</td>
                  <td className="py-2 pe-4 text-gray-900">{t(`method.${p.paymentMethod}`, p.paymentMethod)}{p.paymentMethodOther ? ` - ${p.paymentMethodOther}` : ""}</td>
                  <td className="py-2 pe-4 text-gray-900">{formatMoney(p.amount)}</td>
                  <td className="py-2">{p.hasProof
                    ? <button onClick={() => dataService.openProof(p.paymentId).catch((err) => toast.error(parseError(err).message))} className="inline-flex items-center gap-1 text-orange-600 hover:underline"><ExternalLink className="h-3.5 w-3.5" /> {t("invoices.view")}</button>
                    : <span className="text-gray-400">-</span>}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ))}
    </div>
  );
}

/** Two confirmations: first the warning, then the word DELETE must be typed exactly. */
function DeleteCourseDataDialog({ open, course, onClose, onDeleted }: { open: boolean; course: CompletedCourse; onClose: () => void; onDeleted: () => void }) {
  const { t, tf } = usePreferences();
  const toast = useToast();
  const [step, setStep] = useState<1 | 2>(1);
  const [typed, setTyped] = useState("");
  const [busy, setBusy] = useState(false);
  useEffect(() => { if (open) { setStep(1); setTyped(""); } }, [open]);

  const run = async () => {
    setBusy(true);
    try {
      const r = await dataService.deleteCourseData(course.courseId, typed);
      toast.success(tf("ui.course_deleted_summary", { code: r.courseCode, invoices: r.invoicesDeleted, payments: r.paymentsDeleted, enrollments: r.enrollmentsDeleted }));
      onClose();
      onDeleted();
    } catch (err) {
      toast.error(parseError(err).message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <Modal open={open} title={step === 1 ? t("ui.delete_all_data_for_this") : t("ui.type_delete_to_confirm")} onClose={onClose}>
      <div className="space-y-4">
        <div className="rounded-lg border border-red-200 bg-red-50 px-3 py-2 text-sm font-medium text-red-800">{course.courseCode} - {course.courseName}</div>
        {step === 1 ? (
          <>
            <p className="text-sm text-gray-600">{t("ui.this_action_permanently_deletes_the")}</p>
            <p className="text-sm text-gray-600">{t("ui.students_are_never_deleted_and")}</p>
            <div className="flex justify-end gap-2">
              <button onClick={onClose} className="rounded-lg border border-gray-300 px-4 py-2 text-sm hover:bg-gray-50">{t("dataGate.cancel")}</button>
              <button onClick={() => setStep(2)} className="rounded-lg bg-red-600 px-4 py-2 text-sm font-medium text-white hover:bg-red-700">{t("ui.continue")}</button>
            </div>
          </>
        ) : (
          <>
            <label htmlFor="confirm-delete" className="block text-sm text-gray-600">{t("ui.type")} <span className="font-mono font-semibold">{t("ui.delete_2")}</span> {t("ui.exactly_to_enable_the_final")}</label>
            <input id="confirm-delete" value={typed} onChange={(e) => setTyped(e.target.value)} autoFocus autoComplete="off"
                   className="w-full rounded-lg border border-gray-300 px-3 py-2 font-mono text-sm outline-none focus:border-red-500 focus:ring-2 focus:ring-red-200" />
            <div className="flex justify-end gap-2">
              <button onClick={onClose} disabled={busy} className="rounded-lg border border-gray-300 px-4 py-2 text-sm hover:bg-gray-50">{t("dataGate.cancel")}</button>
              <button onClick={run} disabled={typed !== "DELETE" || busy} className="rounded-lg bg-red-600 px-4 py-2 text-sm font-medium text-white hover:bg-red-700 disabled:opacity-40">{busy ? t("ui.deleting") : t("ui.delete_permanently")}</button>
            </div>
          </>
        )}
      </div>
    </Modal>
  );
}
