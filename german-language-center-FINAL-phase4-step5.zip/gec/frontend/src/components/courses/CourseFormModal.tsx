import { useEffect, useState } from "react";
import type { FormEvent } from "react";
import FormInput from "../FormInput";
import Modal from "../Modal";
import { useToast } from "../../contexts/ToastContext";
import { parseError } from "../../services/api";
import { courseService } from "../../services/courseService";
import type { Course } from "../../types";
import { useIdempotencyKey } from "../../utils/idempotency";
import { usePreferences } from "../../contexts/PreferencesContext";

interface Props { open: boolean; course: Course | null; onClose: () => void; onSaved: () => void }

export default function CourseFormModal({ open, course, onClose, onSaved }: Props) {
  const { t, tf } = usePreferences();
  const toast = useToast();
  const idem = useIdempotencyKey();
  const editing = course !== null;
  const [name, setName] = useState("");
  const [price, setPrice] = useState("");
  const [capacity, setCapacity] = useState("");
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (!open) return;
    idem.renew(); // a newly opened form is a new intent: it gets its own key
    setName(course?.courseName ?? "");
    setPrice(course ? String(course.price) : "");
    setCapacity(course ? String(course.maxCapacity) : "");
    setErrors({});
  }, [open, course]);

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (busy) return; // a second click while saving is ignored (the server is protected as well)
    const errs: Record<string, string> = {};
    if (name.trim().length < 2) errs.name = t("ui.course_name_must_be_at");
    const p = Number(price);
    if (price.trim() === "" || Number.isNaN(p) || p <= 0) errs.price = t("ui.price_must_be_greater_than");
    const cap = Number(capacity);
    if (capacity.trim() === "" || !Number.isInteger(cap) || cap < 1 || cap > 1000) errs.capacity = t("ui.enter_a_whole_number_between");
    if (course && !errs.capacity && cap < course.enrolledCount) errs.capacity = tf("ui.students_already_registered", { n: course.enrolledCount });
    setErrors(errs);
    if (Object.keys(errs).length) return;

    const body = { courseName: name.trim(), price: p, maxCapacity: cap };
    setBusy(true);
    try {
      if (course) {
        const before = course;
        await courseService.update(before.courseId, body);
        onSaved();
        toast.success(t("ui.course_updated_successfully"), {
          undo: async () => {
            await courseService.update(before.courseId, { courseName: before.courseName, price: before.price, maxCapacity: before.maxCapacity });
            onSaved();
          }
        });
      } else {
        const created = await courseService.create(body, idem.current());
        idem.renew();
        onSaved();
        toast.success(tf("ui.course_created", { code: created.courseCode }));
      }
      onClose();
    } catch (err) {
      toast.error(parseError(err).message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <Modal open={open} title={editing ? t("ui.edit_course") : t("courses.add")} onClose={onClose}>
      <form onSubmit={submit} noValidate className="space-y-4">
        <div className="rounded-lg bg-gray-50 px-3 py-2 text-sm">
          <span className="text-gray-500">{t("ui.course_code")} </span>
          {course ? <span className="font-mono font-semibold text-gray-900">{course.courseCode}</span>
                  : <span className="text-gray-500">{t("ui.generated_automatically_a_001_a")}</span>}
        </div>
        <FormInput label={t("ui.course_name")} value={name} onChange={(e) => setName(e.target.value)} error={errors.name} autoFocus />
        <div className="grid gap-4 sm:grid-cols-2">
          <FormInput label={t("courses.price")} type="number" min="0" step="0.01" value={price} onChange={(e) => setPrice(e.target.value)} error={errors.price} />
          <FormInput label={t("data.capacity")} type="number" min="1" step="1" value={capacity} onChange={(e) => setCapacity(e.target.value)} error={errors.capacity} />
        </div>
        <div className="flex justify-end gap-2 pt-2">
          <button type="button" onClick={onClose} className="rounded-lg border border-gray-300 px-4 py-2 text-sm hover:bg-gray-50">{t("dataGate.cancel")}</button>
          <button type="submit" disabled={busy} className="rounded-lg bg-orange-500 px-4 py-2 text-sm font-medium text-white hover:bg-orange-600 disabled:opacity-60">{busy ? t("ui.saving") : t("account.save")}</button>
        </div>
      </form>
    </Modal>
  );
}
