import type { ReactNode, SelectHTMLAttributes } from "react";

interface Props extends SelectHTMLAttributes<HTMLSelectElement> { label?: string; error?: string; children: ReactNode }

export default function SelectInput({ label, error, id, className = "", children, ...rest }: Props) {
  const selectId = id ?? rest.name ?? label;
  return (
    <div className="space-y-1">
      {label && <label htmlFor={selectId} className="block text-sm font-medium text-gray-700">{label}</label>}
      <select id={selectId} {...rest}
              className={`w-full rounded-lg border bg-white px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-orange-300 ${error ? "border-red-400" : "border-gray-300 focus:border-orange-500"} ${className}`}>
        {children}
      </select>
      {error && <p className="text-xs text-red-600">{error}</p>}
    </div>
  );
}
