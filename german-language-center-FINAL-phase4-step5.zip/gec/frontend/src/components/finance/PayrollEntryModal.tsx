import { useEffect, useState } from "react";
import FormInput from "../FormInput";
import Modal from "../Modal";
import SelectInput from "../SelectInput";
import { usePreferences } from "../../contexts/PreferencesContext";
import { useToast } from "../../contexts/ToastContext";
import { parseError } from "../../services/api";
import { payrollService } from "../../services/payrollService";
import type { PayrollEmployee, PayrollEntry } from "../../types";
import { formatMoney } from "../../utils/format";
import { useIdempotencyKey } from "../../utils/idempotency";

interface Props { entry?: PayrollEntry | null; onClose: () => void; onSaved: () => void }

const currentMonth = () => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`; };
const num = (s: string) => (s.trim() === "" ? 0 : Number(s));

/** New / edit salary entry. Net salary = base + bonus - deductions is only a preview here; the server calculates and stores the real value. */
export default function PayrollEntryModal({ entry, onClose, onSaved }: Props) {
  const { t } = usePreferences();
  const toast = useToast();
  const idem = useIdempotencyKey();
  const [employees, setEmployees] = useState<PayrollEmployee[]>([]);
  const [employeeId, setEmployeeId] = useState(entry ? String(entry.employeeId) : "");
  const [period, setPeriod] = useState(entry ? `${entry.year}-${String(entry.month).padStart(2, "0")}` : currentMonth());
  const [base, setBase] = useState(entry ? String(entry.baseSalary) : "");
  const [bonus, setBonus] = useState(entry ? String(entry.bonus) : "0");
  const [deductions, setDeductions] = useState(entry ? String(entry.deductions) : "0");
  const [notes, setNotes] = useState(entry?.notes ?? "");
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (entry) return;
    payrollService.employees({ isActive: true, page: 1, pageSize: 100, sortBy: "name", sortDir: "asc" }).then((r) => setEmployees(r.items)).catch((err) => toast.error(parseError(err).message));
    // loaded once when the dialog opens
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const net = num(base) + num(bonus) - num(deductions);

  const pickEmployee = (id: string) => {
    setEmployeeId(id);
    const e = employees.find((x) => String(x.employeeId) === id);
    if (e) setBase(String(e.baseSalary));
  };

  const submit = async () => {
    if (busy) return;
    const errs: Record<string, string> = {};
    const [year, month] = period.split("-").map(Number);
    if (!entry && !employeeId) errs.employee = t("payroll.employeeRequired");
    if (!entry && (!year || !month)) errs.period = t("payroll.periodRequired");
    else if (!entry && period > currentMonth()) errs.period = t("payroll.periodFuture");
    if (base.trim() === "" || !(num(base) >= 0)) errs.base = t("payroll.nonNegative");
    if (!(num(bonus) >= 0)) errs.bonus = t("payroll.nonNegative");
    if (!(num(deductions) >= 0)) errs.deductions = t("payroll.nonNegative");
    else if (num(deductions) > num(base) + num(bonus)) errs.deductions = t("payroll.deductionsTooHigh");
    if (notes.length > 300) errs.notes = t("payroll.notesTooLong");
    setErrors(errs);
    if (Object.keys(errs).length) return;

    setBusy(true);
    const body = { employeeId: entry ? entry.employeeId : Number(employeeId), year: entry ? entry.year : year, month: entry ? entry.month : month,
                   baseSalary: num(base), bonus: num(bonus), deductions: num(deductions), notes: notes.trim() || undefined };
    try {
      if (entry) await payrollService.update(entry.payrollId, body);
      else { await payrollService.create(body, idem.current()); idem.renew(); }
      toast.success(t("payroll.saved"));
      onSaved();
      onClose();
    } catch (err) { setErrors({ form: parseError(err).message }); }
    finally { setBusy(false); }
  };

  return (
    <Modal open title={entry ? t("payroll.editEntry") : t("payroll.newEntry")} onClose={onClose} wide>
      <div className="space-y-4">
        {entry ? (
          <FormInput label={t("payroll.employee")} value={`${entry.employeeName} - ${entry.year}-${String(entry.month).padStart(2, "0")}`} readOnly disabled />
        ) : (
          <div className="grid gap-4 sm:grid-cols-2">
            <SelectInput label={t("payroll.employee")} value={employeeId} onChange={(e) => pickEmployee(e.target.value)} error={errors.employee} disabled={busy}>
              <option value="">-</option>
              {employees.map((e) => <option key={e.employeeId} value={e.employeeId}>{e.fullName}</option>)}
            </SelectInput>
            <FormInput label={t("payroll.month")} type="month" max={currentMonth()} value={period} onChange={(e) => setPeriod(e.target.value)} error={errors.period} disabled={busy} />
          </div>
        )}
        <div className="grid gap-4 sm:grid-cols-3">
          <FormInput label={t("payroll.base")} type="number" min="0" step="0.01" value={base} onChange={(e) => setBase(e.target.value)} error={errors.base} disabled={busy} />
          <FormInput label={t("payroll.bonus")} type="number" min="0" step="0.01" value={bonus} onChange={(e) => setBonus(e.target.value)} error={errors.bonus} disabled={busy} />
          <FormInput label={t("payroll.deductions")} type="number" min="0" step="0.01" value={deductions} onChange={(e) => setDeductions(e.target.value)} error={errors.deductions} disabled={busy} />
        </div>
        <div className="flex items-center justify-between rounded-xl bg-orange-50 px-4 py-3 text-sm">
          <span className="text-gray-600">{t("payroll.net")} = {t("payroll.base")} + {t("payroll.bonus")} - {t("payroll.deductions")}</span>
          <span className="text-base font-semibold text-orange-700">{formatMoney(Number.isFinite(net) ? net : 0)}</span>
        </div>
        <FormInput label={t("payroll.notes")} value={notes} maxLength={300} onChange={(e) => setNotes(e.target.value)} error={errors.notes} disabled={busy} />
        {errors.form && <p className="rounded-lg bg-red-50 px-3 py-2 text-sm text-red-700">{errors.form}</p>}
        <div className="flex justify-end gap-2">
          <button onClick={onClose} disabled={busy} className="rounded-lg border border-gray-300 px-4 py-2 text-sm hover:bg-gray-50">{t("dataGate.cancel")}</button>
          <button onClick={submit} disabled={busy} className="rounded-lg bg-orange-500 px-4 py-2 text-sm font-medium text-white hover:bg-orange-600 disabled:opacity-60">{busy ? t("common.loading") : t("account.save")}</button>
        </div>
      </div>
    </Modal>
  );
}
