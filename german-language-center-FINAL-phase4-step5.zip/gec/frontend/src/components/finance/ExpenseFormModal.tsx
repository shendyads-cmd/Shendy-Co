import { useState } from "react";
import FormInput from "../FormInput";
import Modal from "../Modal";
import SelectInput from "../SelectInput";
import { usePreferences } from "../../contexts/PreferencesContext";
import { useToast } from "../../contexts/ToastContext";
import { parseError } from "../../services/api";
import { expenseService } from "../../services/expenseService";
import type { Expense } from "../../types";
import { toDateInput, todayInput } from "../../utils/format";
import { useIdempotencyKey } from "../../utils/idempotency";

/** Same list as the server (salaries are paid through Payroll, so they are not an expense category). The server validates it again. */
export const EXPENSE_CATEGORIES = ["Rent", "Utilities", "Supplies", "Marketing", "Maintenance", "Transport", "Other"];

interface Props { expense?: Expense | null; onClose: () => void; onSaved: () => void }

/** New / edit expense. Saving also creates (or updates) its Cash Out on the server, in one transaction. */
export default function ExpenseFormModal({ expense, onClose, onSaved }: Props) {
  const { t } = usePreferences();
  const toast = useToast();
  const idem = useIdempotencyKey();
  const [title, setTitle] = useState(expense?.title ?? "");
  const [category, setCategory] = useState(expense && EXPENSE_CATEGORIES.includes(expense.category) ? expense.category : expense ? "" : EXPENSE_CATEGORIES[0]);
  const [amount, setAmount] = useState(expense ? String(expense.amount) : "");
  const [date, setDate] = useState(expense ? toDateInput(expense.expenseDate) : todayInput());
  const [description, setDescription] = useState(expense?.description ?? "");
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [busy, setBusy] = useState(false);

  const submit = async () => {
    if (busy) return;
    const errs: Record<string, string> = {};
    const value = Number(amount);
    if (title.trim().length < 2) errs.title = t("exp.titleRequired");
    if (!category) errs.category = t("exp.categoryRequired");
    if (!amount.trim() || !Number.isFinite(value) || value <= 0) errs.amount = t("pay.amountPositive");
    if (!date) errs.date = t("exp.dateRequired");
    else if (date > todayInput()) errs.date = t("exp.dateFuture");
    if (description.length > 500) errs.description = t("exp.descTooLong");
    setErrors(errs);
    if (Object.keys(errs).length) return;

    setBusy(true);
    const body = { title: title.trim(), category, amount: value, expenseDate: date, description: description.trim() || undefined };
    try {
      if (expense) await expenseService.update(expense.expenseId, body);
      else { await expenseService.create(body, idem.current()); idem.renew(); }
      toast.success(expense ? t("exp.updated") : t("exp.created"));
      onSaved();
      onClose();
    } catch (err) { setErrors({ form: parseError(err).message }); }
    finally { setBusy(false); }
  };

  return (
    <Modal open title={expense ? t("exp.edit") : t("exp.new")} onClose={onClose} wide>
      <div className="space-y-4">
        <FormInput label={t("exp.fieldTitle")} value={title} maxLength={150} onChange={(e) => setTitle(e.target.value)} error={errors.title} disabled={busy} autoFocus />
        <div className="grid gap-4 sm:grid-cols-2">
          <SelectInput label={t("exp.category")} value={category} onChange={(e) => setCategory(e.target.value)} error={errors.category} disabled={busy}>
            {!category && <option value="">-</option>}
            {EXPENSE_CATEGORIES.map((c) => <option key={c} value={c}>{t(`expcat.${c}`)}</option>)}
          </SelectInput>
          <FormInput label={t("pay.amount")} type="number" min="0" step="0.01" value={amount} onChange={(e) => setAmount(e.target.value)} error={errors.amount} disabled={busy} />
        </div>
        <FormInput label={t("exp.date")} type="date" max={todayInput()} value={date} onChange={(e) => setDate(e.target.value)} error={errors.date} disabled={busy} />
        <div className="space-y-1">
          <label htmlFor="exp-desc" className="block text-sm font-medium text-gray-700">{t("exp.description")}</label>
          <textarea id="exp-desc" rows={3} maxLength={500} value={description} onChange={(e) => setDescription(e.target.value)} disabled={busy}
                    className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm outline-none focus:border-orange-500 focus:ring-2 focus:ring-orange-300" />
          {errors.description && <p className="text-xs text-red-600">{errors.description}</p>}
        </div>
        {errors.form && <p className="rounded-lg bg-red-50 px-3 py-2 text-sm text-red-700">{errors.form}</p>}
        <div className="flex justify-end gap-2">
          <button onClick={onClose} disabled={busy} className="rounded-lg border border-gray-300 px-4 py-2 text-sm hover:bg-gray-50">{t("dataGate.cancel")}</button>
          <button onClick={submit} disabled={busy} className="rounded-lg bg-orange-500 px-4 py-2 text-sm font-medium text-white hover:bg-orange-600 disabled:opacity-60">
            {busy ? t("common.loading") : t("account.save")}
          </button>
        </div>
      </div>
    </Modal>
  );
}
