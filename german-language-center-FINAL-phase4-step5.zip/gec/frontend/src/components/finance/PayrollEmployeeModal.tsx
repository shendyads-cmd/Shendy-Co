import { useState } from "react";
import FormInput from "../FormInput";
import Modal from "../Modal";
import { usePreferences } from "../../contexts/PreferencesContext";
import { useToast } from "../../contexts/ToastContext";
import { parseError } from "../../services/api";
import { payrollService } from "../../services/payrollService";
import type { PayrollEmployee } from "../../types";
import { useIdempotencyKey } from "../../utils/idempotency";

interface Props { employee?: PayrollEmployee | null; onClose: () => void; onSaved: () => void }

/** New / edit payroll employee. Changing the base salary only affects FUTURE salary entries. */
export default function PayrollEmployeeModal({ employee, onClose, onSaved }: Props) {
  const { t } = usePreferences();
  const toast = useToast();
  const idem = useIdempotencyKey();
  const [name, setName] = useState(employee?.fullName ?? "");
  const [job, setJob] = useState(employee?.jobTitle ?? "");
  const [phone, setPhone] = useState(employee?.phone ?? "");
  const [salary, setSalary] = useState(employee ? String(employee.baseSalary) : "");
  const [active, setActive] = useState(employee?.isActive ?? true);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [busy, setBusy] = useState(false);

  const submit = async () => {
    if (busy) return;
    const errs: Record<string, string> = {};
    const value = Number(salary);
    if (name.trim().length < 2) errs.name = t("payroll.nameRequired");
    if (phone.trim() && !/^[0-9+()\-\s]{6,30}$/.test(phone.trim())) errs.phone = t("payroll.phoneInvalid");
    if (salary.trim() === "" || !Number.isFinite(value) || value < 0) errs.salary = t("payroll.nonNegative");
    setErrors(errs);
    if (Object.keys(errs).length) return;

    setBusy(true);
    const body = { fullName: name.trim(), jobTitle: job.trim() || undefined, phone: phone.trim() || undefined, baseSalary: value, isActive: active };
    try {
      if (employee) await payrollService.updateEmployee(employee.employeeId, body);
      else { await payrollService.createEmployee(body, idem.current()); idem.renew(); }
      toast.success(t("payroll.employeeSaved"));
      onSaved();
      onClose();
    } catch (err) { setErrors({ form: parseError(err).message }); }
    finally { setBusy(false); }
  };

  return (
    <Modal open title={employee ? t("payroll.editEmployee") : t("payroll.newEmployee")} onClose={onClose} wide>
      <div className="space-y-4">
        <FormInput label={t("payroll.employeeName")} value={name} maxLength={150} onChange={(e) => setName(e.target.value)} error={errors.name} disabled={busy} autoFocus />
        <div className="grid gap-4 sm:grid-cols-2">
          <FormInput label={t("payroll.jobTitle")} value={job} maxLength={100} onChange={(e) => setJob(e.target.value)} disabled={busy} />
          <FormInput label={t("payroll.phone")} value={phone} maxLength={30} onChange={(e) => setPhone(e.target.value)} error={errors.phone} disabled={busy} />
        </div>
        <FormInput label={t("payroll.base")} type="number" min="0" step="0.01" value={salary} onChange={(e) => setSalary(e.target.value)} error={errors.salary} disabled={busy} />
        <label className="flex items-center gap-2 text-sm text-gray-700">
          <input type="checkbox" checked={active} onChange={(e) => setActive(e.target.checked)} disabled={busy} className="h-4 w-4 accent-orange-500" /> {t("common.active")}
        </label>
        {errors.form && <p className="rounded-lg bg-red-50 px-3 py-2 text-sm text-red-700">{errors.form}</p>}
        <div className="flex justify-end gap-2">
          <button onClick={onClose} disabled={busy} className="rounded-lg border border-gray-300 px-4 py-2 text-sm hover:bg-gray-50">{t("dataGate.cancel")}</button>
          <button onClick={submit} disabled={busy} className="rounded-lg bg-orange-500 px-4 py-2 text-sm font-medium text-white hover:bg-orange-600 disabled:opacity-60">{busy ? t("common.loading") : t("account.save")}</button>
        </div>
      </div>
    </Modal>
  );
}
