import { useState } from "react";
import FormInput from "../FormInput";
import Modal from "../Modal";
import SelectInput from "../SelectInput";
import { usePreferences } from "../../contexts/PreferencesContext";
import { useToast } from "../../contexts/ToastContext";
import { parseError } from "../../services/api";
import { invoiceService } from "../../services/invoiceService";
import type { PaymentMethod } from "../../types";
import { formatMoney } from "../../utils/format";
import { useIdempotencyKey } from "../../utils/idempotency";

interface Props {
  invoice: { invoiceId: number; invoiceNumber: string; grandTotal: number; amountPaid: number };
  onClose: () => void;
  onSaved: () => void;
}

const METHODS: PaymentMethod[] = ["Cash", "InstaPay"];
const PROOF_EXTENSIONS = [".jpg", ".jpeg", ".png", ".pdf"];

/** Records an additional (partial or final) payment on an existing invoice. Cash or InstaPay only. The server has the last word on the amount. */
export default function AddPaymentModal({ invoice, onClose, onSaved }: Props) {
  const { t } = usePreferences();
  const toast = useToast();
  const idem = useIdempotencyKey();
  const remaining = Math.max(0, Math.round((invoice.grandTotal - invoice.amountPaid) * 100) / 100);
  const [amount, setAmount] = useState(remaining.toFixed(2));
  const [method, setMethod] = useState<PaymentMethod>("Cash");
  const [proof, setProof] = useState<File | null>(null);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [busy, setBusy] = useState(false);

  const submit = async () => {
    if (busy) return;
    const value = Number(amount);
    const errs: Record<string, string> = {};
    if (!amount.trim() || !Number.isFinite(value) || value <= 0) errs.amount = t("pay.amountPositive");
    else if (Math.round(value * 100) > Math.round(remaining * 100)) errs.amount = `${t("pay.amountMax")} (${formatMoney(remaining)}).`;
    if (proof && method === "InstaPay") {
      const lower = proof.name.toLowerCase();
      if (!PROOF_EXTENSIONS.some((x) => lower.endsWith(x))) errs.proof = t("pay.proofType");
      else if (proof.size > 5 * 1024 * 1024) errs.proof = t("pay.proofSize");
    }
    setErrors(errs);
    if (Object.keys(errs).length) return;

    setBusy(true);
    try {
      const res = await invoiceService.addPayment(invoice.invoiceId, { amount: value, paymentMethod: method }, method === "InstaPay" ? proof : null, idem.current());
      idem.renew();
      toast.success(`${t("pay.saved")} ${t("pay.remaining")}: ${formatMoney(res.remaining)}`);
      onSaved();
      onClose();
    } catch (err) {
      // the same key stays in place: pressing Save again after a network error can never record the payment twice
      setErrors({ amount: parseError(err).message });
    } finally { setBusy(false); }
  };

  return (
    <Modal open title={`${t("pay.title")} - ${invoice.invoiceNumber}`} onClose={onClose}>
      <div className="space-y-4">
        <dl className="grid grid-cols-3 gap-2 rounded-xl bg-orange-50 p-3 text-sm">
          <div><dt className="text-gray-500">{t("invoices.total")}</dt><dd className="font-semibold text-gray-900">{formatMoney(invoice.grandTotal)}</dd></div>
          <div><dt className="text-gray-500">{t("pay.paid")}</dt><dd className="font-semibold text-gray-900">{formatMoney(invoice.amountPaid)}</dd></div>
          <div><dt className="text-gray-500">{t("pay.remaining")}</dt><dd className="font-semibold text-orange-700">{formatMoney(remaining)}</dd></div>
        </dl>
        <FormInput label={t("pay.amount")} type="number" min="0" step="0.01" value={amount} onChange={(e) => { setAmount(e.target.value); setErrors({}); }} error={errors.amount} disabled={busy} autoFocus />
        <SelectInput label={t("pay.method")} value={method} onChange={(e) => { setMethod(e.target.value as PaymentMethod); setProof(null); }} disabled={busy}>
          {METHODS.map((m) => <option key={m} value={m}>{t(`method.${m}`)}</option>)}
        </SelectInput>
        {method === "InstaPay" && (
          <div className="space-y-1">
            <label htmlFor="pay-proof" className="block text-sm font-medium text-gray-700">{t("pay.proof")}</label>
            <input id="pay-proof" type="file" accept=".jpg,.jpeg,.png,.pdf,image/jpeg,image/png,application/pdf" onChange={(e) => setProof(e.target.files?.[0] ?? null)} disabled={busy}
                   className="block w-full text-sm text-gray-600 file:me-3 file:rounded-lg file:border-0 file:bg-orange-50 file:px-3 file:py-2 file:text-sm file:font-medium file:text-orange-700" />
            {errors.proof && <p className="text-xs text-red-600">{errors.proof}</p>}
          </div>
        )}
        <div className="flex justify-end gap-2">
          <button onClick={onClose} disabled={busy} className="rounded-lg border border-gray-300 px-4 py-2 text-sm hover:bg-gray-50">{t("dataGate.cancel")}</button>
          <button onClick={submit} disabled={busy || remaining <= 0} className="rounded-lg bg-orange-500 px-4 py-2 text-sm font-medium text-white hover:bg-orange-600 disabled:opacity-60">
            {busy ? t("common.loading") : t("account.save")}
          </button>
        </div>
      </div>
    </Modal>
  );
}
