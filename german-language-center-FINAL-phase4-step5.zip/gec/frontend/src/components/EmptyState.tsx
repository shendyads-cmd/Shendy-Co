import type { LucideIcon } from "lucide-react";
import { Inbox } from "lucide-react";

export default function EmptyState({ title, text, icon: Icon = Inbox }: { title: string; text?: string; icon?: LucideIcon }) {
  return (
    <div className="flex flex-col items-center gap-2 py-12 text-center">
      <div className="rounded-full bg-orange-50 p-3"><Icon className="h-6 w-6 text-orange-500" /></div>
      <p className="font-medium text-gray-800">{title}</p>
      {text && <p className="max-w-sm text-sm text-gray-500">{text}</p>}
    </div>
  );
}
