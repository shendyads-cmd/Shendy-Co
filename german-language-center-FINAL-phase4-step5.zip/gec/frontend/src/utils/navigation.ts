import { BarChart3, BookOpen, Database, LayoutDashboard, Receipt, Users } from "lucide-react";
import type { LucideIcon } from "lucide-react";
import type { Role } from "../types";

export interface NavItem {
  path: string;
  label: string;
  icon: LucideIcon;
  roles: Role[];
  /** Shown at the bottom of the sidebar, separated from the main items. */
  bottom?: boolean;
}

const both: Role[] = ["Admin", "Employee"];
const admin: Role[] = ["Admin"];

/**
 * The sidebar has exactly these six items. Expenses, Payroll, Payments, Offers, Schedule, Audit Log, Notifications and
 * account settings are reached from inside these screens or from the top bar, never from extra sidebar items.
 */
export const navItems: NavItem[] = [
  { path: "/dashboard", label: "Dashboard", icon: LayoutDashboard, roles: admin },
  { path: "/students", label: "Students", icon: Users, roles: both },
  { path: "/courses", label: "Courses", icon: BookOpen, roles: both },
  { path: "/invoices", label: "Invoices", icon: Receipt, roles: both },
  { path: "/reports", label: "Reports", icon: BarChart3, roles: admin },
  // Everyone sees Data; staff must enter the Data password first (the API checks it as well).
  { path: "/data", label: "Data", icon: Database, roles: both, bottom: true }
];

export const homePath = (role: Role): string => (role === "Admin" ? "/dashboard" : "/students");
