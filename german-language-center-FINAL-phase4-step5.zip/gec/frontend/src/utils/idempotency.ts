import { useRef } from "react";

/** A fresh random key. One key = one user intent ("create this student"), not one HTTP call. */
export function newIdempotencyKey(): string {
  const c = globalThis.crypto;
  if (c?.randomUUID) return c.randomUUID();
  const bytes = new Uint8Array(16);
  if (c?.getRandomValues) c.getRandomValues(bytes);
  else for (let i = 0; i < bytes.length; i++) bytes[i] = Math.floor(Math.random() * 256);
  return Array.from(bytes, (b) => b.toString(16).padStart(2, "0")).join("");
}

/**
 * Holds the Idempotency-Key of the form that is open right now.
 * - The SAME key is sent again when the user retries (double click, timeout, error) so the server never creates the record twice.
 * - Call renew() after the operation succeeded or when the form is opened again: the next save is a new intent with a new key.
 * The server is the real protection; this only supplies the key (buttons are also disabled while saving, for UX).
 */
export function useIdempotencyKey() {
  const ref = useRef<string>(newIdempotencyKey());
  return {
    current: () => ref.current,
    renew: () => { ref.current = newIdempotencyKey(); }
  };
}

/** Header object for axios. */
export const idempotencyHeaders = (key: string) => ({ "Idempotency-Key": key });
