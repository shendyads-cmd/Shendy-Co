import type { CourseStatus, EnrollmentStatus } from "../types";

const currency: string = import.meta.env.VITE_CURRENCY ?? "EGP";

export const formatMoney = (n: number): string =>
  new Intl.NumberFormat(undefined, { style: "currency", currency }).format(n);

const pad = (n: number) => String(n).padStart(2, "0");

/** Date-only strings ("2026-07-01") are read as local dates so they never shift by a day. */
const toDate = (s: string): Date => {
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(s);
  return m ? new Date(Number(m[1]), Number(m[2]) - 1, Number(m[3])) : new Date(s);
};

/** 05/10/2026 */
export const formatDate = (s?: string | null): string => {
  if (!s) return "-";
  const d = toDate(s);
  return Number.isNaN(d.getTime()) ? "-" : `${pad(d.getDate())}/${pad(d.getMonth() + 1)}/${d.getFullYear()}`;
};

/** 02:30 AM */
export const formatTime = (s?: string | null): string => {
  if (!s) return "-";
  const d = new Date(s);
  if (Number.isNaN(d.getTime())) return "-";
  const h = d.getHours();
  return `${pad(h % 12 === 0 ? 12 : h % 12)}:${pad(d.getMinutes())} ${h < 12 ? "AM" : "PM"}`;
};

/** Date -> "2026-07-01" (what the API expects for fromDate / toDate). */
export const toIsoDate = (d: Date): string => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
export const parseIsoDate = (s?: string): Date | undefined => (s ? toDate(s) : undefined);

/** "2026-10-02T00:00:00" -> "2026-10-02" for <input type="date">. */
export const toDateInput = (s?: string | null): string => (s ? s.slice(0, 10) : "");

export const todayInput = (): string => {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
};

export const statusTone = (s: EnrollmentStatus): "green" | "gray" | "red" =>
  s === "Active" ? "green" : s === "Completed" ? "gray" : "red";

export const courseTone = (s: CourseStatus): "green" | "orange" | "gray" =>
  s === "Open" ? "green" : s === "Full" ? "orange" : "gray";
