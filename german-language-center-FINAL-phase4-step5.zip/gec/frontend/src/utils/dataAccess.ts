/**
 * Data access token (staff only). It is returned by the API after the correct Data password was entered and is sent
 * in the X-Data-Token header on every /data request. It lives in sessionStorage: closing the browser or logging out removes it.
 * This is only a convenience for the screen; the API checks the token on every request and decides.
 */
const KEY = "gec.dataToken";

interface Stored { token: string; exp: number }

export const setDataToken = (token: string, expiresAtUtc: string): void => {
  try { sessionStorage.setItem(KEY, JSON.stringify({ token, exp: new Date(expiresAtUtc).getTime() } satisfies Stored)); } catch { /* storage unavailable */ }
};

export const getDataToken = (): string | null => {
  try {
    const raw = sessionStorage.getItem(KEY);
    if (!raw) return null;
    const s = JSON.parse(raw) as Stored;
    if (!s.token || !(s.exp > Date.now())) { sessionStorage.removeItem(KEY); return null; }
    return s.token;
  } catch { return null; }
};

export const clearDataToken = (): void => {
  try { sessionStorage.removeItem(KEY); } catch { /* storage unavailable */ }
};
