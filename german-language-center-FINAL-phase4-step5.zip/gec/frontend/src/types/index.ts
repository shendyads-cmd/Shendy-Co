export type Role = "Admin" | "Employee";

export interface UserDto {
  userId: number;
  username: string;
  fullName?: string | null;
  role: Role;
  isActive: boolean;
  createdAt?: string | null;
}

export type AuthUser = UserDto;

export interface DataAccessStatus { requiresPassword: boolean; passwordConfigured: boolean }
/** token is null for an Admin (direct access). */
export interface DataUnlockResult { token: string | null; expiresAtUtc: string | null }

export interface LoginResponse {
  token: string;
  expiresAtUtc: string;
  user: UserDto;
}

export interface ApiError {
  code: string;
  message: string;
  traceId?: string;
}

export interface CreateUserRequest {
  username: string;
  fullName?: string;
  role: Role;
  password: string;
}

export interface UpdateUserRequest {
  fullName?: string;
  role: Role;
  isActive: boolean;
}

// ---------- Phase 2 ----------
export interface ListParams {
  search?: string;
  page: number;
  pageSize: number;
  sortBy: string;
  sortDir: "asc" | "desc";
}

export interface PagedResult<T> {
  items: T[];
  total: number;
  page: number;
  pageSize: number;
}

export interface Customer {
  customerId: number;
  /** Auto-generated Student ID, e.g. STU-0001. */
  studentCode: string;
  /** Codes of the courses the student is registered in now. */
  courseCodes: string[];
  fullName: string;
  phone?: string | null;
  email?: string | null;
  address?: string | null;
  area?: string | null;
  isActive: boolean;
  createdAt?: string | null;
  enrollmentCount: number;
}

export type CourseStatus = "Open" | "Full" | "Deactivated";

export interface Course {
  courseId: number;
  /** Auto-generated, sequential: A-001, A-002... */
  courseCode: string;
  courseName: string;
  price: number;
  maxCapacity: number;
  /** Students currently registered. */
  enrolledCount: number;
  isFull: boolean;
  isActive: boolean;
  /** Open = seats free, Complete = capacity reached (automatic), Deactivated = switched off by an administrator. */
  status: CourseStatus;
}

export type EnrollmentStatus = "Active" | "Completed" | "Cancelled";

export interface Enrollment {
  enrollmentId: number;
  customerId: number;
  studentCode: string;
  studentName: string;
  courseId: number;
  courseCode: string;
  courseName: string;
  enrollmentDate: string;
  startDate?: string | null;
  endDate?: string | null;
  totalAmount: number;
  status: EnrollmentStatus;
  /** True when the course has been marked Completed (history). */
  courseCompleted: boolean;
  /** Student = registered alone, Offer = invoice shared with other students. */
  type: InvoiceType;
  invoiceNumber?: string | null;
}

export interface CustomerStats { total: number; active: number; inactive: number; deleted: number }
export interface CustomerDetails { customer: Customer; enrollments: Enrollment[] }
export interface CourseDetails { course: Course; enrollments: Enrollment[] }

// ---------- Deleted records (kept for history) ----------
export interface EnrollmentSummary {
  courseCode: string;
  courseName: string;
  status: EnrollmentStatus;
  enrollmentDate: string;
  totalAmount: number;
  courseDeleted: boolean;
}

export interface DeletedCustomer {
  customerId: number;
  studentCode: string;
  fullName: string;
  phone?: string | null;
  email?: string | null;
  address?: string | null;
  isActive: boolean;
  createdAt: string;
  deletedAt?: string | null;
  deletionReason?: string | null;
  enrollments: EnrollmentSummary[];
}

export interface DeletedCourse {
  courseId: number;
  courseCode: string;
  courseName: string;
  price: number;
  maxCapacity: number;
  enrolledCount: number;
  isActive: boolean;
  deletedAt?: string | null;
  deletionReason?: string | null;
}

// ---------- Data (completed courses, read-only) ----------
export interface FinancialSummary {
  totalAmount: number;
  totalPaid: number;
  totalRemaining: number;
  paidCount: number;
  partialCount: number;
  unpaidCount: number;
}

export interface CompletedCourse {
  courseId: number;
  courseCode: string;
  courseName: string;
  price: number;
  maxCapacity: number;
  completedAt?: string | null;
  studentCount: number;
  status: "Completed";
  /** Null when the invoicing tables are not ready yet. */
  financial?: FinancialSummary | null;
}

/** "No invoice" = registered before invoicing existed. */
export type PaymentStatus = "Paid" | "Partially Paid" | "Unpaid" | "No invoice";

export interface HistoricalStudent {
  customerId: number;
  studentCode: string;
  fullName: string;
  enrollmentDate: string;
  enrollmentStatus: EnrollmentStatus;
  paymentStatus: PaymentStatus;
  invoiceNumber?: string | null;
}

export interface CompletedCourseDetails { course: CompletedCourse; students: HistoricalStudent[] }

export interface HistoricalPayment {
  paymentId: number;
  paymentDate: string;
  amount: number;
  paymentMethod: string;
  paymentMethodOther?: string | null;
  hasProof: boolean;
  proofFileName?: string | null;
  proofContentType?: string | null;
}

export interface HistoricalInvoice {
  invoiceId: number;
  invoiceNumber: string;
  issueDate: string;
  coursePrice: number;
  discountPercent: number;
  discountAmount: number;
  finalAmount: number;
  amountPaid: number;
  remaining: number;
  status: string;
}

export interface HistoricalStudentDetails {
  customerId: number;
  studentCode: string;
  fullName: string;
  phone?: string | null;
  email?: string | null;
  address?: string | null;
  area?: string | null;
  courseId: number;
  courseCode: string;
  courseName: string;
  enrollmentDate: string;
  enrollmentStatus: string;
  invoice?: HistoricalInvoice | null;
  payments: HistoricalPayment[];
}

export interface DeleteCourseDataResult {
  courseId: number;
  courseCode: string;
  invoicesDeleted: number;
  paymentsDeleted: number;
  paymentsKept: number;
  allocationsDeleted: number;
  enrollmentsDeleted: number;
}

// ---------- New Student / Add Course (invoice + payment) ----------
/** Methods a NEW payment can use. Stored history may also contain Visa, Bank Transfer, Vodafone Cash or Other (shown as plain text). */
export type PaymentMethod = "Cash" | "InstaPay";

export interface RegistrationResult {
  customerId: number;
  studentCode: string;
  studentName: string;
  enrollmentId: number;
  invoiceId: number;
  invoiceNumber: string;
  issueDate: string;
  courseId: number;
  courseCode: string;
  courseName: string;
  coursePrice: number;
  discountPercent: number;
  discountAmount: number;
  finalAmount: number;
  amountPaid: number;
  remaining: number;
  paymentStatus: string;
  paymentId?: number | null;
  paymentMethod?: string | null;
  paymentMethodOther?: string | null;
  paymentDate?: string | null;
  hasProof: boolean;
}

// ---------- Phase 3: Student / Offer invoices ----------
export type InvoiceType = "Student" | "Offer";

export interface InvoiceStudentInput { customerId?: number; fullName?: string; email?: string; phone?: string; area?: string }

export interface InvoiceDraft {
  type: InvoiceType;
  students: InvoiceStudentInput[];
  courseId: number;
  discountPercent: number;
  amountPaid: number;
  paymentMethod: PaymentMethod;
}

export interface InvoicePreview {
  type: InvoiceType;
  courseId: number;
  courseCode: string;
  courseName: string;
  quantity: number;
  unitPrice: number;
  subtotal: number;
  discountPercent: number;
  discountAmount: number;
  grandTotal: number;
  amountPaid: number;
  remaining: number;
  paymentStatus: string;
  paymentMethod?: string | null;
  paymentMethodOther?: string | null;
  previewDate: string;
  studentNames: string[];
}

export interface InvoiceListItem {
  invoiceId: number;
  invoiceNumber: string;
  issueDate: string;
  type: InvoiceType;
  studentCount: number;
  studentLabel: string;
  courseLabel: string;
  subtotal: number;
  discountAmount: number;
  grandTotal: number;
  amountPaid: number;
  paymentStatus: string;
}

export interface InvoiceDetails {
  invoiceId: number;
  invoiceNumber: string;
  issueDate: string;
  type: InvoiceType;
  subtotal: number;
  discountPercent: number;
  discountAmount: number;
  grandTotal: number;
  amountPaid: number;
  remaining: number;
  paymentStatus: string;
  createdBy?: string | null;
  canEdit: boolean;
  students: { customerId: number; studentCode: string; fullName: string }[];
  items: { courseId: number; courseCode: string; courseName: string; quantity: number; unitPrice: number; subtotal: number }[];
  payments: { paymentId: number; paymentDate: string; amount: number; paymentMethod: string; paymentMethodOther?: string | null; hasProof: boolean }[];
}

export interface Expense {
  expenseId: number;
  title: string;
  amount: number;
  category: string;
  expenseDate: string;
  description?: string | null;
  createdBy?: string | null;
}
export interface ExpensePage extends PagedResult<Expense> { totalAmount: number }
export interface ExpenseInput { title: string; category: string; amount: number; expenseDate: string; description?: string }

/** Result of recording an additional payment on an invoice. */
export interface PaymentResult {
  paymentId: number; invoiceId: number; invoiceNumber: string; amount: number; paymentMethod: string; paymentDate: string;
  grandTotal: number; amountPaid: number; remaining: number; paymentStatus: string;
}

// ---------------------------------------------------------------- payroll
export interface PayrollEmployee { employeeId: number; fullName: string; jobTitle?: string | null; phone?: string | null; baseSalary: number; isActive: boolean }
export interface PayrollEmployeeInput { fullName: string; jobTitle?: string; phone?: string; baseSalary: number; isActive: boolean }
export type PayrollStatus = "Pending" | "Paid";
export interface PayrollEntry {
  payrollId: number; employeeId: number; employeeName: string; year: number; month: number;
  baseSalary: number; bonus: number; deductions: number; netSalary: number; status: PayrollStatus; notes?: string | null; paidAt?: string | null;
}
export interface PayrollPage extends PagedResult<PayrollEntry> { totalNet: number; totalPaid: number; totalPending: number }
export interface PayrollInput { employeeId: number; year: number; month: number; baseSalary: number; bonus: number; deductions: number; notes?: string }

// ---------------------------------------------------------------- notifications
/** One notification as seen by the signed-in user (isRead is THAT user's own state). */
export interface AppNotification {
  notificationId: number;
  type: string;
  source: string;
  /** English fallback; the screen translates from type + paramsJson. */
  title: string;
  message: string;
  paramsJson?: string | null;
  linkPath?: string | null;
  createdAt: string;
  isRead: boolean;
}
export interface NotificationList { items: AppNotification[]; unreadCount: number }
export interface UnreadCount { unreadCount: number }


// ---------------------------------------------------------------- analytics (Dashboard + Reports)
export interface FinancialSummary {
  fromDate?: string | null; toDate?: string | null;
  sales: number; invoiceCount: number; collected: number; paymentCount: number; outstanding: number; outstandingCount: number;
  expenses: number; expenseCount: number; payroll: number; payrollPending: number;
  cashIn: number; cashOut: number; netResult: number; cashInDifference: number; cashOutDifference: number;
}
export interface CourseRow {
  courseId: number; code: string; name: string; capacity: number; enrolled: number; occupancyPercent: number;
  revenue: number; paid: number; remaining: number; status: string; rank: number;
}
export interface CourseReport { items: CourseRow[]; totalRevenue: number; totalPaid: number; totalRemaining: number }
export interface TrendPoint { label: string; sales: number; collected: number; cashIn: number; cashOut: number }
export interface DashboardData {
  summary: FinancialSummary; granularity: "day" | "month"; trend: TrendPoint[];
  topCourses: CourseRow[]; occupancy: CourseRow[]; openCourses: number; activeStudents: number;
}
export interface ReportParams { fromDate?: string; toDate?: string; page?: number; pageSize?: number }
export interface SalesRow { invoiceId: number; invoiceNumber: string; issueDate: string; type: string; studentLabel: string; courseLabel: string; subtotal: number; discount: number; grandTotal: number; paid: number; paymentStatus: string }
export interface SalesReport extends PagedResult<SalesRow> { totalSubtotal: number; totalDiscount: number; totalSales: number }
export interface PaymentRow { paymentId: number; paymentDate: string; invoiceId: number; invoiceNumber: string; studentLabel: string; paymentMethod: string; paymentMethodOther?: string | null; amount: number; hasProof: boolean; invoiceStatus: string }
export interface MethodTotal { method: string; count: number; total: number }
export interface PaymentsReport extends PagedResult<PaymentRow> { totalAmount: number; byMethod: MethodTotal[] }
export interface ExpenseReportRow { expenseId: number; expenseDate: string; category: string; title: string; description?: string | null; amount: number; createdBy?: string | null; cashOutId?: number | null }
export interface CategoryTotal { category: string; count: number; total: number }
export interface ExpenseReport extends PagedResult<ExpenseReportRow> { totalAmount: number; withoutCashOut: number; byCategory: CategoryTotal[] }
export interface OutstandingRow { invoiceId: number; invoiceNumber: string; issueDate: string; type: string; studentLabel: string; courseLabel: string; grandTotal: number; paid: number; remaining: number; paymentStatus: string }
export interface OutstandingReport extends PagedResult<OutstandingRow> { totalGrand: number; totalPaid: number; totalRemaining: number }


// ---------------------------------------------------------------- Step 5: audit log, schedule, backup
export interface AuditRow { auditId: number; createdAt: string; userId?: number | null; username?: string | null; action: string; actionType: string; entity: string; reference?: string | null; details?: string | null }
export interface ScheduleEntry { entryId: number; title: string; entryDate: string; entryTime: string; description?: string | null }
export interface ScheduleInput { title: string; entryDate: string; entryTime: string; description?: string }
export interface BackupInfo { backupId: number; createdAt: string; sizeBytes: number; filePath: string }
export interface RestoreResult { restoredAt: string; safetyBackupPath: string }
