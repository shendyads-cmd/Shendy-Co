import { serverMessages, serverPatterns } from "./serverMessages";
import { translations } from "./translations";

/** The language chosen in the top bar (the same storage key as PreferencesContext). */
const currentLanguage = (): "ar" | "en" | "de" => {
  try {
    const v = localStorage.getItem("gec.lang");
    return v === "ar" || v === "de" ? v : "en";
  } catch { return "en"; }
};

/**
 * Translates a message returned by the API into the selected language.
 * Exact texts come from a table, texts with numbers or names inside from patterns; anything unknown stays as the server wrote it (English).
 */
export function translateServerMessage(message: string): string {
  const lang = currentLanguage();
  if (lang === "en" || !message) return message;
  const exact = serverMessages[message];
  if (exact) return exact[lang];
  for (const p of serverPatterns) {
    const m = message.match(p.rx);
    if (m) return p[lang].replace(/\$(\d)/g, (_, i: string) => m[Number(i)] ?? "");
  }
  return message;
}

/** A dictionary text outside React components (for example in the API layer). */
export const tr = (key: string): string => translations[currentLanguage()][key] ?? translations.en[key] ?? key;
