import { api } from "./api";
import { idempotencyHeaders } from "../utils/idempotency";
import type { Expense, ExpenseInput, ExpensePage, ListParams } from "../types";

export const expenseService = {
  list: (params: ListParams & { fromDate?: string; toDate?: string }) => api.get<ExpensePage>("/expenses", { params }).then((r) => r.data),
  /** Saves the expense AND its Cash Out in one step on the server. The key makes a retry or double click harmless. */
  create: (body: ExpenseInput, idempotencyKey: string) =>
    api.post<Expense>("/expenses", body, { headers: idempotencyHeaders(idempotencyKey) }).then((r) => r.data),
  update: (id: number, body: ExpenseInput) => api.put<Expense>(`/expenses/${id}`, body).then((r) => r.data)
};
