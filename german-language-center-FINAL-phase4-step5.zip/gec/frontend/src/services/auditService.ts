import { api } from "./api";
import type { AuditRow, ListParams, PagedResult } from "../types";

export const auditService = {
  list: (params: ListParams & { fromDate?: string; toDate?: string; actionType?: string }) => api.get<PagedResult<AuditRow>>("/audit", { params }).then((r) => r.data),
  types: () => api.get<string[]>("/audit/types").then((r) => r.data)
};
