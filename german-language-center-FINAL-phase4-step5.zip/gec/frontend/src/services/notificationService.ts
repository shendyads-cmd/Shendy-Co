import { api } from "./api";
import type { NotificationList, UnreadCount } from "../types";

export const notificationService = {
  list: (take = 50) => api.get<NotificationList>("/notifications", { params: { take } }).then((r) => r.data),
  unreadCount: () => api.get<UnreadCount>("/notifications/unread-count").then((r) => r.data),
  /** Marks one notification as read for the current user only. */
  markRead: (id: number) => api.post<UnreadCount>(`/notifications/${id}/read`).then((r) => r.data),
  /** Marks every notification as read for the current user only. */
  markAllRead: () => api.post<UnreadCount>("/notifications/read-all").then((r) => r.data)
};
