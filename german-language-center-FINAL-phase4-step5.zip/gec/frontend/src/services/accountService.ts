import { api } from "./api";
import type { UserDto } from "../types";

export const accountService = {
  /** Every user: display name only. */
  updateProfile: (fullName: string) => api.put<UserDto>("/account/profile", { fullName }).then((r) => r.data),
  /** Admin only. */
  changePassword: (currentPassword: string, newPassword: string) =>
    api.post("/account/change-password", { currentPassword, newPassword }).then(() => undefined)
};
