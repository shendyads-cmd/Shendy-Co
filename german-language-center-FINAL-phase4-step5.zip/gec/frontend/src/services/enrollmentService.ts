import { api } from "./api";
import { idempotencyHeaders } from "../utils/idempotency";
import type { Enrollment, EnrollmentStatus, ListParams, PagedResult } from "../types";

export interface EnrollmentFilters {
  status?: string; customerId?: number; courseId?: number; from?: string; to?: string;
}
export interface CreateEnrollmentInput {
  customerId: number; courseId: number; enrollmentDate?: string; startDate?: string; endDate?: string; totalAmount?: number;
}
export interface UpdateEnrollmentInput {
  enrollmentDate: string; startDate?: string; endDate?: string; totalAmount: number; status: EnrollmentStatus;
}

export const enrollmentService = {
  list: (params: ListParams & EnrollmentFilters) =>
    api.get<PagedResult<Enrollment>>("/enrollments", { params }).then((r) => r.data),
  create: (body: CreateEnrollmentInput, idempotencyKey: string) =>
    api.post<Enrollment>("/enrollments", body, { headers: idempotencyHeaders(idempotencyKey) }).then((r) => r.data),
  update: (id: number, body: UpdateEnrollmentInput) => api.put<Enrollment>(`/enrollments/${id}`, body).then((r) => r.data),
  setStatus: (id: number, status: EnrollmentStatus) =>
    api.patch<Enrollment>(`/enrollments/${id}/status`, { status }).then((r) => r.data)
};
