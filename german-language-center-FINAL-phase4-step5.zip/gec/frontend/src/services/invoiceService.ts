import { api } from "./api";
import { idempotencyHeaders } from "../utils/idempotency";
import type { InvoiceDetails, InvoiceDraft, InvoiceListItem, InvoicePreview, InvoiceStudentInput, ListParams, PagedResult, PaymentMethod, PaymentResult } from "../types";

export interface InvoiceFilters { fromDate?: string; toDate?: string; status?: string }
export interface InvoiceUpdateBody { courseId: number; discountPercent: number; students: InvoiceStudentInput[] }

export const invoiceService = {
  /** Search, date range and status are applied by the API in SQL Server. */
  list: (params: ListParams & InvoiceFilters) => api.get<PagedResult<InvoiceListItem>>("/invoices", { params }).then((r) => r.data),
  get: (id: number) => api.get<InvoiceDetails>(`/invoices/${id}`).then((r) => r.data),
  /** The server validates the draft and returns its own calculation. Nothing is saved. */
  preview: (draft: InvoiceDraft) => api.post<InvoicePreview>("/invoices/preview", draft).then((r) => r.data),
  /** Saves the invoice (and its students, enrollments and payment). The optional proof travels in the same request. */
  create: (draft: InvoiceDraft, proof: File | null | undefined, idempotencyKey: string) => {
    const form = new FormData();
    form.append("payload", JSON.stringify(draft));
    if (proof) form.append("proof", proof);
    return api.post<InvoiceDetails>("/invoices", form, { headers: { "Content-Type": "multipart/form-data", ...idempotencyHeaders(idempotencyKey) } }).then((r) => r.data);
  },
  /** An additional payment (Cash or InstaPay) on an existing invoice. The server checks the remaining balance and recalculates the status. */
  addPayment: (id: number, body: { amount: number; paymentMethod: PaymentMethod }, proof: File | null | undefined, idempotencyKey: string) => {
    const form = new FormData();
    form.append("payload", JSON.stringify(body));
    if (proof) form.append("proof", proof);
    return api.post<PaymentResult>(`/invoices/${id}/payments`, form, { headers: { "Content-Type": "multipart/form-data", ...idempotencyHeaders(idempotencyKey) } }).then((r) => r.data);
  },
  /** Updates the SAME invoice. */
  update: (id: number, body: InvoiceUpdateBody) => api.put<InvoiceDetails>(`/invoices/${id}`, body).then((r) => r.data)
};
