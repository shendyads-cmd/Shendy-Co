import { api } from "./api";
import type {
  CourseReport, DashboardData, ExpenseReport, FinancialSummary, OutstandingReport, PayrollPage, PaymentsReport, ReportParams, SalesReport
} from "../types";

// Every number comes from the API (SQL Server does the calculation). From/To are optional ISO dates; the server refuses From > To.
export const reportService = {
  dashboard: (p: ReportParams) => api.get<DashboardData>("/dashboard", { params: p }).then((r) => r.data),
  summary: (p: ReportParams) => api.get<FinancialSummary>("/reports/summary", { params: p }).then((r) => r.data),
  sales: (p: ReportParams) => api.get<SalesReport>("/reports/sales", { params: p }).then((r) => r.data),
  payments: (p: ReportParams) => api.get<PaymentsReport>("/reports/payments", { params: p }).then((r) => r.data),
  expenses: (p: ReportParams) => api.get<ExpenseReport>("/reports/expenses", { params: p }).then((r) => r.data),
  outstanding: (p: ReportParams) => api.get<OutstandingReport>("/reports/outstanding", { params: p }).then((r) => r.data),
  payroll: (p: ReportParams) => api.get<PayrollPage>("/reports/payroll", { params: p }).then((r) => r.data),
  courses: (p: ReportParams) => api.get<CourseReport>("/reports/courses", { params: p }).then((r) => r.data)
};
