import { api } from "./api";
import type { DataAccessStatus, DataUnlockResult } from "../types";

export const dataAccessService = {
  status: () => api.get<DataAccessStatus>("/data-access").then((r) => r.data),
  /** Checks the Data password on the server. An Admin gets no token (none is needed). */
  unlock: (password: string) => api.post<DataUnlockResult>("/data-access/unlock", { password }).then((r) => r.data),
  /** Admin only. The admin's own account password confirms the change. */
  changePassword: (accountPassword: string, newDataPassword: string) =>
    api.put("/data-access/password", { accountPassword, newDataPassword }).then(() => undefined)
};
