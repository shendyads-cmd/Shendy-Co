import { api } from "./api";
import type { AuthUser, LoginResponse } from "../types";

export const authService = {
  login: (username: string, password: string) =>
    api.post<LoginResponse>("/auth/login", { username, password }).then((r) => r.data),
  /** Records the logout in the audit trail. The token is passed explicitly because the caller removes it right afterwards. */
  logout: (token: string) => api.post("/auth/logout", null, { headers: { Authorization: `Bearer ${token}` } }).then(() => undefined),
  me: () => api.get<AuthUser>("/auth/me").then((r) => r.data)
};
