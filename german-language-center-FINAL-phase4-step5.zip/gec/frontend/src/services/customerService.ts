import { api } from "./api";
import { idempotencyHeaders } from "../utils/idempotency";
import type { Customer, CustomerDetails, CustomerStats, DeletedCustomer, ListParams, PagedResult } from "../types";

export interface CustomerInput { fullName: string; phone: string; email?: string; address?: string; area?: string }

export const customerService = {
  list: (params: ListParams & { isActive?: boolean; fromDate?: string; toDate?: string }) =>
    api.get<PagedResult<Customer>>("/customers", { params }).then((r) => r.data),
  stats: () => api.get<CustomerStats>("/customers/stats").then((r) => r.data),
  get: (id: number) => api.get<CustomerDetails>(`/customers/${id}`).then((r) => r.data),
  /** The key makes a repeated request (double click, retry) create ONE student only. */
  create: (body: CustomerInput, idempotencyKey: string) =>
    api.post<Customer>("/customers", body, { headers: idempotencyHeaders(idempotencyKey) }).then((r) => r.data),
  update: (id: number, body: CustomerInput) => api.put<Customer>(`/customers/${id}`, body).then((r) => r.data),
  setActive: (id: number, isActive: boolean) =>
    api.patch<Customer>(`/customers/${id}/status`, { isActive }).then((r) => r.data),
  /** Moves the student to "Deleted students" (history is kept). A reason is required. */
  remove: (id: number, reason: string) => api.delete(`/customers/${id}`, { data: { reason } }).then(() => undefined),
  restore: (id: number) => api.post<Customer>(`/customers/${id}/restore`).then((r) => r.data),
  listDeleted: (params: ListParams) => api.get<PagedResult<DeletedCustomer>>("/customers/deleted", { params }).then((r) => r.data)
};
