import axios from "axios";
import type { ApiError } from "../types";
import { tr, translateServerMessage } from "../i18n/translateServer";
import { clearDataToken, getDataToken } from "../utils/dataAccess";
import { clearToken, getToken } from "../utils/token";

export const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL ?? "/api",
  timeout: 30000
});

api.interceptors.request.use((config) => {
  const token = getToken();
  if (token) config.headers.Authorization = `Bearer ${token}`;
  // The Data area needs the Data token as well (staff). The API decides; the header is only evidence.
  if (config.url?.startsWith("/data/")) {
    const dataToken = getDataToken();
    if (dataToken) config.headers["X-Data-Token"] = dataToken;
  }
  return config;
});

api.interceptors.response.use(
  (response) => response,
  (error) => {
    const isLogin = error.config?.url?.includes("/auth/login");
    if (error.response?.status === 401 && !isLogin) {
      clearToken();
      window.dispatchEvent(new Event("auth:expired"));
    }
    // The Data token expired or the Data password was changed: show the password prompt again.
    if (error.response?.status === 403 && error.response?.data?.code === "DATA_LOCKED") {
      clearDataToken();
      window.dispatchEvent(new Event("data:locked"));
    }
    return Promise.reject(error);
  }
);

export interface ParsedError {
  message: string;
  code?: string;
  status?: number;
}

/** Converts any thrown value into a friendly, user-safe message. */
export function parseError(err: unknown): ParsedError {
  if (axios.isAxiosError(err)) {
    if (!err.response) return { message: tr("ui.cannot_reach_the_server_check") };
    const data = err.response.data as Partial<ApiError> | undefined;
    return {
      message: data?.message ? translateServerMessage(data.message) : tr("ui.something_went_wrong_please_try"),
      code: data?.code,
      status: err.response.status
    };
  }
  return { message: tr("ui.something_went_wrong_please_try") };
}
