import { api } from "./api";
import { idempotencyHeaders } from "../utils/idempotency";
import type { BackupInfo, RestoreResult } from "../types";

export const backupService = {
  list: () => api.get<BackupInfo[]>("/data/backups").then((r) => r.data),
  create: (key: string) => api.post<BackupInfo>("/data/backups", null, { headers: idempotencyHeaders(key), timeout: 30 * 60 * 1000 }).then((r) => r.data),
  /** DESTRUCTIVE. The server checks the typed word and the admin's account password. */
  restore: (id: number, confirmText: string, adminPassword: string) =>
    api.post<RestoreResult>(`/data/backups/${id}/restore`, { confirmText, adminPassword }, { timeout: 60 * 60 * 1000 }).then((r) => r.data)
};
