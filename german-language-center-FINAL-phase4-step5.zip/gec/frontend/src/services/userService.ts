import { api } from "./api";
import type { CreateUserRequest, UpdateUserRequest, UserDto } from "../types";

export const userService = {
  list: (search?: string) =>
    api.get<UserDto[]>("/users", { params: { search: search || undefined } }).then((r) => r.data),
  create: (body: CreateUserRequest) => api.post<UserDto>("/users", body).then((r) => r.data),
  update: (id: number, body: UpdateUserRequest) => api.put<UserDto>(`/users/${id}`, body).then((r) => r.data),
  resetPassword: (id: number, newPassword: string) =>
    api.post(`/users/${id}/reset-password`, { newPassword }).then(() => undefined)
};
