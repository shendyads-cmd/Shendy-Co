import { api } from "./api";
import { idempotencyHeaders } from "../utils/idempotency";
import type { ListParams, PagedResult, PayrollEmployee, PayrollEmployeeInput, PayrollEntry, PayrollInput, PayrollPage } from "../types";

export interface PayrollFilters { year?: number; month?: number; status?: string }

export const payrollService = {
  list: (params: ListParams & PayrollFilters) => api.get<PayrollPage>("/payroll", { params }).then((r) => r.data),
  create: (body: PayrollInput, key: string) => api.post<PayrollEntry>("/payroll", body, { headers: idempotencyHeaders(key) }).then((r) => r.data),
  update: (id: number, body: PayrollInput) => api.put<PayrollEntry>(`/payroll/${id}`, body).then((r) => r.data),
  remove: (id: number) => api.delete(`/payroll/${id}`).then(() => undefined),
  /** Pays the salary: Pending -> Paid and the Cash Out, in one step on the server. */
  pay: (id: number, key: string) => api.post<PayrollEntry>(`/payroll/${id}/pay`, null, { headers: idempotencyHeaders(key) }).then((r) => r.data),

  employees: (params: ListParams & { isActive?: boolean }) => api.get<PagedResult<PayrollEmployee>>("/payroll/employees", { params }).then((r) => r.data),
  createEmployee: (body: PayrollEmployeeInput, key: string) => api.post<PayrollEmployee>("/payroll/employees", body, { headers: idempotencyHeaders(key) }).then((r) => r.data),
  updateEmployee: (id: number, body: PayrollEmployeeInput) => api.put<PayrollEmployee>(`/payroll/employees/${id}`, body).then((r) => r.data)
};
