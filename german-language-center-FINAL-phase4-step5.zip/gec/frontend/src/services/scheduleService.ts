import { api } from "./api";
import type { ScheduleEntry, ScheduleInput } from "../types";

export const scheduleService = {
  list: (params: { fromDate?: string; toDate?: string }) => api.get<ScheduleEntry[]>("/schedule", { params }).then((r) => r.data),
  create: (body: ScheduleInput) => api.post<ScheduleEntry>("/schedule", body).then((r) => r.data),
  update: (id: number, body: ScheduleInput) => api.put<ScheduleEntry>(`/schedule/${id}`, body).then((r) => r.data),
  remove: (id: number) => api.delete(`/schedule/${id}`).then(() => undefined)
};
