import { api } from "./api";
import { idempotencyHeaders } from "../utils/idempotency";
import type { RegistrationResult } from "../types";

export const registrationService = {
  /** Student (new or existing) + enrollment + invoice + payment in one request. Sent as a form so a proof file can travel with it. */
  register: (form: FormData, idempotencyKey: string) =>
    api.post<RegistrationResult>("/registrations", form, { headers: { "Content-Type": "multipart/form-data", ...idempotencyHeaders(idempotencyKey) } }).then((r) => r.data)
};
