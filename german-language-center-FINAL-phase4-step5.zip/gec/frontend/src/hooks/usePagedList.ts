import { useCallback, useEffect, useState } from "react";
import { useToast } from "../contexts/ToastContext";
import { parseError } from "../services/api";
import type { ListParams, PagedResult } from "../types";

type Sort = { sortBy: string; sortDir: "asc" | "desc" };

/** Server-side search (runs on Enter / magnifier), filters, sorting and pagination for list pages. */
export function usePagedList<T, F extends object>(
  fetcher: (p: ListParams & F) => Promise<PagedResult<T>>,
  initialFilters: F,
  initialSort: Sort,
  pageSize = 15
) {
  const toast = useToast();
  const [data, setData] = useState<PagedResult<T>>({ items: [], total: 0, page: 1, pageSize });
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");          // text in the box
  const [applied, setApplied] = useState("");          // text actually searched
  const [filters, setFiltersState] = useState<F>(initialFilters);
  const [page, setPage] = useState(1);
  const [sort, setSort] = useState<Sort>(initialSort);
  const [tick, setTick] = useState(0);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    fetcher({ ...filters, search: applied || undefined, page, pageSize, sortBy: sort.sortBy, sortDir: sort.sortDir } as ListParams & F)
      .then((r) => { if (!cancelled) setData(r); })
      .catch((e) => { if (!cancelled) toast.error(parseError(e).message); })
      .finally(() => { if (!cancelled) setLoading(false); });
    return () => { cancelled = true; };
    // fetcher and toast are stable; they are intentionally not dependencies.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [applied, page, sort, filters, tick, pageSize]);

  // After deleting the last row of a page, step back one page.
  useEffect(() => {
    if (!loading && data.items.length === 0 && page > 1) setPage(page - 1);
  }, [loading, data, page]);

  const setFilters = useCallback((f: Partial<F>) => { setFiltersState((s) => ({ ...s, ...f })); setPage(1); }, []);
  const toggleSort = useCallback((col: string) => {
    setSort((s) => (s.sortBy === col ? { sortBy: col, sortDir: s.sortDir === "asc" ? "desc" : "asc" } : { sortBy: col, sortDir: "asc" }));
    setPage(1);
  }, []);
  const reload = useCallback(() => setTick((t) => t + 1), []);
  /** Enter key and the magnifier button both call this. */
  const submitSearch = useCallback(() => { setApplied(search.trim()); setPage(1); setTick((t) => t + 1); }, [search]);

  return { data, loading, search, setSearch, submitSearch, filters, setFilters, sort, toggleSort, page, setPage, pageSize, reload };
}
