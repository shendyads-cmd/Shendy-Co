import { createContext, useCallback, useContext, useMemo, useState } from "react";
import type { ReactNode } from "react";
import { AlertTriangle, CheckCircle2, XCircle, X } from "lucide-react";
import { parseError } from "../services/api";
import { usePreferences } from "./PreferencesContext";

type Kind = "success" | "error" | "warning";

export interface ToastOptions {
  /** When given, the toast shows an Undo button that runs this function (it must really reverse the operation). */
  undo?: () => Promise<void> | void;
}

interface ToastItem { id: number; kind: Kind; message: string; undo?: () => Promise<void> | void; busy?: boolean }

interface ToastApi {
  success: (message: string, options?: ToastOptions) => void;
  error: (message: string) => void;
  warning: (message: string) => void;
}

const ToastContext = createContext<ToastApi | null>(null);

const styles: Record<Kind, string> = {
  success: "border-green-300 bg-green-50 text-green-800",
  error: "border-red-300 bg-red-50 text-red-800",
  warning: "border-yellow-300 bg-yellow-50 text-yellow-800"
};
const icons = { success: CheckCircle2, error: XCircle, warning: AlertTriangle };

export function ToastProvider({ children }: { children: ReactNode }) {
  const { t } = usePreferences();
  const [items, setItems] = useState<ToastItem[]>([]);

  const dismiss = useCallback((id: number) => setItems((l) => l.filter((x) => x.id !== id)), []);
  const push = useCallback((kind: Kind, message: string, undo?: ToastOptions["undo"]) => {
    const id = Date.now() + Math.random();
    setItems((l) => [...l.slice(-2), { id, kind, message, undo }]);
    setTimeout(() => dismiss(id), undo ? 8000 : 4500); // toasts with Undo stay a little longer
  }, [dismiss]);

  const api = useMemo<ToastApi>(() => ({
    success: (m, o) => push("success", m, o?.undo),
    error: (m) => push("error", m),
    warning: (m) => push("warning", m)
  }), [push]);

  const runUndo = async (item: ToastItem) => {
    if (!item.undo) return;
    setItems((l) => l.map((x) => (x.id === item.id ? { ...x, busy: true } : x)));
    try {
      await item.undo();
      dismiss(item.id);
      push("success", t("ui.undone"));
    } catch (err) {
      dismiss(item.id);
      push("error", `${t("ui.couldnt_undo")}: ${parseError(err).message}`);
    }
  };

  return (
    <ToastContext.Provider value={api}>
      {children}
      <div className="pointer-events-none fixed inset-x-0 top-4 z-[100] flex flex-col items-center gap-2 px-4">
        {items.map((item) => {
          const Icon = icons[item.kind];
          return (
            <div key={item.id} role="status" className={`pointer-events-auto flex w-full max-w-md items-center gap-3 rounded-xl border px-4 py-3 text-sm shadow-lg ${styles[item.kind]}`}>
              <Icon className="h-4 w-4 shrink-0" />
              <span className="flex-1">{item.message}</span>
              {item.undo && (
                <button onClick={() => runUndo(item)} disabled={item.busy}
                        className="rounded-md border border-current px-2.5 py-0.5 text-xs font-semibold hover:bg-white/60 disabled:opacity-50">
                  {item.busy ? "..." : t("ui.undo")}
                </button>
              )}
              <button onClick={() => dismiss(item.id)} aria-label={t("ui.dismiss")}><X className="h-4 w-4" /></button>
            </div>
          );
        })}
      </div>
    </ToastContext.Provider>
  );
}

export function useToast(): ToastApi {
  const ctx = useContext(ToastContext);
  if (!ctx) throw new Error("useToast must be used inside ToastProvider");
  return ctx;
}
