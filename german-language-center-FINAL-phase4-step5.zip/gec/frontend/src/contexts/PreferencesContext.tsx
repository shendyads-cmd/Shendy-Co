import { createContext, useCallback, useContext, useEffect, useMemo, useState } from "react";
import type { ReactNode } from "react";
import { translations } from "../i18n/translations";
import type { Language } from "../i18n/translations";

export type Theme = "light" | "dark";

interface Preferences {
  theme: Theme;
  setTheme: (t: Theme) => void;
  language: Language;
  setLanguage: (l: Language) => void;
  /** Translates a key; falls back to English, then to the supplied fallback / key. */
  t: (key: string, fallback?: string) => string;
  /** Like t, but fills {name} placeholders: tf("ui.course_created", { code: "A-001" }). */
  tf: (key: string, vars: Record<string, string | number>) => string;
}

const THEME_KEY = "gec.theme";
const LANG_KEY = "gec.lang";

/** The saved choice wins; the default is LIGHT (the device preference is deliberately not used). */
const readTheme = (): Theme => {
  try {
    return localStorage.getItem(THEME_KEY) === "dark" ? "dark" : "light";
  } catch { return "light"; }
};
const readLanguage = (): Language => {
  try {
    const v = localStorage.getItem(LANG_KEY);
    return v === "ar" || v === "de" ? v : "en";
  } catch { return "en"; }
};

const PreferencesContext = createContext<Preferences | null>(null);

/** Per-device display preferences (theme + language). Stored in the browser, applied to the whole page. */
export function PreferencesProvider({ children }: { children: ReactNode }) {
  const [theme, setThemeState] = useState<Theme>(readTheme);
  const [language, setLanguageState] = useState<Language>(readLanguage);

  useEffect(() => {
    document.documentElement.classList.toggle("dark", theme === "dark");
  }, [theme]);

  useEffect(() => {
    document.documentElement.lang = language;
    document.documentElement.dir = language === "ar" ? "rtl" : "ltr";
  }, [language]);

  const setTheme = useCallback((t: Theme) => {
    setThemeState(t);
    try { localStorage.setItem(THEME_KEY, t); } catch { /* storage unavailable: keep in memory only */ }
  }, []);
  const setLanguage = useCallback((l: Language) => {
    setLanguageState(l);
    try { localStorage.setItem(LANG_KEY, l); } catch { /* storage unavailable: keep in memory only */ }
  }, []);
  const t = useCallback((key: string, fallback?: string) => translations[language][key] ?? translations.en[key] ?? fallback ?? key, [language]);
  const tf = useCallback((key: string, vars: Record<string, string | number>) => t(key).replace(/\{(\w+)\}/g, (_, k: string) => String(vars[k] ?? "")), [t]);

  const value = useMemo<Preferences>(() => ({ theme, setTheme, language, setLanguage, t, tf }), [theme, setTheme, language, setLanguage, t, tf]);
  return <PreferencesContext.Provider value={value}>{children}</PreferencesContext.Provider>;
}

export function usePreferences(): Preferences {
  const ctx = useContext(PreferencesContext);
  if (!ctx) throw new Error("usePreferences must be used inside PreferencesProvider");
  return ctx;
}
