import { useCallback, useEffect, useState } from "react";
import { KeyRound, Pencil, Plus, Power, Users as UsersIcon } from "lucide-react";
import ConfirmDialog from "../components/ConfirmDialog";
import EmptyState from "../components/EmptyState";
import LoadingSpinner from "../components/LoadingSpinner";
import SearchBox from "../components/SearchBox";
import StatusBadge from "../components/StatusBadge";
import ResetPasswordModal from "../components/users/ResetPasswordModal";
import UserFormModal from "../components/users/UserFormModal";
import { useAuth } from "../contexts/AuthContext";
import { useToast } from "../contexts/ToastContext";
import { parseError } from "../services/api";
import { userService } from "../services/userService";
import type { UserDto } from "../types";
import { usePreferences } from "../contexts/PreferencesContext";

export default function UsersPage({ embedded = false }: { embedded?: boolean }) {
  const { t, tf } = usePreferences();
  const toast = useToast();
  const { user: me } = useAuth();
  const [rows, setRows] = useState<UserDto[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");     // text in the box
  const [applied, setApplied] = useState("");     // text actually searched
  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState<UserDto | null>(null);
  const [resetTarget, setResetTarget] = useState<UserDto | null>(null);
  const [toggleTarget, setToggleTarget] = useState<UserDto | null>(null);
  const [toggling, setToggling] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    try { setRows(await userService.list(applied)); }
    catch (err) { toast.error(parseError(err).message); }
    finally { setLoading(false); }
  }, [applied, toast]);

  useEffect(() => { load(); }, [load]);

  // Enter and the magnifier button both end up here.
  const submitSearch = () => {
    const v = search.trim();
    if (v === applied) load(); else setApplied(v);
  };

  const confirmToggle = async () => {
    if (!toggleTarget) return;
    setToggling(true);
    try {
      const target = toggleTarget;
      const body = (isActive: boolean) => ({ fullName: target.fullName ?? undefined, role: target.role, isActive });
      await userService.update(target.userId, body(!target.isActive));
      toast.success(target.isActive ? t("ui.user_deactivated_successfully") : t("ui.user_activated_successfully"), {
        undo: async () => { await userService.update(target.userId, body(target.isActive)); load(); }
      });
      setToggleTarget(null);
      load();
    } catch (err) {
      toast.error(parseError(err).message);
    } finally {
      setToggling(false);
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          {embedded
            ? <h2 className="text-lg font-semibold text-gray-900">{t("settings.users")}</h2>
            : <h1 className="text-xl font-semibold text-gray-900">{t("settings.users")}</h1>}
          <p className="text-sm text-gray-500">{t("ui.manage_who_can_sign_in")}</p>
        </div>
        <button onClick={() => { setEditing(null); setFormOpen(true); }}
                className="flex items-center gap-2 rounded-lg bg-orange-500 px-4 py-2 text-sm font-medium text-white hover:bg-orange-600">
          <Plus className="h-4 w-4" /> {t("ui.add_user")}
        </button>
      </div>

      <div className="rounded-2xl border border-gray-200 bg-white shadow-sm">
        <div className="border-b border-gray-100 p-4">
          <SearchBox value={search} onChange={setSearch} onSearch={submitSearch} placeholder={t("ui.search_username_or_name")} />
        </div>

        {loading ? <LoadingSpinner /> : rows.length === 0 ? (
          <EmptyState icon={UsersIcon} title={t("ui.no_users_found")} text={t("ui.try_a_different_search_or_3")} />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-start text-sm">
              <thead className="bg-gray-50 text-xs uppercase text-gray-500">
                <tr>
                  <th className="px-4 py-3">{t("account.username")}</th><th className="px-4 py-3">{t("ui.full_name")}</th>
                  <th className="px-4 py-3">{t("account.role")}</th><th className="px-4 py-3">{t("ui.status")}</th>
                  <th className="px-4 py-3">{t("students.created")}</th><th className="px-4 py-3 text-end">{t("ui.actions")}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {rows.map((u) => (
                  <tr key={u.userId} className="hover:bg-orange-50/40">
                    <td className="px-4 py-3 font-medium text-gray-900">{u.username}</td>
                    <td className="px-4 py-3 text-gray-700">{u.fullName || "-"}</td>
                    <td className="px-4 py-3"><StatusBadge tone={u.role === "Admin" ? "orange" : "gray"}>{t(`role.${u.role}`)}</StatusBadge></td>
                    <td className="px-4 py-3"><StatusBadge tone={u.isActive ? "green" : "red"}>{u.isActive ? t("common.active") : t("ui.disabled")}</StatusBadge></td>
                    <td className="px-4 py-3 text-gray-500">{u.createdAt ? new Date(u.createdAt).toLocaleDateString() : "-"}</td>
                    <td className="px-4 py-3">
                      <div className="flex justify-end gap-1">
                        <button title={t("invoices.edit")} onClick={() => { setEditing(u); setFormOpen(true); }} className="icon-btn"><Pencil className="h-4 w-4" /></button>
                        <button title={t("ui.reset_password")} onClick={() => setResetTarget(u)} className="icon-btn"><KeyRound className="h-4 w-4" /></button>
                        <button title={u.isActive ? t("ui.deactivate") : t("ui.activate")} disabled={u.userId === me?.userId} onClick={() => setToggleTarget(u)}
                                className="rounded-lg p-2 text-gray-600 hover:bg-gray-100 disabled:cursor-not-allowed disabled:opacity-40"><Power className="h-4 w-4" /></button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      <UserFormModal open={formOpen} user={editing} onClose={() => setFormOpen(false)} onSaved={load} />
      <ResetPasswordModal user={resetTarget} onClose={() => setResetTarget(null)} />
      <ConfirmDialog open={toggleTarget !== null} busy={toggling} danger={toggleTarget?.isActive}
                     title={toggleTarget?.isActive ? t("ui.deactivate_user") : t("ui.activate_user")}
                     message={toggleTarget?.isActive
                       ? tf("ui.deactivate_user_confirm", { name: toggleTarget?.username ?? "" })
                       : tf("ui.activate_user_confirm", { name: toggleTarget?.username ?? "" })}
                     confirmLabel={toggleTarget?.isActive ? t("ui.deactivate") : t("ui.activate")}
                     onConfirm={confirmToggle} onCancel={() => setToggleTarget(null)} />
    </div>
  );
}
