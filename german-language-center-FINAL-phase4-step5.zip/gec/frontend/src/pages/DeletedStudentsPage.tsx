import { tr } from "../i18n/translateServer";
import { Fragment, useState } from "react";
import { Link } from "react-router-dom";
import { Archive, ArrowLeft, ChevronDown, ChevronUp, RotateCcw } from "lucide-react";
import EmptyState from "../components/EmptyState";
import LoadingSpinner from "../components/LoadingSpinner";
import PageHeader from "../components/PageHeader";
import Pagination from "../components/Pagination";
import SearchBox from "../components/SearchBox";
import StatusBadge from "../components/StatusBadge";
import { useToast } from "../contexts/ToastContext";
import { usePagedList } from "../hooks/usePagedList";
import { parseError } from "../services/api";
import { customerService } from "../services/customerService";
import type { DeletedCustomer } from "../types";
import { formatDate, formatMoney, statusTone } from "../utils/format";
import { usePreferences } from "../contexts/PreferencesContext";

/** Deleted students: history kept for analysis, with Restore. Reached from the Students page (not in the sidebar). */
export default function DeletedStudentsPage() {
  const { t } = usePreferences();
  const toast = useToast();
  const list = usePagedList<DeletedCustomer, Record<string, never>>(customerService.listDeleted, {}, { sortBy: "deleted", sortDir: "desc" });
  const [open, setOpen] = useState<number | null>(null);
  const [busyId, setBusyId] = useState<number | null>(null);

  const restore = async (s: DeletedCustomer) => {
    setBusyId(s.customerId);
    try {
      await customerService.restore(s.customerId);
      list.reload();
      toast.success(t("ui.student_restored_successfully"), {
        // Undo = delete again with the same reason.
        undo: async () => { await customerService.remove(s.customerId, s.deletionReason || tr("ui.restored_by_mistake")); list.reload(); }
      });
    } catch (err) {
      toast.error(parseError(err).message);
    } finally {
      setBusyId(null);
    }
  };

  return (
    <div className="space-y-4">
      <Link to="/students" className="inline-flex items-center gap-1 text-sm text-gray-600 hover:text-orange-600"><ArrowLeft className="h-4 w-4 rtl:rotate-180" /> {t("nav.students")}</Link>
      <PageHeader title={t("ui.deleted_students")} subtitle={t("ui.kept_for_history_and_analysis")} />

      <div className="rounded-2xl border border-gray-200 bg-white shadow-sm">
        <div className="border-b border-gray-100 p-4">
          <SearchBox value={list.search} onChange={list.setSearch} onSearch={list.submitSearch} placeholder={t("students.search")} />
        </div>

        {list.loading ? <LoadingSpinner /> : list.data.items.length === 0 ? (
          <EmptyState icon={Archive} title={t("ui.no_deleted_students")} text={t("ui.students_you_delete_will_appear")} />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-start text-sm">
              <thead className="bg-gray-50 text-xs uppercase text-gray-500">
                <tr><th className="px-4 py-3">{t("students.id")}</th><th className="px-4 py-3">{t("common.name")}</th><th className="px-4 py-3">{t("students.phone")}</th><th className="px-4 py-3">{t("common.deleted")}</th><th className="px-4 py-3">{t("ui.reason")}</th><th className="px-4 py-3 text-end">{t("ui.actions")}</th></tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {list.data.items.map((s) => (
                  <Fragment key={s.customerId}>
                    <tr className="hover:bg-orange-50/40">
                      <td className="px-4 py-3 font-mono font-semibold text-gray-900">{s.studentCode}</td>
                      <td className="px-4 py-3 font-medium text-gray-900">{s.fullName}</td>
                      <td className="px-4 py-3 text-gray-700">{s.phone || "-"}</td>
                      <td className="px-4 py-3 text-gray-500">{formatDate(s.deletedAt)}</td>
                      <td className="max-w-xs px-4 py-3 text-gray-700">{s.deletionReason || "-"}</td>
                      <td className="px-4 py-3">
                        <div className="flex justify-end gap-1">
                          <button title={t("ui.history")} onClick={() => setOpen(open === s.customerId ? null : s.customerId)} className="flex items-center gap-1 rounded-lg px-2 py-2 text-xs text-gray-600 hover:bg-gray-100">
                            {t("ui.history")} {open === s.customerId ? <ChevronUp className="h-3 w-3" /> : <ChevronDown className="h-3 w-3" />}
                          </button>
                          <button onClick={() => restore(s)} disabled={busyId === s.customerId}
                                  className="flex items-center gap-1 rounded-lg bg-orange-500 px-3 py-1.5 text-xs font-medium text-white hover:bg-orange-600 disabled:opacity-60"><RotateCcw className="h-3.5 w-3.5" /> {t("ui.restore")}</button>
                        </div>
                      </td>
                    </tr>
                    {open === s.customerId && (
                      <tr className="bg-gray-50/60">
                        <td colSpan={6} className="px-6 py-4">
                          <dl className="mb-3 grid gap-3 text-sm sm:grid-cols-4">
                            <div><dt className="text-xs uppercase text-gray-500">{t("students.email")}</dt><dd>{s.email || "-"}</dd></div>
                            <div><dt className="text-xs uppercase text-gray-500">{t("flow.area")}</dt><dd>{s.address || "-"}</dd></div>
                            <div><dt className="text-xs uppercase text-gray-500">{t("ui.registered")}</dt><dd>{formatDate(s.createdAt)}</dd></div>
                            <div><dt className="text-xs uppercase text-gray-500">{t("ui.status_before_deletion")}</dt><dd>{s.isActive ? t("common.active") : t("common.inactive")}</dd></div>
                          </dl>
                          {s.enrollments.length === 0 ? <p className="text-sm text-gray-500">{t("ui.no_course_history")}</p> : (
                            <table className="w-full text-start text-sm">
                              <thead className="text-xs uppercase text-gray-500"><tr><th className="py-1 pe-4">{t("rep.col.course")}</th><th className="py-1 pe-4">{t("ui.registered")}</th><th className="py-1 pe-4">{t("rep.col.amount")}</th><th className="py-1">{t("ui.status")}</th></tr></thead>
                              <tbody>
                                {s.enrollments.map((e, i) => (
                                  <tr key={i}>
                                    <td className="py-1 pe-4"><span className="font-mono font-semibold">{e.courseCode}</span> — {e.courseName}{e.courseDeleted && <span className="ms-2 text-xs text-gray-400">{t("ui.course_deleted")}</span>}</td>
                                    <td className="py-1 pe-4 text-gray-500">{formatDate(e.enrollmentDate)}</td>
                                    <td className="py-1 pe-4 text-gray-700">{formatMoney(e.totalAmount)}</td>
                                    <td className="py-1"><StatusBadge tone={statusTone(e.status)}>{t(`st.${e.status}`, e.status)}</StatusBadge></td>
                                  </tr>
                                ))}
                              </tbody>
                            </table>
                          )}
                        </td>
                      </tr>
                    )}
                  </Fragment>
                ))}
              </tbody>
            </table>
          </div>
        )}
        <Pagination page={list.page} pageSize={list.pageSize} total={list.data.total} onPage={list.setPage} />
      </div>
    </div>
  );
}
