import { useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { ArrowDownCircle, ArrowUpCircle, BarChart3, Banknote, BookOpen, Clock, Receipt, TrendingUp, Users, Wallet, Scale } from "lucide-react";
import { Bar, BarChart, CartesianGrid, Legend, Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { ChartCard, COLORS, CourseTable, KpiCard, money } from "../components/analytics/shared";
import DateRangePicker from "../components/DateRangePicker";
import type { DateRange } from "../components/DateRangePicker";
import EmptyState from "../components/EmptyState";
import LoadingSpinner from "../components/LoadingSpinner";
import PageHeader from "../components/PageHeader";
import { usePreferences } from "../contexts/PreferencesContext";
import { useToast } from "../contexts/ToastContext";
import { parseError } from "../services/api";
import { reportService } from "../services/reportService";
import type { DashboardData } from "../types";
import { toIsoDate } from "../utils/format";

type Preset = "month" | "quarter" | "year" | "all" | "custom";

const rangeFor = (p: Preset): DateRange => {
  const now = new Date();
  const today = toIsoDate(now);
  if (p === "month") return { from: toIsoDate(new Date(now.getFullYear(), now.getMonth(), 1)), to: today };
  if (p === "quarter") return { from: toIsoDate(new Date(now.getFullYear(), now.getMonth() - 2, 1)), to: today };
  if (p === "year") return { from: toIsoDate(new Date(now.getFullYear(), 0, 1)), to: today };
  return {};
};

/** Management dashboard: ONE API call returns the KPIs, the trends and the course analysis for the selected period. */
export default function DashboardPage() {
  const { t } = usePreferences();
  const toast = useToast();
  const [preset, setPreset] = useState<Preset>("month");
  const [range, setRange] = useState<DateRange>(() => rangeFor("month"));
  const [data, setData] = useState<DashboardData | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let off = false;
    setLoading(true);
    reportService.dashboard({ fromDate: range.from, toDate: range.to })
      .then((d) => { if (!off) setData(d); })
      .catch((err) => { if (!off) toast.error(parseError(err).message); })
      .finally(() => { if (!off) setLoading(false); });
    return () => { off = true; };
    // toast is stable; the period is the only input
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [range.from, range.to]);

  const presets: { id: Preset; label: string }[] = [
    { id: "month", label: t("dash.thisMonth") }, { id: "quarter", label: t("dash.last3") },
    { id: "year", label: t("dash.thisYear") }, { id: "all", label: t("dash.allTime") }
  ];

  const trend = useMemo(() => (data?.trend ?? []).map((p) => ({ ...p, name: data?.granularity === "day" ? p.label.slice(5) : p.label })), [data]);
  const s = data?.summary;
  const hasTrend = trend.some((p) => p.sales || p.collected || p.cashIn || p.cashOut);
  const reconciled = s ? Math.abs(s.cashInDifference) < 0.005 && Math.abs(s.cashOutDifference) < 0.005 : true;

  return (
    <div className="space-y-4">
      <PageHeader title={t("nav.dashboard")} subtitle={t("dash.subtitle")}
        action={<Link to="/reports" className="inline-flex items-center gap-2 rounded-lg border border-gray-300 bg-white px-3 py-2 text-sm font-medium text-gray-700 hover:bg-orange-50 hover:text-orange-700"><BarChart3 className="h-4 w-4" /> {t("nav.reports")}</Link>} />

      <div className="flex flex-wrap items-center gap-2">
        <div className="flex flex-wrap gap-1 rounded-xl bg-gray-100 p-1 text-sm font-medium">
          {presets.map((p) => (
            <button key={p.id} onClick={() => { setPreset(p.id); setRange(rangeFor(p.id)); }}
                    className={`rounded-lg px-3 py-1.5 ${preset === p.id ? "bg-white text-orange-700 shadow-sm" : "text-gray-600 hover:text-gray-900"}`}>{p.label}</button>
          ))}
        </div>
        <DateRangePicker value={range} onChange={(r) => { setPreset("custom"); setRange(r); }} />
        {preset === "custom" && (range.from || range.to) && <span className="text-xs text-gray-500">{range.from ?? "…"} → {range.to ?? "…"}</span>}
      </div>

      {loading && !data ? <LoadingSpinner /> : !s || !data ? <EmptyState icon={BarChart3} title={t("rep.empty")} /> : (
        <div className={loading ? "opacity-60 transition" : "transition"}>
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 xl:grid-cols-4">
            <KpiCard icon={TrendingUp} label={t("kpi.sales")} value={money(s.sales)} hint={`${t("kpi.invoices")}: ${s.invoiceCount}`} />
            <KpiCard icon={Wallet} label={t("kpi.collected")} value={money(s.collected)} hint={`${t("kpi.payments")}: ${s.paymentCount}`} />
            <KpiCard icon={Clock} label={t("kpi.outstanding")} value={money(s.outstanding)} hint={`${t("kpi.invoices")}: ${s.outstandingCount}`} />
            <KpiCard icon={Receipt} label={t("kpi.expenses")} value={money(s.expenses)} hint={`${s.expenseCount}`} />
            <KpiCard icon={Banknote} label={t("kpi.payroll")} value={money(s.payroll)} hint={`${t("kpi.payrollPending")}: ${money(s.payrollPending)}`} />
            <KpiCard icon={ArrowDownCircle} label={t("kpi.cashIn")} value={money(s.cashIn)} />
            <KpiCard icon={ArrowUpCircle} label={t("kpi.cashOut")} value={money(s.cashOut)} />
            <KpiCard icon={Scale} label={t("kpi.net")} value={money(s.netResult)} tone={s.netResult >= 0 ? "positive" : "negative"} hint={t("kpi.netHint")} />
          </div>
          {!reconciled && <p className="mt-3 rounded-lg bg-yellow-50 px-3 py-2 text-xs text-yellow-800">{t("rep.reconWarn")}</p>}

          <div className="mt-4 grid gap-4 lg:grid-cols-2">
            <ChartCard title={t("chart.incomeExpenses")}>
              {!hasTrend ? <EmptyState title={t("rep.empty")} /> : (
                <ResponsiveContainer width="100%" height={260}>
                  <BarChart data={trend}><CartesianGrid strokeDasharray="3 3" vertical={false} /><XAxis dataKey="name" tick={{ fontSize: 11 }} /><YAxis tick={{ fontSize: 11 }} width={60} />
                    <Tooltip formatter={(v: number) => money(v)} /><Legend />
                    <Bar dataKey="cashIn" name={t("kpi.cashIn")} fill={COLORS.green} radius={[4, 4, 0, 0]} />
                    <Bar dataKey="cashOut" name={t("kpi.cashOut")} fill={COLORS.orange} radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              )}
            </ChartCard>
            <ChartCard title={t("chart.salesCollection")}>
              {!hasTrend ? <EmptyState title={t("rep.empty")} /> : (
                <ResponsiveContainer width="100%" height={260}>
                  <LineChart data={trend}><CartesianGrid strokeDasharray="3 3" vertical={false} /><XAxis dataKey="name" tick={{ fontSize: 11 }} /><YAxis tick={{ fontSize: 11 }} width={60} />
                    <Tooltip formatter={(v: number) => money(v)} /><Legend />
                    <Line type="monotone" dataKey="sales" name={t("kpi.sales")} stroke={COLORS.orange} strokeWidth={2} dot={false} />
                    <Line type="monotone" dataKey="collected" name={t("kpi.collected")} stroke={COLORS.dark} strokeWidth={2} dot={false} />
                  </LineChart>
                </ResponsiveContainer>
              )}
            </ChartCard>
            <ChartCard title={t("chart.topCourses")}>
              {data.topCourses.length === 0 ? <EmptyState icon={BookOpen} title={t("rep.empty")} /> : (
                <ResponsiveContainer width="100%" height={Math.max(200, data.topCourses.length * 48)}>
                  <BarChart data={data.topCourses} layout="vertical" margin={{ left: 10 }}><CartesianGrid strokeDasharray="3 3" horizontal={false} />
                    <XAxis type="number" tick={{ fontSize: 11 }} /><YAxis type="category" dataKey="code" tick={{ fontSize: 11 }} width={60} />
                    <Tooltip formatter={(v: number) => money(v)} labelFormatter={(code) => data.topCourses.find((c) => c.code === code)?.name ?? String(code)} /><Legend />
                    <Bar dataKey="revenue" name={t("rep.col.revenue")} fill={COLORS.orange} radius={[0, 4, 4, 0]} />
                    <Bar dataKey="paid" name={t("rep.col.paid")} fill={COLORS.dark} radius={[0, 4, 4, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              )}
            </ChartCard>
            <ChartCard title={`${t("chart.occupancy")} (${data.openCourses} ${t("dash.openCourses")}, ${data.activeStudents} ${t("dash.students")})`}>
              {data.occupancy.length === 0 ? <EmptyState icon={Users} title={t("rep.empty")} /> : (
                <ResponsiveContainer width="100%" height={Math.max(200, data.occupancy.length * 36)}>
                  <BarChart data={data.occupancy} layout="vertical" margin={{ left: 10 }}><CartesianGrid strokeDasharray="3 3" horizontal={false} />
                    <XAxis type="number" domain={[0, 100]} unit="%" tick={{ fontSize: 11 }} /><YAxis type="category" dataKey="code" tick={{ fontSize: 11 }} width={60} />
                    <Tooltip formatter={(v: number) => `${v}%`} labelFormatter={(code) => data.occupancy.find((c) => c.code === code)?.name ?? String(code)} />
                    <Bar dataKey="occupancyPercent" name={t("rep.col.occupancy")} fill={COLORS.orange} radius={[0, 4, 4, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              )}
            </ChartCard>
          </div>

          <section className="mt-4 rounded-2xl border border-gray-200 bg-white shadow-sm">
            <h2 className="border-b border-gray-100 px-4 py-3 text-sm font-semibold text-gray-800">{t("dash.coursePerformance")}</h2>
            {data.topCourses.length === 0 ? <EmptyState icon={BookOpen} title={t("rep.empty")} text={t("rep.emptyText")} /> : <CourseTable rows={data.topCourses} />}
          </section>
        </div>
      )}
    </div>
  );
}
