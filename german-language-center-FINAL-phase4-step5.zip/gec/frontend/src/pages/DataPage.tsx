import { useEffect, useState } from "react";
import DataPasswordGate from "../components/data/DataPasswordGate";
import BackupSection from "../components/data/BackupSection";
import DataSection from "../components/settings/DataSection";
import { useAuth } from "../contexts/AuthContext";
import { getDataToken } from "../utils/dataAccess";

/**
 * Sidebar > Data. Admin opens it directly. Everyone else sees the password prompt first; the API refuses every /data request
 * without a valid Data token, so skipping this screen would only produce errors.
 */
export default function DataPage() {
  const { isAdmin } = useAuth();
  const [unlocked, setUnlocked] = useState(() => getDataToken() !== null);

  useEffect(() => {
    const relock = () => setUnlocked(false); // the token expired or the Data password was changed
    window.addEventListener("data:locked", relock);
    return () => window.removeEventListener("data:locked", relock);
  }, []);

  // Backup and Restore are Admin only (the API refuses everyone else); staff with the Data password see the exports and completed courses only
  if (isAdmin) return <><DataSection /><BackupSection /></>;
  if (unlocked) return <DataSection />;
  return <DataPasswordGate onUnlocked={() => setUnlocked(true)} />;
}
