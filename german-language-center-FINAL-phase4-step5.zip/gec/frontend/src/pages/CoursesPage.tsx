import { useCallback, useState } from "react";
import { Link } from "react-router-dom";
import { BookOpen, CheckCircle2, Eye, Pencil, Plus, Power } from "lucide-react";
import ConfirmDialog from "../components/ConfirmDialog";
import CourseFormModal from "../components/courses/CourseFormModal";
import EmptyState from "../components/EmptyState";
import LoadingSpinner from "../components/LoadingSpinner";
import PageHeader from "../components/PageHeader";
import Pagination from "../components/Pagination";
import SearchBox from "../components/SearchBox";
import SortableTh from "../components/SortableTh";
import StatusBadge from "../components/StatusBadge";
import StatusFilter from "../components/StatusFilter";
import { useAuth } from "../contexts/AuthContext";
import { usePreferences } from "../contexts/PreferencesContext";
import { useToast } from "../contexts/ToastContext";
import { usePagedList } from "../hooks/usePagedList";
import { parseError } from "../services/api";
import { courseService } from "../services/courseService";
import type { Course } from "../types";
import { courseTone, formatMoney } from "../utils/format";

type StatusValue = "all" | "open" | "full" | "deactivated";

export default function CoursesPage() {
  const toast = useToast();
  const { isAdmin } = useAuth();
  const { t, tf } = usePreferences();
  const list = usePagedList<Course, { status?: string }>(courseService.list, {}, { sortBy: "code", sortDir: "asc" });
  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState<Course | null>(null);
  const [completing, setCompleting] = useState<Course | null>(null);
  const [working, setWorking] = useState(false);
  const refresh = useCallback(() => list.reload(), [list.reload]); // eslint-disable-line react-hooks/exhaustive-deps

  const status = (list.filters.status ?? "all") as StatusValue;
  const statusLabel = (s: Course["status"]) => t(`courses.${s.toLowerCase()}`, s);

  // Activate / Deactivate is a manual switch only (a full course shows as "Full" by itself).
  const toggleActive = async (course: Course) => {
    const wasActive = course.status !== "Deactivated";
    try {
      await courseService.setActive(course.courseId, !wasActive);
      refresh();
      toast.success(wasActive ? t("ui.course_deactivated_successfully") : t("ui.course_activated_successfully"), {
        undo: async () => { await courseService.setActive(course.courseId, wasActive); refresh(); }
      });
    } catch (err) {
      toast.error(parseError(err).message);
    }
  };

  // Completing keeps every record; the course just leaves this list and moves to Data.
  const confirmComplete = async () => {
    if (!completing) return;
    const course = completing;
    setWorking(true);
    try {
      await courseService.complete(course.courseId);
      setCompleting(null);
      refresh();
      toast.success(t("ui.course_completed_successfully_its_history"), {
        undo: async () => { await courseService.reopen(course.courseId); refresh(); }
      });
    } catch (err) {
      toast.error(parseError(err).message);
      setCompleting(null);
    } finally {
      setWorking(false);
    }
  };

  return (
    <div className="space-y-4">
      <PageHeader title={t("courses.title")} subtitle={t("courses.subtitle")}
        action={<button onClick={() => { setEditing(null); setFormOpen(true); }} className="flex items-center gap-2 rounded-lg bg-orange-500 px-4 py-2 text-sm font-medium text-white hover:bg-orange-600"><Plus className="h-4 w-4" /> {t("courses.add")}</button>} />

      <div className="rounded-2xl border border-gray-200 bg-white shadow-sm">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-gray-100 p-4">
          <SearchBox value={list.search} onChange={list.setSearch} onSearch={list.submitSearch} placeholder={t("courses.search")} />
          <StatusFilter<StatusValue> value={status}
            onChange={(v) => list.setFilters({ status: v === "all" ? undefined : v })}
            options={[
              { value: "all", label: t("common.all") }, { value: "open", label: t("courses.open") },
              { value: "full", label: t("courses.full") }, { value: "deactivated", label: t("courses.deactivated") }
            ]} />
        </div>

        {list.loading ? <LoadingSpinner /> : list.data.items.length === 0 ? (
          <EmptyState icon={BookOpen} title={t("ui.no_courses_found")} text={t("ui.try_a_different_search_or")} />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-start text-sm">
              <thead className="bg-gray-50 text-xs text-gray-500">
                <tr>
                  <SortableTh label={t("courses.code")} col="code" sort={list.sort} onSort={list.toggleSort} />
                  <SortableTh label={t("common.name")} col="name" sort={list.sort} onSort={list.toggleSort} />
                  <SortableTh label={t("courses.price")} col="price" sort={list.sort} onSort={list.toggleSort} />
                  <SortableTh label={t("courses.students")} col="enrolled" sort={list.sort} onSort={list.toggleSort} />
                  <th className="px-4 py-3">{t("common.status")}</th>
                  <th className="px-4 py-3 text-end">{t("common.actions")}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {list.data.items.map((c) => (
                  <tr key={c.courseId} className="hover:bg-orange-50/40">
                    <td className="px-4 py-3 font-mono font-semibold text-gray-900"><Link to={`/courses/${c.courseId}`} className="hover:text-orange-600">{c.courseCode}</Link></td>
                    <td className="px-4 py-3 text-gray-900">{c.courseName}</td>
                    <td className="px-4 py-3 text-gray-700">{formatMoney(c.price)}</td>
                    <td className="px-4 py-3 text-gray-700">{c.enrolledCount} / {c.maxCapacity}</td>
                    <td className="px-4 py-3"><StatusBadge tone={courseTone(c.status)}>{statusLabel(c.status)}</StatusBadge></td>
                    <td className="px-4 py-3">
                      <div className="flex justify-end gap-1">
                        <Link title={t("invoices.view")} to={`/courses/${c.courseId}`} className="icon-btn"><Eye className="h-4 w-4" /></Link>
                        <button title={t("invoices.edit")} onClick={() => { setEditing(c); setFormOpen(true); }} className="icon-btn"><Pencil className="h-4 w-4" /></button>
                        <button title={c.status === "Deactivated" ? t("ui.activate") : t("ui.deactivate")} onClick={() => toggleActive(c)} className="icon-btn"><Power className="h-4 w-4" /></button>
                        {isAdmin && <button title={t("ui.mark_as_completed")} onClick={() => setCompleting(c)} className="icon-btn text-green-600"><CheckCircle2 className="h-4 w-4" /></button>}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
        <Pagination page={list.page} pageSize={list.pageSize} total={list.data.total} onPage={list.setPage} />
      </div>

      <CourseFormModal open={formOpen} course={editing} onClose={() => setFormOpen(false)} onSaved={refresh} />
      <ConfirmDialog open={completing !== null} busy={working} title={t("ui.mark_course_as_completed")}
        message={completing ? tf("ui.confirm_complete_course", { code: completing.courseCode, name: completing.courseName }) : ""}
        confirmLabel={t("ui.mark_as_completed")} onConfirm={confirmComplete} onCancel={() => setCompleting(null)} />
    </div>
  );
}
