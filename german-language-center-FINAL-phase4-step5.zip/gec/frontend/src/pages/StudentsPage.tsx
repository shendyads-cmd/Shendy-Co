import { useCallback, useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { Archive, Eye, Pencil, Plus, Power, Trash2, Users as UsersIcon } from "lucide-react";
import DeleteReasonDialog from "../components/DeleteReasonDialog";
import EmptyState from "../components/EmptyState";
import LoadingSpinner from "../components/LoadingSpinner";
import PageHeader from "../components/PageHeader";
import Pagination from "../components/Pagination";
import SearchBox from "../components/SearchBox";
import SortableTh from "../components/SortableTh";
import StatusBadge from "../components/StatusBadge";
import StatusFilter from "../components/StatusFilter";
import DateRangePicker from "../components/DateRangePicker";
import NewInvoiceFlow from "../components/invoices/NewInvoiceFlow";
import StudentFormModal from "../components/students/StudentFormModal";
import { useAuth } from "../contexts/AuthContext";
import { usePreferences } from "../contexts/PreferencesContext";
import { useToast } from "../contexts/ToastContext";
import { usePagedList } from "../hooks/usePagedList";
import { parseError } from "../services/api";
import { customerService } from "../services/customerService";
import type { Customer, CustomerStats } from "../types";
import { formatDate } from "../utils/format";

type StatusValue = "all" | "active" | "inactive";

// translation keys of the suggested deletion reasons (the chosen text is stored in the language the user sees)
const REASON_KEYS = ["ui.course_is_too_expensive", "ui.student_stopped_attending", "ui.student_moved", "ui.student_requested_cancellation"];

export default function StudentsPage() {
  const toast = useToast();
  const { isAdmin } = useAuth();
  const { t } = usePreferences();
  const list = usePagedList<Customer, { isActive?: boolean; fromDate?: string; toDate?: string }>(customerService.list, {}, { sortBy: "id", sortDir: "asc" });
  const [stats, setStats] = useState<CustomerStats | null>(null);
  const [formOpen, setFormOpen] = useState(false);
  const [wizardOpen, setWizardOpen] = useState(false);
  const [editing, setEditing] = useState<Customer | null>(null);
  const [deleting, setDeleting] = useState<Customer | null>(null);
  const [working, setWorking] = useState(false);

  const loadStats = useCallback(() => { customerService.stats().then(setStats).catch(() => setStats(null)); }, []);
  useEffect(() => { loadStats(); }, [loadStats]);
  const refresh = useCallback(() => { list.reload(); loadStats(); }, [list.reload, loadStats]); // eslint-disable-line react-hooks/exhaustive-deps

  const status: StatusValue = list.filters.isActive === undefined ? "all" : list.filters.isActive ? "active" : "inactive";

  // Activate / Deactivate happens immediately; the toast offers Undo.
  const toggleActive = async (student: Customer) => {
    try {
      await customerService.setActive(student.customerId, !student.isActive);
      refresh();
      toast.success(student.isActive ? t("ui.student_deactivated_successfully") : t("ui.student_activated_successfully"), {
        undo: async () => { await customerService.setActive(student.customerId, student.isActive); refresh(); }
      });
    } catch (err) {
      toast.error(parseError(err).message);
    }
  };

  const confirmDelete = async (reason: string) => {
    if (!deleting) return;
    const student = deleting;
    setWorking(true);
    try {
      await customerService.remove(student.customerId, reason);
      setDeleting(null);
      refresh();
      toast.success(t("ui.student_deleted_successfully"), {
        undo: async () => { await customerService.restore(student.customerId); refresh(); }
      });
    } catch (err) {
      toast.error(parseError(err).message);
      setDeleting(null);
    } finally {
      setWorking(false);
    }
  };

  return (
    <div className="space-y-4">
      <PageHeader title={t("students.title")} subtitle={t("students.subtitle")}
        action={
          <div className="flex flex-wrap gap-2">
            {isAdmin && (
              <Link to="/students/deleted" className="flex items-center gap-2 rounded-lg border border-orange-500 px-4 py-2 text-sm font-medium text-orange-600 hover:bg-orange-50">
                <Archive className="h-4 w-4" /> {t("common.deleted")}{stats && stats.deleted > 0 ? ` (${stats.deleted})` : ""}
              </Link>
            )}
            <button onClick={() => setWizardOpen(true)} className="flex items-center gap-2 rounded-lg bg-orange-500 px-4 py-2 text-sm font-medium text-white hover:bg-orange-600"><Plus className="h-4 w-4" /> {t("students.add")}</button>
          </div>
        } />

      <div className="rounded-2xl border border-gray-200 bg-white shadow-sm">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-gray-100 p-4">
          <div className="flex flex-wrap items-center gap-2">
            <SearchBox value={list.search} onChange={list.setSearch} onSearch={list.submitSearch} placeholder={t("students.search")} />
            <DateRangePicker value={{ from: list.filters.fromDate, to: list.filters.toDate }} onChange={(r) => list.setFilters({ fromDate: r.from, toDate: r.to })} />
          </div>
          <StatusFilter<StatusValue> value={status}
            onChange={(v) => list.setFilters({ isActive: v === "all" ? undefined : v === "active" })}
            options={[
              { value: "all", label: t("common.all"), count: stats?.total },
              { value: "active", label: t("common.active"), count: stats?.active },
              { value: "inactive", label: t("common.inactive"), count: stats?.inactive }
            ]} />
        </div>

        {list.loading ? <LoadingSpinner /> : list.data.items.length === 0 ? (
          <EmptyState icon={UsersIcon} title={t("ui.no_students_found")} text={t("ui.try_a_different_search_or_2")} />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-start text-sm">
              <thead className="bg-gray-50 text-xs text-gray-500">
                <tr>
                  <SortableTh label={t("students.id")} col="id" sort={list.sort} onSort={list.toggleSort} />
                  <SortableTh label={t("common.name")} col="name" sort={list.sort} onSort={list.toggleSort} />
                  <SortableTh label={t("students.phone")} col="phone" sort={list.sort} onSort={list.toggleSort} />
                  <SortableTh label={t("students.email")} col="email" sort={list.sort} onSort={list.toggleSort} />
                  <SortableTh label={t("students.courses")} col="enrollments" sort={list.sort} onSort={list.toggleSort} />
                  <th className="px-4 py-3">{t("common.status")}</th>
                  <SortableTh label={t("students.created")} col="created" sort={list.sort} onSort={list.toggleSort} />
                  <th className="px-4 py-3 text-end">{t("common.actions")}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {list.data.items.map((s) => (
                  <tr key={s.customerId} className="hover:bg-orange-50/40">
                    <td className="px-4 py-3 font-mono font-semibold text-gray-900"><Link to={`/students/${s.customerId}`} className="hover:text-orange-600">{s.studentCode}</Link></td>
                    <td className="px-4 py-3 font-medium text-gray-900">{s.fullName}</td>
                    <td className="px-4 py-3 text-gray-700">{s.phone || "-"}</td>
                    <td className="px-4 py-3 text-gray-700">{s.email || "-"}</td>
                    <td className="px-4 py-3 font-mono text-gray-700">{s.courseCodes.length > 0 ? s.courseCodes.join(", ") : "-"}</td>
                    <td className="px-4 py-3"><StatusBadge tone={s.isActive ? "green" : "red"}>{s.isActive ? t("common.active") : t("common.inactive")}</StatusBadge></td>
                    <td className="px-4 py-3 text-gray-500">{formatDate(s.createdAt)}</td>
                    <td className="px-4 py-3">
                      <div className="flex justify-end gap-1">
                        <Link title={t("invoices.view")} to={`/students/${s.customerId}`} className="icon-btn"><Eye className="h-4 w-4" /></Link>
                        <button title={t("invoices.edit")} onClick={() => { setEditing(s); setFormOpen(true); }} className="icon-btn"><Pencil className="h-4 w-4" /></button>
                        <button title={s.isActive ? t("ui.deactivate") : t("ui.activate")} onClick={() => toggleActive(s)} className="icon-btn"><Power className="h-4 w-4" /></button>
                        {isAdmin && <button title={t("ui.delete")} onClick={() => setDeleting(s)} className="icon-btn icon-btn-danger"><Trash2 className="h-4 w-4" /></button>}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
        <Pagination page={list.page} pageSize={list.pageSize} total={list.data.total} onPage={list.setPage} />
      </div>

      <NewInvoiceFlow open={wizardOpen} onClose={() => setWizardOpen(false)} onSaved={refresh} />
      <StudentFormModal open={formOpen} student={editing} onClose={() => setFormOpen(false)} onSaved={refresh} />
      <DeleteReasonDialog open={deleting !== null} busy={working} title={t("ui.delete_student")}
        subject={deleting ? <>{deleting.studentCode} — {deleting.fullName}</> : null}
        description={t("ui.the_student_moves_to_deleted")}
        suggestions={REASON_KEYS.map((k) => t(k))} onConfirm={confirmDelete} onCancel={() => setDeleting(null)} />
    </div>
  );
}
