import { useCallback, useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { ArrowLeft, BookOpen, CheckCircle2, Pencil, Plus, XCircle } from "lucide-react";
import EmptyState from "../components/EmptyState";
import LoadingSpinner from "../components/LoadingSpinner";
import StatusBadge from "../components/StatusBadge";
import NewInvoiceFlow from "../components/invoices/NewInvoiceFlow";
import StudentFormModal from "../components/students/StudentFormModal";
import { useToast } from "../contexts/ToastContext";
import { parseError } from "../services/api";
import { customerService } from "../services/customerService";
import { enrollmentService } from "../services/enrollmentService";
import type { CustomerDetails, Enrollment, EnrollmentStatus } from "../types";
import { formatDate, formatMoney, statusTone } from "../utils/format";
import { usePreferences } from "../contexts/PreferencesContext";

export default function StudentDetailsPage() {
  const { t, tf } = usePreferences();
  const { id } = useParams();
  const toast = useToast();
  const [data, setData] = useState<CustomerDetails | null>(null);
  const [loading, setLoading] = useState(true);
  const [notFound, setNotFound] = useState(false);
  const [editOpen, setEditOpen] = useState(false);
  const [addOpen, setAddOpen] = useState(false);
  const [showPrevious, setShowPrevious] = useState(false);

  const load = useCallback(async () => {
    try {
      setData(await customerService.get(Number(id)));
      setNotFound(false);
    } catch (err) {
      const p = parseError(err);
      if (p.status === 404) setNotFound(true); else toast.error(p.message);
    } finally {
      setLoading(false);
    }
  }, [id, toast]);

  useEffect(() => { setLoading(true); load(); }, [load]);

  const changeStatus = async (e: Enrollment, status: EnrollmentStatus, message: string) => {
    try {
      await enrollmentService.setStatus(e.enrollmentId, status);
      await load();
      toast.success(message, { undo: async () => { await enrollmentService.setStatus(e.enrollmentId, e.status); await load(); } });
    } catch (err) {
      toast.error(parseError(err).message);
    }
  };

  if (loading) return <LoadingSpinner />;
  if (notFound || !data) return <EmptyState title={t("ui.student_not_found")} text={t("ui.this_student_may_have_been")} />;

  const { customer, enrollments } = data;
  // Current = active registrations in running courses. Everything else (cancelled, completed or finished courses) is history, never hidden.
  const isCurrent = (e: Enrollment) => e.status === "Active" && !e.courseCompleted;
  const current = enrollments.filter(isCurrent);
  const previous = enrollments.filter((e) => !isCurrent(e));
  const rows = showPrevious ? [...current, ...previous] : current;

  const field = (label: string, value?: string | null) => (
    <div><dt className="text-xs uppercase text-gray-500">{label}</dt><dd className="mt-0.5 text-sm text-gray-900">{value || "-"}</dd></div>
  );

  return (
    <div className="space-y-4">
      <Link to="/students" className="inline-flex items-center gap-1 text-sm text-gray-600 hover:text-orange-600"><ArrowLeft className="h-4 w-4 rtl:rotate-180" /> {t("nav.students")}</Link>

      <div className="rounded-2xl border border-gray-200 bg-white p-5 shadow-sm">
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div>
            <p className="font-mono text-sm font-semibold text-orange-600">{customer.studentCode}</p>
            <div className="flex items-center gap-3">
              <h1 className="text-xl font-semibold text-gray-900">{customer.fullName}</h1>
              <StatusBadge tone={customer.isActive ? "green" : "red"}>{customer.isActive ? t("common.active") : t("common.inactive")}</StatusBadge>
            </div>
          </div>
          <button onClick={() => setEditOpen(true)} className="flex items-center gap-2 rounded-lg border border-gray-300 px-3 py-2 text-sm hover:bg-gray-50"><Pencil className="h-4 w-4" /> {t("invoices.edit")}</button>
        </div>
        <dl className="mt-4 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {field(t("students.phone"), customer.phone)}
          {field(t("students.email"), customer.email)}
          {field(t("flow.area"), customer.area)}
          {field(t("ui.registered"), customer.createdAt ? formatDate(customer.createdAt) : null)}
        </dl>
      </div>

      <div className="rounded-2xl border border-gray-200 bg-white shadow-sm">
        <div className="flex flex-wrap items-center justify-between gap-2 border-b border-gray-100 px-5 py-3">
          <h2 className="font-semibold text-gray-900">{t("ui.registered_courses")}</h2>
          <div className="flex items-center gap-3">
            {previous.length > 0 && (
              <button onClick={() => setShowPrevious((v) => !v)} className="text-sm text-gray-600 hover:text-orange-600">
                {showPrevious ? t("ui.hide") : t("ui.show")} {t("ui.completed_removed")}{previous.length})
              </button>
            )}
            <button onClick={() => setAddOpen(true)} disabled={!customer.isActive} title={customer.isActive ? "" : t("ui.activate_the_student_first")}
                    className="flex items-center gap-2 rounded-lg bg-orange-500 px-3 py-2 text-sm font-medium text-white hover:bg-orange-600 disabled:opacity-50"><Plus className="h-4 w-4" /> {t("ui.add_course")}</button>
          </div>
        </div>
        {rows.length === 0 ? (
          <EmptyState icon={BookOpen} title={t("ui.no_registered_courses")} text={t("ui.use_add_course_to_register")} />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-start text-sm">
              <thead className="bg-gray-50 text-xs uppercase text-gray-500">
                <tr><th className="px-4 py-3">{t("courses.code")}</th><th className="px-4 py-3">{t("rep.col.course")}</th><th className="px-4 py-3">{t("courses.price")}</th><th className="px-4 py-3">{t("ui.registered")}</th><th className="px-4 py-3">{t("ui.type")}</th><th className="px-4 py-3">{t("rep.col.invoice")}</th><th className="px-4 py-3">{t("ui.status")}</th><th className="px-4 py-3 text-end">{t("ui.actions")}</th></tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {rows.map((e) => (
                  <tr key={e.enrollmentId} className="hover:bg-orange-50/40">
                    <td className="px-4 py-3 font-mono font-semibold text-gray-900"><Link to={`/courses/${e.courseId}`} className="hover:text-orange-600">{e.courseCode}</Link></td>
                    <td className="px-4 py-3 text-gray-900">{e.courseName}</td>
                    <td className="px-4 py-3 text-gray-700">{formatMoney(e.totalAmount)}</td>
                    <td className="px-4 py-3 text-gray-500">{formatDate(e.enrollmentDate)}</td>
                    <td className="px-4 py-3"><StatusBadge tone={e.type === "Offer" ? "orange" : "gray"}>{t(`type.${e.type}`, e.type)}</StatusBadge></td>
                    <td className="px-4 py-3 font-mono text-xs text-gray-600">{e.invoiceNumber || "-"}</td>
                    <td className="px-4 py-3"><StatusBadge tone={statusTone(e.status)}>{e.courseCompleted ? t("ui.course_completed") : e.status}</StatusBadge></td>
                    <td className="px-4 py-3">
                      {isCurrent(e) && (
                        <div className="flex justify-end gap-1">
                          <button title={t("ui.mark_completed")} onClick={() => changeStatus(e, "Completed", tf("ui.course_marked_completed", { code: e.courseCode }))} className="icon-btn text-green-600"><CheckCircle2 className="h-4 w-4" /></button>
                          <button title={t("ui.remove_from_course")} onClick={() => changeStatus(e, "Cancelled", tf("ui.course_removed", { code: e.courseCode }))} className="icon-btn icon-btn-danger"><XCircle className="h-4 w-4" /></button>
                        </div>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      <StudentFormModal open={editOpen} student={customer} onClose={() => setEditOpen(false)} onSaved={load} />
      <NewInvoiceFlow open={addOpen} presetStudent={customer} onClose={() => setAddOpen(false)} onSaved={load} />
    </div>
  );
}
