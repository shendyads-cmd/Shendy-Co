import { useState } from "react";
import type { FormEvent } from "react";
import { Navigate, useLocation, useNavigate } from "react-router-dom";
import { Eye, EyeOff, GraduationCap, Loader2, AlertTriangle, XCircle } from "lucide-react";
import FormInput from "../components/FormInput";
import { useAuth } from "../contexts/AuthContext";
import { parseError } from "../services/api";
import { homePath } from "../utils/navigation";
import { usePreferences } from "../contexts/PreferencesContext";

export default function LoginPage() {
  const { t } = usePreferences();
  const { user, login } = useAuth();
  const navigate = useNavigate();
  const from = (useLocation().state as { from?: string } | null)?.from;

  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [show, setShow] = useState(false);
  const [busy, setBusy] = useState(false);
  const [fieldErrors, setFieldErrors] = useState<{ username?: string; password?: string }>({});
  const [error, setError] = useState<{ message: string; disabled: boolean } | null>(null);

  if (user) return <Navigate to={from ?? homePath(user.role)} replace />;

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    const errs: typeof fieldErrors = {};
    if (!username.trim()) errs.username = t("ui.username_is_required");
    if (!password) errs.password = t("ui.password_is_required");
    setFieldErrors(errs);
    if (Object.keys(errs).length) return;

    setBusy(true);
    setError(null);
    try {
      const u = await login(username.trim(), password);
      navigate(from ?? homePath(u.role), { replace: true });
    } catch (err) {
      const p = parseError(err);
      setError({ message: p.message, disabled: p.code === "ACCOUNT_DISABLED" });
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="flex min-h-screen">
      <div className="hidden flex-1 flex-col justify-between bg-orange-500 p-12 text-white lg:flex">
        <div className="flex items-center gap-3">
          <div className="rounded-xl bg-white/20 p-2"><GraduationCap className="h-7 w-7" /></div>
          <span className="text-lg font-semibold">{t("ui.german_language_center")}</span>
        </div>
        <div>
          <h1 className="text-4xl font-bold leading-tight">{t("ui.students_courses_and")}<br />{t("ui.finances_in_one_place")}</h1>
          <p className="mt-4 max-w-md text-orange-50">{t("ui.manage_enrollments_invoices_payments_and")}</p>
        </div>
        <p className="text-sm text-orange-100">{t("ui.management_accounting_system")}</p>
      </div>

      <div className="flex flex-1 items-center justify-center bg-white p-6">
        <form onSubmit={submit} noValidate className="w-full max-w-sm space-y-5">
          <div>
            <h2 className="text-2xl font-bold text-gray-900">{t("ui.sign_in")}</h2>
            <p className="mt-1 text-sm text-gray-500">{t("ui.enter_your_credentials_to_continue")}</p>
          </div>

          {error && (
            <div role="alert" className={`flex items-start gap-2 rounded-lg border px-3 py-2 text-sm ${error.disabled ? "border-yellow-300 bg-yellow-50 text-yellow-800" : "border-red-300 bg-red-50 text-red-700"}`}>
              {error.disabled ? <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" /> : <XCircle className="mt-0.5 h-4 w-4 shrink-0" />}
              {error.message}
            </div>
          )}

          <FormInput label={t("account.username")} name="username" autoComplete="username" autoFocus
                     value={username} onChange={(e) => setUsername(e.target.value)} error={fieldErrors.username} />
          <FormInput label={t("account.password")} name="password" autoComplete="current-password"
                     type={show ? "text" : "password"} value={password} onChange={(e) => setPassword(e.target.value)}
                     error={fieldErrors.password}
                     right={<button type="button" onClick={() => setShow(!show)} aria-label={show ? t("ui.hide_password") : t("ui.show_password")} className="text-gray-500 hover:text-gray-700">
                       {show ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                     </button>} />

          <button type="submit" disabled={busy}
                  className="flex w-full items-center justify-center gap-2 rounded-lg bg-orange-500 py-2.5 text-sm font-semibold text-white transition hover:bg-orange-600 disabled:opacity-60">
            {busy && <Loader2 className="h-4 w-4 animate-spin" />}
            {busy ? t("ui.signing_in") : t("ui.login")}
          </button>
        </form>
      </div>
    </div>
  );
}
