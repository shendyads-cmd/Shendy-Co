import { useSearchParams } from "react-router-dom";
import { CalendarClock, KeyRound, Lock, ScrollText, User, UserCog } from "lucide-react";
import type { LucideIcon } from "lucide-react";
import AuditSection from "../components/account/AuditSection";
import DataPasswordSection from "../components/account/DataPasswordSection";
import ScheduleSection from "../components/account/ScheduleSection";
import PageHeader from "../components/PageHeader";
import PasswordSection from "../components/account/PasswordSection";
import ProfileSection from "../components/account/ProfileSection";
import { useAuth } from "../contexts/AuthContext";
import { usePreferences } from "../contexts/PreferencesContext";
import UsersPage from "./UsersPage";

type Section = "profile" | "schedule" | "password" | "dataPassword" | "users" | "audit";

/**
 * Account Settings (user menu, not the sidebar).
 *  Staff: display name and their own schedule.
 *  Admin: also own password, the Data password, all user accounts (status, role/permissions, password reset) and the read-only audit log.
 * Every admin-only section is also protected by the API.
 */
export default function AccountSettingsPage() {
  const { isAdmin } = useAuth();
  const { t } = usePreferences();
  const [params, setParams] = useSearchParams();

  const sections: { id: Section; label: string; icon: LucideIcon }[] = [
    { id: "profile", label: t("account.profile"), icon: User },
    { id: "schedule", label: t("account.schedule"), icon: CalendarClock },
    ...(isAdmin ? [
      { id: "password" as const, label: t("account.password"), icon: KeyRound },
      { id: "dataPassword" as const, label: t("account.dataPassword"), icon: Lock },
      { id: "users" as const, label: t("account.users"), icon: UserCog },
      { id: "audit" as const, label: t("account.audit"), icon: ScrollText }
    ] : [])
  ];
  const requested = params.get("section") as Section | null;
  const current = sections.some((s) => s.id === requested) ? (requested as Section) : "profile";

  return (
    <div className="space-y-4">
      <PageHeader title={t("account.title")} subtitle={t("account.subtitle")} />
      <div className="flex flex-col gap-4 md:flex-row">
        {sections.length > 1 && (
          <nav className="flex gap-1 overflow-x-auto md:w-52 md:shrink-0 md:flex-col" aria-label={t("account.title")}>
            {sections.map(({ id, label, icon: Icon }) => (
              <button key={id} onClick={() => setParams({ section: id })} aria-current={current === id ? "page" : undefined}
                      className={`flex items-center gap-2 whitespace-nowrap rounded-lg px-3 py-2 text-sm font-medium transition ${current === id ? "bg-orange-500 text-white" : "text-gray-700 hover:bg-orange-50 hover:text-orange-700"}`}>
                <Icon className="h-4 w-4" /> {label}
              </button>
            ))}
          </nav>
        )}
        <section className="min-w-0 flex-1 rounded-2xl border border-gray-200 bg-white p-5 shadow-sm">
          {current === "profile" && <ProfileSection />}
          {current === "schedule" && <ScheduleSection />}
          {current === "password" && isAdmin && <PasswordSection />}
          {current === "dataPassword" && isAdmin && <DataPasswordSection />}
          {current === "users" && isAdmin && <UsersPage embedded />}
          {current === "audit" && isAdmin && <AuditSection />}
        </section>
      </div>
    </div>
  );
}
