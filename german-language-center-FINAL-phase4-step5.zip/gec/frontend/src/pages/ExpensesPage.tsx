import { useState } from "react";
import { Link } from "react-router-dom";
import { ArrowLeft, Pencil, Plus, Receipt } from "lucide-react";
import DateRangePicker from "../components/DateRangePicker";
import EmptyState from "../components/EmptyState";
import ExpenseFormModal from "../components/finance/ExpenseFormModal";
import LoadingSpinner from "../components/LoadingSpinner";
import PageHeader from "../components/PageHeader";
import Pagination from "../components/Pagination";
import SearchBox from "../components/SearchBox";
import { usePreferences } from "../contexts/PreferencesContext";
import { usePagedList } from "../hooks/usePagedList";
import { expenseService } from "../services/expenseService";
import type { Expense, ExpensePage } from "../types";
import { formatDate, formatMoney } from "../utils/format";

/** Expenses: list, search, date range, new expense and edit. Every saved expense also creates its Cash Out on the server. */
export default function ExpensesPage() {
  const { t } = usePreferences();
  const list = usePagedList<Expense, { fromDate?: string; toDate?: string }>(expenseService.list, {}, { sortBy: "date", sortDir: "desc" });
  const totalAmount = (list.data as ExpensePage).totalAmount ?? 0;
  const [form, setForm] = useState<{ expense: Expense | null } | null>(null);

  return (
    <div className="space-y-4">
      <PageHeader title={t("expenses.title")} subtitle={t("expenses.subtitle")}
        action={<div className="flex items-center gap-2">
          <Link to="/invoices" className="inline-flex items-center gap-2 rounded-lg border border-gray-300 bg-white px-3 py-2 text-sm font-medium text-gray-700 hover:bg-orange-50 hover:text-orange-700"><ArrowLeft className="h-4 w-4 rtl:rotate-180" /> {t("nav.invoices")}</Link>
          <button onClick={() => setForm({ expense: null })} className="inline-flex items-center gap-2 rounded-lg bg-orange-500 px-3 py-2 text-sm font-medium text-white hover:bg-orange-600"><Plus className="h-4 w-4" /> {t("exp.new")}</button>
        </div>} />
      <div className="rounded-2xl border border-gray-200 bg-white shadow-sm">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-gray-100 p-4">
          <div className="flex flex-wrap items-center gap-2">
            <SearchBox value={list.search} onChange={list.setSearch} onSearch={list.submitSearch} placeholder={t("expenses.search")} />
            <DateRangePicker value={{ from: list.filters.fromDate, to: list.filters.toDate }} onChange={(r) => list.setFilters({ fromDate: r.from, toDate: r.to })} />
          </div>
          <p className="text-sm text-gray-600">{t("expenses.total")}: <span className="font-semibold text-gray-900">{formatMoney(totalAmount)}</span></p>
        </div>
        {list.loading ? <LoadingSpinner /> : list.data.items.length === 0 ? (
          <EmptyState icon={Receipt} title={t("ui.no_expenses_found")} text={t("invoices.emptyText")} />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-start text-sm">
              <thead className="bg-gray-50 text-xs uppercase text-gray-500">
                <tr><th className="px-4 py-3">{t("rep.col.date")}</th><th className="px-4 py-3">{t("ui.title")}</th><th className="px-4 py-3">{t("rep.col.category")}</th><th className="px-4 py-3 text-end">{t("rep.col.amount")}</th><th className="px-4 py-3">{t("ui.added_by")}</th><th className="px-4 py-3">{t("rep.col.description")}</th><th className="px-4 py-3 text-end">{t("common.actions")}</th></tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {list.data.items.map((e) => (
                  <tr key={e.expenseId} className="hover:bg-orange-50/40">
                    <td className="px-4 py-3 text-gray-700">{formatDate(e.expenseDate)}</td>
                    <td className="px-4 py-3 font-medium text-gray-900">{e.title}</td>
                    <td className="px-4 py-3 text-gray-700">{t(`expcat.${e.category}`, e.category)}</td>
                    <td className="px-4 py-3 text-end text-gray-900">{formatMoney(e.amount)}</td>
                    <td className="px-4 py-3 text-gray-500">{e.createdBy || "-"}</td>
                    <td className="max-w-xs truncate px-4 py-3 text-gray-500">{e.description || "-"}</td>
                    <td className="px-4 py-3"><div className="flex justify-end"><button onClick={() => setForm({ expense: e })} className="icon-btn" title={t("exp.edit")} aria-label={t("exp.edit")}><Pencil className="h-4 w-4" /></button></div></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
        <Pagination page={list.page} pageSize={list.pageSize} total={list.data.total} onPage={list.setPage} />
      </div>
      {form && <ExpenseFormModal expense={form.expense} onClose={() => setForm(null)} onSaved={list.reload} />}
    </div>
  );
}
