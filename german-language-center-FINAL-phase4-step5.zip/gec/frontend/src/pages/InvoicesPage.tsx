import { useState } from "react";
import { Link } from "react-router-dom";
import { Eye, FileText, Pencil, Printer, Receipt, Users, Wallet } from "lucide-react";
import DateRangePicker from "../components/DateRangePicker";
import EmptyState from "../components/EmptyState";
import AddPaymentModal from "../components/finance/AddPaymentModal";
import InvoiceEditModal from "../components/invoices/InvoiceEditModal";
import InvoicePrintHost from "../components/invoices/InvoicePrintHost";
import InvoiceViewModal from "../components/invoices/InvoiceViewModal";
import LoadingSpinner from "../components/LoadingSpinner";
import PageHeader from "../components/PageHeader";
import Pagination from "../components/Pagination";
import SearchBox from "../components/SearchBox";
import StatusBadge from "../components/StatusBadge";
import StatusFilter from "../components/StatusFilter";
import { useAuth } from "../contexts/AuthContext";
import { usePreferences } from "../contexts/PreferencesContext";
import { usePagedList } from "../hooks/usePagedList";
import { invoiceService } from "../services/invoiceService";
import type { InvoiceFilters } from "../services/invoiceService";
import type { InvoiceListItem } from "../types";
import { formatDate, formatMoney, formatTime } from "../utils/format";

type StatusValue = "all" | "paid" | "partial" | "unpaid";
const tone = (s: string) => (s === "Paid" ? "green" : s === "Partially Paid" ? "orange" : "red");

export default function InvoicesPage() {
  const { t } = usePreferences();
  const { isAdmin } = useAuth();
  const list = usePagedList<InvoiceListItem, InvoiceFilters>(invoiceService.list, {}, { sortBy: "date", sortDir: "desc" });
  const [viewId, setViewId] = useState<number | null>(null);
  const [payFor, setPayFor] = useState<InvoiceListItem | null>(null);
  const [editId, setEditId] = useState<number | null>(null);
  const [printId, setPrintId] = useState<number | null>(null);

  const status = (list.filters.status ?? "all") as StatusValue;

  return (
    <div className="space-y-4">
      <PageHeader title={t("invoices.title")} subtitle={t("invoices.subtitle")}
        action={isAdmin ? (
          <div className="flex items-center gap-2">
            <Link to="/expenses" className="inline-flex items-center gap-2 rounded-lg border border-gray-300 bg-white px-3 py-2 text-sm font-medium text-gray-700 hover:bg-orange-50 hover:text-orange-700"><Receipt className="h-4 w-4" /> {t("nav.expenses")}</Link>
            <Link to="/payroll" className="inline-flex items-center gap-2 rounded-lg border border-gray-300 bg-white px-3 py-2 text-sm font-medium text-gray-700 hover:bg-orange-50 hover:text-orange-700"><Users className="h-4 w-4" /> {t("payroll.title")}</Link>
          </div>
        ) : undefined} />

      <div className="rounded-2xl border border-gray-200 bg-white shadow-sm">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-gray-100 p-4">
          <div className="flex flex-wrap items-center gap-2">
            <SearchBox value={list.search} onChange={list.setSearch} onSearch={list.submitSearch} placeholder={t("invoices.search")} />
            <DateRangePicker value={{ from: list.filters.fromDate, to: list.filters.toDate }} onChange={(r) => list.setFilters({ fromDate: r.from, toDate: r.to })} />
          </div>
          <StatusFilter<StatusValue> value={status} onChange={(v) => list.setFilters({ status: v === "all" ? undefined : v })}
            options={[{ value: "all", label: t("common.all") }, { value: "paid", label: t("rep.col.paid") }, { value: "partial", label: t("ui.partially_paid") }, { value: "unpaid", label: t("st.Unpaid") }]} />
        </div>

        {list.loading ? <LoadingSpinner /> : list.data.items.length === 0 ? (
          <EmptyState icon={FileText} title={t("invoices.empty")} text={t("invoices.emptyText")} />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-start text-sm">
              <thead className="bg-gray-50 text-xs uppercase text-gray-500">
                <tr>
                  <th className="px-4 py-3">{t("invoices.number")}</th><th className="px-4 py-3">{t("invoices.studentOffer")}</th><th className="px-4 py-3">{t("invoices.course")}</th>
                  <th className="px-4 py-3">{t("invoices.date")}</th><th className="px-4 py-3">{t("invoices.time")}</th>
                  <th className="px-4 py-3 text-end">{t("invoices.subtotal")}</th><th className="px-4 py-3 text-end">{t("invoices.discount")}</th><th className="px-4 py-3 text-end">{t("invoices.total")}</th>
                  <th className="px-4 py-3">{t("invoices.status")}</th><th className="px-4 py-3 text-end">{t("common.actions")}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {list.data.items.map((i) => (
                  <tr key={i.invoiceId} className="hover:bg-orange-50/40">
                    <td className="px-4 py-3 font-mono font-semibold text-gray-900"><button onClick={() => setViewId(i.invoiceId)} className="hover:text-orange-600">{i.invoiceNumber}</button></td>
                    <td className="px-4 py-3 text-gray-900">{i.studentLabel}{i.type === "Offer" && <span className="ms-2 rounded-full bg-orange-100 px-2 py-0.5 text-xs font-medium text-orange-700">{t("rep.typeOffer")}</span>}</td>
                    <td className="px-4 py-3 text-gray-700">{i.courseLabel}</td>
                    <td className="px-4 py-3 text-gray-700">{formatDate(i.issueDate)}</td>
                    <td className="px-4 py-3 text-gray-500">{formatTime(i.issueDate)}</td>
                    <td className="px-4 py-3 text-end text-gray-700">{formatMoney(i.subtotal)}</td>
                    <td className="px-4 py-3 text-end text-gray-700">{formatMoney(i.discountAmount)}</td>
                    <td className="px-4 py-3 text-end font-medium text-gray-900">{formatMoney(i.grandTotal)}</td>
                    <td className="px-4 py-3"><StatusBadge tone={tone(i.paymentStatus)}>{t(`st.${i.paymentStatus}`, i.paymentStatus)}</StatusBadge></td>
                    <td className="px-4 py-3">
                      <div className="flex justify-end gap-1">
                        <button onClick={() => setViewId(i.invoiceId)} className="icon-btn" title={t("invoices.view")} aria-label={t("invoices.view")}><Eye className="h-4 w-4" /></button>
                        <button onClick={() => setEditId(i.invoiceId)} className="icon-btn" title={t("invoices.edit")} aria-label={t("invoices.edit")}><Pencil className="h-4 w-4" /></button>
                        {i.paymentStatus !== "Paid" && <button onClick={() => setPayFor(i)} className="icon-btn" title={t("pay.title")} aria-label={t("pay.title")}><Wallet className="h-4 w-4" /></button>}
                        <button onClick={() => setPrintId(i.invoiceId)} className="icon-btn" title={t("invoices.print")} aria-label={t("invoices.print")}><Printer className="h-4 w-4" /></button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
        <Pagination page={list.page} pageSize={list.pageSize} total={list.data.total} onPage={list.setPage} />
      </div>

      {viewId !== null && <InvoiceViewModal id={viewId} onClose={() => setViewId(null)} onEdit={(id) => { setViewId(null); setEditId(id); }} onChanged={list.reload} />}
      {payFor && <AddPaymentModal invoice={payFor} onClose={() => setPayFor(null)} onSaved={list.reload} />}
      {editId !== null && <InvoiceEditModal id={editId} onClose={() => setEditId(null)} onSaved={list.reload} />}
      {printId !== null && <InvoicePrintHost id={printId} onDone={() => setPrintId(null)} />}
    </div>
  );
}
