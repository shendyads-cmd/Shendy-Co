import { useCallback, useEffect, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { ArrowLeft, CheckCircle2, Pencil, Users as UsersIcon } from "lucide-react";
import ConfirmDialog from "../components/ConfirmDialog";
import CourseFormModal from "../components/courses/CourseFormModal";
import EmptyState from "../components/EmptyState";
import LoadingSpinner from "../components/LoadingSpinner";
import StatusBadge from "../components/StatusBadge";
import { useAuth } from "../contexts/AuthContext";
import { useToast } from "../contexts/ToastContext";
import { parseError } from "../services/api";
import { courseService } from "../services/courseService";
import type { CourseDetails } from "../types";
import { courseTone, formatDate, formatMoney, statusTone } from "../utils/format";
import { usePreferences } from "../contexts/PreferencesContext";

export default function CourseDetailsPage() {
  const { t, tf } = usePreferences();
  const { id } = useParams();
  const toast = useToast();
  const { isAdmin } = useAuth();
  const navigate = useNavigate();
  const [data, setData] = useState<CourseDetails | null>(null);
  const [loading, setLoading] = useState(true);
  const [notFound, setNotFound] = useState(false);
  const [editOpen, setEditOpen] = useState(false);
  const [confirmOpen, setConfirmOpen] = useState(false);
  const [completing, setCompleting] = useState(false);

  const load = useCallback(async () => {
    try {
      setData(await courseService.get(Number(id)));
      setNotFound(false);
    } catch (err) {
      const p = parseError(err);
      if (p.status === 404) setNotFound(true); else toast.error(p.message);
    } finally {
      setLoading(false);
    }
  }, [id, toast]);

  useEffect(() => { setLoading(true); load(); }, [load]);

  const complete = async () => {
    if (!data) return;
    const { courseId } = data.course;
    setCompleting(true);
    try {
      await courseService.complete(courseId);
      setConfirmOpen(false);
      toast.success(t("ui.course_completed_successfully_its_history"), {
        undo: async () => { await courseService.reopen(courseId); }
      });
      navigate("/courses");
    } catch (err) {
      toast.error(parseError(err).message);
      setConfirmOpen(false);
    } finally {
      setCompleting(false);
    }
  };

  if (loading) return <LoadingSpinner />;
  if (notFound || !data) return <EmptyState title={t("ui.course_not_found")} text={t("ui.this_course_may_have_been")} />;

  const { course, enrollments } = data;
  const field = (label: string, value: string) => (
    <div><dt className="text-xs uppercase text-gray-500">{label}</dt><dd className="mt-0.5 text-sm text-gray-900">{value}</dd></div>
  );

  return (
    <div className="space-y-4">
      <Link to="/courses" className="inline-flex items-center gap-1 text-sm text-gray-600 hover:text-orange-600"><ArrowLeft className="h-4 w-4 rtl:rotate-180" /> {t("nav.courses")}</Link>

      <div className="rounded-2xl border border-gray-200 bg-white p-5 shadow-sm">
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div>
            <p className="font-mono text-sm font-semibold text-orange-600">{course.courseCode}</p>
            <div className="flex items-center gap-3">
              <h1 className="text-xl font-semibold text-gray-900">{course.courseName}</h1>
              <StatusBadge tone={courseTone(course.status)}>{t(`st.${course.status}`, course.status)}</StatusBadge>
            </div>
          </div>
          <div className="flex gap-2">
            <button onClick={() => setEditOpen(true)} className="flex items-center gap-2 rounded-lg border border-gray-300 px-3 py-2 text-sm hover:bg-gray-50"><Pencil className="h-4 w-4" /> {t("invoices.edit")}</button>
            {isAdmin && <button onClick={() => setConfirmOpen(true)} className="flex items-center gap-2 rounded-lg border border-green-600 px-3 py-2 text-sm text-green-700 hover:bg-green-50"><CheckCircle2 className="h-4 w-4" /> {t("ui.mark_as_completed")}</button>}
          </div>
        </div>
        <dl className="mt-4 grid gap-4 sm:grid-cols-3">
          {field(t("courses.price"), formatMoney(course.price))}
          {field(t("rep.col.capacity"), String(course.maxCapacity))}
          {field(t("rep.col.enrolled"), `${course.enrolledCount} / ${course.maxCapacity}`)}
        </dl>
      </div>

      <div className="rounded-2xl border border-gray-200 bg-white shadow-sm">
        <div className="border-b border-gray-100 px-5 py-3"><h2 className="font-semibold text-gray-900">{t("ui.registered_students")}</h2></div>
        {enrollments.length === 0 ? (
          <EmptyState icon={UsersIcon} title={t("ui.no_students_yet")} text={t("ui.students_are_added_from_their")} />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-start text-sm">
              <thead className="bg-gray-50 text-xs uppercase text-gray-500">
                <tr><th className="px-4 py-3">{t("students.id")}</th><th className="px-4 py-3">{t("common.name")}</th><th className="px-4 py-3">{t("ui.registered")}</th><th className="px-4 py-3">{t("ui.status")}</th></tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {enrollments.map((e) => (
                  <tr key={e.enrollmentId} className="hover:bg-orange-50/40">
                    <td className="px-4 py-3 font-mono font-semibold text-gray-900"><Link to={`/students/${e.customerId}`} className="hover:text-orange-600">{e.studentCode}</Link></td>
                    <td className="px-4 py-3 text-gray-900">{e.studentName}</td>
                    <td className="px-4 py-3 text-gray-500">{formatDate(e.enrollmentDate)}</td>
                    <td className="px-4 py-3"><StatusBadge tone={statusTone(e.status)}>{t(`st.${e.status}`, e.status)}</StatusBadge></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      <ConfirmDialog open={confirmOpen} busy={completing} title={t("ui.mark_course_as_completed")}
        message={tf("ui.confirm_complete_course", { code: course.courseCode, name: course.courseName })}
        confirmLabel={t("ui.mark_as_completed")} onConfirm={complete} onCancel={() => setConfirmOpen(false)} />
      <CourseFormModal open={editOpen} course={course} onClose={() => setEditOpen(false)} onSaved={load} />
    </div>
  );
}
