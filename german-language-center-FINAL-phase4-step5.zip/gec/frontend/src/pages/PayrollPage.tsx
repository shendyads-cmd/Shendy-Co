import { useRef, useState } from "react";
import { Link } from "react-router-dom";
import { ArrowLeft, Banknote, Pencil, Plus, Trash2, Users } from "lucide-react";
import ConfirmDialog from "../components/ConfirmDialog";
import EmptyState from "../components/EmptyState";
import PayrollEmployeeModal from "../components/finance/PayrollEmployeeModal";
import PayrollEntryModal from "../components/finance/PayrollEntryModal";
import LoadingSpinner from "../components/LoadingSpinner";
import PageHeader from "../components/PageHeader";
import Pagination from "../components/Pagination";
import SearchBox from "../components/SearchBox";
import SelectInput from "../components/SelectInput";
import StatusBadge from "../components/StatusBadge";
import { usePreferences } from "../contexts/PreferencesContext";
import { useToast } from "../contexts/ToastContext";
import { usePagedList } from "../hooks/usePagedList";
import { parseError } from "../services/api";
import { payrollService } from "../services/payrollService";
import type { PayrollFilters } from "../services/payrollService";
import type { PayrollEmployee, PayrollEntry, PayrollPage } from "../types";
import { formatDate, formatMoney } from "../utils/format";
import { newIdempotencyKey } from "../utils/idempotency";

type Tab = "salaries" | "employees";
const linkBtn = "inline-flex items-center gap-2 rounded-lg border border-gray-300 bg-white px-3 py-2 text-sm font-medium text-gray-700 hover:bg-orange-50 hover:text-orange-700";
const primaryBtn = "inline-flex items-center gap-2 rounded-lg bg-orange-500 px-3 py-2 text-sm font-medium text-white hover:bg-orange-600";

/** Payroll (Admin only; reached from the Invoices screen, not from the sidebar). Salaries and the employees they belong to. */
export default function PayrollPage() {
  const { t } = usePreferences();
  const [tab, setTab] = useState<Tab>("salaries");
  const [entryForm, setEntryForm] = useState<{ entry: PayrollEntry | null } | null>(null);
  const [employeeForm, setEmployeeForm] = useState<{ employee: PayrollEmployee | null } | null>(null);

  const salaries = usePagedList<PayrollEntry, PayrollFilters>(payrollService.list, {}, { sortBy: "period", sortDir: "desc" });
  const employees = usePagedList<PayrollEmployee, { isActive?: boolean }>(payrollService.employees, {}, { sortBy: "name", sortDir: "asc" });
  const totals = salaries.data as PayrollPage;

  return (
    <div className="space-y-4">
      <PageHeader title={t("payroll.title")} subtitle={t("payroll.subtitle")}
        action={<div className="flex items-center gap-2">
          <Link to="/invoices" className={linkBtn}><ArrowLeft className="h-4 w-4 rtl:rotate-180" /> {t("nav.invoices")}</Link>
          {tab === "salaries"
            ? <button onClick={() => setEntryForm({ entry: null })} className={primaryBtn}><Plus className="h-4 w-4" /> {t("payroll.newEntry")}</button>
            : <button onClick={() => setEmployeeForm({ employee: null })} className={primaryBtn}><Plus className="h-4 w-4" /> {t("payroll.newEmployee")}</button>}
        </div>} />

      <div className="flex gap-1 rounded-xl bg-gray-100 p-1 text-sm font-medium sm:w-fit" role="tablist">
        {(["salaries", "employees"] as Tab[]).map((id) => (
          <button key={id} role="tab" aria-selected={tab === id} onClick={() => setTab(id)}
                  className={`flex items-center gap-2 rounded-lg px-4 py-1.5 ${tab === id ? "bg-white text-orange-700 shadow-sm" : "text-gray-600 hover:text-gray-900"}`}>
            {id === "salaries" ? <Banknote className="h-4 w-4" /> : <Users className="h-4 w-4" />}
            {id === "salaries" ? t("payroll.salaries") : t("payroll.employees")}
          </button>
        ))}
      </div>

      {tab === "salaries" ? (
        <SalariesTab list={salaries} totals={totals} onEdit={(e) => setEntryForm({ entry: e })} />
      ) : (
        <EmployeesTab list={employees} onEdit={(e) => setEmployeeForm({ employee: e })} />
      )}

      {entryForm && <PayrollEntryModal entry={entryForm.entry} onClose={() => setEntryForm(null)} onSaved={salaries.reload} />}
      {employeeForm && <PayrollEmployeeModal employee={employeeForm.employee} onClose={() => setEmployeeForm(null)} onSaved={() => { employees.reload(); salaries.reload(); }} />}
    </div>
  );
}

// ---------------------------------------------------------------- salaries

function SalariesTab({ list, totals, onEdit }: { list: ReturnType<typeof usePagedList<PayrollEntry, PayrollFilters>>; totals: PayrollPage; onEdit: (e: PayrollEntry) => void }) {
  const { t } = usePreferences();
  const toast = useToast();
  const [payTarget, setPayTarget] = useState<PayrollEntry | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<PayrollEntry | null>(null);
  const [busy, setBusy] = useState(false);
  // one key per salary being paid: pressing Pay again after an error re-sends the SAME key, so the salary can never be paid twice
  const payKeys = useRef(new Map<number, string>());

  const period = list.filters.year && list.filters.month ? `${list.filters.year}-${String(list.filters.month).padStart(2, "0")}` : "";

  const pay = async () => {
    if (!payTarget || busy) return;
    setBusy(true);
    let key = payKeys.current.get(payTarget.payrollId);
    if (!key) { key = newIdempotencyKey(); payKeys.current.set(payTarget.payrollId, key); }
    try {
      await payrollService.pay(payTarget.payrollId, key);
      payKeys.current.delete(payTarget.payrollId);
      toast.success(t("payroll.paid"));
      setPayTarget(null);
      list.reload();
    } catch (err) { toast.error(parseError(err).message); list.reload(); setPayTarget(null); }
    finally { setBusy(false); }
  };

  const remove = async () => {
    if (!deleteTarget || busy) return;
    setBusy(true);
    try { await payrollService.remove(deleteTarget.payrollId); toast.success(t("payroll.deleted")); setDeleteTarget(null); list.reload(); }
    catch (err) { toast.error(parseError(err).message); setDeleteTarget(null); list.reload(); }
    finally { setBusy(false); }
  };

  return (
    <div className="rounded-2xl border border-gray-200 bg-white shadow-sm">
      <div className="flex flex-wrap items-end justify-between gap-3 border-b border-gray-100 p-4">
        <div className="flex flex-wrap items-end gap-2">
          <SearchBox value={list.search} onChange={list.setSearch} onSearch={list.submitSearch} placeholder={t("payroll.search")} />
          <label className="space-y-1 text-sm">
            <span className="block text-xs font-medium text-gray-500">{t("payroll.month")}</span>
            <input type="month" value={period} onChange={(e) => { const [y, m] = e.target.value.split("-").map(Number); list.setFilters(e.target.value ? { year: y, month: m } : { year: undefined, month: undefined }); }}
                   className="rounded-lg border border-gray-300 px-3 py-2 text-sm outline-none focus:border-orange-500 focus:ring-2 focus:ring-orange-300" />
          </label>
          <div className="w-36">
            <SelectInput label={t("common.status")} value={list.filters.status ?? ""} onChange={(e) => list.setFilters({ status: e.target.value || undefined })}>
              <option value="">{t("common.all")}</option><option value="Pending">{t("payroll.pending")}</option><option value="Paid">{t("payroll.paidStatus")}</option>
            </SelectInput>
          </div>
        </div>
        <dl className="flex gap-4 text-sm">
          <div><dt className="text-gray-500">{t("payroll.totalNet")}</dt><dd className="font-semibold text-gray-900">{formatMoney(totals.totalNet ?? 0)}</dd></div>
          <div><dt className="text-gray-500">{t("payroll.paidStatus")}</dt><dd className="font-semibold text-green-700">{formatMoney(totals.totalPaid ?? 0)}</dd></div>
          <div><dt className="text-gray-500">{t("payroll.pending")}</dt><dd className="font-semibold text-orange-700">{formatMoney(totals.totalPending ?? 0)}</dd></div>
        </dl>
      </div>
      {list.loading ? <LoadingSpinner /> : list.data.items.length === 0 ? (
        <EmptyState icon={Banknote} title={t("payroll.empty")} text={t("payroll.emptyText")} />
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full text-start text-sm">
            <thead className="bg-gray-50 text-xs uppercase text-gray-500">
              <tr>
                <th className="px-4 py-3">{t("payroll.month")}</th><th className="px-4 py-3">{t("payroll.employee")}</th>
                <th className="px-4 py-3 text-end">{t("payroll.base")}</th><th className="px-4 py-3 text-end">{t("payroll.bonus")}</th>
                <th className="px-4 py-3 text-end">{t("payroll.deductions")}</th><th className="px-4 py-3 text-end">{t("payroll.net")}</th>
                <th className="px-4 py-3">{t("common.status")}</th><th className="px-4 py-3 text-end">{t("common.actions")}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {list.data.items.map((p) => (
                <tr key={p.payrollId} className="hover:bg-orange-50/40">
                  <td className="px-4 py-3 text-gray-700">{p.year}-{String(p.month).padStart(2, "0")}</td>
                  <td className="px-4 py-3 font-medium text-gray-900">{p.employeeName}</td>
                  <td className="px-4 py-3 text-end text-gray-700">{formatMoney(p.baseSalary)}</td>
                  <td className="px-4 py-3 text-end text-gray-700">{formatMoney(p.bonus)}</td>
                  <td className="px-4 py-3 text-end text-gray-700">{formatMoney(p.deductions)}</td>
                  <td className="px-4 py-3 text-end font-semibold text-gray-900">{formatMoney(p.netSalary)}</td>
                  <td className="px-4 py-3"><StatusBadge tone={p.status === "Paid" ? "green" : "orange"}>{p.status === "Paid" ? `${t("payroll.paidStatus")} ${formatDate(p.paidAt)}` : t("payroll.pending")}</StatusBadge></td>
                  <td className="px-4 py-3">
                    {p.status === "Pending" && (
                      <div className="flex justify-end gap-1">
                        <button onClick={() => setPayTarget(p)} className="rounded-lg bg-orange-500 px-2.5 py-1 text-xs font-medium text-white hover:bg-orange-600">{t("payroll.pay")}</button>
                        <button onClick={() => onEdit(p)} className="icon-btn" title={t("payroll.editEntry")} aria-label={t("payroll.editEntry")}><Pencil className="h-4 w-4" /></button>
                        <button onClick={() => setDeleteTarget(p)} className="icon-btn" title={t("payroll.deleteEntry")} aria-label={t("payroll.deleteEntry")}><Trash2 className="h-4 w-4" /></button>
                      </div>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      <Pagination page={list.page} pageSize={list.pageSize} total={list.data.total} onPage={list.setPage} />

      <ConfirmDialog open={payTarget !== null} busy={busy} title={t("payroll.payTitle")} confirmLabel={t("payroll.pay")}
        message={payTarget ? `${payTarget.employeeName} - ${payTarget.year}-${String(payTarget.month).padStart(2, "0")}: ${formatMoney(payTarget.netSalary)}. ${t("payroll.payNote")}` : ""}
        onConfirm={pay} onCancel={() => setPayTarget(null)} />
      <ConfirmDialog open={deleteTarget !== null} busy={busy} danger title={t("payroll.deleteEntry")} confirmLabel={t("payroll.deleteEntry")}
        message={deleteTarget ? `${deleteTarget.employeeName} - ${deleteTarget.year}-${String(deleteTarget.month).padStart(2, "0")}. ${t("payroll.deleteNote")}` : ""}
        onConfirm={remove} onCancel={() => setDeleteTarget(null)} />
    </div>
  );
}

// ---------------------------------------------------------------- employees

function EmployeesTab({ list, onEdit }: { list: ReturnType<typeof usePagedList<PayrollEmployee, { isActive?: boolean }>>; onEdit: (e: PayrollEmployee) => void }) {
  const { t } = usePreferences();
  return (
    <div className="rounded-2xl border border-gray-200 bg-white shadow-sm">
      <div className="flex flex-wrap items-center gap-2 border-b border-gray-100 p-4">
        <SearchBox value={list.search} onChange={list.setSearch} onSearch={list.submitSearch} placeholder={t("payroll.search")} />
      </div>
      {list.loading ? <LoadingSpinner /> : list.data.items.length === 0 ? (
        <EmptyState icon={Users} title={t("payroll.noEmployees")} text={t("payroll.noEmployeesText")} />
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full text-start text-sm">
            <thead className="bg-gray-50 text-xs uppercase text-gray-500">
              <tr><th className="px-4 py-3">{t("common.name")}</th><th className="px-4 py-3">{t("payroll.jobTitle")}</th><th className="px-4 py-3">{t("payroll.phone")}</th><th className="px-4 py-3 text-end">{t("payroll.base")}</th><th className="px-4 py-3">{t("common.status")}</th><th className="px-4 py-3 text-end">{t("common.actions")}</th></tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {list.data.items.map((e) => (
                <tr key={e.employeeId} className="hover:bg-orange-50/40">
                  <td className="px-4 py-3 font-medium text-gray-900">{e.fullName}</td>
                  <td className="px-4 py-3 text-gray-700">{e.jobTitle || "-"}</td>
                  <td className="px-4 py-3 text-gray-700">{e.phone || "-"}</td>
                  <td className="px-4 py-3 text-end text-gray-900">{formatMoney(e.baseSalary)}</td>
                  <td className="px-4 py-3"><StatusBadge tone={e.isActive ? "green" : "gray"}>{e.isActive ? t("common.active") : t("common.inactive")}</StatusBadge></td>
                  <td className="px-4 py-3"><div className="flex justify-end"><button onClick={() => onEdit(e)} className="icon-btn" title={t("payroll.editEmployee")} aria-label={t("payroll.editEmployee")}><Pencil className="h-4 w-4" /></button></div></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      <Pagination page={list.page} pageSize={list.pageSize} total={list.data.total} onPage={list.setPage} />
    </div>
  );
}
