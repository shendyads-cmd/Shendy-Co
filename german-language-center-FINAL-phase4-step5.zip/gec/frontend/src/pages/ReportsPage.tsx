import { useEffect, useState } from "react";
import type { ReactNode } from "react";
import { ArrowDownCircle, ArrowUpCircle, Banknote, BookOpen, Clock, CreditCard, PieChart, Receipt, Scale, TrendingUp, Wallet } from "lucide-react";
import type { LucideIcon } from "lucide-react";
import { CourseTable, KpiCard, invoiceTone, money, useStatusText } from "../components/analytics/shared";
import DateRangePicker from "../components/DateRangePicker";
import type { DateRange } from "../components/DateRangePicker";
import EmptyState from "../components/EmptyState";
import LoadingSpinner from "../components/LoadingSpinner";
import PageHeader from "../components/PageHeader";
import Pagination from "../components/Pagination";
import StatusBadge from "../components/StatusBadge";
import { usePreferences } from "../contexts/PreferencesContext";
import { useToast } from "../contexts/ToastContext";
import { parseError } from "../services/api";
import { reportService } from "../services/reportService";
import type { CourseReport, ExpenseReport, FinancialSummary, OutstandingReport, PayrollPage, PaymentsReport, ReportParams, SalesReport } from "../types";
import { formatDate } from "../utils/format";

type Tab = "summary" | "sales" | "payments" | "expenses" | "outstanding" | "courses" | "payroll";
const TABS: { id: Tab; icon: LucideIcon }[] = [
  { id: "summary", icon: PieChart }, { id: "sales", icon: TrendingUp }, { id: "payments", icon: Wallet }, { id: "expenses", icon: CreditCard },
  { id: "outstanding", icon: Clock }, { id: "courses", icon: BookOpen }, { id: "payroll", icon: Banknote }
];
const PAGE_SIZE = 15;
const th = "px-3 py-3";

/** Loads one report from the API for the selected period. The tab is re-mounted when the period changes, so paging starts again at page 1. */
function useReport<T>(fetcher: (p: ReportParams) => Promise<T>, range: DateRange, paged: boolean) {
  const toast = useToast();
  const [page, setPage] = useState(1);
  const [data, setData] = useState<T | null>(null);
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    let off = false;
    setLoading(true);
    fetcher({ fromDate: range.from, toDate: range.to, ...(paged ? { page, pageSize: PAGE_SIZE } : {}) })
      .then((d) => { if (!off) setData(d); })
      .catch((err) => { if (!off) toast.error(parseError(err).message); })
      .finally(() => { if (!off) setLoading(false); });
    return () => { off = true; };
    // fetcher and toast are stable; the period and the page are the inputs
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [range.from, range.to, page]);
  return { data, loading, page, setPage };
}

function Panel({ children }: { children: ReactNode }) {
  return <div className="rounded-2xl border border-gray-200 bg-white shadow-sm">{children}</div>;
}

function Totals({ items }: { items: { label: string; value: string; strong?: boolean }[] }) {
  return (
    <dl className="flex flex-wrap gap-x-6 gap-y-2 border-b border-gray-100 p-4 text-sm">
      {items.map((i) => <div key={i.label}><dt className="text-gray-500">{i.label}</dt><dd className={`font-semibold ${i.strong ? "text-orange-700" : "text-gray-900"}`}>{i.value}</dd></div>)}
    </dl>
  );
}

// ---------------------------------------------------------------- page

export default function ReportsPage() {
  const { t } = usePreferences();
  const [tab, setTab] = useState<Tab>("summary");
  const [range, setRange] = useState<DateRange>({});
  const key = `${range.from ?? ""}|${range.to ?? ""}`;

  return (
    <div className="space-y-4">
      <PageHeader title={t("nav.reports")} subtitle={t("rep.subtitle")} />
      <div className="flex flex-wrap items-center gap-2">
        <DateRangePicker value={range} onChange={setRange} />
        <span className="text-sm text-gray-600">{range.from || range.to ? `${range.from ?? "…"} → ${range.to ?? "…"}` : t("rep.allDates")}</span>
        {(range.from || range.to) && <button onClick={() => setRange({})} className="text-sm font-medium text-orange-700 hover:underline">{t("rep.clear")}</button>}
      </div>

      <div className="flex gap-1 overflow-x-auto rounded-xl bg-gray-100 p-1 text-sm font-medium" role="tablist">
        {TABS.map(({ id, icon: Icon }) => (
          <button key={id} role="tab" aria-selected={tab === id} onClick={() => setTab(id)}
                  className={`flex shrink-0 items-center gap-2 rounded-lg px-3 py-1.5 ${tab === id ? "bg-white text-orange-700 shadow-sm" : "text-gray-600 hover:text-gray-900"}`}>
            <Icon className="h-4 w-4" /> {t(`rep.tab.${id}`)}
          </button>
        ))}
      </div>

      {tab === "summary" && <SummaryTab key={key} range={range} />}
      {tab === "sales" && <SalesTab key={key} range={range} />}
      {tab === "payments" && <PaymentsTab key={key} range={range} />}
      {tab === "expenses" && <ExpensesTab key={key} range={range} />}
      {tab === "outstanding" && <OutstandingTab key={key} range={range} />}
      {tab === "courses" && <CoursesTab key={key} range={range} />}
      {tab === "payroll" && <PayrollTab key={key} range={range} />}
    </div>
  );
}

// ---------------------------------------------------------------- financial summary

function SummaryTab({ range }: { range: DateRange }) {
  const { t } = usePreferences();
  const { data: s, loading } = useReport<FinancialSummary>(reportService.summary, range, false);
  if (loading && !s) return <LoadingSpinner />;
  if (!s) return <EmptyState icon={PieChart} title={t("rep.empty")} />;
  const reconciled = Math.abs(s.cashInDifference) < 0.005 && Math.abs(s.cashOutDifference) < 0.005;
  const basis = [
    ["kpi.sales", "rep.basis.sales"], ["kpi.collected", "rep.basis.collected"], ["kpi.outstanding", "rep.basis.outstanding"], ["kpi.expenses", "rep.basis.expenses"],
    ["kpi.payroll", "rep.basis.payroll"], ["kpi.cashIn", "rep.basis.cashIn"], ["kpi.cashOut", "rep.basis.cashOut"], ["kpi.net", "rep.basis.net"]
  ];
  return (
    <div className={loading ? "space-y-4 opacity-60" : "space-y-4"}>
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 xl:grid-cols-4">
        <KpiCard icon={TrendingUp} label={t("kpi.sales")} value={money(s.sales)} hint={`${t("kpi.invoices")}: ${s.invoiceCount}`} />
        <KpiCard icon={Wallet} label={t("kpi.collected")} value={money(s.collected)} hint={`${t("kpi.payments")}: ${s.paymentCount}`} />
        <KpiCard icon={Clock} label={t("kpi.outstanding")} value={money(s.outstanding)} hint={`${t("kpi.invoices")}: ${s.outstandingCount}`} />
        <KpiCard icon={Receipt} label={t("kpi.expenses")} value={money(s.expenses)} hint={`${s.expenseCount}`} />
        <KpiCard icon={Banknote} label={t("kpi.payroll")} value={money(s.payroll)} hint={`${t("kpi.payrollPending")}: ${money(s.payrollPending)}`} />
        <KpiCard icon={ArrowDownCircle} label={t("kpi.cashIn")} value={money(s.cashIn)} />
        <KpiCard icon={ArrowUpCircle} label={t("kpi.cashOut")} value={money(s.cashOut)} />
        <KpiCard icon={Scale} label={t("kpi.net")} value={money(s.netResult)} tone={s.netResult >= 0 ? "positive" : "negative"} />
      </div>
      <p className={`rounded-lg px-3 py-2 text-xs ${reconciled ? "bg-green-50 text-green-800" : "bg-yellow-50 text-yellow-800"}`}>
        {reconciled ? t("rep.reconOk") : `${t("rep.reconWarn")} (${t("kpi.cashIn")} - ${t("kpi.collected")}: ${money(s.cashInDifference)}; ${t("kpi.cashOut")} - (${t("kpi.expenses")} + ${t("kpi.payroll")}): ${money(s.cashOutDifference)})`}
      </p>
      <Panel>
        <h2 className="border-b border-gray-100 px-4 py-3 text-sm font-semibold text-gray-800">{t("rep.basis.title")}</h2>
        <dl className="divide-y divide-gray-100 text-sm">
          {basis.map(([label, text]) => <div key={label} className="grid gap-1 px-4 py-2 sm:grid-cols-[10rem_1fr]"><dt className="font-medium text-gray-800">{t(label)}</dt><dd className="text-gray-600">{t(text)}</dd></div>)}
        </dl>
      </Panel>
    </div>
  );
}

// ---------------------------------------------------------------- sales

function StudentCell({ label, type }: { label: string; type: string }) {
  const { t } = usePreferences();
  return <>{label}{type === "Offer" && <span className="ms-2 rounded bg-orange-100 px-1.5 py-0.5 text-xs text-orange-700">{t("rep.typeOffer")}</span>}</>;
}

function SalesTab({ range }: { range: DateRange }) {
  const { t } = usePreferences();
  const st = useStatusText();
  const { data, loading, page, setPage } = useReport<SalesReport>(reportService.sales, range, true);
  if (loading && !data) return <LoadingSpinner />;
  if (!data || data.items.length === 0) return <Panel><EmptyState icon={TrendingUp} title={t("rep.empty")} text={t("rep.emptyText")} /></Panel>;
  return (
    <Panel>
      <Totals items={[{ label: t("rep.col.subtotal"), value: money(data.totalSubtotal) }, { label: t("rep.col.discount"), value: money(data.totalDiscount) }, { label: t("rep.col.final"), value: money(data.totalSales), strong: true }, { label: t("kpi.invoices"), value: String(data.total) }]} />
      <div className={`overflow-x-auto ${loading ? "opacity-60" : ""}`}>
        <table className="w-full text-start text-sm">
          <thead className="bg-gray-50 text-xs uppercase text-gray-500"><tr>
            <th className={th}>{t("rep.col.invoice")}</th><th className={th}>{t("rep.col.date")}</th><th className={th}>{t("rep.col.student")}</th><th className={th}>{t("rep.col.course")}</th>
            <th className={`${th} text-end`}>{t("rep.col.total")}</th><th className={`${th} text-end`}>{t("rep.col.discount")}</th><th className={`${th} text-end`}>{t("rep.col.final")}</th><th className={th}>{t("common.status")}</th>
          </tr></thead>
          <tbody className="divide-y divide-gray-100">
            {data.items.map((r) => (
              <tr key={r.invoiceId} className="hover:bg-orange-50/40">
                <td className="px-3 py-3 font-medium text-gray-900">{r.invoiceNumber}</td><td className="px-3 py-3 text-gray-700">{formatDate(r.issueDate)}</td>
                <td className="px-3 py-3 text-gray-700"><StudentCell label={r.studentLabel} type={r.type} /></td><td className="px-3 py-3 text-gray-700">{r.courseLabel}</td>
                <td className="px-3 py-3 text-end text-gray-700">{money(r.subtotal)}</td><td className="px-3 py-3 text-end text-gray-700">{money(r.discount)}</td>
                <td className="px-3 py-3 text-end font-semibold text-gray-900">{money(r.grandTotal)}</td>
                <td className="px-3 py-3"><StatusBadge tone={invoiceTone(r.paymentStatus)}>{st(r.paymentStatus)}</StatusBadge></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <Pagination page={page} pageSize={PAGE_SIZE} total={data.total} onPage={setPage} />
    </Panel>
  );
}

// ---------------------------------------------------------------- payments

function PaymentsTab({ range }: { range: DateRange }) {
  const { t } = usePreferences();
  const st = useStatusText();
  const { data, loading, page, setPage } = useReport<PaymentsReport>(reportService.payments, range, true);
  if (loading && !data) return <LoadingSpinner />;
  if (!data || data.items.length === 0) return <Panel><EmptyState icon={Wallet} title={t("rep.empty")} text={t("rep.emptyText")} /></Panel>;
  // Cash and InstaPay are the methods of NEW payments; older methods (Visa, Vodafone Cash ...) are shown as they were stored
  const method = (m: string, other?: string | null) => (other ? `${t(`method.${m}`, m)} (${other})` : t(`method.${m}`, m));
  return (
    <Panel>
      <Totals items={[{ label: t("rep.col.amount"), value: money(data.totalAmount), strong: true }, { label: t("kpi.payments"), value: String(data.total) }, ...data.byMethod.map((m) => ({ label: method(m.method), value: `${money(m.total)} (${m.count})` }))]} />
      <div className={`overflow-x-auto ${loading ? "opacity-60" : ""}`}>
        <table className="w-full text-start text-sm">
          <thead className="bg-gray-50 text-xs uppercase text-gray-500"><tr>
            <th className={th}>{t("rep.col.paymentDate")}</th><th className={th}>{t("rep.col.invoice")}</th><th className={th}>{t("rep.col.student")}</th>
            <th className={th}>{t("rep.col.method")}</th><th className={`${th} text-end`}>{t("rep.col.amount")}</th><th className={th}>{t("rep.col.invoiceStatus")}</th>
          </tr></thead>
          <tbody className="divide-y divide-gray-100">
            {data.items.map((r) => (
              <tr key={`${r.paymentId}-${r.invoiceId}`} className="hover:bg-orange-50/40">
                <td className="px-3 py-3 text-gray-700">{formatDate(r.paymentDate)}</td><td className="px-3 py-3 font-medium text-gray-900">{r.invoiceNumber}</td>
                <td className="px-3 py-3 text-gray-700">{r.studentLabel}</td><td className="px-3 py-3 text-gray-700">{method(r.paymentMethod, r.paymentMethodOther)}</td>
                <td className="px-3 py-3 text-end font-semibold text-gray-900">{money(r.amount)}</td>
                <td className="px-3 py-3"><StatusBadge tone={invoiceTone(r.invoiceStatus)}>{st(r.invoiceStatus)}</StatusBadge></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <Pagination page={page} pageSize={PAGE_SIZE} total={data.total} onPage={setPage} />
    </Panel>
  );
}

// ---------------------------------------------------------------- expenses

function ExpensesTab({ range }: { range: DateRange }) {
  const { t } = usePreferences();
  const { data, loading, page, setPage } = useReport<ExpenseReport>(reportService.expenses, range, true);
  if (loading && !data) return <LoadingSpinner />;
  if (!data || data.items.length === 0) return <Panel><EmptyState icon={CreditCard} title={t("rep.empty")} text={t("rep.emptyText")} /></Panel>;
  return (
    <Panel>
      <Totals items={[{ label: t("rep.col.amount"), value: money(data.totalAmount), strong: true }, { label: t("kpi.expenses"), value: String(data.total) },
        ...data.byCategory.map((c) => ({ label: t(`expcat.${c.category}`, c.category), value: `${money(c.total)} (${c.count})` })),
        ...(data.withoutCashOut > 0 ? [{ label: t("rep.withoutCashOut"), value: String(data.withoutCashOut) }] : [])]} />
      <div className={`overflow-x-auto ${loading ? "opacity-60" : ""}`}>
        <table className="w-full text-start text-sm">
          <thead className="bg-gray-50 text-xs uppercase text-gray-500"><tr>
            <th className={th}>{t("rep.col.date")}</th><th className={th}>{t("rep.col.category")}</th><th className={th}>{t("rep.col.description")}</th>
            <th className={`${th} text-end`}>{t("rep.col.amount")}</th><th className={th}>{t("rep.col.user")}</th><th className={th}>{t("rep.col.cashOut")}</th>
          </tr></thead>
          <tbody className="divide-y divide-gray-100">
            {data.items.map((r) => (
              <tr key={r.expenseId} className="hover:bg-orange-50/40">
                <td className="px-3 py-3 text-gray-700">{formatDate(r.expenseDate)}</td><td className="px-3 py-3 text-gray-700">{t(`expcat.${r.category}`, r.category)}</td>
                <td className="max-w-xs px-3 py-3 text-gray-700"><span className="font-medium text-gray-900">{r.title}</span>{r.description && <span className="block truncate text-xs text-gray-500">{r.description}</span>}</td>
                <td className="px-3 py-3 text-end font-semibold text-gray-900">{money(r.amount)}</td><td className="px-3 py-3 text-gray-700">{r.createdBy || "-"}</td>
                <td className="px-3 py-3">{r.cashOutId ? <StatusBadge tone="green">{`#${r.cashOutId}`}</StatusBadge> : <StatusBadge tone="red">{t("rep.noCashOut")}</StatusBadge>}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <Pagination page={page} pageSize={PAGE_SIZE} total={data.total} onPage={setPage} />
    </Panel>
  );
}

// ---------------------------------------------------------------- outstanding

function OutstandingTab({ range }: { range: DateRange }) {
  const { t } = usePreferences();
  const st = useStatusText();
  const { data, loading, page, setPage } = useReport<OutstandingReport>(reportService.outstanding, range, true);
  if (loading && !data) return <LoadingSpinner />;
  if (!data || data.items.length === 0) return <Panel><EmptyState icon={Clock} title={t("rep.emptyOutstanding")} text={t("rep.emptyText")} /></Panel>;
  return (
    <Panel>
      <Totals items={[{ label: t("rep.col.total"), value: money(data.totalGrand) }, { label: t("rep.col.paid"), value: money(data.totalPaid) }, { label: t("rep.col.remaining"), value: money(data.totalRemaining), strong: true }, { label: t("kpi.invoices"), value: String(data.total) }]} />
      <div className={`overflow-x-auto ${loading ? "opacity-60" : ""}`}>
        <table className="w-full text-start text-sm">
          <thead className="bg-gray-50 text-xs uppercase text-gray-500"><tr>
            <th className={th}>{t("rep.col.invoice")}</th><th className={th}>{t("rep.col.student")}</th><th className={th}>{t("rep.col.course")}</th>
            <th className={`${th} text-end`}>{t("rep.col.total")}</th><th className={`${th} text-end`}>{t("rep.col.paid")}</th><th className={`${th} text-end`}>{t("rep.col.remaining")}</th><th className={th}>{t("common.status")}</th>
          </tr></thead>
          <tbody className="divide-y divide-gray-100">
            {data.items.map((r) => (
              <tr key={r.invoiceId} className="hover:bg-orange-50/40">
                <td className="px-3 py-3"><span className="font-medium text-gray-900">{r.invoiceNumber}</span><span className="block text-xs text-gray-500">{formatDate(r.issueDate)}</span></td>
                <td className="px-3 py-3 text-gray-700"><StudentCell label={r.studentLabel} type={r.type} /></td><td className="px-3 py-3 text-gray-700">{r.courseLabel}</td>
                <td className="px-3 py-3 text-end text-gray-700">{money(r.grandTotal)}</td><td className="px-3 py-3 text-end text-gray-700">{money(r.paid)}</td>
                <td className="px-3 py-3 text-end font-semibold text-orange-700">{money(r.remaining)}</td>
                <td className="px-3 py-3"><StatusBadge tone={invoiceTone(r.paymentStatus)}>{st(r.paymentStatus)}</StatusBadge></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <Pagination page={page} pageSize={PAGE_SIZE} total={data.total} onPage={setPage} />
    </Panel>
  );
}

// ---------------------------------------------------------------- courses

function CoursesTab({ range }: { range: DateRange }) {
  const { t } = usePreferences();
  const { data, loading } = useReport<CourseReport>(reportService.courses, range, false);
  if (loading && !data) return <LoadingSpinner />;
  if (!data || data.items.length === 0) return <Panel><EmptyState icon={BookOpen} title={t("rep.empty")} text={t("rep.emptyText")} /></Panel>;
  return (
    <Panel>
      <p className="border-b border-gray-100 px-4 py-3 text-xs text-gray-500">{t("rep.courseNote")}</p>
      <div className={loading ? "opacity-60" : ""}><CourseTable rows={data.items} footer={{ revenue: data.totalRevenue, paid: data.totalPaid, remaining: data.totalRemaining }} /></div>
    </Panel>
  );
}

// ---------------------------------------------------------------- payroll

function PayrollTab({ range }: { range: DateRange }) {
  const { t } = usePreferences();
  const st = useStatusText();
  const { data, loading, page, setPage } = useReport<PayrollPage>(reportService.payroll, range, true);
  if (loading && !data) return <LoadingSpinner />;
  if (!data || data.items.length === 0) return <Panel><EmptyState icon={Banknote} title={t("rep.empty")} text={t("rep.emptyText")} /></Panel>;
  return (
    <Panel>
      <Totals items={[{ label: t("rep.col.net"), value: money(data.totalNet), strong: true }, { label: t("st.Paid"), value: money(data.totalPaid) }, { label: t("st.Pending"), value: money(data.totalPending) }]} />
      <p className="px-4 pt-3 text-xs text-gray-500">{t("rep.payrollNote")}</p>
      <div className={`overflow-x-auto ${loading ? "opacity-60" : ""}`}>
        <table className="w-full text-start text-sm">
          <thead className="bg-gray-50 text-xs uppercase text-gray-500"><tr>
            <th className={th}>{t("rep.col.employee")}</th><th className={th}>{t("rep.col.month")}</th><th className={`${th} text-end`}>{t("rep.col.base")}</th><th className={`${th} text-end`}>{t("rep.col.bonus")}</th>
            <th className={`${th} text-end`}>{t("rep.col.deductions")}</th><th className={`${th} text-end`}>{t("rep.col.net")}</th><th className={th}>{t("common.status")}</th><th className={th}>{t("rep.col.paymentDate")}</th>
          </tr></thead>
          <tbody className="divide-y divide-gray-100">
            {data.items.map((r) => (
              <tr key={r.payrollId} className="hover:bg-orange-50/40">
                <td className="px-3 py-3 font-medium text-gray-900">{r.employeeName}</td><td className="px-3 py-3 text-gray-700">{r.year}-{String(r.month).padStart(2, "0")}</td>
                <td className="px-3 py-3 text-end text-gray-700">{money(r.baseSalary)}</td><td className="px-3 py-3 text-end text-gray-700">{money(r.bonus)}</td>
                <td className="px-3 py-3 text-end text-gray-700">{money(r.deductions)}</td><td className="px-3 py-3 text-end font-semibold text-gray-900">{money(r.netSalary)}</td>
                <td className="px-3 py-3"><StatusBadge tone={r.status === "Paid" ? "green" : "orange"}>{st(r.status)}</StatusBadge></td>
                <td className="px-3 py-3 text-gray-700">{r.paidAt ? formatDate(r.paidAt) : "-"}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <Pagination page={page} pageSize={PAGE_SIZE} total={data.total} onPage={setPage} />
    </Panel>
  );
}
