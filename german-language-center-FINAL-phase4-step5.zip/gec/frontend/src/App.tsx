import { lazy, Suspense } from "react";
import { Navigate, Route, Routes } from "react-router-dom";
import LoadingSpinner from "./components/LoadingSpinner";
import ProtectedRoute from "./components/ProtectedRoute";
import { useAuth } from "./contexts/AuthContext";
import MainLayout from "./layouts/MainLayout";
import LoginPage from "./pages/LoginPage";
import CourseDetailsPage from "./pages/CourseDetailsPage";
import DeletedStudentsPage from "./pages/DeletedStudentsPage";
import CoursesPage from "./pages/CoursesPage";
import StudentDetailsPage from "./pages/StudentDetailsPage";
import StudentsPage from "./pages/StudentsPage";
import ExpensesPage from "./pages/ExpensesPage";
import InvoicesPage from "./pages/InvoicesPage";
import AccountSettingsPage from "./pages/AccountSettingsPage";
import DataPage from "./pages/DataPage";
import PayrollPage from "./pages/PayrollPage";

// The chart library is only downloaded when Dashboard or Reports is opened.
const DashboardPage = lazy(() => import("./pages/DashboardPage"));
const ReportsPage = lazy(() => import("./pages/ReportsPage"));
import { homePath } from "./utils/navigation";
import type { Role } from "./types";

const BOTH: Role[] = ["Admin", "Employee"];
// Pages implemented so far; the rest still use the phase shell.

function Home() {
  const { user } = useAuth();
  return <Navigate to={user ? homePath(user.role) : "/login"} replace />;
}

export default function App() {
  return (
    <Routes>
      <Route path="/login" element={<LoginPage />} />
      <Route element={<ProtectedRoute><MainLayout /></ProtectedRoute>}>
        <Route index element={<Home />} />
        <Route path="/dashboard" element={<ProtectedRoute roles={["Admin"]}><Suspense fallback={<LoadingSpinner />}><DashboardPage /></Suspense></ProtectedRoute>} />
        <Route path="/reports" element={<ProtectedRoute roles={["Admin"]}><Suspense fallback={<LoadingSpinner />}><ReportsPage /></Suspense></ProtectedRoute>} />
        <Route path="/students" element={<ProtectedRoute roles={BOTH}><StudentsPage /></ProtectedRoute>} />
        <Route path="/students/deleted" element={<ProtectedRoute roles={["Admin"]}><DeletedStudentsPage /></ProtectedRoute>} />
        <Route path="/students/:id" element={<ProtectedRoute roles={BOTH}><StudentDetailsPage /></ProtectedRoute>} />
        <Route path="/courses" element={<ProtectedRoute roles={BOTH}><CoursesPage /></ProtectedRoute>} />
        <Route path="/courses/:id" element={<ProtectedRoute roles={BOTH}><CourseDetailsPage /></ProtectedRoute>} />
        <Route path="/invoices" element={<ProtectedRoute roles={BOTH}><InvoicesPage /></ProtectedRoute>} />
        <Route path="/expenses" element={<ProtectedRoute roles={["Admin"]}><ExpensesPage /></ProtectedRoute>} />
        <Route path="/payroll" element={<ProtectedRoute roles={["Admin"]}><PayrollPage /></ProtectedRoute>} />
        <Route path="/data" element={<ProtectedRoute roles={BOTH}><DataPage /></ProtectedRoute>} />
        <Route path="/account" element={<ProtectedRoute roles={BOTH}><AccountSettingsPage /></ProtectedRoute>} />
        {/* old addresses */}
        <Route path="/settings" element={<Navigate to="/account" replace />} />
        <Route path="/users" element={<Navigate to="/account?section=users" replace />} />
      </Route>
      <Route path="*" element={<Home />} />
    </Routes>
  );
}
