-- Global idempotency / duplicate-operation protection.
-- Non-destructive and safe to run more than once.
--
--   IdempotencyKeys  one row per (user, operation, key). The API reserves the key BEFORE it creates anything:
--                    the UNIQUE index below is what makes a repeated request (double click, refresh, retry after a timeout)
--                    impossible to process twice. After the first request finishes, the original response is stored and is
--                    returned again for every repeat of the same key.
--
-- Also verifies/creates the database constraints that protect real relationships (these are NOT replaced by the key):
--   * one ACTIVE enrollment per student and course     (UX_Enrollments_active_customer_course, also created by 007)
--   * unique invoice numbers                           (UX_Invoices_invoice_number, skipped if duplicates or a unique index already exist)
SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
SET ANSI_PADDING ON;
SET ANSI_WARNINGS ON;
SET ARITHABORT ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET NUMERIC_ROUNDABORT OFF;
GO
USE german_language_center;
GO

IF OBJECT_ID(N'dbo.IdempotencyKeys', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.IdempotencyKeys
    (
        idempotency_id  INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_IdempotencyKeys PRIMARY KEY,
        user_id         INT           NOT NULL,
        operation       NVARCHAR(60)  NOT NULL,                  -- e.g. customers.create, invoices.create
        idem_key        NVARCHAR(100) NOT NULL,                  -- the Idempotency-Key header sent by the browser
        request_hash    CHAR(64)      NOT NULL,                  -- SHA-256 of the request; same key + different data is rejected
        status          NVARCHAR(20)  NOT NULL,                  -- Processing | Completed
        response_status INT           NULL,
        response_body   NVARCHAR(MAX) NULL,                      -- the original result, returned again on a repeat
        created_at      DATETIME2(0)  NOT NULL CONSTRAINT DF_IdempotencyKeys_created_at DEFAULT (SYSDATETIME()),
        completed_at    DATETIME2(0)  NULL,
        CONSTRAINT CK_IdempotencyKeys_status CHECK (status IN (N'Processing', N'Completed')),
        CONSTRAINT FK_IdempotencyKeys_user FOREIGN KEY (user_id) REFERENCES dbo.Users (user_id)
    );
END
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'UX_IdempotencyKeys_user_operation_key' AND object_id = OBJECT_ID(N'dbo.IdempotencyKeys'))
    CREATE UNIQUE NONCLUSTERED INDEX UX_IdempotencyKeys_user_operation_key ON dbo.IdempotencyKeys (user_id, operation, idem_key);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_IdempotencyKeys_created_at' AND object_id = OBJECT_ID(N'dbo.IdempotencyKeys'))
    CREATE NONCLUSTERED INDEX IX_IdempotencyKeys_created_at ON dbo.IdempotencyKeys (created_at);
GO

-- One ACTIVE enrollment per student and course (same index as script 007; created here if 007 skipped it).
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'UX_Enrollments_active_customer_course' AND object_id = OBJECT_ID(N'dbo.Enrollments'))
BEGIN
    IF EXISTS (SELECT 1 FROM dbo.Enrollments WHERE status = N'Active' GROUP BY customer_id, course_id HAVING COUNT(*) > 1)
    BEGIN
        PRINT 'SKIPPED the one-active-enrollment index: duplicate ACTIVE enrollments exist. They are listed below. Cancel the extra rows, then run this script again.';
        SELECT customer_id, course_id, COUNT(*) AS active_rows, MIN(enrollment_id) AS keep_this_id
        FROM dbo.Enrollments WHERE status = N'Active' GROUP BY customer_id, course_id HAVING COUNT(*) > 1;
    END
    ELSE
        CREATE UNIQUE NONCLUSTERED INDEX UX_Enrollments_active_customer_course ON dbo.Enrollments (customer_id, course_id) WHERE status = N'Active';
END
GO

-- Invoice numbers must be unique. Only added when no UNIQUE index/constraint on invoice_number alone exists yet.
IF OBJECT_ID(N'dbo.Invoices', N'U') IS NOT NULL
   AND NOT EXISTS (
        SELECT 1
        FROM sys.indexes i
        WHERE i.object_id = OBJECT_ID(N'dbo.Invoices') AND i.is_unique = 1 AND i.has_filter = 0
          AND (SELECT COUNT(*) FROM sys.index_columns ic WHERE ic.object_id = i.object_id AND ic.index_id = i.index_id AND ic.is_included_column = 0) = 1
          AND EXISTS (SELECT 1 FROM sys.index_columns ic JOIN sys.columns c ON c.object_id = ic.object_id AND c.column_id = ic.column_id
                      WHERE ic.object_id = i.object_id AND ic.index_id = i.index_id AND c.name = N'invoice_number'))
BEGIN
    IF EXISTS (SELECT 1 FROM dbo.Invoices GROUP BY invoice_number HAVING COUNT(*) > 1)
        PRINT 'SKIPPED the unique invoice number index: duplicate invoice numbers exist. Fix them, then run this script again.';
    ELSE
    BEGIN
        BEGIN TRY
            CREATE UNIQUE NONCLUSTERED INDEX UX_Invoices_invoice_number ON dbo.Invoices (invoice_number);
        END TRY
        BEGIN CATCH
            PRINT 'SKIPPED the unique invoice number index: ' + ERROR_MESSAGE();
        END CATCH
    END
END
GO

PRINT 'Idempotency tables and duplicate-protection indexes are ready. Run database/Scripts/diagnostics/verify_idempotency.sql to check them.';
GO
