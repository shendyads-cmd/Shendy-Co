-- Step 2: course codes change from A001 to A-001.
-- Converts EXISTING codes in place. Only Courses.course_code is updated: course_id, prices, enrollments, invoices and every other column
-- stay exactly as they are (invoices and enrollments point to course_id, not to the code), so nothing is lost or duplicated.
-- Safe to run more than once (rows already in the A-001 format are skipped) and all-or-nothing (one transaction).
-- It STOPS with a clear message, changing nothing, if the column is too short or if two courses would end up with the same code.
-- Run it ONCE against german_language_center, then restart the API. New courses are created as A-001, A-002, ... by the API.
SET XACT_ABORT ON;
SET NOCOUNT ON;
GO
USE german_language_center;
GO

DECLARE @maxChars INT =
(
    SELECT CASE WHEN c.max_length = -1 THEN 2147483647
                WHEN ty.name IN (N'nvarchar', N'nchar') THEN c.max_length / 2
                ELSE c.max_length END
    FROM sys.columns c
    JOIN sys.types ty ON ty.user_type_id = c.user_type_id
    WHERE c.object_id = OBJECT_ID(N'dbo.Courses') AND c.name = N'course_code'
);

IF @maxChars IS NULL
    THROW 50010, N'Courses.course_code was not found. Nothing was changed.', 1;

IF @maxChars < 8
    THROW 50011, N'Courses.course_code is shorter than 8 characters, too short for A-001 style codes. Nothing was changed. Widen the column first (drop and re-create the unique index UX_Courses_course_code around the ALTER) and run this script again.', 1;

-- old format = the letter A followed by digits only (A001, A12 ...)
CREATE TABLE #Map (course_id INT NOT NULL PRIMARY KEY, old_code NVARCHAR(50) NOT NULL, new_code NVARCHAR(50) NOT NULL);

INSERT INTO #Map (course_id, old_code, new_code)
SELECT course_id,
       course_code,
       N'A-' + CASE WHEN LEN(SUBSTRING(course_code, 2, 50)) < 3 THEN RIGHT(N'000' + SUBSTRING(course_code, 2, 50), 3)
                    ELSE SUBSTRING(course_code, 2, 50) END
FROM dbo.Courses
WHERE course_code LIKE N'A[0-9]%'
  AND SUBSTRING(course_code, 2, 50) NOT LIKE N'%[^0-9]%';

IF NOT EXISTS (SELECT 1 FROM #Map)
BEGIN
    PRINT N'Nothing to convert: no course code is in the old A001 format.';
    DROP TABLE #Map;
    RETURN;
END

-- two old codes that would become the same new code (for example A1 and A001)
IF EXISTS (SELECT new_code FROM #Map GROUP BY new_code HAVING COUNT(*) > 1)
BEGIN
    SELECT new_code, COUNT(*) AS courses_with_this_new_code FROM #Map GROUP BY new_code HAVING COUNT(*) > 1;
    THROW 50012, N'Two courses would receive the same new code (listed above). Nothing was changed. Fix those codes by hand and run the script again.', 1;
END

-- a new code that is already used by a different course
IF EXISTS (SELECT 1 FROM #Map m JOIN dbo.Courses c ON c.course_code = m.new_code AND c.course_id <> m.course_id)
BEGIN
    SELECT m.course_id, m.old_code, m.new_code FROM #Map m JOIN dbo.Courses c ON c.course_code = m.new_code AND c.course_id <> m.course_id;
    THROW 50013, N'A new code is already used by another course (listed above). Nothing was changed.', 1;
END

DECLARE @expected INT = (SELECT COUNT(*) FROM #Map);
DECLARE @before INT = (SELECT COUNT(*) FROM dbo.Courses);

BEGIN TRANSACTION;

UPDATE c SET course_code = m.new_code
FROM dbo.Courses c
JOIN #Map m ON m.course_id = c.course_id;

IF @@ROWCOUNT <> @expected OR (SELECT COUNT(*) FROM dbo.Courses) <> @before
    THROW 50014, N'Unexpected row count. The conversion was rolled back; nothing was changed.', 1;

-- Notifications keep their text in English plus the values as JSON: bring the old "course full" notices in line (only if the table exists).
IF OBJECT_ID(N'dbo.Notifications', N'U') IS NOT NULL
BEGIN
    UPDATE n SET
        message     = CASE WHEN n.message LIKE m.old_code + N' %' THEN m.new_code + SUBSTRING(n.message, LEN(m.old_code) + 1, 1000) ELSE n.message END,
        title       = REPLACE(n.title, N' ' + m.old_code + N' ', N' ' + m.new_code + N' '),
        params_json = REPLACE(n.params_json, N'"courseCode":"' + m.old_code + N'"', N'"courseCode":"' + m.new_code + N'"')
    FROM dbo.Notifications n
    JOIN #Map m ON n.params_json LIKE N'%"courseCode":"' + m.old_code + N'"%';
END

COMMIT TRANSACTION;

PRINT CONCAT(N'Converted ', @expected, N' course code(s) to the A-001 format.');
SELECT old_code, new_code FROM #Map ORDER BY course_id;
DROP TABLE #Map;
GO
