-- Step 3: financial core (standalone payments, expenses with Cash Out, payroll with Cash Out, duplicate protection).
-- Non-destructive and safe to run more than once. Nothing is dropped. Run ONCE against german_language_center, then restart the API.
--
--   Cash In  = Transactions.transaction_type 'INCOME'  linked to ONE payment   (related_payment_id)
--   Cash Out = Transactions.transaction_type 'EXPENSE' linked to ONE expense   (related_expense_id)
--                                                      or to ONE payroll entry (related_payroll_id)
--
-- What it does
--   1. checks that Transactions.transaction_type accepts 'EXPENSE' (stops with a clear message if a CHECK constraint forbids it)
--   2. Expenses: adds created_at (if missing) and a CHECK amount > 0 (only if all existing rows comply)
--   3. creates PayrollEmployees and PayrollEntries (one salary entry per employee and month, net salary protected by a CHECK)
--   4. Transactions: adds related_payroll_id (+ foreign key)
--   5. UNIQUE filtered indexes so a payment, an expense or a payroll entry can never have two cash transactions
--      (each index is skipped with a warning if old data already contains duplicates; fix the data and run the script again)
--   6. gives every old expense that has no Cash Out row its Cash Out row (back-fill), so reports see all expenses
SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
SET XACT_ABORT ON;
GO
USE german_language_center;
GO

-- ------------------------------------------------------------------ 1. transaction types
DECLARE @def NVARCHAR(MAX) =
(
    SELECT TOP (1) cc.definition FROM sys.check_constraints cc
    WHERE cc.parent_object_id = OBJECT_ID(N'dbo.Transactions') AND cc.definition LIKE N'%transaction_type%'
);
IF @def IS NOT NULL
BEGIN
    PRINT CONCAT(N'Existing CHECK on Transactions.transaction_type: ', @def);
    IF @def NOT LIKE N'%EXPENSE%'
        THROW 50020, N'The CHECK constraint on Transactions.transaction_type does not allow the value EXPENSE (printed above). Nothing was changed. Extend that constraint to allow ''EXPENSE'' and run this script again.', 1;
END
GO

-- ------------------------------------------------------------------ 2. Expenses
IF COL_LENGTH(N'dbo.Expenses', N'created_at') IS NULL
    ALTER TABLE dbo.Expenses ADD created_at DATETIME2(0) NOT NULL CONSTRAINT DF_Expenses_created_at DEFAULT (SYSDATETIME());
GO
IF NOT EXISTS (SELECT 1 FROM sys.check_constraints WHERE name = N'CK_Expenses_amount_positive' AND parent_object_id = OBJECT_ID(N'dbo.Expenses'))
BEGIN
    IF EXISTS (SELECT 1 FROM dbo.Expenses WHERE amount <= 0)
        PRINT N'WARNING: some old expenses have an amount <= 0, so CK_Expenses_amount_positive was NOT created. Correct them and run this script again.';
    ELSE
        ALTER TABLE dbo.Expenses ADD CONSTRAINT CK_Expenses_amount_positive CHECK (amount > 0);
END
GO

-- ------------------------------------------------------------------ 3. payroll tables
IF OBJECT_ID(N'dbo.PayrollEmployees', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.PayrollEmployees
    (
        employee_id  INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_PayrollEmployees PRIMARY KEY,
        full_name    NVARCHAR(150) NOT NULL,
        job_title    NVARCHAR(100) NULL,
        phone        NVARCHAR(30)  NULL,
        base_salary  DECIMAL(12,2) NOT NULL CONSTRAINT CK_PayrollEmployees_salary CHECK (base_salary >= 0),
        is_active    BIT NOT NULL CONSTRAINT DF_PayrollEmployees_active DEFAULT (1),
        created_at   DATETIME2(0) NOT NULL CONSTRAINT DF_PayrollEmployees_created DEFAULT (SYSDATETIME()),
        created_by   INT NULL CONSTRAINT FK_PayrollEmployees_created_by FOREIGN KEY REFERENCES dbo.Users (user_id)
    );
    CREATE INDEX IX_PayrollEmployees_name ON dbo.PayrollEmployees (full_name);
END
GO
IF OBJECT_ID(N'dbo.PayrollEntries', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.PayrollEntries
    (
        payroll_id    INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_PayrollEntries PRIMARY KEY,
        employee_id   INT NOT NULL CONSTRAINT FK_PayrollEntries_employee FOREIGN KEY REFERENCES dbo.PayrollEmployees (employee_id),
        period_year   SMALLINT NOT NULL,
        period_month  TINYINT  NOT NULL CONSTRAINT CK_PayrollEntries_month CHECK (period_month BETWEEN 1 AND 12),
        base_salary   DECIMAL(12,2) NOT NULL,
        bonus         DECIMAL(12,2) NOT NULL CONSTRAINT DF_PayrollEntries_bonus DEFAULT (0),
        deductions    DECIMAL(12,2) NOT NULL CONSTRAINT DF_PayrollEntries_deductions DEFAULT (0),
        net_salary    DECIMAL(12,2) NOT NULL,   -- always base_salary + bonus - deductions (enforced below)
        status        NVARCHAR(20)  NOT NULL CONSTRAINT DF_PayrollEntries_status DEFAULT (N'Pending') CONSTRAINT CK_PayrollEntries_status CHECK (status IN (N'Pending', N'Paid')),
        notes         NVARCHAR(300) NULL,
        created_at    DATETIME2(0) NOT NULL CONSTRAINT DF_PayrollEntries_created DEFAULT (SYSDATETIME()),
        created_by    INT NULL CONSTRAINT FK_PayrollEntries_created_by FOREIGN KEY REFERENCES dbo.Users (user_id),
        updated_at    DATETIME2(0) NULL,
        paid_at       DATETIME2(0) NULL,
        paid_by       INT NULL CONSTRAINT FK_PayrollEntries_paid_by FOREIGN KEY REFERENCES dbo.Users (user_id),
        CONSTRAINT CK_PayrollEntries_amounts CHECK (base_salary >= 0 AND bonus >= 0 AND deductions >= 0 AND net_salary >= 0 AND net_salary = base_salary + bonus - deductions),
        CONSTRAINT CK_PayrollEntries_paid CHECK ((status = N'Paid' AND paid_at IS NOT NULL) OR (status = N'Pending' AND paid_at IS NULL))
    );
    -- one salary entry per employee and month: the same salary can never be created twice
    CREATE UNIQUE INDEX UX_PayrollEntries_employee_period ON dbo.PayrollEntries (employee_id, period_year, period_month);
    CREATE INDEX IX_PayrollEntries_period ON dbo.PayrollEntries (period_year, period_month);
END
GO

-- ------------------------------------------------------------------ 4. Transactions.related_payroll_id
IF COL_LENGTH(N'dbo.Transactions', N'related_payroll_id') IS NULL
    ALTER TABLE dbo.Transactions ADD related_payroll_id INT NULL;
GO
IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_Transactions_payroll')
    ALTER TABLE dbo.Transactions ADD CONSTRAINT FK_Transactions_payroll FOREIGN KEY (related_payroll_id) REFERENCES dbo.PayrollEntries (payroll_id);
GO

-- ------------------------------------------------------------------ 5. one cash transaction per payment / expense / payroll entry
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'UX_Transactions_payment' AND object_id = OBJECT_ID(N'dbo.Transactions'))
BEGIN
    IF EXISTS (SELECT related_payment_id FROM dbo.Transactions WHERE related_payment_id IS NOT NULL GROUP BY related_payment_id HAVING COUNT(*) > 1)
        PRINT N'WARNING: some payments have more than one Cash In row; UX_Transactions_payment was NOT created. Remove the duplicates and run this script again.';
    ELSE
        CREATE UNIQUE INDEX UX_Transactions_payment ON dbo.Transactions (related_payment_id) WHERE related_payment_id IS NOT NULL;
END
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'UX_Transactions_expense' AND object_id = OBJECT_ID(N'dbo.Transactions'))
BEGIN
    IF EXISTS (SELECT related_expense_id FROM dbo.Transactions WHERE related_expense_id IS NOT NULL GROUP BY related_expense_id HAVING COUNT(*) > 1)
        PRINT N'WARNING: some expenses have more than one Cash Out row; UX_Transactions_expense was NOT created. Remove the duplicates and run this script again.';
    ELSE
        CREATE UNIQUE INDEX UX_Transactions_expense ON dbo.Transactions (related_expense_id) WHERE related_expense_id IS NOT NULL;
END
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'UX_Transactions_payroll' AND object_id = OBJECT_ID(N'dbo.Transactions'))
    CREATE UNIQUE INDEX UX_Transactions_payroll ON dbo.Transactions (related_payroll_id) WHERE related_payroll_id IS NOT NULL;
GO

-- ------------------------------------------------------------------ 6. back-fill Cash Out for old expenses
DECLARE @filled INT;
INSERT INTO dbo.Transactions (transaction_type, amount, related_payment_id, related_expense_id, transaction_date)
SELECT N'EXPENSE', e.amount, NULL, e.expense_id, e.expense_date
FROM dbo.Expenses e
WHERE NOT EXISTS (SELECT 1 FROM dbo.Transactions t WHERE t.related_expense_id = e.expense_id);
SET @filled = @@ROWCOUNT;
PRINT CONCAT(N'Cash Out rows created for old expenses: ', @filled);
GO

PRINT N'Financial core is ready.';
GO
