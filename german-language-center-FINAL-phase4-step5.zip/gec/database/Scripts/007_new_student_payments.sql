-- New Student workflow (student + enrollment + invoice + payment).
-- Non-destructive and safe to run more than once. It only ADDS columns / relaxes one CHECK constraint / adds one index:
--   1. Customers.area                      - the student's area / region (Girga, Sohag, ...)
--   2. Payments.payment_method_other       - optional free text when the method is "Other"
--   3. Payments.proof_* columns            - metadata of an optional InstaPay / Vodafone Cash proof (the file itself is stored on disk)
--   4. Payments method CHECK constraint    - now also allows 'InstaPay'. Old values (Bank Transfer, Visa) stay valid for old records.
--   5. One ACTIVE enrollment per student and course (filtered unique index; skipped if duplicates already exist).
-- Nothing is deleted, no identity is reseeded.
USE german_language_center;
GO

IF COL_LENGTH('dbo.Customers', 'area') IS NULL
    ALTER TABLE dbo.Customers ADD area NVARCHAR(100) NULL;
GO
IF COL_LENGTH('dbo.Payments', 'payment_method_other') IS NULL
    ALTER TABLE dbo.Payments ADD payment_method_other NVARCHAR(100) NULL;
GO
IF COL_LENGTH('dbo.Payments', 'proof_file_name') IS NULL
    ALTER TABLE dbo.Payments ADD proof_file_name NVARCHAR(260) NULL;
GO
IF COL_LENGTH('dbo.Payments', 'proof_stored_name') IS NULL
    ALTER TABLE dbo.Payments ADD proof_stored_name VARCHAR(100) NULL;
GO
IF COL_LENGTH('dbo.Payments', 'proof_content_type') IS NULL
    ALTER TABLE dbo.Payments ADD proof_content_type VARCHAR(100) NULL;
GO

-- Payment method constraint: whatever it is called today, replace it with one that also allows InstaPay.
IF NOT EXISTS (SELECT 1 FROM sys.check_constraints
               WHERE parent_object_id = OBJECT_ID('dbo.Payments') AND definition LIKE '%payment_method%' AND definition LIKE '%InstaPay%')
BEGIN
    DECLARE @drop NVARCHAR(MAX) = N'';
    SELECT @drop += N'ALTER TABLE dbo.Payments DROP CONSTRAINT ' + QUOTENAME(name) + N';'
    FROM sys.check_constraints
    WHERE parent_object_id = OBJECT_ID('dbo.Payments') AND definition LIKE '%payment_method%';
    IF LEN(@drop) > 0 EXEC sp_executesql @drop;

    ALTER TABLE dbo.Payments WITH CHECK ADD CONSTRAINT CK_Payments_Method
        CHECK (payment_method IN ('Cash', 'InstaPay', 'Vodafone Cash', 'Other', 'Bank Transfer', 'Visa'));
END
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'UX_Enrollments_active_customer_course' AND object_id = OBJECT_ID('dbo.Enrollments'))
BEGIN
    IF EXISTS (SELECT 1 FROM dbo.Enrollments WHERE status = 'Active' GROUP BY customer_id, course_id HAVING COUNT(*) > 1)
        PRINT 'SKIPPED the one-active-enrollment index: some students already have duplicate ACTIVE enrollments in the same course. Fix those rows, then run this script again. (The application still blocks new duplicates.)';
    ELSE
        CREATE UNIQUE NONCLUSTERED INDEX UX_Enrollments_active_customer_course ON dbo.Enrollments (customer_id, course_id) WHERE status = 'Active';
END
GO
