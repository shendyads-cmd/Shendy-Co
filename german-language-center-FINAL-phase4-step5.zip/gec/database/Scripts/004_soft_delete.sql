-- Phase 2: "Delete" keeps the record for history instead of destroying it.
-- Adds is_deleted / deleted_at / deletion_reason to Customers and Courses.
-- Non-destructive and safe to run more than once: it only ADDS columns (existing rows become is_deleted = 0).
-- Run it ONCE against german_language_center, then restart the API.
USE german_language_center;
GO

IF COL_LENGTH('dbo.Customers', 'is_deleted') IS NULL
    ALTER TABLE dbo.Customers ADD is_deleted BIT NOT NULL CONSTRAINT DF_Customers_is_deleted DEFAULT (0);
GO
IF COL_LENGTH('dbo.Customers', 'deleted_at') IS NULL
    ALTER TABLE dbo.Customers ADD deleted_at DATETIME2 NULL;
GO
IF COL_LENGTH('dbo.Customers', 'deletion_reason') IS NULL
    ALTER TABLE dbo.Customers ADD deletion_reason NVARCHAR(500) NULL;
GO

IF COL_LENGTH('dbo.Courses', 'is_deleted') IS NULL
    ALTER TABLE dbo.Courses ADD is_deleted BIT NOT NULL CONSTRAINT DF_Courses_is_deleted DEFAULT (0);
GO
IF COL_LENGTH('dbo.Courses', 'deleted_at') IS NULL
    ALTER TABLE dbo.Courses ADD deleted_at DATETIME2 NULL;
GO
IF COL_LENGTH('dbo.Courses', 'deletion_reason') IS NULL
    ALTER TABLE dbo.Courses ADD deletion_reason NVARCHAR(500) NULL;
GO
