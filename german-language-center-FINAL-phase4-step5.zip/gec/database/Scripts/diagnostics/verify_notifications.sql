-- Read-only check of the notification tables. Safe to run at any time; changes nothing.
USE german_language_center;
GO
SELECT 'Notifications table'      AS item, CASE WHEN OBJECT_ID(N'dbo.Notifications', N'U')     IS NULL THEN 'MISSING - run 008_notifications.sql' ELSE 'OK' END AS result
UNION ALL
SELECT 'NotificationReads table',          CASE WHEN OBJECT_ID(N'dbo.NotificationReads', N'U') IS NULL THEN 'MISSING - run 008_notifications.sql' ELSE 'OK' END;

-- The dedupe index must be UNIQUE and FILTERED (dedupe_key IS NOT NULL).
SELECT i.name AS index_name, i.is_unique, i.has_filter, i.filter_definition,
       CASE WHEN i.is_unique = 1 AND i.has_filter = 1 THEN 'OK' ELSE 'PROBLEM' END AS result
FROM sys.indexes i
WHERE i.object_id = OBJECT_ID(N'dbo.Notifications') AND i.name = N'UX_Notifications_dedupe_key';

-- The read table must have PRIMARY KEY (notification_id, user_id).
SELECT kc.name AS constraint_name, STRING_AGG(c.name, ', ') WITHIN GROUP (ORDER BY ic.key_ordinal) AS key_columns
FROM sys.key_constraints kc
JOIN sys.index_columns ic ON ic.object_id = kc.parent_object_id AND ic.index_id = kc.unique_index_id
JOIN sys.columns c ON c.object_id = ic.object_id AND c.column_id = ic.column_id
WHERE kc.parent_object_id = OBJECT_ID(N'dbo.NotificationReads') AND kc.type = 'PK'
GROUP BY kc.name;

-- Duplicated events (must return no rows).
SELECT dedupe_key, COUNT(*) AS copies FROM dbo.Notifications WHERE dedupe_key IS NOT NULL GROUP BY dedupe_key HAVING COUNT(*) > 1;

-- Newest notifications with how many users have read each one.
SELECT TOP (20) n.notification_id, n.notification_type, n.source, n.title, n.dedupe_key, n.created_at,
       (SELECT COUNT(*) FROM dbo.NotificationReads r WHERE r.notification_id = n.notification_id) AS read_by_users
FROM dbo.Notifications n ORDER BY n.created_at DESC, n.notification_id DESC;
GO
