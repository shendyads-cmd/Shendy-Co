-- Read-only check of the duplicate-protection objects. Safe to run at any time; changes nothing.
USE german_language_center;
GO
SELECT 'IdempotencyKeys table' AS item, CASE WHEN OBJECT_ID(N'dbo.IdempotencyKeys', N'U') IS NULL THEN 'MISSING - run 009_idempotency.sql' ELSE 'OK' END AS result
UNION ALL
SELECT 'UX_IdempotencyKeys_user_operation_key', CASE WHEN EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'UX_IdempotencyKeys_user_operation_key' AND is_unique = 1) THEN 'OK' ELSE 'MISSING' END
UNION ALL
SELECT 'UX_Enrollments_active_customer_course', CASE WHEN EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'UX_Enrollments_active_customer_course' AND is_unique = 1 AND has_filter = 1) THEN 'OK' ELSE 'MISSING (duplicates may block it - see 009 output)' END
UNION ALL
SELECT 'Unique index on Invoices.invoice_number', CASE WHEN EXISTS (
        SELECT 1 FROM sys.indexes i JOIN sys.index_columns ic ON ic.object_id = i.object_id AND ic.index_id = i.index_id
        JOIN sys.columns c ON c.object_id = ic.object_id AND c.column_id = ic.column_id
        WHERE i.object_id = OBJECT_ID(N'dbo.Invoices') AND i.is_unique = 1 AND c.name = N'invoice_number') THEN 'OK' ELSE 'MISSING' END;

-- Data that would break the constraints (each query must return no rows).
SELECT 'duplicate active enrollment' AS problem, customer_id, course_id, COUNT(*) AS copies
FROM dbo.Enrollments WHERE status = N'Active' GROUP BY customer_id, course_id HAVING COUNT(*) > 1;
SELECT 'duplicate invoice number' AS problem, invoice_number, COUNT(*) AS copies FROM dbo.Invoices GROUP BY invoice_number HAVING COUNT(*) > 1;

-- Keys that are stuck in "Processing" (older than 5 minutes) - normally none.
SELECT idempotency_id, user_id, operation, idem_key, status, created_at
FROM dbo.IdempotencyKeys WHERE status = N'Processing' AND created_at < DATEADD(MINUTE, -5, SYSDATETIME());

-- Recent operations protected by a key.
SELECT TOP (20) idempotency_id, user_id, operation, idem_key, status, response_status, created_at, completed_at
FROM dbo.IdempotencyKeys ORDER BY idempotency_id DESC;
GO
