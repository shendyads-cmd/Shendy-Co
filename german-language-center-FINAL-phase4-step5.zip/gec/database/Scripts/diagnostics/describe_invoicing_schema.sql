-- READ-ONLY. Run in SSMS against german_language_center and send the three result grids back.
-- It lists the real columns, relationships and rules of the invoicing tables so the New Student
-- (invoice + payment) workflow can be built on the actual schema instead of guesses.
USE german_language_center;

-- 1) Columns
SELECT t.name AS table_name, c.column_id, c.name AS column_name, ty.name AS data_type,
       c.max_length, c.precision, c.scale, c.is_nullable, c.is_identity,
       OBJECT_DEFINITION(c.default_object_id) AS default_value
FROM sys.tables t
JOIN sys.columns c ON c.object_id = t.object_id
JOIN sys.types ty ON ty.user_type_id = c.user_type_id
WHERE t.name IN ('Invoices', 'InvoiceCustomers', 'InvoiceDetails', 'Payments', 'PaymentAllocations', 'PaymentGuarantees', 'Transactions', 'Expenses')
ORDER BY t.name, c.column_id;

-- 2) Foreign keys (who points to whom, and what happens on delete)
SELECT OBJECT_NAME(fk.parent_object_id) AS child_table,
       COL_NAME(fkc.parent_object_id, fkc.parent_column_id) AS child_column,
       OBJECT_NAME(fk.referenced_object_id) AS parent_table,
       COL_NAME(fkc.referenced_object_id, fkc.referenced_column_id) AS parent_column,
       fk.delete_referential_action_desc AS on_delete
FROM sys.foreign_keys fk
JOIN sys.foreign_key_columns fkc ON fkc.constraint_object_id = fk.object_id
ORDER BY child_table, child_column;

-- 3) Rules that affect inserts: check constraints, triggers, procedures, sequences (invoice numbering)
SELECT 'check constraint' AS kind, OBJECT_NAME(parent_object_id) AS on_table, name, definition AS detail FROM sys.check_constraints
UNION ALL SELECT 'trigger', OBJECT_NAME(parent_id), name, NULL FROM sys.triggers WHERE is_ms_shipped = 0 AND parent_class = 1
UNION ALL SELECT 'procedure', NULL, name, NULL FROM sys.procedures
UNION ALL SELECT 'sequence', NULL, name, NULL FROM sys.sequences
ORDER BY kind, on_table, name;

-- 4) The stored procedures that exist today (CreateInvoice, CreatePayment, ...) - to compare them with the real schema
SELECT p.name AS procedure_name, m.definition
FROM sys.procedures p JOIN sys.sql_modules m ON m.object_id = p.object_id
ORDER BY p.name;
