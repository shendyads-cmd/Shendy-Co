-- Step 2: dbo.SystemSettings, a small key/value table for server-side settings.
-- Today it holds ONE row: data_password_hash = the bcrypt HASH of the fixed Data password (never the password itself).
-- It is not exported by Data > Export and no API returns it.
-- Non-destructive and safe to run more than once.
--
-- How the first Data password is set (choose one):
--   a) before the first start:  dotnet user-secrets set "Bootstrap:DataPassword" "<8+ characters>"   (stored hashed at startup, then remove the setting)
--   b) after the first start:   log in as Admin -> user menu -> Account Settings -> Data password
SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
GO
USE german_language_center;
GO

IF OBJECT_ID(N'dbo.SystemSettings', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.SystemSettings
    (
        setting_key   NVARCHAR(100)  NOT NULL CONSTRAINT PK_SystemSettings PRIMARY KEY,
        setting_value NVARCHAR(500)  NOT NULL,
        updated_at    DATETIME2(0)   NOT NULL CONSTRAINT DF_SystemSettings_updated_at DEFAULT (SYSDATETIME()),
        updated_by    INT            NULL,
        CONSTRAINT FK_SystemSettings_updated_by FOREIGN KEY (updated_by) REFERENCES dbo.Users (user_id)
    );
END
GO

PRINT 'SystemSettings is ready.';
GO
