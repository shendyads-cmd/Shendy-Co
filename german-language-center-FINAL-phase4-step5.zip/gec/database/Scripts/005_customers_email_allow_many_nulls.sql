-- Email is OPTIONAL in the application, but must be unique when it is filled in.
-- A plain UNIQUE constraint/index on Customers.email lets SQL Server store only ONE row with a NULL email,
-- so the second student registered without an email fails with "Student could not be created".
-- This script replaces it with a FILTERED unique index (unique only where email IS NOT NULL).
--
-- Non-destructive: no rows are changed or deleted; only the index definition changes. Safe to run more than once.
-- Run it ONLY if the diagnostic query (see the README / chat) shows a unique, unfiltered index on email.
USE german_language_center;
GO

-- 1) Drop single-column UNIQUE constraints / unique indexes on email that are not filtered.
DECLARE @sql NVARCHAR(MAX) = N'';
SELECT @sql += CASE WHEN kc.object_id IS NOT NULL
                    THEN N'ALTER TABLE dbo.Customers DROP CONSTRAINT ' + QUOTENAME(i.name) + N';'
                    ELSE N'DROP INDEX ' + QUOTENAME(i.name) + N' ON dbo.Customers;' END
FROM sys.indexes i
JOIN sys.index_columns ic ON ic.object_id = i.object_id AND ic.index_id = i.index_id AND ic.is_included_column = 0
JOIN sys.columns c ON c.object_id = ic.object_id AND c.column_id = ic.column_id
LEFT JOIN sys.key_constraints kc ON kc.parent_object_id = i.object_id AND kc.unique_index_id = i.index_id
WHERE i.object_id = OBJECT_ID('dbo.Customers')
  AND i.is_unique = 1 AND i.is_primary_key = 0 AND i.has_filter = 0
  AND c.name = 'email'
  AND (SELECT COUNT(*) FROM sys.index_columns x
       WHERE x.object_id = i.object_id AND x.index_id = i.index_id AND x.is_included_column = 0) = 1;
IF LEN(@sql) > 0 EXEC sp_executesql @sql;
GO

-- 2) Re-create the rule as a filtered unique index (skipped if real duplicate emails already exist).
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID('dbo.Customers') AND name = 'UX_Customers_email_notnull')
   AND NOT EXISTS (SELECT email FROM dbo.Customers WHERE email IS NOT NULL GROUP BY email HAVING COUNT(*) > 1)
    CREATE UNIQUE NONCLUSTERED INDEX UX_Customers_email_notnull ON dbo.Customers (email) WHERE email IS NOT NULL;
GO
