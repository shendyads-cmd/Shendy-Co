-- Notification system: Notifications + NotificationReads.
-- Non-destructive and safe to run more than once (every object is created only if it is missing).
--
--   Notifications      one row per EVENT (e.g. "course A-003 is full"). Texts are stored in English as a fallback;
--                      the screen translates them (Arabic / English / German) from notification_type + params_json.
--   NotificationReads  one row per (notification, user) that has READ it. No row = unread for that user.
--                      Read state is therefore user-specific: when user A reads a notification, user B still sees it unread.
--
-- Duplicate protection (database level): the filtered UNIQUE index UX_Notifications_dedupe_key stops the same event
-- from being stored twice (refresh, API restart, retry). NotificationReads has PRIMARY KEY (notification_id, user_id),
-- so a double click cannot create two read rows.
--
-- Filtered indexes require these SET options. Keep them at the top of the script.
SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
SET ANSI_PADDING ON;
SET ANSI_WARNINGS ON;
SET ARITHABORT ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET NUMERIC_ROUNDABORT OFF;
GO
USE german_language_center;
GO

IF OBJECT_ID(N'dbo.Notifications', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.Notifications
    (
        notification_id   INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Notifications PRIMARY KEY,
        notification_type NVARCHAR(50)   NOT NULL,                 -- CourseFull, PaymentReceived, PaymentDue, ...
        source            NVARCHAR(50)   NOT NULL,                 -- Courses, Payments, Payroll, ...
        title             NVARCHAR(200)  NOT NULL,                 -- English fallback text
        message           NVARCHAR(1000) NOT NULL,                 -- English fallback text
        params_json       NVARCHAR(1000) NULL,                     -- values used by the translated texts
        link_path         NVARCHAR(200)  NULL,                     -- screen opened by "View details"
        target_user_id    INT NULL,                                -- NULL = every user allowed by target_role
        target_role       NVARCHAR(30)   NULL,                     -- NULL = every role
        dedupe_key        NVARCHAR(200)  NULL,                     -- one event = one key
        created_at        DATETIME2(0)   NOT NULL CONSTRAINT DF_Notifications_created_at DEFAULT (SYSDATETIME()),
        CONSTRAINT FK_Notifications_target_user FOREIGN KEY (target_user_id) REFERENCES dbo.Users (user_id)
    );
END
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'UX_Notifications_dedupe_key' AND object_id = OBJECT_ID(N'dbo.Notifications'))
    CREATE UNIQUE NONCLUSTERED INDEX UX_Notifications_dedupe_key
        ON dbo.Notifications (dedupe_key) WHERE dedupe_key IS NOT NULL;
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_Notifications_created_at' AND object_id = OBJECT_ID(N'dbo.Notifications'))
    CREATE NONCLUSTERED INDEX IX_Notifications_created_at ON dbo.Notifications (created_at DESC, notification_id DESC);
GO

IF OBJECT_ID(N'dbo.NotificationReads', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.NotificationReads
    (
        notification_id INT          NOT NULL,
        user_id         INT          NOT NULL,
        read_at         DATETIME2(0) NOT NULL CONSTRAINT DF_NotificationReads_read_at DEFAULT (SYSDATETIME()),
        CONSTRAINT PK_NotificationReads PRIMARY KEY CLUSTERED (notification_id, user_id),
        CONSTRAINT FK_NotificationReads_notification FOREIGN KEY (notification_id) REFERENCES dbo.Notifications (notification_id) ON DELETE CASCADE,
        CONSTRAINT FK_NotificationReads_user FOREIGN KEY (user_id) REFERENCES dbo.Users (user_id) ON DELETE CASCADE
    );
END
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_NotificationReads_user_id' AND object_id = OBJECT_ID(N'dbo.NotificationReads'))
    CREATE NONCLUSTERED INDEX IX_NotificationReads_user_id ON dbo.NotificationReads (user_id) INCLUDE (notification_id);
GO

PRINT 'Notifications are ready. Run database/Scripts/diagnostics/verify_notifications.sql to check them.';
GO
