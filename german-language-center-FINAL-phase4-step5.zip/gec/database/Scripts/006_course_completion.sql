-- A course can be marked "Completed" by an administrator when it has finished.
-- Adds is_completed / completed_at to Courses. Non-destructive and safe to run more than once:
-- existing courses stay Active (is_completed = 0) and nothing is deleted. Identity values are never touched,
-- so Course IDs keep counting forward and are never reused.
USE german_language_center;
GO

IF COL_LENGTH('dbo.Courses', 'is_completed') IS NULL
    ALTER TABLE dbo.Courses ADD is_completed BIT NOT NULL CONSTRAINT DF_Courses_is_completed DEFAULT (0);
GO
IF COL_LENGTH('dbo.Courses', 'completed_at') IS NULL
    ALTER TABLE dbo.Courses ADD completed_at DATETIME2 NULL;
GO
