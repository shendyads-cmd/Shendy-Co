-- Phase 2 refinement: adds the Maximum Capacity column to Courses.
-- Non-destructive and safe to run more than once: it only ADDS a column (default 30) and never drops or rewrites data.
-- Run it ONCE against german_language_center, then restart the API.
USE german_language_center;
GO

IF COL_LENGTH('dbo.Courses', 'max_capacity') IS NULL
    ALTER TABLE dbo.Courses ADD max_capacity INT NOT NULL CONSTRAINT DF_Courses_max_capacity DEFAULT (30);
GO

-- Courses that already have more active students than the default are raised to their current size,
-- so no existing course starts out as "35 / 30".
UPDATE c
SET c.max_capacity = x.active_count
FROM dbo.Courses c
JOIN (SELECT course_id, COUNT(*) AS active_count FROM dbo.Enrollments WHERE status = 'Active' GROUP BY course_id) x
     ON x.course_id = c.course_id
WHERE x.active_count > c.max_capacity;
GO

IF NOT EXISTS (SELECT 1 FROM sys.check_constraints WHERE name = 'CK_Courses_max_capacity' AND parent_object_id = OBJECT_ID('dbo.Courses'))
    ALTER TABLE dbo.Courses ADD CONSTRAINT CK_Courses_max_capacity CHECK (max_capacity > 0);
GO
