-- OPTIONAL hardening for Phase 2. Non-destructive: only creates indexes, never drops or alters data.
-- Run GET /api/system/schema-check first and confirm these table/column names match your database.
-- The application already enforces these rules in code; the indexes make them race-proof and speed up search.
USE german_language_center;
GO

-- Unique course code (skipped automatically if duplicates already exist, so nothing fails).
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'UX_Courses_course_code' AND object_id = OBJECT_ID('dbo.Courses'))
   AND NOT EXISTS (SELECT 1 FROM dbo.Courses GROUP BY course_code HAVING COUNT(*) > 1)
    CREATE UNIQUE INDEX UX_Courses_course_code ON dbo.Courses (course_code);
GO

-- Lookup indexes for enrollment history per student / per course.
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_Enrollments_customer_id' AND object_id = OBJECT_ID('dbo.Enrollments'))
    CREATE INDEX IX_Enrollments_customer_id ON dbo.Enrollments (customer_id);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_Enrollments_course_id' AND object_id = OBJECT_ID('dbo.Enrollments'))
    CREATE INDEX IX_Enrollments_course_id ON dbo.Enrollments (course_id);
GO
