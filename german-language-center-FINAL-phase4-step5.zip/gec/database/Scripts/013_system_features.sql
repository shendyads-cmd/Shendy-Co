-- Step 5: audit log, personal schedule and a safe invoice-number counter.
-- Non-destructive and safe to run more than once. Nothing is dropped and no existing invoice number is changed.
-- Run ONCE against german_language_center, after 010, 011 and 012, then restart the API.
--
--   1. AuditLogs            persistent audit trail. A trigger refuses UPDATE and DELETE, so nobody (not even through the API)
--                           can edit or erase a record. Rows are only ever added by the API from authenticated actions.
--   2. ScheduleEntries      private schedule entries of each user (title, date, time, optional details).
--   3. InvoiceNumberCounters one counter row per year. A new invoice number is allocated by incrementing it, so a number can never
--                           be handed out twice, even when the newest invoice was deleted (the old MAX() method could reuse it).
--                           Seeded from the highest number already used in each year.
SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
SET XACT_ABORT ON;
GO
USE german_language_center;
GO

-- ------------------------------------------------------------------ 1. audit log
IF OBJECT_ID(N'dbo.AuditLogs', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.AuditLogs
    (
        audit_id    BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_AuditLogs PRIMARY KEY,
        created_at  DATETIME2(0)  NOT NULL CONSTRAINT DF_AuditLogs_created DEFAULT (SYSDATETIME()),
        user_id     INT           NULL CONSTRAINT FK_AuditLogs_user FOREIGN KEY REFERENCES dbo.Users (user_id),
        username    NVARCHAR(100) NULL,            -- copy of the name at the time of the action
        action      NVARCHAR(100) NOT NULL,        -- e.g. Expenses.Create, Payroll.Pay, Auth.Login
        action_type NVARCHAR(30)  NOT NULL,        -- Auth, Create, Update, Delete, Restore, Financial, Data, Admin
        entity      NVARCHAR(60)  NOT NULL,        -- module / controller
        reference   NVARCHAR(100) NULL,            -- the record (id, invoice number ...)
        details     NVARCHAR(1000) NULL,           -- short JSON: request path, status, amounts. Never passwords or request bodies.
        ip_address  NVARCHAR(45)  NULL
    );
    CREATE INDEX IX_AuditLogs_created ON dbo.AuditLogs (created_at DESC, audit_id DESC);
    CREATE INDEX IX_AuditLogs_user ON dbo.AuditLogs (user_id, created_at DESC);
    CREATE INDEX IX_AuditLogs_type ON dbo.AuditLogs (action_type, created_at DESC);
END
GO
IF OBJECT_ID(N'dbo.TR_AuditLogs_immutable', N'TR') IS NULL
    EXEC (N'CREATE TRIGGER dbo.TR_AuditLogs_immutable ON dbo.AuditLogs INSTEAD OF UPDATE, DELETE AS
            BEGIN
                SET NOCOUNT ON;
                THROW 50030, N''Audit records cannot be changed or deleted.'', 1;
            END');
GO

-- ------------------------------------------------------------------ 2. personal schedule
IF OBJECT_ID(N'dbo.ScheduleEntries', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.ScheduleEntries
    (
        entry_id    INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_ScheduleEntries PRIMARY KEY,
        user_id     INT           NOT NULL CONSTRAINT FK_ScheduleEntries_user FOREIGN KEY REFERENCES dbo.Users (user_id),
        title       NVARCHAR(150) NOT NULL,
        entry_date  DATE          NOT NULL,
        entry_time  TIME(0)       NOT NULL,
        description NVARCHAR(500) NULL,
        created_at  DATETIME2(0)  NOT NULL CONSTRAINT DF_ScheduleEntries_created DEFAULT (SYSDATETIME()),
        updated_at  DATETIME2(0)  NULL
    );
    CREATE INDEX IX_ScheduleEntries_user_date ON dbo.ScheduleEntries (user_id, entry_date, entry_time);
    -- the same entry cannot be saved twice by the same user
    CREATE UNIQUE INDEX UX_ScheduleEntries_unique ON dbo.ScheduleEntries (user_id, entry_date, entry_time, title);
END
GO

-- ------------------------------------------------------------------ 3. invoice number counters
IF OBJECT_ID(N'dbo.InvoiceNumberCounters', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.InvoiceNumberCounters
    (
        counter_year INT NOT NULL CONSTRAINT PK_InvoiceNumberCounters PRIMARY KEY,
        last_number  INT NOT NULL CONSTRAINT CK_InvoiceNumberCounters_last CHECK (last_number >= 0)
    );
END
GO
-- INV-2026-00017: the year is characters 5-8, the number starts at character 10. Existing numbers are NOT changed.
INSERT INTO dbo.InvoiceNumberCounters (counter_year, last_number)
SELECT TRY_CAST(SUBSTRING(i.invoice_number, 5, 4) AS INT), MAX(TRY_CAST(SUBSTRING(i.invoice_number, 10, 20) AS INT))
FROM dbo.Invoices i
WHERE i.invoice_number LIKE N'INV-[0-9][0-9][0-9][0-9]-[0-9]%'
  AND NOT EXISTS (SELECT 1 FROM dbo.InvoiceNumberCounters c WHERE c.counter_year = TRY_CAST(SUBSTRING(i.invoice_number, 5, 4) AS INT))
GROUP BY TRY_CAST(SUBSTRING(i.invoice_number, 5, 4) AS INT)
HAVING MAX(TRY_CAST(SUBSTRING(i.invoice_number, 10, 20) AS INT)) IS NOT NULL;
PRINT CONCAT(N'Invoice counters seeded: ', @@ROWCOUNT);
GO
-- never lower than the highest number in use (re-running the script after new invoices keeps the counter correct)
UPDATE c SET last_number = x.max_n
FROM dbo.InvoiceNumberCounters c
JOIN (SELECT TRY_CAST(SUBSTRING(invoice_number, 5, 4) AS INT) AS y, MAX(TRY_CAST(SUBSTRING(invoice_number, 10, 20) AS INT)) AS max_n
      FROM dbo.Invoices WHERE invoice_number LIKE N'INV-[0-9][0-9][0-9][0-9]-[0-9]%' GROUP BY TRY_CAST(SUBSTRING(invoice_number, 5, 4) AS INT)) x
  ON x.y = c.counter_year
WHERE x.max_n > c.last_number;
GO

PRINT N'Step 5 database objects are ready.';
GO
