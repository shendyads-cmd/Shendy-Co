<#
 Phase 2 smoke test (PowerShell 5.1 or 7). Run with the API running.
 Creates records prefixed SMOKE and a temporary Employee user - run it against a development copy of the database.
 Run database/Scripts/003_course_capacity.sql, 004_soft_delete.sql, 006_course_completion.sql and 007_new_student_payments.sql first.
 Also run 008_notifications.sql and 009_idempotency.sql (notification + duplicate-protection tests at the end).
 Usage: ./phase2-smoke.ps1 -AdminUser admin -AdminPassword '<password>' [-BaseUrl http://localhost:5000]
#>
param(
  [string]$BaseUrl = "http://localhost:5000",
  [Parameter(Mandatory = $true)][string]$AdminUser,
  [Parameter(Mandatory = $true)][string]$AdminPassword
)
$ErrorActionPreference = "Stop"
$script:pass = 0; $script:fail = 0

# Create endpoints protected by the Idempotency-Key filter. A fresh key is sent automatically unless one is passed (or $NoKey).
$script:protectedCreates = '^/api/(customers|courses|enrollments|invoices|registrations)$'
function Call($Method, $Path, $Body = $null, $Token = $null, $IdemKey = $null, [switch]$NoKey) {
  $req = @{ Uri = "$BaseUrl$Path"; Method = $Method; Headers = @{}; UseBasicParsing = $true }
  if ($Token) { $req.Headers["Authorization"] = "Bearer $Token" }
  if ($IdemKey) { $req.Headers["Idempotency-Key"] = $IdemKey }
  elseif (-not $NoKey -and $Method -eq "POST" -and $Path -match $script:protectedCreates) { $req.Headers["Idempotency-Key"] = [guid]::NewGuid().ToString() }
  if ($null -ne $Body) { $req.Body = ($Body | ConvertTo-Json -Depth 5); $req.ContentType = "application/json" }
  try {
    $r = Invoke-WebRequest @req
    $json = $null; if ($r.Content) { $json = $r.Content | ConvertFrom-Json }
    return @{ Status = [int]$r.StatusCode; Body = $json }
  } catch {
    if ($null -eq $_.Exception.Response) { throw }
    $msg = ""
    if ($_.ErrorDetails -and $_.ErrorDetails.Message) { $msg = $_.ErrorDetails.Message }
    return @{ Status = [int]$_.Exception.Response.StatusCode; Body = $null; Message = $msg }
  }
}
function Check($Name, $Condition) {
  if ($Condition) { $script:pass++; Write-Host "  PASS  $Name" -ForegroundColor Green }
  else { $script:fail++; Write-Host "  FAIL  $Name" -ForegroundColor Red }
}
function CheckStatus($Name, $Result, $Expected) {
  $ok = ($Result.Status -eq $Expected)
  Check $Name $ok
  if (-not $ok) {
    Write-Host ("        got HTTP {0}, expected {1}. API said: {2}" -f $Result.Status, $Expected, $Result.Message) -ForegroundColor Yellow
  }
}
Add-Type -AssemblyName System.Net.Http
function PostForm($Path, $Fields, $FilePath, $Token, $IdemKey = $null) {
  $client = New-Object System.Net.Http.HttpClient
  try {
    $client.DefaultRequestHeaders.Authorization = New-Object System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", $Token)
    if (-not $IdemKey) { $IdemKey = [guid]::NewGuid().ToString() }
    $client.DefaultRequestHeaders.Add("Idempotency-Key", $IdemKey)
    $content = New-Object System.Net.Http.MultipartFormDataContent
    foreach ($key in $Fields.Keys) { $content.Add((New-Object System.Net.Http.StringContent([string]$Fields[$key])), $key) }
    if ($FilePath) {
      $bytes = [System.IO.File]::ReadAllBytes($FilePath)
      $content.Add((New-Object System.Net.Http.ByteArrayContent(,$bytes)), "proof", [System.IO.Path]::GetFileName($FilePath))
    }
    $resp = $client.PostAsync("$BaseUrl$Path", $content).GetAwaiter().GetResult()
    $text = $resp.Content.ReadAsStringAsync().GetAwaiter().GetResult()
    $json = $null
    if ($text) { try { $json = $text | ConvertFrom-Json } catch { $json = $null } }
    return @{ Status = [int]$resp.StatusCode; Body = $json; Message = $text }
  } finally { $client.Dispose() }
}
function Download($Path, $Token) {
  try {
    $r = Invoke-WebRequest -Uri "$BaseUrl$Path" -Headers @{ Authorization = "Bearer $Token" } -UseBasicParsing
    return @{ Status = [int]$r.StatusCode; Bytes = $r.RawContentStream.ToArray(); Type = [string]$r.Headers["Content-Type"] }
  } catch {
    if ($null -eq $_.Exception.Response) { throw }
    return @{ Status = [int]$_.Exception.Response.StatusCode; Bytes = @(); Type = "" }
  }
}
function NewPhone { "010" + (Get-Random -Minimum 10000000 -Maximum 99999999) }
function CodeNumber($code) { [int]($code.Substring(1)) }

$n = Get-Random -Minimum 10000 -Maximum 99999

Write-Host "`n[Authentication]"
Check "bad login -> 401" ((Call POST "/api/auth/login" @{ username = $AdminUser; password = "wrong-password" }).Status -eq 401)
$login = Call POST "/api/auth/login" @{ username = $AdminUser; password = $AdminPassword }
Check "admin login -> 200" ($login.Status -eq 200)
$admin = $login.Body.token
Check "no token -> 401" ((Call GET "/api/customers").Status -eq 401)

$empName = "smoke_emp_$n"; $empPass = "Smoke!Pass123"
$empUser = Call POST "/api/users" @{ username = $empName; fullName = "Smoke Employee"; role = "Employee"; password = $empPass } $admin
Check "admin creates employee -> 201" ($empUser.Status -eq 201)
$emp = (Call POST "/api/auth/login" @{ username = $empName; password = $empPass }).Body.token

Write-Host "`n[Authorization]"
Check "employee GET /api/users -> 403" ((Call GET "/api/users" $null $emp).Status -eq 403)
Check "employee GET /api/customers -> 200" ((Call GET "/api/customers" $null $emp).Status -eq 200)
Check "employee GET /api/courses -> 200" ((Call GET "/api/courses" $null $emp).Status -eq 200)

Write-Host "`n[Students]"
$phone1 = NewPhone
$s1 = Call POST "/api/customers" @{ fullName = "SMOKE Student $n"; phone = $phone1; email = "smoke$n@example.com"; address = "Girga" } $admin
Check "create student -> 201" ($s1.Status -eq 201)
$sid = $s1.Body.customerId
Check "Student ID is generated (STU-0000 format)" ($s1.Body.studentCode -match '^STU-\d{4,}$')
Check "Student ID matches the database key" ($s1.Body.studentCode -eq ("STU-{0:D4}" -f [int]$sid))
Check "duplicate phone -> 409" ((Call POST "/api/customers" @{ fullName = "SMOKE Dup"; phone = $phone1 } $admin).Status -eq 409)
Check "duplicate email -> 409" ((Call POST "/api/customers" @{ fullName = "SMOKE Dup"; phone = (NewPhone); email = "smoke$n@example.com" } $admin).Status -eq 409)
Check "invalid email -> 400" ((Call POST "/api/customers" @{ fullName = "SMOKE Bad"; phone = (NewPhone); email = "not-an-email" } $admin).Status -eq 400)
Check "missing phone -> 400" ((Call POST "/api/customers" @{ fullName = "SMOKE NoPhone" } $admin).Status -eq 400)
Check "missing name -> 400" ((Call POST "/api/customers" @{ fullName = ""; phone = (NewPhone) } $admin).Status -eq 400)
Check "get student -> 200" ((Call GET "/api/customers/$sid" $null $admin).Status -eq 200)
Check "get missing student -> 404" ((Call GET "/api/customers/999999999" $null $admin).Status -eq 404)
Check "update student -> 200" ((Call PUT "/api/customers/$sid" @{ fullName = "SMOKE Student $n"; phone = $phone1; email = "smoke$n@example.com"; address = "Sohag" } $admin).Status -eq 200)
Check "search by name finds student" ((Call GET "/api/customers?search=SMOKE%20Student%20$n" $null $admin).Body.total -ge 1)
$byCode = Call GET "/api/customers?search=$($s1.Body.studentCode)" $null $admin
Check "search by Student ID finds exactly that student" (($byCode.Body.total -ge 1) -and ($byCode.Body.items[0].customerId -eq $sid))
Check "search by phone finds student" ((Call GET "/api/customers?search=$phone1" $null $admin).Body.total -ge 1)
$s2 = Call POST "/api/customers" @{ fullName = "SMOKE Employee-made $n"; phone = (NewPhone) } $emp
Check "employee creates student -> 201" ($s2.Status -eq 201)
$sid2 = $s2.Body.customerId
# Email is optional, so two students without an email must both be saveable.
# (If the database has a plain UNIQUE index on Customers.email, SQL Server allows only ONE NULL and this fails: run 005.)
$s2b = Call POST "/api/customers" @{ fullName = "SMOKE No-email $n"; phone = (NewPhone) } $admin
CheckStatus "a second student without an email can also be saved -> 201" $s2b 201
$sid2b = $s2b.Body.customerId
$s3 = Call POST "/api/customers" @{ fullName = "SMOKE Third $n"; phone = (NewPhone); email = "smoke3_$n@example.com" } $admin
CheckStatus "create the third test student -> 201" $s3 201
$sid3 = $s3.Body.customerId
if (-not $sid3) { Write-Host "        Student 3 was not created, so the checks that use it are not reliable." -ForegroundColor Red }

Write-Host "`n[Courses - automatic code, capacity]"
$c1 = Call POST "/api/courses" @{ courseName = "SMOKE German A1 $n"; price = 1500; maxCapacity = 30 } $admin
Check "create course -> 201" ($c1.Status -eq 201)
$cid = $c1.Body.courseId; $code1 = $c1.Body.courseCode
Check "course code format is A-001" ($code1 -match '^A-\d{3,}$')
Check "capacity saved and enrolled starts at 0" (($c1.Body.maxCapacity -eq 30) -and ($c1.Body.enrolledCount -eq 0))
$c2 = Call POST "/api/courses" @{ courseName = "SMOKE German A2 $n"; price = 1800; maxCapacity = 1 } $admin
$cid2 = $c2.Body.courseId; $code2 = $c2.Body.courseCode
Check "next course code is sequential" ((CodeNumber $code2) -eq ((CodeNumber $code1) + 1))
Check "price 0 -> 400" ((Call POST "/api/courses" @{ courseName = "Free"; price = 0; maxCapacity = 10 } $admin).Status -eq 400)
Check "capacity 0 -> 400" ((Call POST "/api/courses" @{ courseName = "Empty"; price = 100; maxCapacity = 0 } $admin).Status -eq 400)
Check "missing name -> 400" ((Call POST "/api/courses" @{ courseName = ""; price = 100; maxCapacity = 5 } $admin).Status -eq 400)
$upd = Call PUT "/api/courses/$cid" @{ courseName = "SMOKE German A1 $n"; price = 1600; maxCapacity = 25 } $admin
Check "update course -> 200 and the code does not change" (($upd.Status -eq 200) -and ($upd.Body.courseCode -eq $code1) -and ($upd.Body.price -eq 1600))
Check "search course by code" ((Call GET "/api/courses?search=$code1" $null $admin).Body.total -ge 1)
Check "search course by name" ((Call GET "/api/courses?search=SMOKE%20German%20A1%20$n" $null $admin).Body.total -eq 1)
Check "course list has no category field" (-not ((Call GET "/api/courses?search=$code1" $null $admin).Body.items[0].PSObject.Properties.Name -contains "category"))

Write-Host "`n[Registering students]"
$e1 = Call POST "/api/enrollments" @{ customerId = $sid; courseId = $cid } $admin
Check "add course to student -> 201" ($e1.Status -eq 201)
Check "total defaults to course price" ($e1.Body.totalAmount -eq 1600)
$eid = $e1.Body.enrollmentId
Check "enrolled count increased to 1" ((Call GET "/api/courses/$cid" $null $admin).Body.course.enrolledCount -eq 1)
Check "duplicate registration -> 409" ((Call POST "/api/enrollments" @{ customerId = $sid; courseId = $cid } $admin).Status -eq 409)
Check "unknown student -> 400" ((Call POST "/api/enrollments" @{ customerId = 999999999; courseId = $cid } $admin).Status -eq 400)
Check "student details list the course" ((Call GET "/api/customers/$sid" $null $admin).Body.enrollments.Count -eq 1)
Check "student list counts registered courses" ((Call GET "/api/customers?search=$($s1.Body.studentCode)" $null $admin).Body.items[0].enrollmentCount -eq 1)
$cd = Call GET "/api/courses/$cid" $null $admin
Check "course details list the student with Student ID" (($cd.Body.enrollments.Count -eq 1) -and ($cd.Body.enrollments[0].studentCode -eq $s1.Body.studentCode))
Check "invalid status -> 400" ((Call PATCH "/api/enrollments/$eid/status" @{ status = "Nope" } $admin).Status -eq 400)

Write-Host "`n[Capacity is enforced]"
Check "student 1 takes the only seat (capacity 1) -> 201" ((Call POST "/api/enrollments" @{ customerId = $sid; courseId = $cid2 } $admin).Status -eq 201)
$full = Call POST "/api/enrollments" @{ customerId = $sid2; courseId = $cid2 } $admin
Check "second student in a full course -> 409 (never 2 / 1)" ($full.Status -eq 409)
$cd2 = Call GET "/api/courses/$cid2" $null $admin
Check "course shows 1 / 1 and is full" (($cd2.Body.course.enrolledCount -eq 1) -and ($cd2.Body.course.isFull -eq $true))
Check "full course shows as Full (and stays active)" (($cd2.Body.course.status -eq "Full") -and ($cd2.Body.course.isActive -eq $true))
Check "status filter: Full finds it" ((Call GET "/api/courses?search=$code2&status=full" $null $admin).Body.total -eq 1)
Check "status filter: Open does not" ((Call GET "/api/courses?search=$code2&status=open" $null $admin).Body.total -eq 0)
Check "capacity 0 on update -> 400" ((Call PUT "/api/courses/$cid2" @{ courseName = "SMOKE German A2 $n"; price = 1800; maxCapacity = 0 } $admin).Status -eq 400)
$avail = Call GET "/api/courses?search=$code2&availableForStudent=$sid2" $null $admin
Check "full course is not offered in Add Course" ($avail.Body.total -eq 0)
$availOpen = Call GET "/api/courses?search=$code1&availableForStudent=$sid2" $null $admin
Check "open course is offered to a student who is not registered" ($availOpen.Body.total -eq 1)
$availDup = Call GET "/api/courses?search=$code1&availableForStudent=$sid" $null $admin
Check "course the student already has is not offered again" ($availDup.Body.total -eq 0)

$e2 = (Call GET "/api/customers/$sid" $null $admin).Body.enrollments | Where-Object { $_.courseId -eq $cid2 } | Select-Object -First 1
Check "removing a student (Cancelled = what Undo does) -> 200" ((Call PATCH "/api/enrollments/$($e2.enrollmentId)/status" @{ status = "Cancelled" } $admin).Status -eq 200)
Check "seat is free again (0 / 1)" ((Call GET "/api/courses/$cid2" $null $admin).Body.course.enrolledCount -eq 0)
Check "now the other student can register -> 201" ((Call POST "/api/enrollments" @{ customerId = $sid2; courseId = $cid2 } $admin).Status -eq 201)
Check "reactivating the removed one while full -> 409" ((Call PATCH "/api/enrollments/$($e2.enrollmentId)/status" @{ status = "Active" } $admin).Status -eq 409)

Write-Host "`n[Active / Inactive]"
Call PATCH "/api/courses/$cid/status" @{ isActive = $false } $admin | Out-Null
Check "inactive course rejects registration -> 400" ((Call POST "/api/enrollments" @{ customerId = $sid3; courseId = $cid } $admin).Status -eq 400)
Check "inactive course is not offered in Add Course" ((Call GET "/api/courses?search=$code1&availableForStudent=$sid3" $null $admin).Body.total -eq 0)
Check "manually deactivated course is Deactivated" ((Call GET "/api/courses/$cid" $null $admin).Body.course.status -eq "Deactivated")
Check "status filter: Deactivated" ((Call GET "/api/courses?search=$code1&status=deactivated" $null $admin).Body.total -eq 1)
Call PATCH "/api/courses/$cid/status" @{ isActive = $true } $admin | Out-Null
Call PATCH "/api/customers/$sid3/status" @{ isActive = $false } $admin | Out-Null
Check "inactive student cannot be registered -> 400" ((Call POST "/api/enrollments" @{ customerId = $sid3; courseId = $cid } $admin).Status -eq 400)
Call PATCH "/api/customers/$sid3/status" @{ isActive = $true } $admin | Out-Null
Check "student status filter" ((Call GET "/api/customers?search=SMOKE%20Third%20$n&isActive=true" $null $admin).Body.total -eq 1)

Write-Host "`n[Completing and re-registering]"
Check "mark Completed -> 200" ((Call PATCH "/api/enrollments/$eid/status" @{ status = "Completed" } $admin).Status -eq 200)
Check "completed registration no longer takes a seat" ((Call GET "/api/courses/$cid" $null $admin).Body.course.enrolledCount -eq 0)
Check "register again after completion -> 201" ((Call POST "/api/enrollments" @{ customerId = $sid; courseId = $cid } $admin).Status -eq 201)
Check "reactivating the completed one would duplicate -> 409" ((Call PATCH "/api/enrollments/$eid/status" @{ status = "Active" } $admin).Status -eq 409)

Write-Host "`n[Delete and restore - students]"
$delBody = @{ reason = "Course is too expensive" }
Check "delete without a reason -> 400" ((Call DELETE "/api/customers/$sid" @{ reason = "" } $admin).Status -eq 400)
Check "employee delete student -> 403" ((Call DELETE "/api/customers/$sid" $delBody $emp).Status -eq 403)
$seatsBefore = (Call GET "/api/courses/$cid" $null $admin).Body.course.enrolledCount
Check "delete a student WITH registrations -> 204 (not blocked)" ((Call DELETE "/api/customers/$sid" $delBody $admin).Status -eq 204)
Check "deleted student is gone from the normal list" ((Call GET "/api/customers?search=$($s1.Body.studentCode)" $null $admin).Body.total -eq 0)
Check "deleted student cannot be opened normally -> 404" ((Call GET "/api/customers/$sid" $null $admin).Status -eq 404)
$deleted = Call GET "/api/customers/deleted?search=$($s1.Body.studentCode)" $null $admin
Check "Deleted list keeps ID, reason and course history" (($deleted.Body.total -eq 1) -and ($deleted.Body.items[0].deletionReason -eq "Course is too expensive") -and ($deleted.Body.items[0].enrollments.Count -ge 1) -and ($deleted.Body.items[0].studentCode -eq $s1.Body.studentCode))
Check "employee cannot open the Deleted list -> 403" ((Call GET "/api/customers/deleted" $null $emp).Status -eq 403)
Check "deleted student no longer takes a seat" ((Call GET "/api/courses/$cid" $null $admin).Body.course.enrolledCount -eq ($seatsBefore - 1))
Check "deleted student cannot be registered -> 400" ((Call POST "/api/enrollments" @{ customerId = $sid; courseId = $cid } $admin).Status -eq 400)
Check "phone of a deleted student cannot be reused -> 409" ((Call POST "/api/customers" @{ fullName = "SMOKE Reuse"; phone = $phone1 } $admin).Status -eq 409)
Check "stats count deleted students" ((Call GET "/api/customers/stats" $null $admin).Body.deleted -ge 1)
Check "employee restore -> 403" ((Call POST "/api/customers/$sid/restore" $null $emp).Status -eq 403)
$restored = Call POST "/api/customers/$sid/restore" $null $admin
Check "restore -> 200 with the same Student ID" (($restored.Status -eq 200) -and ($restored.Body.studentCode -eq $s1.Body.studentCode))
Check "restored student is back in the list (no duplicate)" ((Call GET "/api/customers?search=$($s1.Body.studentCode)" $null $admin).Body.total -eq 1)
Check "restored student takes the seat again" ((Call GET "/api/courses/$cid" $null $admin).Body.course.enrolledCount -eq $seatsBefore)
Check "restored student keeps registrations" ((Call GET "/api/customers/$sid" $null $admin).Body.enrollments.Count -ge 1)
Check "restoring a student who is not deleted -> 404" ((Call POST "/api/customers/$sid/restore" $null $admin).Status -eq 404)

Write-Host "`n[Restore needs a free seat]"
Check "delete the student who holds the last seat -> 204" ((Call DELETE "/api/customers/$sid2" $delBody $admin).Status -eq 204)
Check "the seat is free again (0 / 1)" ((Call GET "/api/courses/$cid2" $null $admin).Body.course.enrolledCount -eq 0)
Check "another student takes the seat -> 201" ((Call POST "/api/enrollments" @{ customerId = $sid3; courseId = $cid2 } $admin).Status -eq 201)
Check "restore is refused while the course is full -> 409" ((Call POST "/api/customers/$sid2/restore" $null $admin).Status -eq 409)
$e3 = @((Call GET "/api/customers/$sid3" $null $admin).Body.enrollments | Where-Object { $_.courseId -eq $cid2 })[0]
Call PATCH "/api/enrollments/$($e3.enrollmentId)/status" @{ status = "Cancelled" } $admin | Out-Null
Check "restore works once a seat is free -> 200" ((Call POST "/api/customers/$sid2/restore" $null $admin).Status -eq 200)

Write-Host "`n[Delete and restore - courses]"
Check "employee delete course -> 403" ((Call DELETE "/api/courses/$cid" $delBody $emp).Status -eq 403)
Check "delete a course WITH registered students -> 204 (not blocked)" ((Call DELETE "/api/courses/$cid" @{ reason = "Course cancelled" } $admin).Status -eq 204)
Check "deleted course is gone from the list" ((Call GET "/api/courses?search=$code1" $null $admin).Body.total -eq 0)
Check "deleted course cannot be opened normally -> 404" ((Call GET "/api/courses/$cid" $null $admin).Status -eq 404)
$dc = Call GET "/api/courses/deleted?search=$code1" $null $admin
Check "Deleted courses keeps the reason" (($dc.Body.total -eq 1) -and ($dc.Body.items[0].deletionReason -eq "Course cancelled"))
Check "student no longer lists the deleted course" (@((Call GET "/api/customers/$sid" $null $admin).Body.enrollments | Where-Object { $_.courseId -eq $cid }).Count -eq 0)
Check "registering into a deleted course -> 400" ((Call POST "/api/enrollments" @{ customerId = $sid3; courseId = $cid } $admin).Status -eq 400)
$c4 = Call POST "/api/courses" @{ courseName = "SMOKE After delete $n"; price = 100; maxCapacity = 5 } $admin
Check "course code of a deleted course is not reused" ((CodeNumber $c4.Body.courseCode) -gt (CodeNumber $code2))
$rc = Call POST "/api/courses/$cid/restore" $null $admin
Check "restore course -> 200 with the same code" (($rc.Status -eq 200) -and ($rc.Body.courseCode -eq $code1))
Check "restored course has its students back" ($rc.Body.enrolledCount -ge 1)
Check "admin delete an unused course -> 204" ((Call DELETE "/api/courses/$($c4.Body.courseId)" @{ reason = "Created by mistake" } $admin).Status -eq 204)

Write-Host "`n[Course completion]"
$cc = Call POST "/api/courses" @{ courseName = "SMOKE Finished $n"; price = 900; maxCapacity = 5 } $admin
CheckStatus "create a course to complete -> 201" $cc 201
$ccId = $cc.Body.courseId; $ccCode = $cc.Body.courseCode
Check "register a student in it -> 201" ((Call POST "/api/enrollments" @{ customerId = $sid3; courseId = $ccId } $admin).Status -eq 201)
Check "employee cannot complete a course -> 403" ((Call POST "/api/courses/$ccId/complete" $null $emp).Status -eq 403)
$done = Call POST "/api/courses/$ccId/complete" $null $admin
Check "admin completes the course -> 200 with a completion date" (($done.Status -eq 200) -and ($null -ne $done.Body.completedAt))
Check "completed course leaves the Courses list" ((Call GET "/api/courses?search=$ccCode" $null $admin).Body.total -eq 0)
Check "completed course cannot be opened in Courses -> 404" ((Call GET "/api/courses/$ccId" $null $admin).Status -eq 404)
Check "completed course is not offered in Add Course" ((Call GET "/api/courses?search=$ccCode&availableForStudent=$sid2" $null $admin).Body.total -eq 0)
Check "registering into a completed course -> 400" ((Call POST "/api/enrollments" @{ customerId = $sid2; courseId = $ccId } $admin).Status -eq 400)
Check "completed course cannot be edited -> 404" ((Call PUT "/api/courses/$ccId" @{ courseName = "x"; price = 1; maxCapacity = 5 } $admin).Status -eq 404)
Check "the completed course stays in the student history, marked as completed" (@((Call GET "/api/customers/$sid3" $null $admin).Body.enrollments | Where-Object { ($_.courseId -eq $ccId) -and ($_.courseCompleted -eq $true) }).Count -eq 1)

Write-Host "`n[Settings > Data - admin only]"
Check "employee cannot open Data -> 403" ((Call GET "/api/data/courses" $null $emp).Status -eq 403)
Check "employee cannot export SQL -> 403" ((Download "/api/data/export/sql" $emp).Status -eq 403)
Check "employee cannot export Excel -> 403" ((Download "/api/data/export/excel" $emp).Status -eq 403)
$byCode = Call GET "/api/data/courses?search=$ccCode" $null $admin
Check "Data lists the completed course (search by code)" (($byCode.Body.total -eq 1) -and ($byCode.Body.items[0].studentCount -eq 1))
Check "search by course name works" ((Call GET "/api/data/courses?search=SMOKE%20Finished%20$n" $null $admin).Body.total -eq 1)
Check "search is case-insensitive" ((Call GET "/api/data/courses?search=smoke%20finished%20$n" $null $admin).Body.total -eq 1)
Check "Data does not list active courses" ((Call GET "/api/data/courses?search=$code2" $null $admin).Body.total -eq 0)
$hist = Call GET "/api/data/courses/$ccId" $null $admin
Check "course history shows its student" (($hist.Status -eq 200) -and ($hist.Body.students.Count -eq 1) -and ($hist.Body.students[0].customerId -eq $sid3))
Check "history of an active course -> 404" ((Call GET "/api/data/courses/$cid2" $null $admin).Status -eq 404)

Write-Host "`n[Export Data is read-only]"
$studentsBefore = (Call GET "/api/customers" $null $admin).Body.total
$completedBefore = (Call GET "/api/data/courses" $null $admin).Body.total
$sqlFile = Download "/api/data/export/sql" $admin
$sqlText = [System.Text.Encoding]::UTF8.GetString($sqlFile.Bytes)
Check "SQL export -> 200" ($sqlFile.Status -eq 200)
Check "SQL export is a real script with INSERT statements" ($sqlText.Contains("BEGIN TRANSACTION") -and $sqlText.Contains("INSERT INTO [dbo].[Customers]") -and $sqlText.Contains("INSERT INTO [dbo].[Courses]") -and $sqlText.Contains("COMMIT TRANSACTION"))
Check "SQL export contains the completed course" ($sqlText.Contains($ccCode))
Check "SQL export never contains the Users table" (-not $sqlText.Contains("[dbo].[Users]"))
$xlsxFile = Download "/api/data/export/excel" $admin
Check "Excel export -> 200 and is an .xlsx package" (($xlsxFile.Status -eq 200) -and ($xlsxFile.Bytes.Length -gt 4) -and ($xlsxFile.Bytes[0] -eq 0x50) -and ($xlsxFile.Bytes[1] -eq 0x4B))
Check "Excel content type is spreadsheetml" ($xlsxFile.Type -like "*spreadsheetml*")
Check "exporting changed no data" (((Call GET "/api/customers" $null $admin).Body.total -eq $studentsBefore) -and ((Call GET "/api/data/courses" $null $admin).Body.total -eq $completedBefore))

Write-Host "`n[Undo of completion]"
Check "reopen -> 200" ((Call POST "/api/courses/$ccId/reopen" $null $admin).Status -eq 200)
Check "reopened course is back in the Courses list" ((Call GET "/api/courses?search=$ccCode" $null $admin).Body.total -eq 1)
Check "reopened course is no longer in Data" ((Call GET "/api/data/courses?search=$ccCode" $null $admin).Body.total -eq 0)

Write-Host "`n[New Student - invoice, payment, proof]"
$tmp = [System.IO.Path]::GetTempPath()
$pngFile = Join-Path $tmp "smoke_proof_$n.png"; [System.IO.File]::WriteAllBytes($pngFile, [byte[]](0x89,0x50,0x4E,0x47,0x0D,0x0A,0x1A,0x0A,0x00,0x00,0x00,0x00))
$jpgFile = Join-Path $tmp "smoke_proof_$n.jpg"; [System.IO.File]::WriteAllBytes($jpgFile, [byte[]](0xFF,0xD8,0xFF,0xE0,0x00,0x10,0x4A,0x46,0x49,0x46))
$pdfFile = Join-Path $tmp "smoke_proof_$n.pdf"; [System.IO.File]::WriteAllText($pdfFile, "%PDF-1.4`n%%EOF")
$fakeFile = Join-Path $tmp "smoke_fake_$n.png"; [System.IO.File]::WriteAllText($fakeFile, "this is not an image")

$rcourse = Call POST "/api/courses" @{ courseName = "SMOKE Register $n"; price = 1000; maxCapacity = 10 } $admin
CheckStatus "create the course used for registrations -> 201" $rcourse 201
$regCourse = $rcourse.Body.courseId; $regCode = $rcourse.Body.courseCode
$regBodies = @()
$pReg1 = NewPhone

$r1 = PostForm "/api/registrations" @{ fullName = "SMOKE Reg Unpaid $n"; phone = $pReg1; courseId = $regCourse; discountPercent = 0; amountPaid = 0; paymentMethod = "Cash" } $null $admin
CheckStatus "Cash, nothing paid -> 201" $r1 201
Check "Unpaid; price came from the course; no payment row" (($r1.Body.paymentStatus -eq "Unpaid") -and ($r1.Body.coursePrice -eq 1000) -and ($r1.Body.remaining -eq 1000) -and ($null -eq $r1.Body.paymentId))
Check "invoice number and Student ID are generated" (($r1.Body.invoiceNumber -match '^INV-\d{4}-\d{5}$') -and ($r1.Body.studentCode -match '^STU-\d{4,}$'))
$regBodies += $r1.Body

$r2 = PostForm "/api/registrations" @{ fullName = "SMOKE Reg Partial $n"; phone = (NewPhone); courseId = $regCourse; discountPercent = 10; amountPaid = 300; paymentMethod = "Cash" } $null $admin
CheckStatus "Cash, 10% discount, partial payment -> 201" $r2 201
Check "discount 100, final 900, remaining 600, Partially Paid" (($r2.Body.discountAmount -eq 100) -and ($r2.Body.finalAmount -eq 900) -and ($r2.Body.remaining -eq 600) -and ($r2.Body.paymentStatus -eq "Partially Paid"))
$regBodies += $r2.Body

$r3 = PostForm "/api/registrations" @{ fullName = "SMOKE Reg Paid $n"; phone = (NewPhone); courseId = $regCourse; discountPercent = 10; amountPaid = 900; paymentMethod = "InstaPay" } $null $admin
CheckStatus "InstaPay WITHOUT a proof, paid in full -> 201" $r3 201
Check "Paid, remaining 0, no proof stored" (($r3.Body.paymentStatus -eq "Paid") -and ($r3.Body.remaining -eq 0) -and ($r3.Body.hasProof -eq $false) -and ($r3.Body.paymentMethod -eq "InstaPay"))
$regBodies += $r3.Body

$r4 = PostForm "/api/registrations" @{ fullName = "SMOKE Reg InstaPng $n"; phone = (NewPhone); courseId = $regCourse; discountPercent = 0; amountPaid = 500; paymentMethod = "InstaPay" } $pngFile $admin
CheckStatus "InstaPay with a PNG proof -> 201" $r4 201
Check "proof is recorded" ($r4.Body.hasProof -eq $true)
$regBodies += $r4.Body

$r5 = PostForm "/api/registrations" @{ fullName = "SMOKE Reg VodaJpg $n"; phone = (NewPhone); courseId = $regCourse; discountPercent = 0; amountPaid = 1000; paymentMethod = "Vodafone Cash" } $jpgFile $admin
CheckStatus "Vodafone Cash with a JPG proof -> 201" $r5 201
$regBodies += $r5.Body
$r6 = PostForm "/api/registrations" @{ fullName = "SMOKE Reg VodaPdf $n"; phone = (NewPhone); courseId = $regCourse; discountPercent = 0; amountPaid = 400; paymentMethod = "Vodafone Cash" } $pdfFile $admin
CheckStatus "Vodafone Cash with a PDF proof -> 201" $r6 201
$regBodies += $r6.Body

$r7 = PostForm "/api/registrations" @{ fullName = "SMOKE Reg OtherText $n"; phone = (NewPhone); courseId = $regCourse; discountPercent = 0; amountPaid = 1000; paymentMethod = "Other"; paymentMethodOther = "Cheque" } $null $admin
CheckStatus "Other with text -> 201" $r7 201
Check "the Other payment method text is saved" ($r7.Body.paymentMethodOther -eq "Cheque")
$regBodies += $r7.Body
$r8 = PostForm "/api/registrations" @{ fullName = "SMOKE Reg OtherEmpty $n"; phone = (NewPhone); courseId = $regCourse; discountPercent = 0; amountPaid = 250; paymentMethod = "Other" } $null $admin
CheckStatus "Other with the text EMPTY still saves -> 201" $r8 201
Check "Other text is empty (null)" ($null -eq $r8.Body.paymentMethodOther)
$regBodies += $r8.Body

Write-Host "`n[New Student - validation]"
Check "Cash with a proof file -> 400" ((PostForm "/api/registrations" @{ fullName = "SMOKE Bad1 $n"; phone = (NewPhone); courseId = $regCourse; discountPercent = 0; amountPaid = 100; paymentMethod = "Cash" } $pngFile $admin).Status -eq 400)
Check "Visa is not accepted for new payments -> 400" ((PostForm "/api/registrations" @{ fullName = "SMOKE Bad2 $n"; phone = (NewPhone); courseId = $regCourse; discountPercent = 0; amountPaid = 100; paymentMethod = "Visa" } $null $admin).Status -eq 400)
Check "Bank Transfer is not accepted for new payments -> 400" ((PostForm "/api/registrations" @{ fullName = "SMOKE Bad3 $n"; phone = (NewPhone); courseId = $regCourse; discountPercent = 0; amountPaid = 100; paymentMethod = "Bank Transfer" } $null $admin).Status -eq 400)
Check "paying more than the final amount -> 400" ((PostForm "/api/registrations" @{ fullName = "SMOKE Bad4 $n"; phone = (NewPhone); courseId = $regCourse; discountPercent = 10; amountPaid = 901; paymentMethod = "Cash" } $null $admin).Status -eq 400)
Check "discount above 100% -> 400" ((PostForm "/api/registrations" @{ fullName = "SMOKE Bad5 $n"; phone = (NewPhone); courseId = $regCourse; discountPercent = 101; amountPaid = 0; paymentMethod = "Cash" } $null $admin).Status -eq 400)
Check "a text file renamed .png is rejected -> 400" ((PostForm "/api/registrations" @{ fullName = "SMOKE Bad6 $n"; phone = (NewPhone); courseId = $regCourse; discountPercent = 0; amountPaid = 100; paymentMethod = "InstaPay" } $fakeFile $admin).Status -eq 400)
Check "a proof without an amount paid -> 400" ((PostForm "/api/registrations" @{ fullName = "SMOKE Bad7 $n"; phone = (NewPhone); courseId = $regCourse; discountPercent = 0; amountPaid = 0; paymentMethod = "InstaPay" } $pngFile $admin).Status -eq 400)
Check "unknown course -> 400" ((PostForm "/api/registrations" @{ fullName = "SMOKE Bad8 $n"; phone = (NewPhone); courseId = 999999999; discountPercent = 0; amountPaid = 0; paymentMethod = "Cash" } $null $admin).Status -eq 400)
Check "duplicate phone -> 409" ((PostForm "/api/registrations" @{ fullName = "SMOKE Dup $n"; phone = $pReg1; courseId = $regCourse; discountPercent = 0; amountPaid = 0; paymentMethod = "Cash" } $null $admin).Status -eq 409)
Check "a failed registration left no student behind" ((Call GET "/api/customers?search=SMOKE%20Bad" $null $admin).Body.total -eq 0)

Write-Host "`n[New Student - capacity, Add Course, roles]"
$tiny = Call POST "/api/courses" @{ courseName = "SMOKE Tiny $n"; price = 500; maxCapacity = 1 } $admin
$tinyId = $tiny.Body.courseId
CheckStatus "first student takes the only seat -> 201" (PostForm "/api/registrations" @{ fullName = "SMOKE Tiny1 $n"; phone = (NewPhone); courseId = $tinyId; discountPercent = 0; amountPaid = 0; paymentMethod = "Cash" } $null $admin) 201
$tinyFull = PostForm "/api/registrations" @{ fullName = "SMOKE Tiny2 $n"; phone = (NewPhone); courseId = $tinyId; discountPercent = 0; amountPaid = 0; paymentMethod = "Cash" } $null $admin
Check "second student in a full course -> 409 and nothing is saved" (($tinyFull.Status -eq 409) -and ((Call GET "/api/customers?search=SMOKE%20Tiny2" $null $admin).Body.total -eq 0))
Check "the course now shows as Full, not Completed" (((Call GET "/api/courses?search=$($tiny.Body.courseCode)" $null $admin).Body.items[0].status) -eq "Full")

$other = Call POST "/api/courses" @{ courseName = "SMOKE Other Course $n"; price = 800; maxCapacity = 5 } $admin
$otherId = $other.Body.courseId
$again = PostForm "/api/registrations" @{ customerId = $r1.Body.customerId; courseId = $regCourse; discountPercent = 0; amountPaid = 0; paymentMethod = "Cash" } $null $admin
Check "Add Course: the same student in the same course again -> 409" ($again.Status -eq 409)
$add = PostForm "/api/registrations" @{ customerId = $r1.Body.customerId; courseId = $otherId; discountPercent = 0; amountPaid = 800; paymentMethod = "Cash" } $null $admin
CheckStatus "Add Course: existing student, another course, with payment -> 201" $add 201
Check "Add Course reuses the student (no duplicate)" ($add.Body.customerId -eq $r1.Body.customerId)

$remp = PostForm "/api/registrations" @{ fullName = "SMOKE Reg Employee $n"; phone = (NewPhone); courseId = $regCourse; discountPercent = 0; amountPaid = 100; paymentMethod = "Cash" } $null $emp
CheckStatus "an employee can register a student -> 201" $remp 201
$regBodies += $remp.Body
Check "no token -> 401" ((PostForm "/api/registrations" @{ fullName = "x"; courseId = 1; paymentMethod = "Cash" } $null "invalid").Status -eq 401)

Write-Host "`n[Completed course: financial history]"
$sqlBefore = [System.Text.Encoding]::UTF8.GetString((Download "/api/data/export/sql" $admin).Bytes)
Check "SQL export contains the new invoices and payments" ($sqlBefore.Contains($r4.Body.invoiceNumber) -and $sqlBefore.Contains("INSERT INTO [dbo].[Payments]") -and $sqlBefore.Contains("INSERT INTO [dbo].[PaymentAllocations]"))
Check "the 'Other' text and the proof metadata are exported" ($sqlBefore.Contains("Cheque"))
Check "completing the registration course -> 200" ((Call POST "/api/courses/$regCourse/complete" $null $admin).Status -eq 200)

$expTotal = [math]::Round((($regBodies | Measure-Object -Property finalAmount -Sum).Sum), 2)
$expPaid = [math]::Round((($regBodies | Measure-Object -Property amountPaid -Sum).Sum), 2)
$listRow = (Call GET "/api/data/courses?search=$regCode" $null $admin).Body.items[0]
Check "Data: total revenue matches the invoices" ($listRow.financial.totalAmount -eq $expTotal)
Check "Data: total paid matches the payments" ($listRow.financial.totalPaid -eq $expPaid)
Check "Data: total remaining = revenue - paid" ($listRow.financial.totalRemaining -eq ($expTotal - $expPaid))
$nPaid = @($regBodies | Where-Object { $_.paymentStatus -eq "Paid" }).Count
$nPartial = @($regBodies | Where-Object { $_.paymentStatus -eq "Partially Paid" }).Count
$nUnpaid = @($regBodies | Where-Object { $_.paymentStatus -eq "Unpaid" }).Count
Check "Data: Paid / Partial / Unpaid counts" (($listRow.financial.paidCount -eq $nPaid) -and ($listRow.financial.partialCount -eq $nPartial) -and ($listRow.financial.unpaidCount -eq $nUnpaid))
Check "Data: student count" ($listRow.studentCount -eq $regBodies.Count)
Check "Data: filter Paid" ((Call GET "/api/data/courses/$regCourse`?paymentStatus=paid" $null $admin).Body.students.Count -eq $nPaid)
Check "Data: filter Partial / Remaining" ((Call GET "/api/data/courses/$regCourse`?paymentStatus=partial" $null $admin).Body.students.Count -eq $nPartial)
Check "Data: filter Unpaid" ((Call GET "/api/data/courses/$regCourse`?paymentStatus=unpaid" $null $admin).Body.students.Count -eq $nUnpaid)

$hist = Call GET "/api/data/courses/$regCourse/students/$($r4.Body.customerId)" $null $admin
Check "student history: invoice, discount and payment" (($hist.Status -eq 200) -and ($hist.Body.invoice.invoiceNumber -eq $r4.Body.invoiceNumber) -and ($hist.Body.invoice.amountPaid -eq 500) -and ($hist.Body.invoice.remaining -eq 500) -and ($hist.Body.payments[0].paymentMethod -eq "InstaPay"))
Check "student history: personal details and course" (($hist.Body.fullName -eq "SMOKE Reg InstaPng $n") -and ($hist.Body.courseCode -eq $regCode) -and ($hist.Body.studentCode -eq $r4.Body.studentCode))
$proofId = $hist.Body.payments[0].paymentId
Check "history says the proof exists" ($hist.Body.payments[0].hasProof -eq $true)
$proofDl = Download "/api/data/payments/$proofId/proof" $admin
Check "admin can open the stored proof (PNG bytes)" (($proofDl.Status -eq 200) -and ($proofDl.Bytes[0] -eq 0x89))
Check "employee cannot open a proof -> 403" ((Download "/api/data/payments/$proofId/proof" $emp).Status -eq 403)
Check "employee cannot read student history -> 403" ((Call GET "/api/data/courses/$regCourse/students/$($r4.Body.customerId)" $null $emp).Status -eq 403)
Check "history of a student with no payment shows no payments" ((Call GET "/api/data/courses/$regCourse/students/$($r1.Body.customerId)" $null $admin).Body.payments.Count -eq 0)

Write-Host "`n[Delete Course Data]"
Check "wrong confirmation text -> 400" ((Call DELETE "/api/data/courses/$regCourse" @{ confirmation = "delete" } $admin).Status -eq 400)
Check "no confirmation -> 400" ((Call DELETE "/api/data/courses/$regCourse" @{ confirmation = "" } $admin).Status -eq 400)
Check "employee cannot delete course data -> 403" ((Call DELETE "/api/data/courses/$regCourse" @{ confirmation = "DELETE" } $emp).Status -eq 403)
Check "an active course's data cannot be deleted -> 404" ((Call DELETE "/api/data/courses/$otherId" @{ confirmation = "DELETE" } $admin).Status -eq 404)
$del = Call DELETE "/api/data/courses/$regCourse" @{ confirmation = "DELETE" } $admin
CheckStatus "admin deletes the completed course data -> 200" $del 200
$nPayments = @($regBodies | Where-Object { $null -ne $_.paymentId }).Count
Check "removed exactly this course's invoices, payments and registrations" (($del.Body.invoicesDeleted -eq $regBodies.Count) -and ($del.Body.paymentsDeleted -eq $nPayments) -and ($del.Body.enrollmentsDeleted -eq $regBodies.Count))
Check "the course is gone from Data" ((Call GET "/api/data/courses?search=$regCode" $null $admin).Body.total -eq 0)
Check "the stored proof is gone" ((Download "/api/data/payments/$proofId/proof" $admin).Status -eq 404)
Check "the student with another course survives" ((Call GET "/api/customers/$($r1.Body.customerId)" $null $admin).Status -eq 200)
Check "...and keeps the other course registration" (@((Call GET "/api/customers/$($r1.Body.customerId)" $null $admin).Body.enrollments | Where-Object { $_.courseId -eq $otherId }).Count -eq 1)
Check "unrelated courses are untouched" ((Call GET "/api/courses?search=$($other.Body.courseCode)" $null $admin).Body.items[0].enrolledCount -eq 1)
$sqlAfter = [System.Text.Encoding]::UTF8.GetString((Download "/api/data/export/sql" $admin).Bytes)
Check "the deleted invoices no longer appear in the export" (-not $sqlAfter.Contains($r4.Body.invoiceNumber))
Check "the invoice of the other course is still there" ($sqlAfter.Contains($add.Body.invoiceNumber))
$next = Call POST "/api/courses" @{ courseName = "SMOKE After purge $n"; price = 100; maxCapacity = 5 } $admin
Check "Course IDs are never reused" ($next.Body.courseId -gt $regCourse)
Check "Excel export still works after the clean-up" (((Download "/api/data/export/excel" $admin).Bytes[0]) -eq 0x50)

Remove-Item $pngFile, $jpgFile, $pdfFile, $fakeFile -ErrorAction SilentlyContinue

Write-Host "`n[Phase 3 - Student / Offer invoices]"
$today = (Get-Date).ToString("yyyy-MM-dd")
$p3c = Call POST "/api/courses" @{ courseName = "SMOKE Phase3 $n"; price = 1000; maxCapacity = 20 } $admin
CheckStatus "create the Phase 3 course -> 201" $p3c 201
$p3 = $p3c.Body.courseId; $p3Code = $p3c.Body.courseCode
$p3d = Call POST "/api/courses" @{ courseName = "SMOKE Phase3 Second $n"; price = 500; maxCapacity = 20 } $admin
$p3b = $p3d.Body.courseId
$invoicesBefore = (Call GET "/api/invoices" $null $admin).Body.total
$offerStudents = @(
  @{ fullName = "SMOKE Offer A $n"; phone = (NewPhone); area = "Girga" },
  @{ fullName = "SMOKE Offer B $n"; phone = (NewPhone); email = "smoke_offer_b_$n@example.com" },
  @{ fullName = "SMOKE Offer C $n"; phone = (NewPhone) })

$pv = Call POST "/api/invoices/preview" @{ type = "Offer"; students = $offerStudents; courseId = $p3; discountPercent = 10; amountPaid = 1000; paymentMethod = "Cash" } $admin
CheckStatus "preview an Offer -> 200" $pv 200
Check "preview: the SERVER calculates 3 x 1000 = 3000, discount 300, total 2700" (($pv.Body.quantity -eq 3) -and ($pv.Body.unitPrice -eq 1000) -and ($pv.Body.subtotal -eq 3000) -and ($pv.Body.discountAmount -eq 300) -and ($pv.Body.grandTotal -eq 2700) -and ($pv.Body.remaining -eq 1700) -and ($pv.Body.paymentStatus -eq "Partially Paid"))
Check "preview saves nothing (no invoice, no student)" (((Call GET "/api/invoices" $null $admin).Body.total -eq $invoicesBefore) -and ((Call GET "/api/customers?search=SMOKE%20Offer%20A" $null $admin).Body.total -eq 0))
Check "discount above 100% -> 400" ((Call POST "/api/invoices/preview" @{ type = "Offer"; students = $offerStudents; courseId = $p3; discountPercent = 101; amountPaid = 0; paymentMethod = "Cash" } $admin).Status -eq 400)
Check "negative discount -> 400" ((Call POST "/api/invoices/preview" @{ type = "Offer"; students = $offerStudents; courseId = $p3; discountPercent = -5; amountPaid = 0; paymentMethod = "Cash" } $admin).Status -eq 400)
Check "an Offer needs at least two students -> 400" ((Call POST "/api/invoices/preview" @{ type = "Offer"; students = @($offerStudents[0]); courseId = $p3; discountPercent = 0; amountPaid = 0; paymentMethod = "Cash" } $admin).Status -eq 400)
Check "a Student registration with two students -> 400" ((Call POST "/api/invoices/preview" @{ type = "Student"; students = @($offerStudents[0], $offerStudents[1]); courseId = $p3; discountPercent = 0; amountPaid = 0; paymentMethod = "Cash" } $admin).Status -eq 400)
Check "the same phone twice in an Offer -> 400" ((Call POST "/api/invoices/preview" @{ type = "Offer"; students = @($offerStudents[0], @{ fullName = "SMOKE Twin $n"; phone = $offerStudents[0].phone }); courseId = $p3; discountPercent = 0; amountPaid = 0; paymentMethod = "Cash" } $admin).Status -eq 400)
Check "a completed / unknown course -> 400" ((Call POST "/api/invoices/preview" @{ type = "Student"; students = @($offerStudents[0]); courseId = 999999999; discountPercent = 0; amountPaid = 0; paymentMethod = "Cash" } $admin).Status -eq 400)

$single = @{ type = "Student"; students = @(@{ fullName = "SMOKE Single $n"; phone = (NewPhone); email = "smoke_single_$n@example.com"; area = "Sohag" }); courseId = $p3; discountPercent = 0; amountPaid = 0; paymentMethod = "Cash" }
$st1 = PostForm "/api/invoices" @{ payload = ($single | ConvertTo-Json -Depth 6 -Compress) } $null $admin
CheckStatus "save a Student invoice -> 201" $st1 201
Check "Student invoice: one student, number, date and time" (($st1.Body.type -eq "Student") -and ($st1.Body.students.Count -eq 1) -and ($st1.Body.invoiceNumber -match '^INV-\d{4}-\d{5}$') -and ($st1.Body.issueDate -match 'T\d\d:\d\d'))
Check "Student invoice: Unpaid, total 1000" (($st1.Body.grandTotal -eq 1000) -and ($st1.Body.paymentStatus -eq "Unpaid"))

$offer = @{ type = "Offer"; students = $offerStudents; courseId = $p3; discountPercent = 10; amountPaid = 1000; paymentMethod = "Cash" }
$of1 = PostForm "/api/invoices" @{ payload = ($offer | ConvertTo-Json -Depth 6 -Compress) } $null $admin
CheckStatus "save an Offer -> 201" $of1 201
Check "Offer: ONE invoice linked to all 3 students" (($of1.Body.type -eq "Offer") -and ($of1.Body.students.Count -eq 3) -and ($of1.Body.items.Count -eq 1) -and ($of1.Body.items[0].quantity -eq 3))
Check "Offer totals 3000 / 300 / 2700, paid 1000, remaining 1700, Partially Paid" (($of1.Body.subtotal -eq 3000) -and ($of1.Body.discountAmount -eq 300) -and ($of1.Body.grandTotal -eq 2700) -and ($of1.Body.amountPaid -eq 1000) -and ($of1.Body.remaining -eq 1700) -and ($of1.Body.paymentStatus -eq "Partially Paid"))
Check "exactly two new invoices exist (not one per student)" ((Call GET "/api/invoices" $null $admin).Body.total -eq ($invoicesBefore + 2))
$offerFirst = $of1.Body.students[0].customerId
$offerHistory = @((Call GET "/api/customers/$offerFirst" $null $admin).Body.enrollments | Where-Object { $_.courseId -eq $p3 })[0]
Check "student history: this course is shown with Type = Offer and the invoice number" (($offerHistory.type -eq "Offer") -and ($offerHistory.invoiceNumber -eq $of1.Body.invoiceNumber))
$singleHistory = @((Call GET "/api/customers/$($st1.Body.students[0].customerId)" $null $admin).Body.enrollments | Where-Object { $_.courseId -eq $p3 })[0]
Check "student history: the single registration is Type = Student" ($singleHistory.type -eq "Student")
Check "the 4 students take 4 seats" ((Call GET "/api/courses/$p3" $null $admin).Body.course.enrolledCount -eq 4)
Check "a student already in the course cannot be added to another Offer -> 409" ((Call POST "/api/invoices/preview" @{ type = "Offer"; students = @(@{ customerId = $offerFirst }, @{ fullName = "SMOKE Other $n"; phone = (NewPhone) }); courseId = $p3; discountPercent = 0; amountPaid = 0; paymentMethod = "Cash" } $admin).Status -eq 409)

Write-Host "`n[Phase 3 - invoice list, search and date range]"
$byNumber = Call GET "/api/invoices?search=$($of1.Body.invoiceNumber)" $null $admin
Check "search by invoice number" (($byNumber.Body.total -eq 1) -and ($byNumber.Body.items[0].invoiceId -eq $of1.Body.invoiceId))
Check "list row for an Offer: label, count, totals" (($byNumber.Body.items[0].type -eq "Offer") -and ($byNumber.Body.items[0].studentCount -eq 3) -and ($byNumber.Body.items[0].grandTotal -eq 2700))
Check "search by student name" ((Call GET "/api/invoices?search=SMOKE%20Offer%20B" $null $admin).Body.total -eq 1)
Check "search by course code" ((Call GET "/api/invoices?search=$p3Code" $null $admin).Body.total -eq 2)
Check "search by course name" ((Call GET "/api/invoices?search=SMOKE%20Phase3%20$n" $null $admin).Body.total -eq 2)
Check "search treats % as text, not a wildcard" ((Call GET "/api/invoices?search=%25" $null $admin).Body.total -eq 0)
Check "date range with today includes the new invoices" ((Call GET "/api/invoices?search=$p3Code&fromDate=$today&toDate=$today" $null $admin).Body.total -eq 2)
Check "date range in the past excludes them" ((Call GET "/api/invoices?search=$p3Code&fromDate=2000-01-01&toDate=2000-01-31" $null $admin).Body.total -eq 0)
Check "start date after end date -> 400" ((Call GET "/api/invoices?fromDate=2026-08-01&toDate=2026-07-01" $null $admin).Status -eq 400)
Check "status filter: partial" ((Call GET "/api/invoices?search=$p3Code&status=partial" $null $admin).Body.total -eq 1)
Check "status filter: unpaid" ((Call GET "/api/invoices?search=$p3Code&status=unpaid" $null $admin).Body.total -eq 1)
Check "an employee can list invoices" ((Call GET "/api/invoices" $null $emp).Status -eq 200)
Check "invoice details: date, students, items, payments, can edit" ((($d = (Call GET "/api/invoices/$($of1.Body.invoiceId)" $null $admin)).Status -eq 200) -and ($d.Body.canEdit -eq $true) -and ($d.Body.payments.Count -eq 1) -and ($d.Body.students.Count -eq 3))
Check "unknown invoice -> 404" ((Call GET "/api/invoices/999999999" $null $admin).Status -eq 404)
Check "students: date range with today" ((Call GET "/api/customers?search=SMOKE%20Offer&fromDate=$today&toDate=$today" $null $admin).Body.total -eq 3)
Check "students: date range in the past excludes them" ((Call GET "/api/customers?search=SMOKE%20Offer&fromDate=2000-01-01&toDate=2000-01-31" $null $admin).Body.total -eq 0)
Check "students: start after end -> 400" ((Call GET "/api/customers?fromDate=2026-08-01&toDate=2026-07-01" $null $admin).Status -eq 400)

Write-Host "`n[Phase 3 - edit the invoice]"
$offerId = $of1.Body.invoiceId
$members = @($of1.Body.students | ForEach-Object { @{ customerId = $_.customerId } })
$e1 = Call PUT "/api/invoices/$offerId" @{ courseId = $p3; discountPercent = 20; students = $members } $admin
CheckStatus "edit the discount -> 200" $e1 200
Check "SAME invoice id and number" (($e1.Body.invoiceId -eq $offerId) -and ($e1.Body.invoiceNumber -eq $of1.Body.invoiceNumber))
Check "recalculated 3000 / 600 / 2400, remaining 1400" (($e1.Body.subtotal -eq 3000) -and ($e1.Body.discountAmount -eq 600) -and ($e1.Body.grandTotal -eq 2400) -and ($e1.Body.remaining -eq 1400))
Check "no duplicate invoice was created" ((Call GET "/api/invoices" $null $admin).Body.total -eq ($invoicesBefore + 2))
$removedId = $of1.Body.students[2].customerId
$e2 = Call PUT "/api/invoices/$offerId" @{ courseId = $p3; discountPercent = 20; students = @($members[0], $members[1]) } $admin
CheckStatus "remove one student -> 200" $e2 200
Check "2 students, 2000 - 400 = 1600" (($e2.Body.students.Count -eq 2) -and ($e2.Body.subtotal -eq 2000) -and ($e2.Body.grandTotal -eq 1600))
Check "the removed student's registration was cancelled and the seat freed" ((@((Call GET "/api/customers/$removedId" $null $admin).Body.enrollments | Where-Object { ($_.courseId -eq $p3) -and ($_.status -eq "Cancelled") }).Count -eq 1) -and ((Call GET "/api/courses/$p3" $null $admin).Body.course.enrolledCount -eq 3))
$e3 = Call PUT "/api/invoices/$offerId" @{ courseId = $p3; discountPercent = 20; students = @($members[0], $members[1], @{ fullName = "SMOKE Added $n"; phone = (NewPhone); area = "Cairo" }) } $admin
CheckStatus "add a NEW student while editing -> 200" $e3 200
Check "3 students again and the new student is enrolled" (($e3.Body.students.Count -eq 3) -and ((Call GET "/api/customers?search=SMOKE%20Added" $null $admin).Body.total -eq 1))
Check "grand total below what was already paid -> 400" ((Call PUT "/api/invoices/$offerId" @{ courseId = $p3; discountPercent = 100; students = $members } $admin).Status -eq 400)
Check "invalid discount while editing -> 400" ((Call PUT "/api/invoices/$offerId" @{ courseId = $p3; discountPercent = 150; students = $members } $admin).Status -eq 400)
Check "an invoice with no students -> 400" ((Call PUT "/api/invoices/$offerId" @{ courseId = $p3; discountPercent = 0; students = @() } $admin).Status -eq 400)
Check "editing an unknown invoice -> 404" ((Call PUT "/api/invoices/999999999" @{ courseId = $p3; discountPercent = 0; students = $members } $admin).Status -eq 404)
$singleId = $st1.Body.invoiceId
$singleMember = @(@{ customerId = $st1.Body.students[0].customerId })
$e4 = Call PUT "/api/invoices/$singleId" @{ courseId = $p3b; discountPercent = 0; students = $singleMember } $admin
CheckStatus "change the course of an invoice -> 200" $e4 200
Check "the new course price (500) is used and the invoice is the same" (($e4.Body.invoiceId -eq $singleId) -and ($e4.Body.items[0].courseId -eq $p3b) -and ($e4.Body.items[0].unitPrice -eq 500) -and ($e4.Body.grandTotal -eq 500))
Check "the student moved from the old course to the new one" (((Call GET "/api/courses/$p3b" $null $admin).Body.course.enrolledCount -eq 1) -and ((Call GET "/api/courses/$p3" $null $admin).Body.course.enrolledCount -eq 3))
$e5 = Call PUT "/api/invoices/$singleId" @{ courseId = $p3b; discountPercent = 10; students = $singleMember } $emp
Check "an employee can edit an invoice" (($e5.Status -eq 200) -and ($e5.Body.grandTotal -eq 450))
Check "no token -> 401" ((Call GET "/api/invoices" $null "invalid").Status -eq 401)
Check "completing the course makes its invoice read-only" (((Call POST "/api/courses/$p3/complete" $null $admin).Status -eq 200) -and ((Call GET "/api/invoices/$offerId" $null $admin).Body.canEdit -eq $false) -and ((Call PUT "/api/invoices/$offerId" @{ courseId = $p3; discountPercent = 0; students = $members } $admin).Status -eq 409))

Write-Host "`n[Phase 3 - expenses with a date range]"
Check "employee cannot read expenses -> 403" ((Call GET "/api/expenses" $null $emp).Status -eq 403)
$ex = Call GET "/api/expenses" $null $admin
Check "expenses list -> 200 with a total" (($ex.Status -eq 200) -and ($null -ne $ex.Body.totalAmount))
Check "expenses: start after end -> 400" ((Call GET "/api/expenses?fromDate=2026-08-01&toDate=2026-07-01" $null $admin).Status -eq 400)
$exOld = Call GET "/api/expenses?fromDate=1999-01-01&toDate=1999-01-31" $null $admin
Check "expenses: a range with no data returns nothing and a zero total" (($exOld.Status -eq 200) -and ($exOld.Body.total -eq 0) -and ($exOld.Body.totalAmount -eq 0))
Check "expenses: search and range together are accepted" ((Call GET "/api/expenses?search=a&fromDate=2000-01-01&toDate=2100-01-01" $null $admin).Status -eq 200)

Write-Host "`n[Idempotency - the same request twice creates ONE record]"
$k1 = [guid]::NewGuid().ToString(); $ph = NewPhone
$i1 = Call POST "/api/customers" @{ fullName = "SMOKE Idem $n"; phone = $ph } $admin $k1
$i2 = Call POST "/api/customers" @{ fullName = "SMOKE Idem $n"; phone = $ph } $admin $k1
Check "student: first request -> 201" ($i1.Status -eq 201)
Check "student: same key again -> original result, same student id" (($i2.Status -eq 201) -and ($i2.Body.customerId -eq $i1.Body.customerId))
$cnt = (Call GET "/api/customers?search=$ph" $null $admin).Body.total
Check "student: only ONE student exists for that phone" ($cnt -eq 1)
Check "student: same key with different data -> 422" ((Call POST "/api/customers" @{ fullName = "SMOKE Idem Other $n"; phone = (NewPhone) } $admin $k1).Status -eq 422)
Check "student: missing Idempotency-Key -> 400" ((Call POST "/api/customers" @{ fullName = "SMOKE NoKey $n"; phone = (NewPhone) } $admin -NoKey).Status -eq 400)
$sameName1 = Call POST "/api/customers" @{ fullName = "SMOKE Same Name"; phone = (NewPhone) } $admin
$sameName2 = Call POST "/api/customers" @{ fullName = "SMOKE Same Name"; phone = (NewPhone) } $admin
Check "two DIFFERENT students with the same name are still allowed" (($sameName1.Status -eq 201) -and ($sameName2.Status -eq 201) -and ($sameName1.Body.customerId -ne $sameName2.Body.customerId))

$kc = [guid]::NewGuid().ToString()
$ic1 = Call POST "/api/courses" @{ courseName = "SMOKE Idem Course $n"; price = 700; maxCapacity = 1 } $admin $kc
$ic2 = Call POST "/api/courses" @{ courseName = "SMOKE Idem Course $n"; price = 700; maxCapacity = 1 } $admin $kc
Check "course: same key twice -> same course, one code" (($ic1.Status -eq 201) -and ($ic2.Status -eq 201) -and ($ic1.Body.courseCode -eq $ic2.Body.courseCode))

$ke = [guid]::NewGuid().ToString()
$ie1 = Call POST "/api/enrollments" @{ customerId = $i1.Body.customerId; courseId = $ic1.Body.courseId } $admin $ke
$ie2 = Call POST "/api/enrollments" @{ customerId = $i1.Body.customerId; courseId = $ic1.Body.courseId } $admin $ke
Check "enrollment: same key twice -> same enrollment" (($ie1.Status -eq 201) -and ($ie2.Status -eq 201) -and ($ie1.Body.enrollmentId -eq $ie2.Body.enrollmentId))
Check "enrollment: a NEW key for the same student and course -> 409 (database rule)" ((Call POST "/api/enrollments" @{ customerId = $i1.Body.customerId; courseId = $ic1.Body.courseId } $admin).Status -eq 409)

$kr = [guid]::NewGuid().ToString(); $pr = NewPhone
$idemCourse = (Call POST "/api/courses" @{ courseName = "SMOKE Idem Invoice $n"; price = 1000; maxCapacity = 10 } $admin).Body.courseId
$ir1 = PostForm "/api/registrations" @{ fullName = "SMOKE Idem Reg $n"; phone = $pr; courseId = $idemCourse; discountPercent = 0; amountPaid = 400; paymentMethod = "Cash" } $null $admin $kr
$ir2 = PostForm "/api/registrations" @{ fullName = "SMOKE Idem Reg $n"; phone = $pr; courseId = $idemCourse; discountPercent = 0; amountPaid = 400; paymentMethod = "Cash" } $null $admin $kr
Check "registration: same key twice -> same invoice number" (($ir1.Status -eq 201) -and ($ir2.Status -eq 201) -and ($ir1.Body.invoiceNumber -eq $ir2.Body.invoiceNumber))
$inv = (Call GET "/api/invoices/$($ir1.Body.invoiceId)" $null $admin).Body
Check "registration: the payment was recorded ONCE (paid 400, not 800)" ($inv.amountPaid -eq 400)

Write-Host "`n[Notifications]"
$nf0 = Call GET "/api/notifications" $null $admin
Check "notifications list -> 200 with an unread count" (($nf0.Status -eq 200) -and ($null -ne $nf0.Body.unreadCount))
$fullKey = "SMOKE Idem Course $n"
$fullForAdmin = @($nf0.Body.items | Where-Object { $_.type -eq "CourseFull" -and $_.paramsJson -like "*$($ic1.Body.courseCode)*" })
Check "filling the last seat created exactly ONE course-full notification" ($fullForAdmin.Count -eq 1)
$nid = $fullForAdmin[0].notificationId
Check "it is unread for the admin" ($fullForAdmin[0].isRead -eq $false)
$empBefore = Call GET "/api/notifications" $null $emp
$empItem = @($empBefore.Body.items | Where-Object { $_.notificationId -eq $nid })
Check "it is unread for the employee too" (($empItem.Count -eq 1) -and ($empItem[0].isRead -eq $false))
$mr = Call POST "/api/notifications/$nid/read" $null $admin
Check "admin marks it read -> 200" ($mr.Status -eq 200)
Check "after reading, the admin sees it as read" ((@((Call GET "/api/notifications" $null $admin).Body.items | Where-Object { $_.notificationId -eq $nid })[0]).isRead -eq $true)
Check "the employee STILL sees it as unread (read state is per user)" ((@((Call GET "/api/notifications" $null $emp).Body.items | Where-Object { $_.notificationId -eq $nid })[0]).isRead -eq $false)
Check "marking read twice is harmless" ((Call POST "/api/notifications/$nid/read" $null $admin).Status -eq 200)
$all = Call POST "/api/notifications/read-all" $null $emp
Check "mark all as read -> unread count 0" (($all.Status -eq 200) -and ($all.Body.unreadCount -eq 0))
Check "mark all as read for the employee did not touch the admin's list" ((Call GET "/api/notifications/unread-count" $null $emp).Body.unreadCount -eq 0)
Check "no token -> 401" ((Call GET "/api/notifications").Status -eq 401)
# the event cannot be raised twice: cancel + the same status call again does not create a second row
$again = @((Call GET "/api/notifications" $null $admin).Body.items | Where-Object { $_.type -eq "CourseFull" -and $_.paramsJson -like "*$($ic1.Body.courseCode)*" })
Check "still ONE course-full notification after the repeated requests" ($again.Count -eq 1)

Write-Host "`n[Cleanup]"
if ($sid2b) { Call DELETE "/api/customers/$sid2b" @{ reason = "smoke test cleanup" } $admin | Out-Null }
Call PUT "/api/users/$($empUser.Body.userId)" @{ fullName = "Smoke Employee"; role = "Employee"; isActive = $false } $admin | Out-Null
Check "disabled employee token is rejected -> 401" ((Call GET "/api/customers" $null $emp).Status -eq 401)

Write-Host "`nResult: $script:pass passed, $script:fail failed"
Write-Host "Test records start with SMOKE; deactivate or delete them from the UI if you do not want them."
if ($script:fail -gt 0) { exit 1 }
