using System.Collections;
using System.Security.Claims;
using System.Text.Json;
using GermanCenter.Api.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Controllers;
using Microsoft.AspNetCore.Mvc.Filters;

namespace GermanCenter.Api.Filters;

/// <summary>
/// Global filter: after an authenticated action SUCCEEDED (2xx) it writes one audit record for every change (POST, PUT, PATCH, DELETE),
/// plus the Data exports. Nothing is recorded for failed requests (they changed nothing) or for replays of an Idempotency-Key.
/// Request bodies are never stored, so passwords cannot end up in the log. Login is recorded by the login endpoint itself.
/// </summary>
public sealed class AuditFilter(AuditService audit) : IAsyncActionFilter
{
    private static readonly HashSet<string> SkipControllers = new(StringComparer.OrdinalIgnoreCase) { "Audit", "Notifications", "Schedule" };
    private static readonly string[] ReferenceProps = { "InvoiceNumber", "CourseCode", "StudentCode", "PaymentId", "ExpenseId", "PayrollId", "EmployeeId", "UserId", "CourseId", "CustomerId", "InvoiceId", "Id" };
    private static readonly string[] DetailProps = { "Amount", "NetSalary", "GrandTotal", "PaymentStatus", "Status", "PaymentMethod", "Remaining" };
    private static readonly string[] RouteRefs = { "id", "courseId", "customerId", "invoiceId", "paymentId" };

    public async Task OnActionExecutionAsync(ActionExecutingContext context, ActionExecutionDelegate next)
    {
        var executed = await next();
        try { await TryLogAsync(context, executed); }
        catch { /* the audit trail must never affect the request */ }
    }

    private async Task TryLogAsync(ActionExecutingContext context, ActionExecutedContext executed)
    {
        if (executed.Exception != null && !executed.ExceptionHandled) return;
        if (context.ActionDescriptor is not ControllerActionDescriptor d) return;
        var http = context.HttpContext;
        var method = http.Request.Method;
        var controller = d.ControllerName;
        var action = d.ActionName;

        var isExport = controller == "Data" && action.StartsWith("Export", StringComparison.OrdinalIgnoreCase);
        var isChange = method is "POST" or "PUT" or "PATCH" or "DELETE";
        if (!isChange && !isExport) return;
        if (SkipControllers.Contains(controller)) return;
        if (controller == "Auth" && action == "Login") return;
        if (http.Response.Headers.ContainsKey("Idempotent-Replayed")) return;

        var status = executed.Result switch
        {
            ObjectResult o => o.StatusCode ?? 200,
            StatusCodeResult s => s.StatusCode,
            FileResult => 200,
            _ => http.Response.StatusCode
        };
        if (status >= 400) return;

        if (!int.TryParse(http.User.FindFirstValue(ClaimTypes.NameIdentifier), out var userId)) return;

        var value = (executed.Result as ObjectResult)?.Value;
        var reference = RouteRefs.Select(k => context.RouteData.Values.TryGetValue(k, out var v) ? v?.ToString() : null).FirstOrDefault(v => v != null)
                        ?? FindProp(value, ReferenceProps);
        var details = new Dictionary<string, object?> { ["method"] = method, ["path"] = http.Request.Path.Value, ["status"] = status };
        foreach (var name in DetailProps)
            if (FindProp(value, new[] { name }) is { } found) details[name.ToLowerInvariant()] = found;

        await audit.LogAsync(userId, http.User.Identity?.Name, $"{controller}.{action}", TypeOf(controller, action, method), controller, reference,
            JsonSerializer.Serialize(details), http.Connection.RemoteIpAddress?.ToString(), CancellationToken.None);
    }

    private static string TypeOf(string controller, string action, string method)
    {
        if (controller == "Auth") return "Auth";
        if (action.Contains("Restore", StringComparison.OrdinalIgnoreCase)) return "Restore";
        if (controller is "Backup" or "Data" or "DataAccess") return "Data";
        if (controller is "Expenses" or "Payroll" || action == "AddPayment" || (controller is "Invoices" or "Registrations" && method == "POST")) return "Financial";
        if (controller is "Users" or "Account") return "Admin";
        return method switch { "POST" => "Create", "DELETE" => "Delete", _ => "Update" };
    }

    private static string? FindProp(object? value, string[] names)
    {
        if (value is null or string or IEnumerable) return null;
        var type = value.GetType();
        foreach (var n in names)
        {
            var p = type.GetProperty(n);
            var v = p?.GetValue(value);
            if (v is not null and not IEnumerable || v is string) return Convert.ToString(v, System.Globalization.CultureInfo.InvariantCulture);
        }
        return null;
    }
}
