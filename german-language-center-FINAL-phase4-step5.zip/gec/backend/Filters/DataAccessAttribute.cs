using System.Security.Claims;
using GermanCenter.Api.DTOs;
using GermanCenter.Api.Models;
using GermanCenter.Api.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;

namespace GermanCenter.Api.Filters;

/// <summary>
/// Protects the Data endpoints on the SERVER (the password screen in the browser is only the user interface).
///   Admin                          -> allowed directly
///   anyone else                    -> must send a valid X-Data-Token, obtained from POST /api/data-access/unlock with the Data password
/// Without it the answer is 403 DATA_LOCKED.
/// </summary>
[AttributeUsage(AttributeTargets.Class | AttributeTargets.Method)]
public sealed class DataAccessAttribute : Attribute, IAsyncAuthorizationFilter
{
    public async Task OnAuthorizationAsync(AuthorizationFilterContext context)
    {
        var user = context.HttpContext.User;
        if (user.Identity?.IsAuthenticated != true) { context.Result = new UnauthorizedResult(); return; }
        if (user.IsInRole(Roles.Admin)) return;

        var locked = new ObjectResult(new ApiError("DATA_LOCKED", "Enter the Data password to open this area.")) { StatusCode = StatusCodes.Status403Forbidden };
        if (!int.TryParse(user.FindFirstValue(ClaimTypes.NameIdentifier), out var userId)) { context.Result = locked; return; }

        var token = context.HttpContext.Request.Headers[DataAccessService.HeaderName].ToString();
        var service = context.HttpContext.RequestServices.GetRequiredService<DataAccessService>();
        if (!await service.IsTokenValidAsync(token, userId, context.HttpContext.RequestAborted)) context.Result = locked;
    }
}
