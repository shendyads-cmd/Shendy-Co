using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;
using GermanCenter.Api.Middleware;
using GermanCenter.Api.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.AspNetCore.Mvc.Infrastructure;
using Microsoft.Extensions.Options;

namespace GermanCenter.Api.Filters;

/// <summary>
/// Protects a create/transaction endpoint against being executed twice (double click, refresh, network retry, timeout + retry).
/// The browser sends an "Idempotency-Key" header, one fresh key per user intent.
///   first request            -> the key is reserved (UNIQUE index), the action runs, its result is stored
///   same key + same data     -> the action does NOT run again; the stored original result is returned
///   same key while running   -> 409 REQUEST_IN_PROGRESS
///   same key + different data-> 422 IDEMPOTENCY_KEY_REUSED
///   the action failed        -> the key is released, so the user can fix the problem and send again
/// This is NOT a business rule: two different students with the same name still get two different keys.
/// </summary>
[AttributeUsage(AttributeTargets.Method)]
public sealed class IdempotentAttribute(string operation) : ActionFilterAttribute
{
    private static readonly Regex KeyRx = new(@"^[A-Za-z0-9_\-:.]{8,100}$", RegexOptions.Compiled);
    public const string HeaderName = "Idempotency-Key";

    public override async Task OnActionExecutionAsync(ActionExecutingContext context, ActionExecutionDelegate next)
    {
        var http = context.HttpContext;
        var sp = http.RequestServices;
        var required = sp.GetRequiredService<IConfiguration>().GetValue("Idempotency:Required", true);
        var key = http.Request.Headers[HeaderName].ToString().Trim();

        if (key.Length == 0)
        {
            if (required) throw AppException.BadRequest("The request is missing its Idempotency-Key. Reload the page and try again.", "IDEMPOTENCY_KEY_REQUIRED");
            await next();
            return;
        }
        if (!KeyRx.IsMatch(key)) throw AppException.BadRequest("The Idempotency-Key is not valid.", "IDEMPOTENCY_KEY_INVALID");

        var idem = sp.GetRequiredService<IdempotencyService>();
        if (!await idem.IsAvailableAsync(http.RequestAborted))
        {
            if (required)
                throw new AppException(500, "SCHEMA_OUTDATED", "The database needs one update. Run database/Scripts/009_idempotency.sql, then restart the API.");
            await next();
            return;
        }

        var userId = int.Parse(http.User.FindFirstValue(ClaimTypes.NameIdentifier)!);
        var json = sp.GetRequiredService<IOptions<Microsoft.AspNetCore.Mvc.JsonOptions>>().Value.JsonSerializerOptions;
        var hash = HashRequest(http.Request.Method, http.Request.Path, context.ActionArguments, json);

        var reserved = await idem.ReserveAsync(userId, operation, key, hash, http.RequestAborted);
        switch (reserved.Outcome)
        {
            case ReserveOutcome.Replay:
                http.Response.Headers["Idempotent-Replayed"] = "true";
                context.Result = new ContentResult
                {
                    StatusCode = reserved.ResponseStatus ?? 200,
                    Content = reserved.ResponseBody,
                    ContentType = reserved.ResponseBody == null ? null : "application/json; charset=utf-8"
                };
                return;
            case ReserveOutcome.InProgress:
                throw AppException.Conflict("This request is already being processed. Wait a moment and check the list before trying again.", "REQUEST_IN_PROGRESS");
            case ReserveOutcome.KeyReused:
                throw new AppException(422, "IDEMPOTENCY_KEY_REUSED", "This request key was already used with different data. Reload the page and try again.");
        }

        var executed = await next();

        if (executed.Exception != null && !executed.ExceptionHandled)
        {
            await idem.ReleaseAsync(userId, operation, key);   // nothing was created: free the key; the exception continues
            return;
        }

        int status; string? body; bool success;
        switch (executed.Result)
        {
            case ObjectResult o:
                status = o.StatusCode ?? 200;
                success = status < 400;
                body = success && o.Value != null ? JsonSerializer.Serialize(o.Value, o.Value.GetType(), json) : null;
                break;
            case IStatusCodeActionResult s:
                status = s.StatusCode ?? 200;
                success = status < 400;
                body = null;
                break;
            default:
                status = 200; success = true; body = null;
                break;
        }

        if (!success) { await idem.ReleaseAsync(userId, operation, key); return; }
        try { await idem.CompleteAsync(userId, operation, key, status, body, CancellationToken.None); }
        catch (Exception ex)
        {
            // The record exists; only its stored copy is missing. A repeat gets REQUEST_IN_PROGRESS (never a duplicate).
            sp.GetRequiredService<ILogger<IdempotentAttribute>>().LogError(ex, "Idempotency result of {Operation} could not be stored.", operation);
        }
    }

    private static string HashRequest(string method, PathString path, IDictionary<string, object?> args, JsonSerializerOptions json)
    {
        var sb = new StringBuilder().Append(method).Append('|').Append(path.Value);
        foreach (var (name, value) in args.OrderBy(a => a.Key, StringComparer.Ordinal))
        {
            if (value is CancellationToken) continue;
            sb.Append('|').Append(name).Append('=');
            switch (value)
            {
                case null: sb.Append("null"); break;
                case IFormFile f: sb.Append("file:").Append(f.FileName).Append(':').Append(f.Length); break;
                case string text: sb.Append(text); break;
                default:
                    try { sb.Append(JsonSerializer.Serialize(value, value.GetType(), json)); }
                    catch { sb.Append(value); }
                    break;
            }
        }
        return Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(sb.ToString()))).ToLowerInvariant();
    }
}
