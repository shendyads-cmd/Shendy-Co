using BCrypt.Net;

namespace GermanCenter.Api.Authentication;

/// <summary>bcrypt (work factor 12). Stored in Users.password_hash.</summary>
public static class PasswordHasher
{
    // Used to keep response time similar when the username does not exist.
    private static readonly string DummyHash = BCrypt.Net.BCrypt.HashPassword("dummy-password", 12);

    public static string Hash(string password) => BCrypt.Net.BCrypt.HashPassword(password, 12);

    public static bool IsBcrypt(string? hash) =>
        !string.IsNullOrEmpty(hash) && hash.Length == 60 && hash.StartsWith("$2");

    public static bool Verify(string password, string? hash)
    {
        if (!IsBcrypt(hash)) return false;
        try { return BCrypt.Net.BCrypt.Verify(password, hash); }
        catch (SaltParseException) { return false; }
    }

    public static void BurnTime(string password) => BCrypt.Net.BCrypt.Verify(password, DummyHash);
}
