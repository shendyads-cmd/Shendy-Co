using System.Security.Claims;
using System.Text;
using GermanCenter.Api.Authentication;
using GermanCenter.Api.Data;
using GermanCenter.Api.DTOs;
using GermanCenter.Api.Middleware;
using GermanCenter.Api.Services;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;

var builder = WebApplication.CreateBuilder(args);
builder.Configuration.AddUserSecrets<Program>();
var config = builder.Configuration;

// ---- Required secrets (never hard-coded; use user-secrets or environment variables) ----
var connectionString = config.GetConnectionString("Default");
if (string.IsNullOrWhiteSpace(connectionString))
    throw new InvalidOperationException("ConnectionStrings:Default is not configured. Use user-secrets or the ConnectionStrings__Default environment variable.");

var jwt = config.GetSection("Jwt").Get<JwtOptions>() ?? new JwtOptions();
if (string.IsNullOrWhiteSpace(jwt.Key) || jwt.Key.Length < 32)
    throw new InvalidOperationException("Jwt:Key must be set to a random value of 32+ characters (user-secrets or the Jwt__Key environment variable).");

// ---- Services ----
// Snake-case naming convention matches the existing columns (user_id, password_hash, ...).
builder.Services.AddDbContext<AppDbContext>(o => o.UseSqlServer(connectionString).UseSnakeCaseNamingConvention());
builder.Services.Configure<JwtOptions>(config.GetSection("Jwt"));
builder.Services.AddScoped<TokenService>();
builder.Services.AddScoped<AuthService>();
builder.Services.AddScoped<UserService>();
builder.Services.AddScoped<SchemaChecker>();
builder.Services.AddScoped<CustomerService>();
builder.Services.AddScoped<CourseService>();
builder.Services.AddScoped<EnrollmentService>();
builder.Services.AddScoped<DataService>();
builder.Services.AddScoped<ProofStorage>();
builder.Services.AddScoped<PaymentSchemaGuard>();
builder.Services.AddScoped<InvoiceService>();
builder.Services.AddScoped<FinanceSchemaGuard>();
builder.Services.AddScoped<PaymentService>();
builder.Services.AddScoped<ExpenseService>();
builder.Services.AddScoped<PayrollService>();
builder.Services.AddScoped<AnalyticsService>();
builder.Services.AddScoped<AuditService>();
builder.Services.AddScoped<ScheduleService>();
builder.Services.AddScoped<BackupService>();
builder.Services.AddScoped<RegistrationService>();
builder.Services.AddScoped<DataExportService>();
builder.Services.AddScoped<NotificationService>();
builder.Services.AddScoped<IdempotencyService>();
builder.Services.AddScoped<DataAccessService>();

builder.Services.AddControllers(o => o.Filters.Add<GermanCenter.Api.Filters.AuditFilter>()).ConfigureApiBehaviorOptions(o =>
{
    o.InvalidModelStateResponseFactory = ctx =>
    {
        var first = ctx.ModelState.Values.SelectMany(v => v.Errors)
            .Select(e => e.ErrorMessage).FirstOrDefault(m => !string.IsNullOrWhiteSpace(m))
            ?? "The request is invalid.";
        return new BadRequestObjectResult(new ApiError("VALIDATION", first));
    };
});

builder.Services
    .AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
    .AddJwtBearer(o =>
    {
        o.TokenValidationParameters = new TokenValidationParameters
        {
            ValidateIssuer = true,
            ValidIssuer = jwt.Issuer,
            ValidateAudience = true,
            ValidAudience = jwt.Audience,
            ValidateIssuerSigningKey = true,
            IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwt.Key)),
            ValidateLifetime = true,
            ClockSkew = TimeSpan.FromMinutes(1)
        };
        o.Events = new JwtBearerEvents
        {
            // Re-check the account on every request so a disabled user or a role change
            // takes effect immediately instead of waiting for the token to expire.
            OnTokenValidated = async ctx =>
            {
                var idText = ctx.Principal?.FindFirstValue(ClaimTypes.NameIdentifier);
                if (!int.TryParse(idText, out var userId)) { ctx.Fail("Invalid token."); return; }

                var db = ctx.HttpContext.RequestServices.GetRequiredService<AppDbContext>();
                var current = await db.Users.AsNoTracking()
                    .Where(u => u.UserId == userId)
                    .Select(u => new { u.IsActive, u.Role })
                    .FirstOrDefaultAsync();

                if (current is null || !current.IsActive) { ctx.Fail("Account disabled or removed."); return; }

                if (ctx.Principal?.Identity is ClaimsIdentity identity)
                {
                    foreach (var c in identity.FindAll(ClaimTypes.Role).ToList()) identity.RemoveClaim(c);
                    identity.AddClaim(new Claim(ClaimTypes.Role, current.Role));
                }
            }
        };
    });
builder.Services.AddAuthorization();

var origins = config.GetSection("Cors:AllowedOrigins").Get<string[]>() ?? Array.Empty<string>();
builder.Services.AddCors(o => o.AddPolicy("Frontend", p => p.WithOrigins(origins).AllowAnyHeader().AllowAnyMethod()));

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new OpenApiInfo { Title = "German Language Center API", Version = "v1" });
    c.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
    {
        Name = "Authorization", Type = SecuritySchemeType.Http, Scheme = "bearer",
        BearerFormat = "JWT", In = ParameterLocation.Header
    });
    c.AddSecurityRequirement(new OpenApiSecurityRequirement
    {
        { new OpenApiSecurityScheme { Reference = new OpenApiReference { Type = ReferenceType.SecurityScheme, Id = "Bearer" } }, Array.Empty<string>() }
    });
});

// ---- Pipeline ----
var app = builder.Build();

app.UseMiddleware<ExceptionHandlingMiddleware>();
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}
else
{
    app.UseHttpsRedirection();
}
app.UseCors("Frontend");
app.UseAuthentication();
app.UseAuthorization();
app.MapControllers();

using (var scope = app.Services.CreateScope())
{
    var log = scope.ServiceProvider.GetRequiredService<ILoggerFactory>().CreateLogger("Startup");
    try { await AdminBootstrapper.RunAsync(scope.ServiceProvider); }
    catch (Exception ex)
    {
        log.LogError(ex, "Admin bootstrap failed. Check the connection string and call GET /api/system/schema-check.");
    }

    try
    {
        var report = await scope.ServiceProvider.GetRequiredService<SchemaChecker>().CheckAsync(CancellationToken.None);
        foreach (var x in report.Tables.Where(x => !x.Exists || x.MissingColumns.Count > 0))
        {
            log.LogWarning("Schema mismatch on table {Table}: exists={Exists}, missing columns: {Missing}", x.Table, x.Exists, string.Join(", ", x.MissingColumns));
            if (x.Table == "Courses" && x.MissingColumns.Contains("max_capacity"))
                log.LogError("Courses.max_capacity is missing. Run database/Scripts/003_course_capacity.sql once, then restart the API.");
            if (x.Table == "Courses" && x.MissingColumns.Contains("is_completed"))
                log.LogError("Courses.is_completed is missing. Run database/Scripts/006_course_completion.sql once, then restart the API.");
            if (x.Table == "Customers" && x.MissingColumns.Contains("area"))
                log.LogError("Customers.area is missing. Run database/Scripts/007_new_student_payments.sql once, then restart the API.");
            if (x.MissingColumns.Contains("is_deleted"))
                log.LogError("{Table}.is_deleted is missing. Run database/Scripts/004_soft_delete.sql once, then restart the API.", x.Table);
        }
        if (report.Ok) log.LogInformation("Schema check passed for all mapped tables.");
        var present = await scope.ServiceProvider.GetRequiredService<AppDbContext>().Database
            .SqlQueryRaw<string>("SELECT name AS [Value] FROM sys.tables WHERE schema_id = SCHEMA_ID('dbo') AND name IN ('Notifications', 'NotificationReads', 'IdempotencyKeys', 'SystemSettings', 'AuditLogs', 'ScheduleEntries', 'InvoiceNumberCounters')").ToListAsync();
        foreach (var needed in new[] { "AuditLogs", "ScheduleEntries", "InvoiceNumberCounters" })
            if (!present.Contains(needed))
                log.LogError("{Table} is missing. Run database/Scripts/013_system_features.sql once, then restart the API (invoices cannot be saved until InvoiceNumberCounters exists).", needed);
        if (!present.Contains("SystemSettings"))
            log.LogError("SystemSettings is missing. Run database/Scripts/011_system_settings.sql once, then restart the API. Staff cannot open Data until then.");
        else
        {
            try { await scope.ServiceProvider.GetRequiredService<DataAccessService>().EnsureFromConfigAsync(CancellationToken.None); }
            catch (Exception ex) { log.LogError(ex, "The initial Data password could not be stored."); }
        }
        var codeFormat = await scope.ServiceProvider.GetRequiredService<AppDbContext>().Database
            .SqlQueryRaw<int>("SELECT COUNT(*) AS [Value] FROM dbo.Courses WHERE course_code NOT LIKE 'A-%'").SingleAsync();
        if (codeFormat > 0)
            log.LogWarning("{Count} course code(s) are still in the old format (A001). Run database/Scripts/010_course_code_format.sql once to convert them to A-001.", codeFormat);
        if (!present.Contains("Notifications") || !present.Contains("NotificationReads"))
            log.LogError("Notification tables are missing. Run database/Scripts/008_notifications.sql once, then restart the API.");
        if (!present.Contains("IdempotencyKeys"))
            log.LogError("IdempotencyKeys is missing. Run database/Scripts/009_idempotency.sql once, then restart the API. Create requests are refused until then.");
        else await scope.ServiceProvider.GetRequiredService<IdempotencyService>().PurgeAsync(CancellationToken.None);
        try { await scope.ServiceProvider.GetRequiredService<FinanceSchemaGuard>().EnsureAsync(CancellationToken.None); log.LogInformation("Expenses, payroll and cash tables are ready."); }
        catch (Exception ex) { log.LogWarning("Step 3 tables are not ready: {Message}", ex.Message); }
        try { await scope.ServiceProvider.GetRequiredService<PaymentSchemaGuard>().EnsureAsync(CancellationToken.None); log.LogInformation("Invoicing tables are ready for New Student registrations."); }
        catch (AppException ex) { log.LogError("{Message}", ex.Message); }
    }
    catch (Exception ex) { log.LogWarning(ex, "Schema check could not run."); }
}

app.Run();
