using GermanCenter.Api.Models;
using Microsoft.EntityFrameworkCore;

namespace GermanCenter.Api.Data;

public class AppDbContext(DbContextOptions<AppDbContext> options) : DbContext(options)
{
    public DbSet<User> Users => Set<User>();

    public DbSet<Customer> Customers => Set<Customer>();

    public DbSet<Course> Courses => Set<Course>();

    public DbSet<Enrollment> Enrollments => Set<Enrollment>();

    // Phase 3+: Invoices, InvoiceCustomers, InvoiceDetails,
    // Payments, PaymentGuarantees, Expenses, Transactions.

    protected override void OnModelCreating(ModelBuilder modelBuilder)
        => modelBuilder.ApplyConfigurationsFromAssembly(typeof(AppDbContext).Assembly);
}