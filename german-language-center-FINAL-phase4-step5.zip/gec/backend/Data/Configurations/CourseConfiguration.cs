using GermanCenter.Api.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace GermanCenter.Api.Data.Configurations;

public class CourseConfiguration : IEntityTypeConfiguration<Course>
{
    public void Configure(EntityTypeBuilder<Course> b)
    {
        b.ToTable("Courses");
        b.HasKey(x => x.CourseId);
        b.Property(x => x.CourseCode).HasMaxLength(30).IsRequired();
        b.Property(x => x.CourseName).HasMaxLength(150).IsRequired();
        b.Property(x => x.Price).HasPrecision(18, 2);
        b.Property(x => x.MaxCapacity).IsRequired();
        b.Property(x => x.DeletionReason).HasMaxLength(500);
    }
}
