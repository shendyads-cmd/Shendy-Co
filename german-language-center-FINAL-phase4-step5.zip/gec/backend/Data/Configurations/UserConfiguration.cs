using GermanCenter.Api.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace GermanCenter.Api.Data.Configurations;

// Every table mapping lives in its own configuration class. If a column name differs
// from the convention, fix it here with .HasColumnName("...") and nowhere else.
public class UserConfiguration : IEntityTypeConfiguration<User>
{
    public void Configure(EntityTypeBuilder<User> b)
    {
        b.ToTable("Users");
        b.HasKey(x => x.UserId);
        b.Property(x => x.Username).HasMaxLength(100).IsRequired();
        b.Property(x => x.PasswordHash).HasMaxLength(255).IsRequired();
        b.Property(x => x.FullName).HasMaxLength(150);
        b.Property(x => x.Role).HasMaxLength(30).IsRequired();
        b.Property(x => x.CreatedAt).HasDefaultValueSql("GETDATE()");
        b.HasIndex(x => x.Username).IsUnique();
    }
}
