using GermanCenter.Api.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace GermanCenter.Api.Data.Configurations;

public class EnrollmentConfiguration : IEntityTypeConfiguration<Enrollment>
{
    public void Configure(EntityTypeBuilder<Enrollment> b)
    {
        b.ToTable("Enrollments");
        b.HasKey(x => x.EnrollmentId);
        b.Property(x => x.TotalAmount).HasPrecision(18, 2);
        b.Property(x => x.Status).HasMaxLength(30).IsRequired();

        // Restrict: the application never cascades deletes into business records.
        b.HasOne(x => x.Customer).WithMany(c => c.Enrollments)
            .HasForeignKey(x => x.CustomerId).OnDelete(DeleteBehavior.Restrict);
        b.HasOne(x => x.Course).WithMany(c => c.Enrollments)
            .HasForeignKey(x => x.CourseId).OnDelete(DeleteBehavior.Restrict);
    }
}
