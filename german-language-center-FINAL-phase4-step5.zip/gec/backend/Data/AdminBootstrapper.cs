using GermanCenter.Api.Authentication;
using GermanCenter.Api.Models;
using Microsoft.EntityFrameworkCore;

namespace GermanCenter.Api.Data;

/// <summary>
/// Creates or resets the first administrator using Bootstrap:AdminPassword.
/// Runs only when Bootstrap:AdminPassword is configured.
/// </summary>
public static class AdminBootstrapper
{
    public static async Task RunAsync(IServiceProvider sp)
    {
        var config = sp.GetRequiredService<IConfiguration>();
        var log = sp.GetRequiredService<ILoggerFactory>()
            .CreateLogger("AdminBootstrap");

        var db = sp.GetRequiredService<AppDbContext>();

        // Read bootstrap password from User Secrets / Environment Variables
        var password = config["Bootstrap:AdminPassword"];

        if (string.IsNullOrWhiteSpace(password))
        {
            return;
        }

        if (password.Length < 8)
        {
            log.LogError(
                "Bootstrap:AdminPassword must be at least 8 characters."
            );

            return;
        }

        // Default username = admin
        var username = (config["Bootstrap:AdminUsername"] ?? "admin").Trim();

        // Find the admin user
        var user = await db.Users
            .FirstOrDefaultAsync(u => u.Username == username);

        // ---------------------------------------------------------
        // USER DOES NOT EXIST
        // ---------------------------------------------------------
        if (user is null)
        {
            db.Users.Add(new User
            {
                Username = username,
                PasswordHash = PasswordHasher.Hash(password),
                FullName = "Administrator",
                Role = Roles.Admin,
                IsActive = true
            });

            await db.SaveChangesAsync();

            log.LogWarning(
                "Administrator '{Username}' created. Remove Bootstrap:AdminPassword after first login.",
                username
            );

            return;
        }

        // ---------------------------------------------------------
        // USER ALREADY EXISTS
        // Reset password temporarily for testing
        // ---------------------------------------------------------
        user.PasswordHash = PasswordHasher.Hash(password);
        user.IsActive = true;

        await db.SaveChangesAsync();

        log.LogWarning(
            "Password for '{Username}' reset with bcrypt. Remove Bootstrap:AdminPassword after first login.",
            username
        );
    }
}