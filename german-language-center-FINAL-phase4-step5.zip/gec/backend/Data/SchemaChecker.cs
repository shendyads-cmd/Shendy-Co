using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace GermanCenter.Api.Data;

public record TableCheck(string Table, bool Exists, List<string> MissingColumns, List<string> ActualColumns);
public record SchemaReport(bool Ok, List<TableCheck> Tables, List<string> UnmappedTables);

/// <summary>
/// Compares the EF model against the real SQL Server schema (read-only; never changes the database).
/// </summary>
public class SchemaChecker(AppDbContext db)
{
    public async Task<SchemaReport> CheckAsync(CancellationToken ct)
    {
        var actual = new Dictionary<string, HashSet<string>>(StringComparer.OrdinalIgnoreCase);

        await db.Database.OpenConnectionAsync(ct);
        try
        {
            using var cmd = db.Database.GetDbConnection().CreateCommand();
            cmd.CommandText = "SELECT TABLE_NAME, COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS";
            using var reader = await cmd.ExecuteReaderAsync(ct);
            while (await reader.ReadAsync(ct))
            {
                var table = reader.GetString(0);
                if (!actual.TryGetValue(table, out var set))
                    actual[table] = set = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
                set.Add(reader.GetString(1));
            }
        }
        finally { await db.Database.CloseConnectionAsync(); }

        var tables = new List<TableCheck>();
        foreach (var entity in db.Model.GetEntityTypes())
        {
            var name = entity.GetTableName()!;
            var id = StoreObjectIdentifier.Table(name, entity.GetSchema());
            var expected = entity.GetProperties()
                .Select(p => p.GetColumnName(id)).Where(c => c != null).Select(c => c!).ToList();

            if (!actual.TryGetValue(name, out var columns)) { tables.Add(new TableCheck(name, false, expected, new List<string>())); continue; }
            tables.Add(new TableCheck(name, true, expected.Where(c => !columns.Contains(c)).ToList(), columns.OrderBy(c => c).ToList()));
        }

        var mapped = tables.Select(t => t.Table).ToHashSet(StringComparer.OrdinalIgnoreCase);
        var unmapped = actual.Keys.Where(k => !mapped.Contains(k)).OrderBy(k => k).ToList();
        return new SchemaReport(tables.All(t => t.Exists && t.MissingColumns.Count == 0), tables, unmapped);
    }
}
