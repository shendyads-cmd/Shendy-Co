using GermanCenter.Api.Middleware;

namespace GermanCenter.Api.Services;

/// <summary>
/// Stores optional payment proofs (JPG / JPEG / PNG / PDF) as files on disk. The database only keeps the metadata
/// (Payments.proof_file_name / proof_stored_name / proof_content_type). Folder: Storage:PaymentProofs or App_Data/payment-proofs.
/// </summary>
public class ProofStorage(IWebHostEnvironment env, IConfiguration config, ILogger<ProofStorage> log)
{
    public const long MaxBytes = 5 * 1024 * 1024;

    private static readonly Dictionary<string, string> ContentTypes = new(StringComparer.OrdinalIgnoreCase)
    {
        [".jpg"] = "image/jpeg", [".jpeg"] = "image/jpeg", [".png"] = "image/png", [".pdf"] = "application/pdf"
    };

    public sealed record SavedProof(string OriginalName, string StoredName, string ContentType);

    private string Root => !string.IsNullOrWhiteSpace(config["Storage:PaymentProofs"])
        ? Path.GetFullPath(config["Storage:PaymentProofs"]!)
        : Path.Combine(env.ContentRootPath, "App_Data", "payment-proofs");

    public async Task<SavedProof> SaveAsync(IFormFile file, CancellationToken ct)
    {
        if (file.Length == 0) throw AppException.BadRequest("The payment proof file is empty.", "PROOF_EMPTY");
        if (file.Length > MaxBytes) throw AppException.BadRequest("The payment proof is too large (maximum 5 MB).", "PROOF_TOO_LARGE");

        var extension = Path.GetExtension(file.FileName);
        if (!ContentTypes.TryGetValue(extension, out var contentType))
            throw AppException.BadRequest("The payment proof must be a JPG, JPEG, PNG or PDF file.", "PROOF_TYPE");

        // The extension alone is not trusted: the first bytes must match the declared type.
        var header = new byte[8];
        int read;
        await using (var probe = file.OpenReadStream()) read = await probe.ReadAsync(header.AsMemory(0, 8), ct);
        if (!SignatureMatches(extension.ToLowerInvariant(), header, read))
            throw AppException.BadRequest("The payment proof file is not a valid image or PDF.", "PROOF_TYPE");

        Directory.CreateDirectory(Root);
        var storedName = Guid.NewGuid().ToString("N") + extension.ToLowerInvariant();
        await using (var target = File.Create(Path.Combine(Root, storedName)))
        await using (var source = file.OpenReadStream())
            await source.CopyToAsync(target, ct);

        var original = new string(Path.GetFileName(file.FileName).Where(ch => !char.IsControl(ch)).ToArray());
        if (original.Length > 200) original = original[^200..];
        return new SavedProof(original, storedName, contentType);
    }

    public FileStream? Open(string storedName)
    {
        if (!IsSafeName(storedName)) return null;
        var path = Path.Combine(Root, storedName);
        return File.Exists(path) ? new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read) : null;
    }

    public void Delete(string? storedName)
    {
        if (string.IsNullOrEmpty(storedName) || !IsSafeName(storedName)) return;
        try { File.Delete(Path.Combine(Root, storedName)); }
        catch (Exception ex) { log.LogWarning(ex, "Could not delete payment proof file {File}.", storedName); }
    }

    private static bool IsSafeName(string name)
        => System.Text.RegularExpressions.Regex.IsMatch(name, @"^[0-9a-f]{32}\.(jpg|jpeg|png|pdf)$");

    private static bool SignatureMatches(string extension, byte[] h, int n) => extension switch
    {
        ".jpg" or ".jpeg" => n >= 3 && h[0] == 0xFF && h[1] == 0xD8 && h[2] == 0xFF,
        ".png" => n >= 4 && h[0] == 0x89 && h[1] == 0x50 && h[2] == 0x4E && h[3] == 0x47,
        ".pdf" => n >= 4 && h[0] == 0x25 && h[1] == 0x50 && h[2] == 0x44 && h[3] == 0x46,
        _ => false
    };
}
