using GermanCenter.Api.Authentication;
using GermanCenter.Api.Data;
using GermanCenter.Api.DTOs;
using GermanCenter.Api.Models;
using Microsoft.EntityFrameworkCore;

namespace GermanCenter.Api.Services;

public enum LoginStatus { Success, InvalidCredentials, AccountDisabled }
public record LoginResult(LoginStatus Status, LoginResponse? Response = null);

public class AuthService(AppDbContext db, TokenService tokens)
{
    public async Task<LoginResult> LoginAsync(LoginRequest request, CancellationToken ct)
    {
        var username = request.Username.Trim();
        var user = await db.Users.AsNoTracking().FirstOrDefaultAsync(u => u.Username == username, ct);

        if (user is null)
        {
            PasswordHasher.BurnTime(request.Password);
            return new LoginResult(LoginStatus.InvalidCredentials);
        }
        if (!PasswordHasher.Verify(request.Password, user.PasswordHash))
            return new LoginResult(LoginStatus.InvalidCredentials);

        // Only reveal "disabled" after the password was correct, so it cannot be used to probe usernames.
        if (!user.IsActive) return new LoginResult(LoginStatus.AccountDisabled);

        var (token, expires) = tokens.Create(user);
        return new LoginResult(LoginStatus.Success, new LoginResponse(token, expires, ToDto(user)));
    }

    public static UserDto ToDto(User u) => new(u.UserId, u.Username, u.FullName, u.Role, u.IsActive, u.CreatedAt);
}
