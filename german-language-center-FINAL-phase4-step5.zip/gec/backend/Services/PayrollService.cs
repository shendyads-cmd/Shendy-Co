using GermanCenter.Api.Data;
using GermanCenter.Api.DTOs;
using GermanCenter.Api.Middleware;
using GermanCenter.Api.Utilities;
using Microsoft.EntityFrameworkCore;

namespace GermanCenter.Api.Services;

/// <summary>
/// Payroll: employees, monthly salary entries and paying them.
///   Net salary = Base salary + Bonus - Deductions (calculated here and protected by a CHECK constraint in the database; never sent by the browser).
///   One entry per employee and month (UX_PayrollEntries_employee_period).
///   Pay: Pending -> Paid and the Cash Out (Transactions EXPENSE, related_payroll_id) are written in ONE transaction.
///   The entry row is locked and UX_Transactions_payroll allows one Cash Out per entry, so a salary can never be paid or booked twice.
/// </summary>
public class PayrollService(AppDbContext db, FinanceSchemaGuard guard, NotificationService notifications)
{
    private const decimal MaxAmount = 99_999_999.99m;
    private static readonly System.Text.RegularExpressions.Regex PhoneRx = new(@"^[0-9+()\-\s]{6,30}$", System.Text.RegularExpressions.RegexOptions.Compiled);

    public static decimal Net(decimal baseSalary, decimal bonus, decimal deductions) => baseSalary + bonus - deductions;

    private static decimal Money(decimal value, string field)
    {
        if (value < 0) throw AppException.BadRequest($"{field} cannot be negative.", "AMOUNT");
        var v = Math.Round(value, 2, MidpointRounding.AwayFromZero);
        if (v > MaxAmount) throw AppException.BadRequest($"{field} is too large.", "AMOUNT");
        return v;
    }

    // ------------------------------------------------------------------ employees

    public async Task<PagedResult<PayrollEmployeeDto>> ListEmployeesAsync(PayrollEmployeeQuery q, CancellationToken ct)
    {
        await guard.EnsureAsync(ct);
        var clauses = new List<string>();
        var args = new List<(string, object?)>();
        if (!string.IsNullOrWhiteSpace(q.Search))
        {
            clauses.Add(@"(full_name LIKE @like ESCAPE '\' OR job_title LIKE @like ESCAPE '\' OR phone LIKE @like ESCAPE '\')");
            args.Add(("@like", SqlText.LikePattern(q.Search)));
        }
        if (q.IsActive.HasValue) { clauses.Add("is_active = @active"); args.Add(("@active", q.IsActive.Value)); }
        var filter = clauses.Count > 0 ? "WHERE " + string.Join(" AND ", clauses) : "";

        var total = await db.ScalarAsync<int>($"SELECT COUNT(*) FROM PayrollEmployees {filter}", ct, args.ToArray());
        args.Add(("@skip", q.Skip)); args.Add(("@take", q.Take));
        var items = await db.QueryAsync(
            $@"SELECT employee_id, full_name, job_title, phone, base_salary, is_active FROM PayrollEmployees {filter}
               ORDER BY is_active DESC, full_name, employee_id OFFSET @skip ROWS FETCH NEXT @take ROWS ONLY",
            r => new PayrollEmployeeDto(r.GetInt32(0), r.GetString(1), r.GetStringOrNull(2), r.GetStringOrNull(3), r.GetDecimal(4), r.GetBoolean(5)),
            ct, args.ToArray());
        return new PagedResult<PayrollEmployeeDto>(items, total, q.PageNumber, q.Take);
    }

    private async Task<(string Name, string? Title, string? Phone, decimal Salary)> ValidateEmployeeAsync(PayrollEmployeeRequest r, CancellationToken ct)
    {
        await guard.EnsureAsync(ct);
        var name = r.FullName?.Trim() ?? "";
        if (name.Length < 2 || name.Length > 150) throw AppException.BadRequest("Enter the employee's full name (2-150 characters).", "FULL_NAME");
        var title = r.JobTitle.NullIfBlank();
        if (title != null && title.Length > 100) throw AppException.BadRequest("The job title is too long.", "JOB_TITLE");
        var phone = r.Phone.NullIfBlank();
        if (phone != null && !PhoneRx.IsMatch(phone)) throw AppException.BadRequest("Enter a valid phone number.", "PHONE");
        return (name, title, phone, Money(r.BaseSalary, "The base salary"));
    }

    public async Task<PayrollEmployeeDto> CreateEmployeeAsync(PayrollEmployeeRequest r, int userId, CancellationToken ct)
    {
        var v = await ValidateEmployeeAsync(r, ct);
        await using var tx = await db.Database.BeginTransactionAsync(ct);
        var same = await db.ScalarAsync<int>("SELECT COUNT(*) FROM PayrollEmployees WITH (UPDLOCK, HOLDLOCK) WHERE full_name = @n AND ISNULL(phone, '') = ISNULL(@p, '')", ct, ("@n", v.Name), ("@p", v.Phone));
        if (same > 0) throw AppException.Conflict("An employee with this name and phone already exists.", "EMPLOYEE_EXISTS");
        var id = await db.InsertAsync(
            @"INSERT INTO PayrollEmployees (full_name, job_title, phone, base_salary, is_active, created_by) VALUES (@n, @t, @p, @s, @a, @u);
              SELECT CAST(SCOPE_IDENTITY() AS int);", ct,
            ("@n", v.Name), ("@t", v.Title), ("@p", v.Phone), ("@s", v.Salary), ("@a", r.IsActive), ("@u", userId));
        await tx.CommitAsync(ct);
        return new PayrollEmployeeDto(id, v.Name, v.Title, v.Phone, v.Salary, r.IsActive);
    }

    public async Task<PayrollEmployeeDto> UpdateEmployeeAsync(int id, PayrollEmployeeRequest r, CancellationToken ct)
    {
        var v = await ValidateEmployeeAsync(r, ct);
        await using var tx = await db.Database.BeginTransactionAsync(ct);
        var same = await db.ScalarAsync<int>("SELECT COUNT(*) FROM PayrollEmployees WITH (UPDLOCK, HOLDLOCK) WHERE full_name = @n AND ISNULL(phone, '') = ISNULL(@p, '') AND employee_id <> @id", ct,
            ("@n", v.Name), ("@p", v.Phone), ("@id", id));
        if (same > 0) throw AppException.Conflict("An employee with this name and phone already exists.", "EMPLOYEE_EXISTS");
        // changing the base salary or deactivating never touches entries that already exist
        var n = await db.ExecuteAsync("UPDATE PayrollEmployees SET full_name = @n, job_title = @t, phone = @p, base_salary = @s, is_active = @a WHERE employee_id = @id", ct,
            ("@n", v.Name), ("@t", v.Title), ("@p", v.Phone), ("@s", v.Salary), ("@a", r.IsActive), ("@id", id));
        if (n == 0) throw AppException.NotFound("Employee not found.");
        await tx.CommitAsync(ct);
        return new PayrollEmployeeDto(id, v.Name, v.Title, v.Phone, v.Salary, r.IsActive);
    }

    // ------------------------------------------------------------------ entries: list

    public async Task<PayrollPageDto> ListAsync(PayrollQuery q, CancellationToken ct)
    {
        await guard.EnsureAsync(ct);
        if (q.Month.HasValue && (q.Month < 1 || q.Month > 12)) throw AppException.BadRequest("The month must be between 1 and 12.", "MONTH");
        if (q.Status != null && q.Status != "Pending" && q.Status != "Paid") throw AppException.BadRequest("The status must be Pending or Paid.", "STATUS");

        var clauses = new List<string>();
        var args = new List<(string, object?)>();
        if (!string.IsNullOrWhiteSpace(q.Search)) { clauses.Add(@"e.full_name LIKE @like ESCAPE '\'"); args.Add(("@like", SqlText.LikePattern(q.Search))); }
        if (q.Year.HasValue) { clauses.Add("p.period_year = @year"); args.Add(("@year", q.Year.Value)); }
        if (q.Month.HasValue) { clauses.Add("p.period_month = @month"); args.Add(("@month", q.Month.Value)); }
        if (q.Status != null) { clauses.Add("p.status = @status"); args.Add(("@status", q.Status)); }
        if (q.EmployeeId.HasValue) { clauses.Add("p.employee_id = @emp"); args.Add(("@emp", q.EmployeeId.Value)); }
        var filter = clauses.Count > 0 ? "WHERE " + string.Join(" AND ", clauses) : "";

        var totals = await db.QueryAsync(
            $@"SELECT COUNT(*), ISNULL(SUM(p.net_salary), 0),
                      ISNULL(SUM(CASE WHEN p.status = 'Paid' THEN p.net_salary END), 0),
                      ISNULL(SUM(CASE WHEN p.status = 'Pending' THEN p.net_salary END), 0)
               FROM PayrollEntries p JOIN PayrollEmployees e ON e.employee_id = p.employee_id {filter}",
            r => (Count: r.GetInt32(0), Net: r.GetDecimal(1), Paid: r.GetDecimal(2), Pending: r.GetDecimal(3)), ct, args.ToArray());

        args.Add(("@skip", q.Skip)); args.Add(("@take", q.Take));
        var items = await db.QueryAsync(
            $@"SELECT p.payroll_id, p.employee_id, e.full_name, p.period_year, p.period_month, p.base_salary, p.bonus, p.deductions, p.net_salary, p.status, p.notes, p.paid_at
               FROM PayrollEntries p JOIN PayrollEmployees e ON e.employee_id = p.employee_id {filter}
               ORDER BY p.period_year DESC, p.period_month DESC, e.full_name, p.payroll_id DESC
               OFFSET @skip ROWS FETCH NEXT @take ROWS ONLY",
            MapEntry, ct, args.ToArray());
        return new PayrollPageDto(items, totals[0].Count, q.PageNumber, q.Take, totals[0].Net, totals[0].Paid, totals[0].Pending);
    }

    private static PayrollEntryDto MapEntry(System.Data.Common.DbDataReader r)
        => new(r.GetInt32(0), r.GetInt32(1), r.GetString(2), r.GetInt16(3), r.GetByte(4), r.GetDecimal(5), r.GetDecimal(6), r.GetDecimal(7), r.GetDecimal(8),
            r.GetString(9), r.GetStringOrNull(10), r.GetDateTimeOrNull(11));

    private async Task<PayrollEntryDto> GetAsync(int id, CancellationToken ct)
    {
        var rows = await db.QueryAsync(
            @"SELECT p.payroll_id, p.employee_id, e.full_name, p.period_year, p.period_month, p.base_salary, p.bonus, p.deductions, p.net_salary, p.status, p.notes, p.paid_at
              FROM PayrollEntries p JOIN PayrollEmployees e ON e.employee_id = p.employee_id WHERE p.payroll_id = @id", MapEntry, ct, ("@id", id));
        return rows.Count > 0 ? rows[0] : throw AppException.NotFound("Payroll entry not found.");
    }

    // ------------------------------------------------------------------ entries: create / edit / delete (Pending only)

    private static (decimal Base, decimal Bonus, decimal Deductions, decimal Net, string? Notes) ValidateAmounts(PayrollRequest r)
    {
        var b = Money(r.BaseSalary, "The base salary");
        var bonus = Money(r.Bonus, "The bonus");
        var ded = Money(r.Deductions, "The deductions");
        if (ded > b + bonus) throw AppException.BadRequest("The deductions cannot be more than the base salary plus the bonus.", "DEDUCTIONS");
        var notes = r.Notes.NullIfBlank();
        if (notes != null && notes.Length > 300) throw AppException.BadRequest("The notes are too long (maximum 300 characters).", "NOTES");
        return (b, bonus, ded, Net(b, bonus, ded), notes);
    }

    public async Task<PayrollEntryDto> CreateAsync(PayrollRequest r, int userId, CancellationToken ct)
    {
        await guard.EnsureAsync(ct);
        var today = DateTime.Today;
        if (r.Year < 2000 || r.Year > today.Year || r.Month < 1 || r.Month > 12) throw AppException.BadRequest("Choose a valid month.", "PERIOD");
        if (r.Year == today.Year && r.Month > today.Month) throw AppException.BadRequest("The salary month cannot be in the future.", "PERIOD");
        var v = ValidateAmounts(r);

        await using var tx = await db.Database.BeginTransactionAsync(ct);
        var emp = await db.QueryAsync("SELECT is_active FROM PayrollEmployees WITH (UPDLOCK, ROWLOCK) WHERE employee_id = @id", x => x.GetBoolean(0), ct, ("@id", r.EmployeeId));
        if (emp.Count == 0) throw AppException.BadRequest("Choose an employee.", "EMPLOYEE");
        if (!emp[0]) throw AppException.BadRequest("This employee is inactive.", "EMPLOYEE_INACTIVE");
        var exists = await db.ScalarAsync<int>("SELECT COUNT(*) FROM PayrollEntries WHERE employee_id = @e AND period_year = @y AND period_month = @m", ct,
            ("@e", r.EmployeeId), ("@y", r.Year), ("@m", r.Month));
        if (exists > 0) throw AppException.Conflict("A salary entry for this employee and month already exists.", "PAYROLL_EXISTS");

        int id;
        try
        {
            id = await db.InsertAsync(
                @"INSERT INTO PayrollEntries (employee_id, period_year, period_month, base_salary, bonus, deductions, net_salary, status, notes, created_by)
                  VALUES (@e, @y, @m, @b, @bonus, @d, @net, 'Pending', @notes, @u);
                  SELECT CAST(SCOPE_IDENTITY() AS int);", ct,
                ("@e", r.EmployeeId), ("@y", r.Year), ("@m", r.Month), ("@b", v.Base), ("@bonus", v.Bonus), ("@d", v.Deductions), ("@net", v.Net), ("@notes", v.Notes), ("@u", userId));
        }
        catch (Exception ex) when (SqlErrors.IsUniqueViolation(ex))
        {
            throw AppException.Conflict("A salary entry for this employee and month already exists.", "PAYROLL_EXISTS");
        }
        await tx.CommitAsync(ct);
        return await GetAsync(id, ct);
    }

    public async Task<PayrollEntryDto> UpdateAsync(int id, PayrollRequest r, CancellationToken ct)
    {
        await guard.EnsureAsync(ct);
        var v = ValidateAmounts(r);
        await using var tx = await db.Database.BeginTransactionAsync(ct);
        var head = await db.QueryAsync("SELECT status FROM PayrollEntries WITH (UPDLOCK, ROWLOCK) WHERE payroll_id = @id", x => x.GetString(0), ct, ("@id", id));
        if (head.Count == 0) throw AppException.NotFound("Payroll entry not found.");
        if (head[0] != "Pending") throw AppException.Conflict("A paid salary cannot be edited.", "PAYROLL_PAID");
        // employee and month are fixed once the entry exists; only the amounts and the notes change
        await db.ExecuteAsync(
            "UPDATE PayrollEntries SET base_salary = @b, bonus = @bonus, deductions = @d, net_salary = @net, notes = @notes, updated_at = SYSDATETIME() WHERE payroll_id = @id", ct,
            ("@b", v.Base), ("@bonus", v.Bonus), ("@d", v.Deductions), ("@net", v.Net), ("@notes", v.Notes), ("@id", id));
        await tx.CommitAsync(ct);
        return await GetAsync(id, ct);
    }

    /// <summary>Only an entry that was never paid can be deleted. A paid salary is history and stays.</summary>
    public async Task DeleteAsync(int id, CancellationToken ct)
    {
        await guard.EnsureAsync(ct);
        await using var tx = await db.Database.BeginTransactionAsync(ct);
        var head = await db.QueryAsync("SELECT status FROM PayrollEntries WITH (UPDLOCK, ROWLOCK) WHERE payroll_id = @id", x => x.GetString(0), ct, ("@id", id));
        if (head.Count == 0) throw AppException.NotFound("Payroll entry not found.");
        if (head[0] != "Pending") throw AppException.Conflict("A paid salary cannot be deleted.", "PAYROLL_PAID");
        await db.ExecuteAsync("DELETE FROM PayrollEntries WHERE payroll_id = @id AND status = 'Pending'", ct, ("@id", id));
        await tx.CommitAsync(ct);
    }

    // ------------------------------------------------------------------ pay

    public async Task<PayrollEntryDto> PayAsync(int id, int userId, CancellationToken ct)
    {
        await guard.EnsureAsync(ct);
        await using var tx = await db.Database.BeginTransactionAsync(ct);

        var rows = await db.QueryAsync(
            @"SELECT p.status, p.net_salary, e.full_name, p.period_year, p.period_month
              FROM PayrollEntries p WITH (UPDLOCK, ROWLOCK) JOIN PayrollEmployees e ON e.employee_id = p.employee_id WHERE p.payroll_id = @id",
            x => (Status: x.GetString(0), Net: x.GetDecimal(1), Name: x.GetString(2), Year: (int)x.GetInt16(3), Month: (int)x.GetByte(4)), ct, ("@id", id));
        if (rows.Count == 0) throw AppException.NotFound("Payroll entry not found.");
        var p = rows[0];
        if (p.Status == "Paid") throw AppException.Conflict("This salary was already paid.", "PAYROLL_PAID");
        if (p.Net <= 0) throw AppException.BadRequest("The net salary must be greater than zero to pay it.", "NET_ZERO");

        var changed = await db.ExecuteAsync("UPDATE PayrollEntries SET status = 'Paid', paid_at = SYSDATETIME(), paid_by = @u, updated_at = SYSDATETIME() WHERE payroll_id = @id AND status = 'Pending'", ct,
            ("@u", userId), ("@id", id));
        if (changed != 1) throw AppException.Conflict("This salary was already paid.", "PAYROLL_PAID");

        try
        {
            // Cash Out
            await db.ExecuteAsync("INSERT INTO Transactions (transaction_type, amount, related_payment_id, related_expense_id, related_payroll_id, transaction_date) VALUES ('EXPENSE', @a, NULL, NULL, @p, SYSDATETIME())", ct,
                ("@a", p.Net), ("@p", id));
        }
        catch (Exception ex) when (SqlErrors.IsUniqueViolation(ex))
        {
            throw AppException.Conflict("This salary was already paid.", "PAYROLL_PAID");
        }

        await notifications.NotifyPayrollPaidAsync(id, p.Name, p.Net, p.Year, p.Month, ct);
        await tx.CommitAsync(ct);
        return await GetAsync(id, ct);
    }
}
