using GermanCenter.Api.Data;
using GermanCenter.Api.Middleware;
using GermanCenter.Api.Utilities;

namespace GermanCenter.Api.Services;

/// <summary>
/// The invoicing tables are written with explicit SQL, so before the first registration this checks them against the
/// real database: the columns the code uses must exist, and no OTHER required column (NOT NULL, no default, not an identity)
/// may exist that the code does not fill. In that case the operation stops with a clear message instead of guessing a value.
/// </summary>
public class PaymentSchemaGuard(AppDbContext db)
{
    private static volatile bool _verified;
    private static readonly Dictionary<string, bool> ComputedCache = new();

    // Columns the code reads or writes (names verified against the real database).
    private static readonly Dictionary<string, string[]> Used = new()
    {
        ["Customers"] = new[] { "area" },
        ["Invoices"] = new[] { "invoice_id", "invoice_number", "issue_date", "subtotal", "discount_percent", "discount_amount", "total_amount", "status", "created_by", "due_date", "discount", "tax" },
        ["InvoiceCustomers"] = new[] { "invoice_customer_id", "invoice_id", "customer_id" },
        ["InvoiceDetails"] = new[] { "invoice_detail_id", "invoice_id", "course_id", "quantity", "unit_price", "subtotal" },
        ["Payments"] = new[] { "payment_id", "payment_date", "amount", "payment_method", "user_id", "reference", "payment_method_other", "proof_file_name", "proof_stored_name", "proof_content_type" },
        ["PaymentAllocations"] = new[] { "payment_id", "invoice_id", "allocated_amount" },
        ["PaymentGuarantees"] = new[] { "guarantee_id", "invoice_id", "payment_id" },
        ["Transactions"] = new[] { "transaction_id", "transaction_type", "amount", "related_payment_id", "related_expense_id", "transaction_date" }
    };

    // Columns the registration INSERT statements fill. Anything else that is required would make an INSERT fail.
    private static readonly Dictionary<string, string[]> Filled = new()
    {
        ["Invoices"] = new[] { "invoice_number", "issue_date", "subtotal", "discount_percent", "discount_amount", "total_amount", "status", "created_by", "due_date", "discount", "tax" },
        ["InvoiceCustomers"] = new[] { "invoice_id", "customer_id" },
        ["InvoiceDetails"] = new[] { "invoice_id", "course_id", "quantity", "unit_price", "subtotal" },
        ["Payments"] = new[] { "payment_date", "amount", "payment_method", "user_id", "reference", "payment_method_other", "proof_file_name", "proof_stored_name", "proof_content_type" },
        ["PaymentAllocations"] = new[] { "payment_id", "invoice_id", "allocated_amount" },
        ["Transactions"] = new[] { "transaction_type", "amount", "related_payment_id", "related_expense_id", "transaction_date" }
    };

    private sealed record Col(string Table, string Name, bool Nullable, bool Identity, bool Computed, bool HasDefault, string Type);

    public async Task EnsureAsync(CancellationToken ct)
    {
        if (_verified) return;

        var tableList = string.Join(", ", Used.Keys.Select(t => $"'{t}'"));
        var cols = await db.QueryAsync(
            $@"SELECT t.name, c.name, c.is_nullable, c.is_identity, c.is_computed,
                      CASE WHEN c.default_object_id <> 0 THEN 1 ELSE 0 END, ty.name
               FROM sys.tables t
               JOIN sys.columns c ON c.object_id = t.object_id
               JOIN sys.types ty ON ty.user_type_id = c.user_type_id
               WHERE t.schema_id = SCHEMA_ID('dbo') AND t.name IN ({tableList})",
            r => new Col(r.GetString(0), r.GetString(1), r.GetBoolean(2), r.GetBoolean(3), r.GetBoolean(4), r.GetInt32(5) == 1, r.GetString(6)), ct);

        var problems = new List<string>();
        foreach (var (table, used) in Used)
        {
            var existing = cols.Where(c => c.Table == table).ToList();
            if (existing.Count == 0) { problems.Add($"table {table} not found"); continue; }
            var missing = used.Where(u => !existing.Any(c => string.Equals(c.Name, u, StringComparison.OrdinalIgnoreCase))).ToList();
            if (missing.Count > 0) problems.Add($"{table}: missing {string.Join(", ", missing)}");
        }
        if (problems.Count > 0)
            throw new AppException(500, "SCHEMA_OUTDATED",
                "The database needs one update before students can be registered. Run database/Scripts/007_new_student_payments.sql, then restart the API. (" + string.Join("; ", problems) + ")");

        var unknown = new List<string>();
        foreach (var (table, filled) in Filled)
            foreach (var c in cols.Where(c => c.Table == table))
                if (!c.Nullable && !c.Identity && !c.Computed && !c.HasDefault && c.Type != "timestamp"
                    && !filled.Contains(c.Name, StringComparer.OrdinalIgnoreCase))
                    unknown.Add($"{table}.{c.Name}");
        if (unknown.Count > 0)
            throw new AppException(500, "SCHEMA_UNKNOWN_COLUMN",
                "These required columns exist but the application does not fill them: " + string.Join(", ", unknown) +
                ". Send the table definition so the registration can be extended instead of guessing values.");

        lock (ComputedCache)
            foreach (var c in cols.Where(c => c.Table == "InvoiceDetails" && c.Name == "subtotal")) ComputedCache["InvoiceDetails.subtotal"] = c.Computed;
        _verified = true;
    }

    /// <summary>True when InvoiceDetails.subtotal is a computed column (it must not be inserted then).</summary>
    public bool InvoiceDetailSubtotalIsComputed
    {
        get { lock (ComputedCache) return ComputedCache.TryGetValue("InvoiceDetails.subtotal", out var v) && v; }
    }
}
