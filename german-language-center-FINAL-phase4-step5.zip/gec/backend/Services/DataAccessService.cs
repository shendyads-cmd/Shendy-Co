using System.Collections.Concurrent;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using GermanCenter.Api.Authentication;
using GermanCenter.Api.Data;
using GermanCenter.Api.DTOs;
using GermanCenter.Api.Middleware;
using GermanCenter.Api.Utilities;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;

namespace GermanCenter.Api.Services;

/// <summary>
/// The fixed "Data password" that staff must enter before the Data area opens.
///  * It is stored ONLY as a bcrypt hash in dbo.SystemSettings (key data_password_hash). It is never returned by any endpoint,
///    never logged and never present in the frontend.
///  * A correct password returns a short-lived "data access token" (30 minutes). It is a separate JWT with its own audience, so it
///    can never be used to log in, and it is bound to the user and to the CURRENT password: when the Admin changes the Data password
///    every token that was issued before stops working at once.
///  * An Admin never needs the password (direct access); that rule lives in DataAccessAttribute, not in the browser.
///  * Wrong guesses are limited: 5 failures lock that user out for 5 minutes (per API instance).
/// </summary>
public class DataAccessService(AppDbContext db, IOptions<JwtOptions> jwtOptions, IConfiguration config, ILogger<DataAccessService> log)
{
    public const string HeaderName = "X-Data-Token";
    private const string SettingKey = "data_password_hash";
    private const string DataAudience = "GermanCenter.DataAccess";
    private const string DataClaim = "data_access";
    private const string FingerprintClaim = "fp";
    private static readonly TimeSpan Lifetime = TimeSpan.FromMinutes(30);
    private const int MaxFailures = 5;
    private static readonly TimeSpan LockoutTime = TimeSpan.FromMinutes(5);

    private sealed class Attempt { public int Failures; public DateTime? LockedUntilUtc; }
    private static readonly ConcurrentDictionary<int, Attempt> Attempts = new();

    private readonly JwtOptions _jwt = jwtOptions.Value;

    // ------------------------------------------------------------------ storage

    private async Task<string?> GetHashAsync(CancellationToken ct)
    {
        try
        {
            return await db.ScalarAsync<string>("SELECT setting_value FROM dbo.SystemSettings WHERE setting_key = @k", ct, ("@k", SettingKey));
        }
        catch (SqlException e) when (e.Number == 208) // invalid object name: script 011 has not been run
        {
            throw new AppException(500, "SCHEMA_OUTDATED", "The database needs one update before the Data password can be used. Run database/Scripts/011_system_settings.sql, then restart the API.");
        }
    }

    private async Task SaveHashAsync(string hash, int? userId, CancellationToken ct)
    {
        await db.ExecuteAsync(
            @"MERGE dbo.SystemSettings WITH (HOLDLOCK) AS t
              USING (SELECT @k AS setting_key) AS s ON t.setting_key = s.setting_key
              WHEN MATCHED THEN UPDATE SET setting_value = @v, updated_at = SYSDATETIME(), updated_by = @u
              WHEN NOT MATCHED THEN INSERT (setting_key, setting_value, updated_at, updated_by) VALUES (@k, @v, SYSDATETIME(), @u);",
            ct, ("@k", SettingKey), ("@v", hash), ("@u", userId));
    }

    private static string Fingerprint(string hash) => Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(hash)))[..16];

    public async Task<bool> IsConfiguredAsync(CancellationToken ct) => !string.IsNullOrEmpty(await GetHashAsync(ct));

    /// <summary>First start only: if Bootstrap:DataPassword is configured (user-secrets / environment variable) and no Data password exists yet, it is hashed and stored.</summary>
    public async Task EnsureFromConfigAsync(CancellationToken ct)
    {
        var initial = config["Bootstrap:DataPassword"];
        if (string.IsNullOrWhiteSpace(initial)) return;
        if (initial.Length < 8) { log.LogError("Bootstrap:DataPassword must be at least 8 characters; it was ignored."); return; }
        if (!string.IsNullOrEmpty(await GetHashAsync(ct))) return; // never overwrites a password the Admin already chose
        await SaveHashAsync(PasswordHasher.Hash(initial), null, ct);
        log.LogWarning("The initial Data password was stored (hashed). Remove Bootstrap:DataPassword from the configuration now; change it later from Account Settings.");
    }

    // ------------------------------------------------------------------ unlock (staff)

    public async Task<DataUnlockResponse> UnlockAsync(int userId, string password, CancellationToken ct)
    {
        var attempt = Attempts.GetOrAdd(userId, _ => new Attempt());
        lock (attempt)
        {
            if (attempt.LockedUntilUtc is { } until && until > DateTime.UtcNow)
                throw new AppException(429, "DATA_LOCKED_OUT", $"Too many wrong attempts. Try again in {Math.Max(1, (int)Math.Ceiling((until - DateTime.UtcNow).TotalMinutes))} minute(s).");
        }

        var hash = await GetHashAsync(ct);
        if (string.IsNullOrEmpty(hash))
            throw new AppException(403, "DATA_PASSWORD_NOT_SET", "The Data password has not been set yet. Ask the administrator.");

        if (!PasswordHasher.Verify(password, hash))
        {
            lock (attempt)
            {
                attempt.Failures++;
                if (attempt.Failures >= MaxFailures) { attempt.LockedUntilUtc = DateTime.UtcNow.Add(LockoutTime); attempt.Failures = 0; }
            }
            throw new AppException(403, "DATA_PASSWORD_INVALID", "Incorrect Data password.");
        }

        lock (attempt) { attempt.Failures = 0; attempt.LockedUntilUtc = null; }

        var expires = DateTime.UtcNow.Add(Lifetime);
        var claims = new[]
        {
            new Claim(JwtRegisteredClaimNames.Sub, userId.ToString()),
            new Claim(DataClaim, "1"),
            new Claim(FingerprintClaim, Fingerprint(hash))
        };
        var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_jwt.Key));
        var token = new JwtSecurityToken(_jwt.Issuer, DataAudience, claims, expires: expires, signingCredentials: new SigningCredentials(key, SecurityAlgorithms.HmacSha256));
        return new DataUnlockResponse(new JwtSecurityTokenHandler().WriteToken(token), expires);
    }

    /// <summary>True when the header token is genuine, not expired, belongs to this user and was issued for the CURRENT Data password.</summary>
    public async Task<bool> IsTokenValidAsync(string? token, int userId, CancellationToken ct)
    {
        if (string.IsNullOrWhiteSpace(token)) return false;
        try
        {
            var handler = new JwtSecurityTokenHandler { MapInboundClaims = false };
            var principal = handler.ValidateToken(token, new TokenValidationParameters
            {
                ValidateIssuer = true, ValidIssuer = _jwt.Issuer,
                ValidateAudience = true, ValidAudience = DataAudience,
                ValidateIssuerSigningKey = true, IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_jwt.Key)),
                ValidateLifetime = true, ClockSkew = TimeSpan.Zero
            }, out _);

            if (principal.FindFirst(DataClaim)?.Value != "1") return false;
            if (principal.FindFirst(JwtRegisteredClaimNames.Sub)?.Value != userId.ToString()) return false;
            var hash = await GetHashAsync(ct);
            return !string.IsNullOrEmpty(hash) && principal.FindFirst(FingerprintClaim)?.Value == Fingerprint(hash);
        }
        catch (SecurityTokenException) { return false; }
        catch (ArgumentException) { return false; }
    }

    // ------------------------------------------------------------------ change (Admin)

    public async Task ChangePasswordAsync(int adminUserId, ChangeDataPasswordRequest req, CancellationToken ct)
    {
        var admin = await db.Users.AsNoTracking().FirstOrDefaultAsync(u => u.UserId == adminUserId, ct)
            ?? throw AppException.NotFound("User not found.");
        if (!PasswordHasher.Verify(req.AccountPassword, admin.PasswordHash))
            throw AppException.BadRequest("Your account password is incorrect.", "ACCOUNT_PASSWORD_INVALID");
        var next = req.NewDataPassword.Trim();
        if (next.Length < 8) throw AppException.BadRequest("The Data password must be at least 8 characters.", "DATA_PASSWORD_SHORT");
        await SaveHashAsync(PasswordHasher.Hash(next), adminUserId, ct);
        Attempts.Clear(); // a new password starts with a clean slate
    }
}
