using System.Data.Common;
using System.Globalization;
using GermanCenter.Api.Data;
using GermanCenter.Api.DTOs;
using GermanCenter.Api.Middleware;
using GermanCenter.Api.Models;
using GermanCenter.Api.Utilities;
using Microsoft.EntityFrameworkCore;

namespace GermanCenter.Api.Services;

/// <summary>Data: history of completed courses (read-only) and the permanent clean-up. Admin only (see DataController).</summary>
public class DataService(AppDbContext db, PaymentSchemaGuard guard, ProofStorage proofs, ILogger<DataService> log)
{
    private sealed record MoneyRow(int CourseId, decimal Total, decimal Paid);
    private sealed record CountRow(int CourseId, string Status, int Students);

    // ------------------------------------------------------------------ list

    public async Task<PagedResult<CompletedCourseDto>> ListCompletedAsync(ListQuery q, CancellationToken ct)
    {
        var query = db.Courses.AsNoTracking().Where(c => c.IsCompleted && !c.IsDeleted);
        if (!string.IsNullOrWhiteSpace(q.Search))
        {
            var s = q.Search.Trim();
            var codeText = Utilities.Codes.NormalizeCourseSearch(s); // "A1" / "A001" also find "A-001"
            query = query.Where(c => c.CourseCode.Contains(codeText) || c.CourseName.Contains(s)); // case-insensitive with the default SQL Server collation
        }
        var total = await query.CountAsync(ct);
        var items = await query.OrderByDescending(c => c.CompletedAt).ThenByDescending(c => c.CourseId)
            .Skip(q.Skip).Take(q.Take).Select(CourseService.ToCompletedDto).ToListAsync(ct);

        Dictionary<int, CourseFinancialSummaryDto>? money = null;
        try { money = await FinancialsAsync(items.Select(i => i.CourseId).ToList(), ct); }
        catch (AppException ex) { log.LogWarning("Financial summary skipped: {Message}", ex.Message); } // schema not updated yet: still show the list

        var withMoney = items.Select(i => money != null && money.TryGetValue(i.CourseId, out var f) ? i with { Financial = f } : i).ToList();
        return new PagedResult<CompletedCourseDto>(withMoney, total, q.PageNumber, q.Take);
    }

    /// <summary>
    /// Totals per course from the invoices that contain it. Paid = sum of payment allocations on those invoices.
    /// An invoice that also holds other courses is counted pro rata by line value. Cancelled invoices are ignored.
    /// </summary>
    private async Task<Dictionary<int, CourseFinancialSummaryDto>> FinancialsAsync(List<int> courseIds, CancellationToken ct)
    {
        var result = new Dictionary<int, CourseFinancialSummaryDto>();
        if (courseIds.Count == 0) return result;
        await guard.EnsureAsync(ct);

        var names = courseIds.Select((_, i) => $"@c{i}").ToList();
        var args = courseIds.Select((id, i) => ($"@c{i}", (object?)id)).ToArray();
        var inList = string.Join(", ", names);

        var money = await db.QueryAsync(
            $@"SELECT x.course_id,
                      SUM(i.total_amount * x.share) AS total,
                      SUM(ISNULL(p.paid, 0) * x.share) AS paid
               FROM (SELECT d.course_id, d.invoice_id,
                            CASE WHEN MAX(i2.subtotal) > 0 THEN SUM(d.quantity * d.unit_price) / MAX(i2.subtotal) ELSE 1 END AS share
                     FROM InvoiceDetails d JOIN Invoices i2 ON i2.invoice_id = d.invoice_id
                     WHERE d.course_id IN ({inList}) AND i2.status <> 'Cancelled'
                     GROUP BY d.course_id, d.invoice_id) x
               JOIN Invoices i ON i.invoice_id = x.invoice_id
               LEFT JOIN (SELECT invoice_id, SUM(allocated_amount) AS paid FROM PaymentAllocations GROUP BY invoice_id) p ON p.invoice_id = i.invoice_id
               GROUP BY x.course_id",
            r => new MoneyRow(r.GetInt32(0), r.GetDecimal(1), r.GetDecimal(2)), ct, args);

        var counts = await db.QueryAsync(
            $@"SELECT d.course_id, i.status, COUNT(DISTINCT ic.customer_id)
               FROM InvoiceDetails d
               JOIN Invoices i ON i.invoice_id = d.invoice_id
               JOIN InvoiceCustomers ic ON ic.invoice_id = i.invoice_id
               WHERE d.course_id IN ({inList}) AND i.status <> 'Cancelled'
               GROUP BY d.course_id, i.status",
            r => new CountRow(r.GetInt32(0), r.GetString(1), r.GetInt32(2)), ct, args);

        foreach (var id in courseIds)
        {
            var m = money.FirstOrDefault(x => x.CourseId == id);
            var total = Math.Round(m?.Total ?? 0, 2);
            var paid = Math.Round(m?.Paid ?? 0, 2);
            result[id] = new CourseFinancialSummaryDto(total, paid, total - paid,
                counts.Where(c => c.CourseId == id && c.Status == "Paid").Sum(c => c.Students),
                counts.Where(c => c.CourseId == id && c.Status == "Partially Paid").Sum(c => c.Students),
                counts.Where(c => c.CourseId == id && c.Status == "Unpaid").Sum(c => c.Students));
        }
        return result;
    }

    // ------------------------------------------------------------------ course history

    public async Task<CompletedCourseDetailsDto> GetCompletedAsync(int id, string? paymentStatus, CancellationToken ct)
    {
        var course = await db.Courses.AsNoTracking().Where(c => c.CourseId == id && c.IsCompleted && !c.IsDeleted)
            .Select(CourseService.ToCompletedDto).FirstOrDefaultAsync(ct)
            ?? throw AppException.NotFound("Completed course not found.");

        var money = await FinancialsAsync(new List<int> { id }, ct);
        course = course with { Financial = money[id] };

        var students = await db.QueryAsync(
            @"SELECT e.customer_id, c.full_name, e.enrollment_date, e.status, inv.invoice_number, inv.status
              FROM Enrollments e
              JOIN Customers c ON c.customer_id = e.customer_id
              OUTER APPLY (SELECT TOP 1 i.invoice_number, i.status
                           FROM InvoiceCustomers ic
                           JOIN Invoices i ON i.invoice_id = ic.invoice_id
                           JOIN InvoiceDetails d ON d.invoice_id = i.invoice_id AND d.course_id = e.course_id
                           WHERE ic.customer_id = e.customer_id AND i.status <> 'Cancelled'
                           ORDER BY i.invoice_id DESC) inv
              WHERE e.course_id = @c AND e.status <> 'Cancelled' AND c.is_deleted = 0
              ORDER BY c.full_name",
            r => new HistoricalStudentDto(r.GetInt32(0), r.GetString(1), r.GetDateTime(2), r.GetString(3),
                                          r.GetStringOrNull(5) ?? "No invoice", r.GetStringOrNull(4)), ct, ("@c", id));

        var wanted = paymentStatus?.Trim().ToLowerInvariant() switch
        {
            "paid" => "Paid",
            "partial" => "Partially Paid",
            "unpaid" => "Unpaid",
            _ => null
        };
        if (wanted != null) students = students.Where(s => s.PaymentStatus == wanted).ToList();
        return new CompletedCourseDetailsDto(course, students);
    }

    // ------------------------------------------------------------------ student history (read-only)

    public async Task<HistoricalStudentDetailsDto> GetStudentHistoryAsync(int courseId, int customerId, CancellationToken ct)
    {
        await guard.EnsureAsync(ct);

        var head = await db.QueryAsync(
            @"SELECT c.customer_id, c.full_name, c.phone, c.email, c.address, c.area,
                     co.course_id, co.course_code, co.course_name, e.enrollment_date, e.status
              FROM Enrollments e
              JOIN Customers c ON c.customer_id = e.customer_id
              JOIN Courses co ON co.course_id = e.course_id
              WHERE e.course_id = @course AND e.customer_id = @cust AND co.is_completed = 1 AND co.is_deleted = 0 AND c.is_deleted = 0",
            r => new HistoricalStudentDetailsDto(r.GetInt32(0), Codes.Student(r.GetInt32(0)), r.GetString(1), r.GetStringOrNull(2), r.GetStringOrNull(3),
                                                 r.GetStringOrNull(4), r.GetStringOrNull(5), r.GetInt32(6), r.GetString(7), r.GetString(8),
                                                 r.GetDateTime(9), r.GetString(10), null, new List<HistoricalPaymentDto>()),
            ct, ("@course", courseId), ("@cust", customerId));
        var student = head.FirstOrDefault() ?? throw AppException.NotFound("This student has no history in the selected completed course.");

        var invoices = await db.QueryAsync(
            @"SELECT TOP 1 i.invoice_id, i.invoice_number, i.issue_date, d.unit_price, i.discount_percent, i.discount_amount, i.total_amount, i.status,
                     ISNULL((SELECT SUM(a.allocated_amount) FROM PaymentAllocations a WHERE a.invoice_id = i.invoice_id), 0)
              FROM InvoiceCustomers ic
              JOIN Invoices i ON i.invoice_id = ic.invoice_id
              JOIN InvoiceDetails d ON d.invoice_id = i.invoice_id AND d.course_id = @course
              WHERE ic.customer_id = @cust AND i.status <> 'Cancelled'
              ORDER BY i.invoice_id DESC",
            r => new HistoricalInvoiceDto(r.GetInt32(0), r.GetString(1), r.GetDateTime(2), r.GetDecimal(3), r.GetDecimal(4), r.GetDecimal(5),
                                          r.GetDecimal(6), r.GetDecimal(8), r.GetDecimal(6) - r.GetDecimal(8), r.GetString(7)),
            ct, ("@course", courseId), ("@cust", customerId));
        var invoice = invoices.FirstOrDefault();
        if (invoice == null) return student;

        var payments = await db.QueryAsync(
            @"SELECT p.payment_id, p.payment_date, a.allocated_amount, p.payment_method, p.payment_method_other, p.proof_stored_name, p.proof_file_name, p.proof_content_type
              FROM PaymentAllocations a JOIN Payments p ON p.payment_id = a.payment_id
              WHERE a.invoice_id = @inv
              ORDER BY p.payment_date, p.payment_id",
            r => new HistoricalPaymentDto(r.GetInt32(0), r.GetDateTime(1), r.GetDecimal(2), r.GetString(3), r.GetStringOrNull(4),
                                          !r.IsDBNull(5), r.GetStringOrNull(6), r.GetStringOrNull(7)),
            ct, ("@inv", invoice.InvoiceId));
        return student with { Invoice = invoice, Payments = payments };
    }

    /// <summary>Opens a payment proof file for the Admin who is viewing a student's history.</summary>
    public async Task<(FileStream Stream, string ContentType, string FileName)> OpenProofAsync(int paymentId, CancellationToken ct)
    {
        await guard.EnsureAsync(ct);
        var rows = await db.QueryAsync("SELECT proof_stored_name, proof_content_type, proof_file_name FROM Payments WHERE payment_id = @p AND proof_stored_name IS NOT NULL",
            r => (Stored: r.GetString(0), Type: r.GetStringOrNull(1) ?? "application/octet-stream", Name: r.GetStringOrNull(2) ?? "proof"), ct, ("@p", paymentId));
        var row = rows.FirstOrDefault();
        var stream = row.Stored == null ? null : proofs.Open(row.Stored);
        if (stream == null) throw AppException.NotFound("Payment proof not found.");
        return (stream, row.Type, row.Name);
    }

    // ------------------------------------------------------------------ permanent clean-up of one completed course

    /// <summary>
    /// Permanently removes the data that belongs to ONE completed course, in foreign-key order, inside one transaction:
    /// guarantees and allocations of its invoices -> payments used only by those invoices (and their INCOME transactions) ->
    /// invoice details / customers / invoices -> enrollments -> the course row.
    /// Students are never deleted. A payment that also pays other invoices is kept (only its allocation to this course goes).
    /// Identity values are not touched, so the Course ID is never reused. Any failure rolls everything back.
    /// </summary>
    public async Task<DeleteCourseDataResultDto> DeleteCourseDataAsync(int courseId, string? confirmation, CancellationToken ct)
    {
        if (!string.Equals(confirmation, "DELETE", StringComparison.Ordinal))
            throw AppException.BadRequest("Type DELETE exactly to confirm.", "CONFIRMATION_REQUIRED");
        await guard.EnsureAsync(ct);

        var course = await db.Courses.AsNoTracking().FirstOrDefaultAsync(c => c.CourseId == courseId && c.IsCompleted, ct)
            ?? throw AppException.NotFound("Completed course not found.");

        List<string> proofFiles;
        DeleteCourseDataResultDto result;
        await using var tx = await db.Database.BeginTransactionAsync(ct);
        try
        {
            // courseId is an int, so it is safe to write into the SQL text. The statements must not use parameters:
            // a parameterised command runs inside sp_executesql, which would drop the #temp tables when it ends.
            var cid = courseId.ToString(CultureInfo.InvariantCulture);
            await db.ExecuteAsync("CREATE TABLE #inv (invoice_id INT NOT NULL PRIMARY KEY); INSERT INTO #inv SELECT DISTINCT invoice_id FROM InvoiceDetails WHERE course_id = " + cid + ";", ct);

            var shared = await db.QueryAsync(
                @"SELECT DISTINCT i.invoice_number FROM Invoices i JOIN InvoiceDetails d ON d.invoice_id = i.invoice_id
                  WHERE i.invoice_id IN (SELECT invoice_id FROM #inv) AND d.course_id <> " + cid + " ORDER BY 1", r => r.GetString(0), ct);
            if (shared.Count > 0)
                throw AppException.Conflict($"Invoice(s) {string.Join(", ", shared)} also contain other courses, so this course's data cannot be removed automatically.", "SHARED_INVOICE");

            await db.ExecuteAsync(
                @"CREATE TABLE #pay (payment_id INT NOT NULL PRIMARY KEY);
                  INSERT INTO #pay SELECT payment_id FROM PaymentAllocations WHERE invoice_id IN (SELECT invoice_id FROM #inv)
                  UNION SELECT payment_id FROM PaymentGuarantees WHERE invoice_id IN (SELECT invoice_id FROM #inv) AND payment_id IS NOT NULL;", ct);

            await db.ExecuteAsync("DELETE FROM PaymentGuarantees WHERE invoice_id IN (SELECT invoice_id FROM #inv)", ct);
            var allocations = await db.ExecuteAsync("DELETE FROM PaymentAllocations WHERE invoice_id IN (SELECT invoice_id FROM #inv)", ct);

            // A payment may only go when nothing else still points at it.
            await db.ExecuteAsync(
                @"CREATE TABLE #paydel (payment_id INT NOT NULL PRIMARY KEY);
                  INSERT INTO #paydel SELECT p.payment_id FROM #pay p
                  WHERE NOT EXISTS (SELECT 1 FROM PaymentAllocations a WHERE a.payment_id = p.payment_id)
                    AND NOT EXISTS (SELECT 1 FROM PaymentGuarantees g WHERE g.payment_id = p.payment_id);", ct);
            var kept = await db.ScalarAsync<int>("SELECT COUNT(*) FROM #pay WHERE payment_id NOT IN (SELECT payment_id FROM #paydel)", ct);

            proofFiles = await db.QueryAsync("SELECT proof_stored_name FROM Payments WHERE payment_id IN (SELECT payment_id FROM #paydel) AND proof_stored_name IS NOT NULL", r => r.GetString(0), ct);
            await db.ExecuteAsync("DELETE FROM Transactions WHERE related_payment_id IN (SELECT payment_id FROM #paydel)", ct);
            var payments = await db.ExecuteAsync("DELETE FROM Payments WHERE payment_id IN (SELECT payment_id FROM #paydel)", ct);

            await db.ExecuteAsync("DELETE FROM InvoiceDetails WHERE invoice_id IN (SELECT invoice_id FROM #inv)", ct);
            await db.ExecuteAsync("DELETE FROM InvoiceCustomers WHERE invoice_id IN (SELECT invoice_id FROM #inv)", ct);
            var invoices = await db.ExecuteAsync("DELETE FROM Invoices WHERE invoice_id IN (SELECT invoice_id FROM #inv)", ct);

            var enrollments = await db.ExecuteAsync("DELETE FROM Enrollments WHERE course_id = " + cid, ct);
            var removed = await db.ExecuteAsync("DELETE FROM Courses WHERE course_id = " + cid + " AND is_completed = 1", ct);
            if (removed != 1) throw AppException.Conflict("The course could not be removed.", "DELETE_FAILED");

            await db.ExecuteAsync("DROP TABLE #paydel; DROP TABLE #pay; DROP TABLE #inv;", ct);
            await tx.CommitAsync(ct);
            result = new DeleteCourseDataResultDto(courseId, course.CourseCode, invoices, payments, kept, allocations, enrollments);
        }
        catch (AppException) { throw; } // expected business errors keep their message; the transaction is rolled back on dispose
        catch (Exception ex)
        {
            log.LogError(ex, "Deleting the data of course {CourseId} failed and was rolled back.", courseId);
            throw new AppException(500, "DELETE_FAILED", "The data could not be deleted. Nothing was changed.");
        }

        foreach (var file in proofFiles) proofs.Delete(file); // files are removed only after the database commit succeeded
        return result;
    }
}
