using GermanCenter.Api.DTOs;
using GermanCenter.Api.Data;
using GermanCenter.Api.Middleware;
using GermanCenter.Api.Utilities;
using Microsoft.EntityFrameworkCore;

namespace GermanCenter.Api.Services;

/// <summary>
/// Expenses: list, create and edit. Every expense has exactly ONE Cash Out row (Transactions EXPENSE, related_expense_id):
/// the expense and its Cash Out are written (and edited) in ONE database transaction, so they can never disagree.
/// Duplicates: the Idempotency-Key stops a repeated request; UX_Transactions_expense allows only one Cash Out per expense; an identical
/// expense (same title, category, amount and date) entered by the same user within one minute is refused.
/// Expenses are never deleted here, because deleting would remove history that reports rely on.
/// </summary>
public class ExpenseService(AppDbContext db, FinanceSchemaGuard guard, NotificationService notifications)
{
    /// <summary>Salaries are NOT an expense category: they are paid through Payroll.</summary>
    public static readonly string[] Categories = { "Rent", "Utilities", "Supplies", "Marketing", "Maintenance", "Transport", "Other" };
    private const decimal MaxAmount = 99_999_999.99m;

    public async Task<ExpensePageDto> ListAsync(ExpenseQuery q, CancellationToken ct)
    {
        if (q.FromDate.HasValue && q.ToDate.HasValue && q.FromDate.Value.Date > q.ToDate.Value.Date)
            throw AppException.BadRequest("The start date must not be after the end date.", "DATE_RANGE");

        var clauses = new List<string>();
        var args = new List<(string, object?)>();
        if (!string.IsNullOrWhiteSpace(q.Search))
        {
            clauses.Add(@"(e.expense_title LIKE @like ESCAPE '\' OR e.category LIKE @like ESCAPE '\' OR e.description LIKE @like ESCAPE '\')");
            args.Add(("@like", SqlText.LikePattern(q.Search)));
        }
        if (q.FromDate.HasValue) { clauses.Add("e.expense_date >= @from"); args.Add(("@from", q.FromDate.Value.Date)); }
        if (q.ToDate.HasValue) { clauses.Add("e.expense_date < @toExclusive"); args.Add(("@toExclusive", q.ToDate.Value.Date.AddDays(1))); }
        var filter = clauses.Count > 0 ? "WHERE " + string.Join(" AND ", clauses) : "";

        var totals = await db.QueryAsync($"SELECT COUNT(*), ISNULL(SUM(e.amount), 0) FROM Expenses e {filter}",
            r => (Count: r.GetInt32(0), Sum: r.GetDecimal(1)), ct, args.ToArray());

        args.Add(("@skip", q.Skip));
        args.Add(("@take", q.Take));
        var items = await db.QueryAsync(
            $@"SELECT e.expense_id, e.expense_title, e.amount, e.category, e.expense_date, e.description, u.full_name
               FROM Expenses e LEFT JOIN Users u ON u.user_id = e.user_id {filter}
               ORDER BY e.expense_date DESC, e.expense_id DESC
               OFFSET @skip ROWS FETCH NEXT @take ROWS ONLY",
            r => new ExpenseDto(r.GetInt32(0), r.GetString(1), r.GetDecimal(2), r.GetString(3), r.GetDateTime(4), r.GetStringOrNull(5), r.GetStringOrNull(6)),
            ct, args.ToArray());

        return new ExpensePageDto(items, totals[0].Count, q.PageNumber, q.Take, totals[0].Sum);
    }

    // ------------------------------------------------------------------ create / edit

    private async Task<(string Title, string Category, decimal Amount, DateTime Date, string? Description)> ValidateAsync(ExpenseRequest r, CancellationToken ct)
    {
        await guard.EnsureAsync(ct);
        var title = r.Title?.Trim() ?? "";
        var maxTitle = guard.MaxLength("Expenses", "expense_title", 150);
        if (title.Length < 2 || title.Length > maxTitle) throw AppException.BadRequest($"Enter the expense title (2-{maxTitle} characters).", "TITLE");

        var category = Categories.FirstOrDefault(c => string.Equals(c, r.Category?.Trim(), StringComparison.OrdinalIgnoreCase));
        if (category == null) throw AppException.BadRequest("Choose a category from the list.", "CATEGORY");
        if (category.Length > guard.MaxLength("Expenses", "category", 100)) throw AppException.BadRequest("The category is too long.", "CATEGORY");

        if (r.Amount <= 0) throw AppException.BadRequest("Enter an amount greater than zero.", "AMOUNT");
        var amount = Math.Round(r.Amount, 2, MidpointRounding.AwayFromZero);
        if (amount <= 0 || amount > MaxAmount) throw AppException.BadRequest("The amount is not valid.", "AMOUNT");

        if (r.ExpenseDate == default) throw AppException.BadRequest("Choose the expense date.", "DATE");
        var date = r.ExpenseDate.Date;
        if (date > DateTime.Today) throw AppException.BadRequest("The expense date cannot be in the future.", "DATE");
        if (date < new DateTime(2000, 1, 1)) throw AppException.BadRequest("The expense date is not valid.", "DATE");

        var description = r.Description.NullIfBlank();
        var maxDescription = guard.MaxLength("Expenses", "description", 500);
        if (description != null && description.Length > maxDescription) throw AppException.BadRequest($"The description is too long (maximum {maxDescription} characters).", "DESCRIPTION");
        return (title, category, amount, date, description);
    }

    public async Task<ExpenseDto> CreateAsync(ExpenseRequest r, int userId, CancellationToken ct)
    {
        var v = await ValidateAsync(r, ct);
        await using var tx = await db.Database.BeginTransactionAsync(ct);

        var duplicate = await db.ScalarAsync<int>(
            @"SELECT COUNT(*) FROM Expenses WITH (UPDLOCK, HOLDLOCK)
              WHERE user_id = @u AND expense_title = @t AND category = @c AND amount = @a AND CAST(expense_date AS date) = @d
                AND created_at >= DATEADD(MINUTE, -1, SYSDATETIME())", ct,
            ("@u", userId), ("@t", v.Title), ("@c", v.Category), ("@a", v.Amount), ("@d", v.Date));
        if (duplicate > 0) throw AppException.Conflict("An identical expense was just saved. Check the list before adding it again.", "DUPLICATE_EXPENSE");

        var id = await db.InsertAsync(
            @"INSERT INTO Expenses (expense_title, amount, category, expense_date, description, user_id)
              VALUES (@t, @a, @c, @d, @desc, @u);
              SELECT CAST(SCOPE_IDENTITY() AS int);", ct,
            ("@t", v.Title), ("@a", v.Amount), ("@c", v.Category), ("@d", v.Date), ("@desc", v.Description), ("@u", userId));
        // Cash Out
        await db.ExecuteAsync("INSERT INTO Transactions (transaction_type, amount, related_payment_id, related_expense_id, related_payroll_id, transaction_date) VALUES ('EXPENSE', @a, NULL, @e, NULL, @d)", ct,
            ("@a", v.Amount), ("@e", id), ("@d", v.Date));
        await notifications.NotifyExpenseCreatedAsync(id, v.Title, v.Amount, v.Category, ct);

        await tx.CommitAsync(ct);
        return await GetAsync(id, ct);
    }

    public async Task<ExpenseDto> UpdateAsync(int id, ExpenseRequest r, CancellationToken ct)
    {
        var v = await ValidateAsync(r, ct);
        await using var tx = await db.Database.BeginTransactionAsync(ct);

        var exists = await db.QueryAsync("SELECT expense_id FROM Expenses WITH (UPDLOCK, ROWLOCK) WHERE expense_id = @id", x => x.GetInt32(0), ct, ("@id", id));
        if (exists.Count == 0) throw AppException.NotFound("Expense not found.");

        await db.ExecuteAsync(
            "UPDATE Expenses SET expense_title = @t, amount = @a, category = @c, expense_date = @d, description = @desc WHERE expense_id = @id", ct,
            ("@t", v.Title), ("@a", v.Amount), ("@c", v.Category), ("@d", v.Date), ("@desc", v.Description), ("@id", id));
        // the Cash Out follows the expense
        var changed = await db.ExecuteAsync("UPDATE Transactions SET amount = @a, transaction_date = @d WHERE related_expense_id = @id", ct,
            ("@a", v.Amount), ("@d", v.Date), ("@id", id));
        if (changed == 0) // an old expense that never had its Cash Out
            await db.ExecuteAsync("INSERT INTO Transactions (transaction_type, amount, related_payment_id, related_expense_id, related_payroll_id, transaction_date) VALUES ('EXPENSE', @a, NULL, @e, NULL, @d)", ct,
                ("@a", v.Amount), ("@e", id), ("@d", v.Date));

        await tx.CommitAsync(ct);
        return await GetAsync(id, ct);
    }

    private async Task<ExpenseDto> GetAsync(int id, CancellationToken ct)
    {
        var rows = await db.QueryAsync(
            @"SELECT e.expense_id, e.expense_title, e.amount, e.category, e.expense_date, e.description, u.full_name
              FROM Expenses e LEFT JOIN Users u ON u.user_id = e.user_id WHERE e.expense_id = @id",
            r => new ExpenseDto(r.GetInt32(0), r.GetString(1), r.GetDecimal(2), r.GetString(3), r.GetDateTime(4), r.GetStringOrNull(5), r.GetStringOrNull(6)),
            ct, ("@id", id));
        return rows.Count > 0 ? rows[0] : throw AppException.NotFound("Expense not found.");
    }
}
