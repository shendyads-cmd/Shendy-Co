using GermanCenter.Api.Authentication;
using GermanCenter.Api.Data;
using GermanCenter.Api.DTOs;
using GermanCenter.Api.Middleware;
using GermanCenter.Api.Models;
using Microsoft.EntityFrameworkCore;

namespace GermanCenter.Api.Services;

public class UserService(AppDbContext db)
{
    public async Task<List<UserDto>> ListAsync(string? search, CancellationToken ct)
    {
        var query = db.Users.AsNoTracking();
        if (!string.IsNullOrWhiteSpace(search))
        {
            var s = search.Trim();
            query = query.Where(u => u.Username.Contains(s) || (u.FullName != null && u.FullName.Contains(s)));
        }
        return await query.OrderBy(u => u.Username)
            .Select(u => new UserDto(u.UserId, u.Username, u.FullName, u.Role, u.IsActive, u.CreatedAt))
            .ToListAsync(ct);
    }

    public async Task<UserDto> CreateAsync(CreateUserRequest req, CancellationToken ct)
    {
        var username = req.Username.Trim();
        if (await db.Users.AnyAsync(u => u.Username == username, ct))
            throw AppException.Conflict("Username already exists.", "USERNAME_EXISTS");

        var user = new User
        {
            Username = username,
            FullName = string.IsNullOrWhiteSpace(req.FullName) ? null : req.FullName.Trim(),
            Role = req.Role,
            IsActive = true,
            PasswordHash = PasswordHasher.Hash(req.Password)
        };
        db.Users.Add(user);
        try { await db.SaveChangesAsync(ct); }
        catch (DbUpdateException) { throw AppException.Conflict("User could not be created. The username may already exist.", "USER_NOT_CREATED"); }

        await db.Entry(user).ReloadAsync(ct); // pick up the database-generated created_at
        return AuthService.ToDto(user);
    }

    public async Task<UserDto> UpdateAsync(int id, UpdateUserRequest req, CancellationToken ct)
    {
        var user = await db.Users.FirstOrDefaultAsync(u => u.UserId == id, ct)
            ?? throw AppException.NotFound("User not found.");

        var losesAdmin = user.Role == Roles.Admin && user.IsActive && (req.Role != Roles.Admin || !req.IsActive);
        if (losesAdmin)
        {
            var otherActiveAdmins = await db.Users.CountAsync(u => u.UserId != id && u.Role == Roles.Admin && u.IsActive, ct);
            if (otherActiveAdmins == 0)
                throw AppException.Conflict("At least one active administrator is required.", "LAST_ADMIN");
        }

        user.FullName = string.IsNullOrWhiteSpace(req.FullName) ? null : req.FullName.Trim();
        user.Role = req.Role;
        user.IsActive = req.IsActive;
        await db.SaveChangesAsync(ct);
        return AuthService.ToDto(user);
    }

    public async Task ResetPasswordAsync(int id, ResetPasswordRequest req, CancellationToken ct)
    {
        var user = await db.Users.FirstOrDefaultAsync(u => u.UserId == id, ct)
            ?? throw AppException.NotFound("User not found.");
        user.PasswordHash = PasswordHasher.Hash(req.NewPassword);
        await db.SaveChangesAsync(ct);
    }

    /// <summary>Display name only. Role, status and username can never be changed through this method.</summary>
    public async Task<UserDto> UpdateOwnProfileAsync(int userId, UpdateProfileRequest req, CancellationToken ct)
    {
        var user = await db.Users.FirstOrDefaultAsync(u => u.UserId == userId, ct)
            ?? throw AppException.NotFound("User not found.");
        var name = req.FullName.Trim();
        if (name.Length < 2) throw AppException.BadRequest("Display name must be 2-150 characters.", "VALIDATION");
        user.FullName = name;
        await db.SaveChangesAsync(ct);
        return AuthService.ToDto(user);
    }

    public async Task ChangeOwnPasswordAsync(int userId, ChangeOwnPasswordRequest req, CancellationToken ct)
    {
        var user = await db.Users.FirstOrDefaultAsync(u => u.UserId == userId, ct)
            ?? throw AppException.NotFound("User not found.");
        // 400 (not 401): a wrong current password must not look like an expired session and log the user out.
        if (!PasswordHasher.Verify(req.CurrentPassword, user.PasswordHash))
            throw AppException.BadRequest("Your current password is incorrect.", "ACCOUNT_PASSWORD_INVALID");
        user.PasswordHash = PasswordHasher.Hash(req.NewPassword);
        await db.SaveChangesAsync(ct);
    }
}
