using System.Linq.Expressions;
using GermanCenter.Api.Data;
using GermanCenter.Api.DTOs;
using GermanCenter.Api.Middleware;
using GermanCenter.Api.Models;
using GermanCenter.Api.Utilities;
using Microsoft.EntityFrameworkCore;

namespace GermanCenter.Api.Services;

public class EnrollmentService(AppDbContext db, NotificationService notifications, ILogger<EnrollmentService> log)
{
    public static readonly Expression<Func<Enrollment, EnrollmentDto>> ToDto = e => new EnrollmentDto(
        e.EnrollmentId, e.CustomerId, e.Customer.FullName,
        e.CourseId, e.Course.CourseCode, e.Course.CourseName,
        e.EnrollmentDate, e.StartDate, e.EndDate, e.TotalAmount, e.Status) { CourseCompleted = e.Course.IsCompleted };

    public async Task<PagedResult<EnrollmentDto>> ListAsync(EnrollmentQuery q, CancellationToken ct)
    {
        var query = db.Enrollments.AsNoTracking().Where(e => !e.Customer.IsDeleted && !e.Course.IsDeleted && !e.Course.IsCompleted);

        if (!string.IsNullOrWhiteSpace(q.Search))
        {
            var s = q.Search.Trim();
            var isId = Codes.TryParseStudent(s, out var searchId);
            query = query.Where(e => e.Customer.FullName.Contains(s)
                || (isId && e.CustomerId == searchId)
                || e.Course.CourseName.Contains(s) || e.Course.CourseCode.Contains(s));
        }
        if (!string.IsNullOrWhiteSpace(q.Status))
        {
            var status = q.Status.Trim();
            query = query.Where(e => e.Status == status);
        }
        if (q.CustomerId.HasValue) { var id = q.CustomerId.Value; query = query.Where(e => e.CustomerId == id); }
        if (q.CourseId.HasValue) { var id = q.CourseId.Value; query = query.Where(e => e.CourseId == id); }
        if (q.From.HasValue) { var fromDate = q.From.Value.Date; query = query.Where(e => e.EnrollmentDate >= fromDate); }
        if (q.To.HasValue) { var toDate = q.To.Value.Date.AddDays(1); query = query.Where(e => e.EnrollmentDate < toDate); }

        IOrderedQueryable<Enrollment> ordered = q.SortBy?.ToLowerInvariant() switch
        {
            "student" => query.Sort(e => e.Customer.FullName, q.Desc),
            "course" => query.Sort(e => e.Course.CourseName, q.Desc),
            "amount" => query.Sort(e => e.TotalAmount, q.Desc),
            "status" => query.Sort(e => e.Status, q.Desc),
            "date" => query.Sort(e => e.EnrollmentDate, q.Desc),
            _ => query.Sort(e => e.EnrollmentDate, true)
        };

        var total = await query.CountAsync(ct);
        var items = await ordered.ThenByDescending(e => e.EnrollmentId).Skip(q.Skip).Take(q.Take)
            .Select(ToDto).ToListAsync(ct);
        return new PagedResult<EnrollmentDto>(items, total, q.PageNumber, q.Take);
    }

    public async Task<EnrollmentDto> GetAsync(int id, CancellationToken ct)
        => await db.Enrollments.AsNoTracking().Where(e => e.EnrollmentId == id && !e.Customer.IsDeleted && !e.Course.IsDeleted && !e.Course.IsCompleted).Select(ToDto).FirstOrDefaultAsync(ct)
        ?? throw AppException.NotFound("Enrollment not found.");

    public async Task<EnrollmentDto> CreateAsync(CreateEnrollmentRequest r, CancellationToken ct)
    {
        var customer = await db.Customers.AsNoTracking().FirstOrDefaultAsync(c => c.CustomerId == r.CustomerId && !c.IsDeleted, ct)
            ?? throw AppException.BadRequest("Selected student does not exist.", "STUDENT_NOT_FOUND");
        var course = await db.Courses.AsNoTracking().FirstOrDefaultAsync(c => c.CourseId == r.CourseId && !c.IsDeleted, ct)
            ?? throw AppException.BadRequest("Selected course does not exist.", "COURSE_NOT_FOUND");

        if (course.IsCompleted) throw AppException.BadRequest("This course is completed and cannot accept new students.", "COURSE_COMPLETED");
        if (!customer.IsActive) throw AppException.BadRequest("This student is inactive. Activate the student before enrolling.", "STUDENT_INACTIVE");
        if (!course.IsActive) throw AppException.BadRequest("This course is inactive and cannot accept new students.", "COURSE_INACTIVE");

        ValidateDates(r.StartDate, r.EndDate);

        // The seat check and the insert run in one transaction, with the course row locked, so two people
        // registering the last seat at the same moment cannot both succeed.
        await using var tx = await db.Database.BeginTransactionAsync(ct);
        await db.LockCourseAsync(r.CourseId, ct);
        if (await ActiveDuplicateExistsAsync(r.CustomerId, r.CourseId, null, ct))
            throw AppException.Conflict("This student is already registered in this course.", "ENROLLMENT_EXISTS");
        await EnsureSeatAvailableAsync(course, null, ct);

        var enrollment = new Enrollment
        {
            CustomerId = r.CustomerId,
            CourseId = r.CourseId,
            EnrollmentDate = (r.EnrollmentDate ?? DateTime.Today).Date,
            StartDate = r.StartDate?.Date,
            EndDate = r.EndDate?.Date,
            TotalAmount = r.TotalAmount ?? course.Price, // the backend decides the default; the client cannot omit it silently
            Status = EnrollmentStatus.Active
        };
        db.Enrollments.Add(enrollment);
        await db.SaveOrFailAsync(log, "Registration could not be saved.", ct);
        await notifications.NotifyCourseFullIfNeededAsync(r.CourseId, enrollment.EnrollmentId, ct); // same transaction as the seat
        await tx.CommitAsync(ct);
        return await GetAsync(enrollment.EnrollmentId, ct);
    }

    public async Task<EnrollmentDto> UpdateAsync(int id, UpdateEnrollmentRequest r, CancellationToken ct)
    {
        var enrollment = await db.Enrollments.FirstOrDefaultAsync(e => e.EnrollmentId == id && !e.Customer.IsDeleted && !e.Course.IsDeleted && !e.Course.IsCompleted, ct)
            ?? throw AppException.NotFound("Enrollment not found.");

        ValidateDates(r.StartDate, r.EndDate);
        await using var tx = await db.Database.BeginTransactionAsync(ct);
        await db.LockCourseAsync(enrollment.CourseId, ct);
        await EnsureStatusChangeAllowedAsync(enrollment, r.Status, ct);

        enrollment.EnrollmentDate = r.EnrollmentDate!.Value.Date;
        enrollment.StartDate = r.StartDate?.Date;
        enrollment.EndDate = r.EndDate?.Date;
        enrollment.TotalAmount = r.TotalAmount;
        enrollment.Status = r.Status;
        await db.SaveOrFailAsync(log, "Registration could not be updated.", ct);
        if (r.Status == EnrollmentStatus.Active) await notifications.NotifyCourseFullIfNeededAsync(enrollment.CourseId, enrollment.EnrollmentId, ct);
        await tx.CommitAsync(ct);
        return await GetAsync(id, ct);
    }

    public async Task<EnrollmentDto> SetStatusAsync(int id, string status, CancellationToken ct)
    {
        var enrollment = await db.Enrollments.FirstOrDefaultAsync(e => e.EnrollmentId == id && !e.Customer.IsDeleted && !e.Course.IsDeleted && !e.Course.IsCompleted, ct)
            ?? throw AppException.NotFound("Enrollment not found.");

        await using var tx = await db.Database.BeginTransactionAsync(ct);
        await db.LockCourseAsync(enrollment.CourseId, ct);
        await EnsureStatusChangeAllowedAsync(enrollment, status, ct);
        enrollment.Status = status;
        await db.SaveOrFailAsync(log, "Registration status could not be changed.", ct);
        if (status == EnrollmentStatus.Active) await notifications.NotifyCourseFullIfNeededAsync(enrollment.CourseId, enrollment.EnrollmentId, ct);
        await tx.CommitAsync(ct);
        return await GetAsync(id, ct);
    }

    private async Task EnsureStatusChangeAllowedAsync(Enrollment enrollment, string newStatus, CancellationToken ct)
    {
        if (!EnrollmentStatus.All.Contains(newStatus))
            throw AppException.BadRequest("Status must be Active, Completed or Cancelled.", "INVALID_STATUS");

        // Reactivating must not create a second active enrollment for the same student and course.
        if (newStatus == EnrollmentStatus.Active && enrollment.Status != EnrollmentStatus.Active
            && await ActiveDuplicateExistsAsync(enrollment.CustomerId, enrollment.CourseId, enrollment.EnrollmentId, ct))
            throw AppException.Conflict("This student is already registered in this course.", "ENROLLMENT_EXISTS");

        // Putting a student back into a course needs a free seat in an active course.
        if (newStatus == EnrollmentStatus.Active && enrollment.Status != EnrollmentStatus.Active)
        {
            var course = await db.Courses.AsNoTracking().FirstAsync(c => c.CourseId == enrollment.CourseId, ct);
            if (!course.IsActive) throw AppException.BadRequest("This course is inactive and cannot accept new students.", "COURSE_INACTIVE");
            await EnsureSeatAvailableAsync(course, enrollment.EnrollmentId, ct);
        }
    }

    private async Task EnsureSeatAvailableAsync(Course course, int? excludeEnrollmentId, CancellationToken ct)
    {
        var exclude = excludeEnrollmentId ?? 0;
        var enrolled = await db.Enrollments.CountAsync(e => e.CourseId == course.CourseId
            && e.Status == EnrollmentStatus.Active && !e.Customer.IsDeleted && e.EnrollmentId != exclude, ct);
        if (enrolled >= course.MaxCapacity)
            throw AppException.Conflict($"This course is full ({enrolled} / {course.MaxCapacity}).", "COURSE_FULL");
    }

    private static void ValidateDates(DateTime? start, DateTime? end)
    {
        if (start.HasValue && end.HasValue && end.Value.Date < start.Value.Date)
            throw AppException.BadRequest("End date cannot be before the start date.", "INVALID_DATES");
    }

    private Task<bool> ActiveDuplicateExistsAsync(int customerId, int courseId, int? excludeId, CancellationToken ct)
    {
        var exclude = excludeId ?? 0;
        return db.Enrollments.AnyAsync(e => e.CustomerId == customerId && e.CourseId == courseId
            && e.Status == EnrollmentStatus.Active && e.EnrollmentId != exclude, ct);
    }
}
