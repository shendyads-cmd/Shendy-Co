using GermanCenter.Api.Data;
using GermanCenter.Api.DTOs;
using GermanCenter.Api.Middleware;
using GermanCenter.Api.Utilities;

namespace GermanCenter.Api.Services;

/// <summary>
/// An additional (usually partial) payment on an existing invoice.
///   Payment -> Cash In (Transactions INCOME) -> invoice status, all in ONE database transaction: if any step fails nothing is saved.
///   The invoice row is locked first, so two payments entered at the same moment can never together exceed the invoice total.
///   The status (Unpaid / Partially Paid / Paid) is recalculated by SQL from the real PaymentAllocations, never taken from the browser.
/// Duplicates: the Idempotency-Key (see the controller) stops a repeated request; UX_Transactions_payment stops a second Cash In per payment.
/// </summary>
public class PaymentService(AppDbContext db, ProofStorage proofs, PaymentSchemaGuard guard, FinanceSchemaGuard finance, NotificationService notifications)
{
    private const decimal MaxAmount = 99_999_999.99m;

    public async Task<PaymentResultDto> AddAsync(int invoiceId, InvoicePaymentRequest r, IFormFile? proof, int userId, CancellationToken ct)
    {
        var method = (r.PaymentMethod ?? "").Trim();
        if (!InvoiceService.Methods.Contains(method)) throw AppException.BadRequest("Choose Cash or InstaPay as the payment method.", "PAYMENT_METHOD");
        if (r.Amount <= 0) throw AppException.BadRequest("Enter an amount greater than zero.", "AMOUNT");
        var amount = Math.Round(r.Amount, 2, MidpointRounding.AwayFromZero);
        if (amount <= 0) throw AppException.BadRequest("Enter an amount greater than zero.", "AMOUNT");
        if (amount > MaxAmount) throw AppException.BadRequest("The amount is too large.", "AMOUNT");
        if (proof != null && method != "InstaPay") throw AppException.BadRequest("A payment proof can only be attached to InstaPay payments.", "PROOF_METHOD");

        await guard.EnsureAsync(ct);
        await finance.EnsureAsync(ct);

        ProofStorage.SavedProof? saved = proof != null ? await proofs.SaveAsync(proof, ct) : null;
        try
        {
            await using var tx = await db.Database.BeginTransactionAsync(ct);

            // lock the invoice: payments on the same invoice are processed one after the other
            var head = await db.QueryAsync("SELECT invoice_number, total_amount, status FROM Invoices WITH (UPDLOCK, ROWLOCK) WHERE invoice_id = @id",
                x => (Number: x.GetString(0), Total: x.GetDecimal(1), Status: x.GetString(2)), ct, ("@id", invoiceId));
            if (head.Count == 0) throw AppException.NotFound("Invoice not found.");
            var h = head[0];
            if (h.Status == "Cancelled") throw AppException.Conflict("A cancelled invoice cannot receive payments.", "INVOICE_CANCELLED");

            var paidBefore = await db.ScalarAsync<decimal>("SELECT ISNULL(SUM(allocated_amount), 0) FROM PaymentAllocations WHERE invoice_id = @id", ct, ("@id", invoiceId));
            var remaining = h.Total - paidBefore;
            if (remaining <= 0) throw AppException.Conflict("This invoice is already fully paid.", "INVOICE_PAID");
            if (amount > remaining) throw AppException.BadRequest($"The amount cannot be more than the remaining balance ({remaining:0.##}).", "OVERPAYMENT");

            var now = DateTime.Now;
            var paymentId = await db.InsertAsync(
                @"INSERT INTO Payments (payment_date, amount, payment_method, user_id, reference, payment_method_other, proof_file_name, proof_stored_name, proof_content_type)
                  VALUES (@date, @amount, @method, @by, NULL, NULL, @proofName, @proofStored, @proofType);
                  SELECT CAST(SCOPE_IDENTITY() AS int);", ct,
                ("@date", now), ("@amount", amount), ("@method", method), ("@by", userId),
                ("@proofName", saved?.OriginalName), ("@proofStored", saved?.StoredName), ("@proofType", saved?.ContentType));
            await db.ExecuteAsync("INSERT INTO PaymentAllocations (payment_id, invoice_id, allocated_amount) VALUES (@p, @i, @a)", ct,
                ("@p", paymentId), ("@i", invoiceId), ("@a", amount));
            // Cash In
            await db.ExecuteAsync("INSERT INTO Transactions (transaction_type, amount, related_payment_id, related_expense_id, related_payroll_id, transaction_date) VALUES ('INCOME', @a, @p, NULL, NULL, @d)", ct,
                ("@a", amount), ("@p", paymentId), ("@d", now));

            await RecalculateStatusAsync(invoiceId, ct);

            var paidNow = await db.ScalarAsync<decimal>("SELECT ISNULL(SUM(allocated_amount), 0) FROM PaymentAllocations WHERE invoice_id = @id", ct, ("@id", invoiceId));
            var status = await db.ScalarAsync<string>("SELECT status FROM Invoices WHERE invoice_id = @id", ct, ("@id", invoiceId)) ?? h.Status;

            await notifications.NotifyPaymentReceivedAsync(paymentId, h.Number, amount, method, h.Total - paidNow, ct);
            if (status == InvoiceService.PayStatus.Paid) await notifications.NotifyInvoicePaidAsync(invoiceId, paymentId, h.Number, ct);

            await tx.CommitAsync(ct);
            return new PaymentResultDto(paymentId, invoiceId, h.Number, amount, method, now, h.Total, paidNow, h.Total - paidNow, status);
        }
        catch
        {
            proofs.Delete(saved?.StoredName);
            throw;
        }
    }

    /// <summary>
    /// Sets Invoices.status from the real data: the sum of PaymentAllocations against total_amount
    /// (nothing paid -> Unpaid, everything paid or a total of 0 -> Paid, otherwise Partially Paid). Cancelled invoices keep their status.
    /// Must run inside the caller's transaction.
    /// </summary>
    public Task RecalculateStatusAsync(int invoiceId, CancellationToken ct)
        => db.ExecuteAsync(
            @"UPDATE i SET status = CASE WHEN i.total_amount = 0 THEN 'Paid'
                                         WHEN p.paid = 0 THEN 'Unpaid'
                                         WHEN p.paid >= i.total_amount THEN 'Paid'
                                         ELSE 'Partially Paid' END
              FROM Invoices i
              CROSS APPLY (SELECT ISNULL(SUM(a.allocated_amount), 0) AS paid FROM PaymentAllocations a WHERE a.invoice_id = i.invoice_id) p
              WHERE i.invoice_id = @id AND i.status <> 'Cancelled'", ct, ("@id", invoiceId));
}
