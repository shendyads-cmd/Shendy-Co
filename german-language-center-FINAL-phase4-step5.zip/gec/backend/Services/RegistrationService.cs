using GermanCenter.Api.Data;
using GermanCenter.Api.DTOs;
using GermanCenter.Api.Models;
using Microsoft.EntityFrameworkCore;

namespace GermanCenter.Api.Services;

/// <summary>
/// Single-student registration (kept for existing clients and tests). It is a thin wrapper: the work is done by InvoiceService,
/// so a student registration and the new Student / Offer invoices share one implementation.
/// </summary>
public class RegistrationService(InvoiceService invoices, AppDbContext db)
{
    public static readonly string[] Methods = InvoiceService.Methods;

    public async Task<RegistrationResultDto> RegisterAsync(RegisterStudentForm f, int userId, CancellationToken ct)
    {
        var request = new InvoiceCreateRequest
        {
            Type = "Student",
            CourseId = f.CourseId,
            DiscountPercent = f.DiscountPercent,
            AmountPaid = f.AmountPaid,
            PaymentMethod = f.PaymentMethod,
            PaymentMethodOther = f.PaymentMethodOther,
            Students = { new InvoiceStudentInput { CustomerId = f.CustomerId, FullName = f.FullName, Phone = f.Phone, Email = f.Email, Area = f.Area } }
        };

        var invoiceId = await invoices.CreateAsync(request, f.Proof, userId, ct);
        var invoice = await invoices.GetAsync(invoiceId, ct);
        var student = invoice.Students[0];
        var item = invoice.Items[0];
        var payment = invoice.Payments.FirstOrDefault();
        var enrollmentId = await db.Enrollments.AsNoTracking()
            .Where(e => e.CustomerId == student.CustomerId && e.CourseId == item.CourseId && e.Status == EnrollmentStatus.Active)
            .OrderByDescending(e => e.EnrollmentId).Select(e => e.EnrollmentId).FirstAsync(ct);

        return new RegistrationResultDto(
            student.CustomerId, student.StudentCode, student.FullName, enrollmentId,
            invoice.InvoiceId, invoice.InvoiceNumber, invoice.IssueDate, item.CourseId, item.CourseCode, item.CourseName,
            item.UnitPrice, invoice.DiscountPercent, invoice.DiscountAmount, invoice.GrandTotal,
            invoice.AmountPaid, invoice.Remaining, invoice.PaymentStatus,
            payment?.PaymentId, payment?.PaymentMethod, payment?.PaymentMethodOther, payment?.PaymentDate, payment?.HasProof ?? false);
    }
}
