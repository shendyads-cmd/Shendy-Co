using GermanCenter.Api.Data;
using GermanCenter.Api.DTOs;
using GermanCenter.Api.Middleware;
using GermanCenter.Api.Utilities;

namespace GermanCenter.Api.Services;

/// <summary>
/// Dashboard and Reports. Every number is calculated by SQL Server from the real tables; the browser only draws what it receives.
/// The Dashboard and the "Financial summary" report call the SAME SummaryAsync, so they can never disagree.
/// Date window: From and To are inclusive and both optional (none, from only, to only, both); From > To is refused.
/// Cancelled invoices are left out of Sales / Outstanding / Course revenue.
/// </summary>
public class AnalyticsService(AppDbContext db, FinanceSchemaGuard guard)
{
    // ------------------------------------------------------------------ date window

    private sealed class Window
    {
        public DateTime? From { get; init; }
        public DateTime? ToExclusive { get; init; }

        /// <summary>" AND col >= @from AND col &lt; @toEx" for the dates that are present (empty when there is no filter).</summary>
        public string Sql(string col) => (From.HasValue ? $" AND {col} >= @from" : "") + (ToExclusive.HasValue ? $" AND {col} < @toEx" : "");

        /// <summary>For payroll periods (a whole month): the From date is moved to the first day of its month.</summary>
        public string SqlMonth(string col) => (From.HasValue ? $" AND {col} >= @fromMonth" : "") + (ToExclusive.HasValue ? $" AND {col} < @toEx" : "");

        public (string, object?)[] Args()
        {
            var a = new List<(string, object?)>();
            if (From.HasValue) { a.Add(("@from", From.Value)); a.Add(("@fromMonth", new DateTime(From.Value.Year, From.Value.Month, 1))); }
            if (ToExclusive.HasValue) a.Add(("@toEx", ToExclusive.Value));
            return a.ToArray();
        }
    }

    private static Window MakeWindow(DateTime? from, DateTime? to)
    {
        if (from.HasValue && to.HasValue && from.Value.Date > to.Value.Date)
            throw AppException.BadRequest("The start date must not be after the end date.", "DATE_RANGE");
        return new Window { From = from?.Date, ToExclusive = to?.Date.AddDays(1) };
    }

    private static (string, object?)[] With(Window w, params (string, object?)[] extra) => w.Args().Concat(extra).ToArray();

    // ------------------------------------------------------------------ financial summary (source of truth)

    public async Task<FinancialSummaryDto> SummaryAsync(DateTime? from, DateTime? to, CancellationToken ct)
    {
        var w = MakeWindow(from, to);
        return await SummaryAsync(w, ct);
    }

    private async Task<FinancialSummaryDto> SummaryAsync(Window w, CancellationToken ct)
    {
        await guard.EnsureAsync(ct);
        var args = w.Args();

        var sales = (await db.QueryAsync(
            $"SELECT ISNULL(SUM(i.total_amount), 0), COUNT(*) FROM Invoices i WHERE i.status <> 'Cancelled'{w.Sql("i.issue_date")}",
            r => (Sum: r.GetDecimal(0), Count: r.GetInt32(1)), ct, args))[0];

        var collected = (await db.QueryAsync(
            $@"SELECT ISNULL(SUM(a.allocated_amount), 0), COUNT(DISTINCT p.payment_id)
               FROM PaymentAllocations a JOIN Payments p ON p.payment_id = a.payment_id WHERE 1 = 1{w.Sql("p.payment_date")}",
            r => (Sum: r.GetDecimal(0), Count: r.GetInt32(1)), ct, args))[0];

        var outstanding = (await db.QueryAsync(
            $@"SELECT ISNULL(SUM(i.total_amount - p.paid), 0), COUNT(*)
               FROM Invoices i CROSS APPLY (SELECT ISNULL(SUM(a.allocated_amount), 0) AS paid FROM PaymentAllocations a WHERE a.invoice_id = i.invoice_id) p
               WHERE i.status <> 'Cancelled' AND i.total_amount > p.paid{w.Sql("i.issue_date")}",
            r => (Sum: r.GetDecimal(0), Count: r.GetInt32(1)), ct, args))[0];

        var expenses = (await db.QueryAsync(
            $"SELECT ISNULL(SUM(e.amount), 0), COUNT(*) FROM Expenses e WHERE 1 = 1{w.Sql("e.expense_date")}",
            r => (Sum: r.GetDecimal(0), Count: r.GetInt32(1)), ct, args))[0];

        var payroll = await db.ScalarAsync<decimal>(
            $"SELECT ISNULL(SUM(p.net_salary), 0) FROM PayrollEntries p WHERE p.status = 'Paid'{w.Sql("p.paid_at")}", ct, args);
        var pending = await db.ScalarAsync<decimal>(
            $"SELECT ISNULL(SUM(p.net_salary), 0) FROM PayrollEntries p WHERE p.status = 'Pending'{w.SqlMonth("DATEFROMPARTS(p.period_year, p.period_month, 1)")}", ct, args);

        var cash = await db.QueryAsync(
            $"SELECT t.transaction_type, ISNULL(SUM(t.amount), 0) FROM Transactions t WHERE 1 = 1{w.Sql("t.transaction_date")} GROUP BY t.transaction_type",
            r => (Type: r.GetString(0), Sum: r.GetDecimal(1)), ct, args);
        var cashIn = cash.Where(c => c.Type == "INCOME").Sum(c => c.Sum);
        var cashOut = cash.Where(c => c.Type == "EXPENSE").Sum(c => c.Sum);

        return new FinancialSummaryDto(w.From, w.ToExclusive?.AddDays(-1),
            sales.Sum, sales.Count, collected.Sum, collected.Count, outstanding.Sum, outstanding.Count,
            expenses.Sum, expenses.Count, payroll, pending,
            cashIn, cashOut, cashIn - cashOut, cashIn - collected.Sum, cashOut - (expenses.Sum + payroll));
    }

    // ------------------------------------------------------------------ course performance

    private async Task<List<CourseRowDto>> CourseRowsAsync(Window w, CancellationToken ct)
    {
        // Revenue and paid of an invoice are split between its courses by their share of the invoice subtotal
        // (normally an invoice has exactly one course, so the share is 100%). Paid comes from the real payment allocations.
        var rows = await db.QueryAsync(
            $@"WITH inv AS (
                   SELECT i.invoice_id, i.total_amount, i.subtotal, p.paid
                   FROM Invoices i
                   CROSS APPLY (SELECT ISNULL(SUM(a.allocated_amount), 0) AS paid FROM PaymentAllocations a WHERE a.invoice_id = i.invoice_id) p
                   WHERE i.status <> 'Cancelled'{w.Sql("i.issue_date")}
               ), part AS (
                   SELECT d.course_id, inv.total_amount, inv.paid,
                          CASE WHEN inv.subtotal = 0 THEN 0.0
                               ELSE CAST(d.quantity * d.unit_price AS float) / CAST(inv.subtotal AS float) END AS share
                   FROM InvoiceDetails d JOIN inv ON inv.invoice_id = d.invoice_id
               ), rev AS (
                   SELECT course_id,
                          CAST(ROUND(SUM(total_amount * share), 2) AS decimal(18, 2)) AS revenue,
                          CAST(ROUND(SUM(paid * share), 2) AS decimal(18, 2)) AS paid
                   FROM part GROUP BY course_id
               )
               SELECT c.course_id, c.course_code, c.course_name, c.max_capacity, c.is_active, c.is_completed, c.is_deleted,
                      (SELECT COUNT(*) FROM Enrollments e JOIN Customers cu ON cu.customer_id = e.customer_id WHERE e.course_id = c.course_id AND e.status = 'Active' AND cu.is_deleted = 0),
                      ISNULL(rev.revenue, 0), ISNULL(rev.paid, 0)
               FROM Courses c LEFT JOIN rev ON rev.course_id = c.course_id
               WHERE c.is_deleted = 0 OR ISNULL(rev.revenue, 0) > 0",
            r => (Id: r.GetInt32(0), Code: r.GetString(1), Name: r.GetString(2), Capacity: r.GetInt32(3), Active: r.GetBoolean(4),
                  Completed: r.GetBoolean(5), Deleted: r.GetBoolean(6), Enrolled: r.GetInt32(7), Revenue: r.GetDecimal(8), Paid: r.GetDecimal(9)),
            ct, w.Args());

        var ordered = rows.OrderByDescending(x => x.Revenue).ThenByDescending(x => x.Enrolled).ThenBy(x => x.Code, StringComparer.OrdinalIgnoreCase).ToList();
        var result = new List<CourseRowDto>();
        var rank = 0;
        foreach (var x in ordered)
        {
            // Deleted / Complete / Deactivated / Full / Open (Complete = finished by the administrator; it stays in the analysis)
            var status = x.Deleted ? "Deleted" : x.Completed ? "Complete" : !x.Active ? "Deactivated" : x.Enrolled >= x.Capacity ? "Full" : "Open";
            var occupancy = x.Capacity > 0 ? Math.Round(x.Enrolled * 100m / x.Capacity, 1) : 0m;
            result.Add(new CourseRowDto(x.Id, x.Code, x.Name, x.Capacity, x.Enrolled, occupancy, x.Revenue, x.Paid, Math.Max(0, x.Revenue - x.Paid), status, x.Revenue > 0 ? ++rank : 0));
        }
        return result;
    }

    public async Task<CourseReportDto> CoursesAsync(DateTime? from, DateTime? to, CancellationToken ct)
    {
        var rows = await CourseRowsAsync(MakeWindow(from, to), ct);
        return new CourseReportDto(rows, rows.Sum(r => r.Revenue), rows.Sum(r => r.Paid), rows.Sum(r => r.Remaining));
    }

    // ------------------------------------------------------------------ dashboard

    public async Task<DashboardDto> DashboardAsync(DateTime? from, DateTime? to, CancellationToken ct)
    {
        var w = MakeWindow(from, to);
        var summary = await SummaryAsync(w, ct);

        // trend window: the chosen period; with no From the last 24 months
        var today = DateTime.Today;
        var end = (to?.Date ?? today);
        var start = from?.Date ?? new DateTime(today.Year, today.Month, 1).AddMonths(-23);
        if (end < start) end = start;
        var monthly = (end - start).TotalDays > 62;
        if (monthly && start < end.AddMonths(-59)) start = end.AddMonths(-59); // never more than 60 points
        var tw = new Window { From = start, ToExclusive = end.AddDays(1) };

        string Bucket(string col) => monthly ? $"DATEFROMPARTS(YEAR({col}), MONTH({col}), 1)" : $"CAST({col} AS date)";
        async Task<Dictionary<DateTime, decimal>> SeriesAsync(string sql)
        {
            var list = await db.QueryAsync(sql, r => (Day: r.GetDateTime(0).Date, Sum: r.GetDecimal(1)), ct, tw.Args());
            return list.GroupBy(x => x.Day).ToDictionary(g => g.Key, g => g.Sum(x => x.Sum));
        }

        var sales = await SeriesAsync($"SELECT {Bucket("i.issue_date")}, ISNULL(SUM(i.total_amount), 0) FROM Invoices i WHERE i.status <> 'Cancelled'{tw.Sql("i.issue_date")} GROUP BY {Bucket("i.issue_date")}");
        var collected = await SeriesAsync($"SELECT {Bucket("p.payment_date")}, ISNULL(SUM(a.allocated_amount), 0) FROM PaymentAllocations a JOIN Payments p ON p.payment_id = a.payment_id WHERE 1 = 1{tw.Sql("p.payment_date")} GROUP BY {Bucket("p.payment_date")}");
        var cashIn = await SeriesAsync($"SELECT {Bucket("t.transaction_date")}, ISNULL(SUM(t.amount), 0) FROM Transactions t WHERE t.transaction_type = 'INCOME'{tw.Sql("t.transaction_date")} GROUP BY {Bucket("t.transaction_date")}");
        var cashOut = await SeriesAsync($"SELECT {Bucket("t.transaction_date")}, ISNULL(SUM(t.amount), 0) FROM Transactions t WHERE t.transaction_type = 'EXPENSE'{tw.Sql("t.transaction_date")} GROUP BY {Bucket("t.transaction_date")}");

        var trend = new List<TrendPointDto>();
        var cursor = monthly ? new DateTime(start.Year, start.Month, 1) : start;
        while (cursor <= end)
        {
            trend.Add(new TrendPointDto(cursor.ToString(monthly ? "yyyy-MM" : "yyyy-MM-dd"),
                sales.GetValueOrDefault(cursor), collected.GetValueOrDefault(cursor), cashIn.GetValueOrDefault(cursor), cashOut.GetValueOrDefault(cursor)));
            cursor = monthly ? cursor.AddMonths(1) : cursor.AddDays(1);
        }

        var courses = await CourseRowsAsync(w, ct);
        var top = courses.Where(c => c.Revenue > 0).Take(5).ToList();
        var open = courses.Where(c => c.Status is "Open" or "Full").ToList();
        var occupancy = open.OrderByDescending(c => c.OccupancyPercent).ThenBy(c => c.Code).Take(8).ToList();
        var students = await db.ScalarAsync<int>("SELECT COUNT(*) FROM Customers WHERE is_deleted = 0 AND is_active = 1", ct);

        return new DashboardDto(summary, monthly ? "month" : "day", trend, top, occupancy, open.Count, students);
    }

    // ------------------------------------------------------------------ report tabs

    private const string StudentLabelSql =
        @"(SELECT COUNT(*) FROM InvoiceCustomers x WHERE x.invoice_id = i.invoice_id),
          (SELECT TOP 1 c.full_name FROM InvoiceCustomers x JOIN Customers c ON c.customer_id = x.customer_id WHERE x.invoice_id = i.invoice_id ORDER BY x.invoice_customer_id)";
    private const string CourseLabelSql =
        "(SELECT TOP 1 co.course_code + ' - ' + co.course_name FROM InvoiceDetails d JOIN Courses co ON co.course_id = d.course_id WHERE d.invoice_id = i.invoice_id ORDER BY d.invoice_detail_id)";

    private static string Label(int count, string? first) => count > 1 ? $"{first ?? "-"} +{count - 1}" : first ?? "-";

    public async Task<SalesReportDto> SalesAsync(ReportQuery q, CancellationToken ct)
    {
        var w = MakeWindow(q.FromDate, q.ToDate);
        var where = $"WHERE i.status <> 'Cancelled'{w.Sql("i.issue_date")}";
        var totals = (await db.QueryAsync(
            $"SELECT COUNT(*), ISNULL(SUM(i.subtotal), 0), ISNULL(SUM(i.discount_amount), 0), ISNULL(SUM(i.total_amount), 0) FROM Invoices i {where}",
            r => (Count: r.GetInt32(0), Sub: r.GetDecimal(1), Disc: r.GetDecimal(2), Total: r.GetDecimal(3)), ct, w.Args()))[0];

        var items = await db.QueryAsync(
            $@"SELECT i.invoice_id, i.invoice_number, i.issue_date, i.subtotal, i.discount_amount, i.total_amount, i.status,
                      ISNULL((SELECT SUM(a.allocated_amount) FROM PaymentAllocations a WHERE a.invoice_id = i.invoice_id), 0),
                      {StudentLabelSql}, {CourseLabelSql}
               FROM Invoices i {where}
               ORDER BY i.issue_date DESC, i.invoice_id DESC OFFSET @skip ROWS FETCH NEXT @take ROWS ONLY",
            r =>
            {
                var count = r.GetInt32(8);
                return new SalesRowDto(r.GetInt32(0), r.GetString(1), r.GetDateTime(2), count > 1 ? "Offer" : "Student", Label(count, r.GetStringOrNull(9)),
                    r.GetStringOrNull(10) ?? "-", r.GetDecimal(3), r.GetDecimal(4), r.GetDecimal(5), r.GetDecimal(7), r.GetString(6));
            }, ct, With(w, ("@skip", q.Skip), ("@take", q.Take)));
        return new SalesReportDto(items, totals.Count, q.PageNumber, q.Take, totals.Sub, totals.Disc, totals.Total);
    }

    public async Task<PaymentsReportDto> PaymentsAsync(ReportQuery q, CancellationToken ct)
    {
        var w = MakeWindow(q.FromDate, q.ToDate);
        var src = $"FROM PaymentAllocations a JOIN Payments p ON p.payment_id = a.payment_id JOIN Invoices i ON i.invoice_id = a.invoice_id WHERE 1 = 1{w.Sql("p.payment_date")}";
        var totals = (await db.QueryAsync($"SELECT COUNT(*), ISNULL(SUM(a.allocated_amount), 0) {src}",
            r => (Count: r.GetInt32(0), Sum: r.GetDecimal(1)), ct, w.Args()))[0];
        var byMethod = await db.QueryAsync(
            $"SELECT p.payment_method, COUNT(*), ISNULL(SUM(a.allocated_amount), 0) {src} GROUP BY p.payment_method ORDER BY SUM(a.allocated_amount) DESC",
            r => new MethodTotalDto(r.GetString(0), r.GetInt32(1), r.GetDecimal(2)), ct, w.Args());
        var items = await db.QueryAsync(
            $@"SELECT p.payment_id, p.payment_date, i.invoice_id, i.invoice_number, p.payment_method, p.payment_method_other, a.allocated_amount,
                      CASE WHEN p.proof_stored_name IS NULL THEN 0 ELSE 1 END, i.status, {StudentLabelSql}
               {src} ORDER BY p.payment_date DESC, p.payment_id DESC OFFSET @skip ROWS FETCH NEXT @take ROWS ONLY",
            r => new PaymentRowDto(r.GetInt32(0), r.GetDateTime(1), r.GetInt32(2), r.GetString(3), Label(r.GetInt32(9), r.GetStringOrNull(10)),
                r.GetString(4), r.GetStringOrNull(5), r.GetDecimal(6), r.GetInt32(7) == 1, r.GetString(8)), ct, With(w, ("@skip", q.Skip), ("@take", q.Take)));
        return new PaymentsReportDto(items, totals.Count, q.PageNumber, q.Take, totals.Sum, byMethod);
    }

    public async Task<ExpenseReportDto> ExpensesAsync(ReportQuery q, CancellationToken ct)
    {
        await guard.EnsureAsync(ct);
        var w = MakeWindow(q.FromDate, q.ToDate);
        var src = $"FROM Expenses e WHERE 1 = 1{w.Sql("e.expense_date")}";
        var totals = (await db.QueryAsync(
            $@"SELECT COUNT(*), ISNULL(SUM(e.amount), 0),
                      SUM(CASE WHEN NOT EXISTS (SELECT 1 FROM Transactions t WHERE t.related_expense_id = e.expense_id) THEN 1 ELSE 0 END) {src}",
            r => (Count: r.GetInt32(0), Sum: r.GetDecimal(1), Missing: r.IsDBNull(2) ? 0 : r.GetInt32(2)), ct, w.Args()))[0];
        var byCategory = await db.QueryAsync($"SELECT e.category, COUNT(*), ISNULL(SUM(e.amount), 0) {src} GROUP BY e.category ORDER BY SUM(e.amount) DESC",
            r => new CategoryTotalDto(r.GetString(0), r.GetInt32(1), r.GetDecimal(2)), ct, w.Args());
        var items = await db.QueryAsync(
            $@"SELECT e.expense_id, e.expense_date, e.category, e.expense_title, e.description, e.amount, u.full_name,
                      (SELECT TOP 1 t.transaction_id FROM Transactions t WHERE t.related_expense_id = e.expense_id ORDER BY t.transaction_id)
               FROM Expenses e LEFT JOIN Users u ON u.user_id = e.user_id WHERE 1 = 1{w.Sql("e.expense_date")}
               ORDER BY e.expense_date DESC, e.expense_id DESC OFFSET @skip ROWS FETCH NEXT @take ROWS ONLY",
            r => new ExpenseReportRowDto(r.GetInt32(0), r.GetDateTime(1), r.GetString(2), r.GetString(3), r.GetStringOrNull(4), r.GetDecimal(5),
                r.GetStringOrNull(6), r.IsDBNull(7) ? null : r.GetInt32(7)), ct, With(w, ("@skip", q.Skip), ("@take", q.Take)));
        return new ExpenseReportDto(items, totals.Count, q.PageNumber, q.Take, totals.Sum, totals.Missing, byCategory);
    }

    public async Task<OutstandingReportDto> OutstandingAsync(ReportQuery q, CancellationToken ct)
    {
        var w = MakeWindow(q.FromDate, q.ToDate);
        var src = $@"FROM Invoices i
                      CROSS APPLY (SELECT ISNULL(SUM(a.allocated_amount), 0) AS paid FROM PaymentAllocations a WHERE a.invoice_id = i.invoice_id) p
                      WHERE i.status <> 'Cancelled' AND i.total_amount > p.paid{w.Sql("i.issue_date")}";
        var totals = (await db.QueryAsync($"SELECT COUNT(*), ISNULL(SUM(i.total_amount), 0), ISNULL(SUM(p.paid), 0), ISNULL(SUM(i.total_amount - p.paid), 0) {src}",
            r => (Count: r.GetInt32(0), Grand: r.GetDecimal(1), Paid: r.GetDecimal(2), Rest: r.GetDecimal(3)), ct, w.Args()))[0];
        var items = await db.QueryAsync(
            $@"SELECT i.invoice_id, i.invoice_number, i.issue_date, i.total_amount, p.paid, i.status, {StudentLabelSql}, {CourseLabelSql}
               {src} ORDER BY (i.total_amount - p.paid) DESC, i.issue_date, i.invoice_id OFFSET @skip ROWS FETCH NEXT @take ROWS ONLY",
            r =>
            {
                var count = r.GetInt32(6);
                return new OutstandingRowDto(r.GetInt32(0), r.GetString(1), r.GetDateTime(2), count > 1 ? "Offer" : "Student", Label(count, r.GetStringOrNull(7)),
                    r.GetStringOrNull(8) ?? "-", r.GetDecimal(3), r.GetDecimal(4), r.GetDecimal(3) - r.GetDecimal(4), r.GetString(5));
            }, ct, With(w, ("@skip", q.Skip), ("@take", q.Take)));
        return new OutstandingReportDto(items, totals.Count, q.PageNumber, q.Take, totals.Grand, totals.Paid, totals.Rest);
    }

    /// <summary>Salary entries of the months inside the period (a month counts when its first day is inside the window; From is moved to the first of its month).</summary>
    public async Task<PayrollPageDto> PayrollAsync(ReportQuery q, CancellationToken ct)
    {
        await guard.EnsureAsync(ct);
        var w = MakeWindow(q.FromDate, q.ToDate);
        var src = $"FROM PayrollEntries p JOIN PayrollEmployees e ON e.employee_id = p.employee_id WHERE 1 = 1{w.SqlMonth("DATEFROMPARTS(p.period_year, p.period_month, 1)")}";
        var totals = (await db.QueryAsync(
            $@"SELECT COUNT(*), ISNULL(SUM(p.net_salary), 0),
                      ISNULL(SUM(CASE WHEN p.status = 'Paid' THEN p.net_salary END), 0),
                      ISNULL(SUM(CASE WHEN p.status = 'Pending' THEN p.net_salary END), 0) {src}",
            r => (Count: r.GetInt32(0), Net: r.GetDecimal(1), Paid: r.GetDecimal(2), Pending: r.GetDecimal(3)), ct, w.Args()))[0];
        var items = await db.QueryAsync(
            $@"SELECT p.payroll_id, p.employee_id, e.full_name, p.period_year, p.period_month, p.base_salary, p.bonus, p.deductions, p.net_salary, p.status, p.notes, p.paid_at
               {src} ORDER BY p.period_year DESC, p.period_month DESC, e.full_name, p.payroll_id DESC OFFSET @skip ROWS FETCH NEXT @take ROWS ONLY",
            r => new PayrollEntryDto(r.GetInt32(0), r.GetInt32(1), r.GetString(2), r.GetInt16(3), r.GetByte(4), r.GetDecimal(5), r.GetDecimal(6), r.GetDecimal(7),
                r.GetDecimal(8), r.GetString(9), r.GetStringOrNull(10), r.GetDateTimeOrNull(11)), ct, With(w, ("@skip", q.Skip), ("@take", q.Take)));
        return new PayrollPageDto(items, totals.Count, q.PageNumber, q.Take, totals.Net, totals.Paid, totals.Pending);
    }
}
