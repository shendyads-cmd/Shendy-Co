using System.Text.RegularExpressions;
using GermanCenter.Api.Data;
using GermanCenter.Api.DTOs;
using GermanCenter.Api.Middleware;
using GermanCenter.Api.Models;
using GermanCenter.Api.Utilities;
using Microsoft.EntityFrameworkCore;

namespace GermanCenter.Api.Services;

/// <summary>
/// Student / Offer invoices: preview, save, edit, list and read. All money is calculated here (never trusted from the browser)
/// and every write is one database transaction. An Offer is ONE invoice linked to all of its students.
/// </summary>
public class InvoiceService(
    AppDbContext db, CustomerService customers, ProofStorage proofs, PaymentSchemaGuard guard, NotificationService notifications, ILogger<InvoiceService> log)
{
    // NEW payments: Cash and InstaPay only. Historical Visa / Bank Transfer / Vodafone Cash / Other rows stay in the database and stay readable.
    public static readonly string[] Methods = { "Cash", "InstaPay" };

    public static class PayStatus
    {
        public const string Unpaid = "Unpaid";
        public const string Partial = "Partially Paid";
        public const string Paid = "Paid";
    }

    private static readonly Regex PhoneRx = new(@"^[0-9+()\-\s]{6,30}$", RegexOptions.Compiled);
    private static readonly Regex EmailRx = new(@"^[^\s@]+@[^\s@]+\.[^\s@]+$", RegexOptions.Compiled);

    // ------------------------------------------------------------------ money

    public sealed record Money(decimal UnitPrice, int Quantity, decimal Subtotal, decimal Percent, decimal DiscountAmount, decimal Total);

    public static Money Calculate(decimal unitPrice, int quantity, decimal discountPercent)
    {
        if (discountPercent < 0 || discountPercent > 100) throw AppException.BadRequest("Invalid discount percentage.", "DISCOUNT");
        var percent = Math.Round(discountPercent, 2, MidpointRounding.AwayFromZero);
        var subtotal = Math.Round(unitPrice * quantity, 2, MidpointRounding.AwayFromZero);
        var discount = Math.Round(subtotal * percent / 100m, 2, MidpointRounding.AwayFromZero);
        return new Money(unitPrice, quantity, subtotal, percent, discount, subtotal - discount);
    }

    /// <summary>Nothing paid -> Unpaid; paid >= total -> Paid (a 100% discount leaves nothing to pay, so it is Paid).</summary>
    public static string StatusFor(decimal paid, decimal total)
        => total == 0 ? PayStatus.Paid : paid == 0 ? PayStatus.Unpaid : paid >= total ? PayStatus.Paid : PayStatus.Partial;

    // ------------------------------------------------------------------ validation helpers

    private sealed record Prepared(int? CustomerId, string? FullName, string? Phone, string? Email, string? Area);

    private static void ValidateType(string type, int count)
    {
        if (type == "Student" && count != 1) throw AppException.BadRequest("A student registration needs exactly one student.", "STUDENT_COUNT");
        if (type == "Offer" && count < 2) throw AppException.BadRequest("An offer needs at least two students.", "STUDENT_COUNT");
        if (type != "Student" && type != "Offer") throw AppException.BadRequest("The registration type must be Student or Offer.", "TYPE");
    }

    /// <summary>Validates every student card (format, duplicates inside the request and in the database).</summary>
    private async Task<List<Prepared>> PrepareStudentsAsync(List<InvoiceStudentInput> input, int? invoiceId, CancellationToken ct)
    {
        if (input.Count == 0) throw AppException.BadRequest("Add at least one student.", "STUDENT_COUNT");
        if (input.Count > 200) throw AppException.BadRequest("Too many students on one invoice.", "STUDENT_COUNT");

        var result = new List<Prepared>();
        var phones = new HashSet<string>();
        var emails = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        var ids = new HashSet<int>();
        var number = 0;
        foreach (var s in input)
        {
            number++;
            if (s.CustomerId is int id)
            {
                if (!ids.Add(id)) throw AppException.BadRequest($"Student {number} is added twice.", "STUDENT_DUPLICATE");
                result.Add(new Prepared(id, null, null, null, null));
                continue;
            }
            var name = s.FullName?.Trim();
            var phone = s.Phone?.Trim();
            var email = s.Email.NullIfBlank();
            var area = s.Area.NullIfBlank();
            if (string.IsNullOrEmpty(name) || name.Length < 2 || name.Length > 150) throw AppException.BadRequest($"Student {number}: enter the full name.", "FULL_NAME");
            if (string.IsNullOrEmpty(phone) || !PhoneRx.IsMatch(phone)) throw AppException.BadRequest($"Student {number}: enter a valid phone number.", "PHONE");
            if (email != null && (!EmailRx.IsMatch(email) || email.Length > 150)) throw AppException.BadRequest($"Student {number}: the email address is not valid.", "EMAIL");
            if (area != null && area.Length > 100) throw AppException.BadRequest($"Student {number}: the area is too long.", "AREA");
            if (!phones.Add(phone)) throw AppException.BadRequest($"Student {number}: this phone number is used twice in the list.", "PHONE_DUPLICATE");
            if (email != null && !emails.Add(email)) throw AppException.BadRequest($"Student {number}: this email is used twice in the list.", "EMAIL_DUPLICATE");
            await customers.EnsureUniqueAsync(null, phone, email, ct);
            result.Add(new Prepared(null, name, phone, email, area));
        }
        return result;
    }

    private async Task<Course> LoadBookableCourseAsync(int courseId, CancellationToken ct)
    {
        var course = await db.Courses.AsNoTracking().FirstOrDefaultAsync(c => c.CourseId == courseId && !c.IsDeleted, ct)
            ?? throw AppException.BadRequest("Course could not be loaded.", "COURSE_NOT_FOUND");
        if (course.IsCompleted) throw AppException.BadRequest("This course is completed and cannot accept new students.", "COURSE_COMPLETED");
        if (!course.IsActive) throw AppException.BadRequest("This course is deactivated and cannot accept new students.", "COURSE_INACTIVE");
        return course;
    }

    private Task<int> SeatsTakenAsync(int courseId, CancellationToken ct)
        => db.Enrollments.CountAsync(e => e.CourseId == courseId && e.Status == EnrollmentStatus.Active && !e.Customer.IsDeleted, ct);

    private static void RequireMethod(string method)
    {
        if (!Methods.Contains(method)) throw AppException.BadRequest("Choose Cash or InstaPay as the payment method.", "PAYMENT_METHOD");
    }

    // ------------------------------------------------------------------ preview (no writes)

    public async Task<InvoicePreviewDto> PreviewAsync(InvoiceCreateRequest r, CancellationToken ct)
    {
        ValidateType(r.Type, r.Students.Count);
        RequireMethod(r.PaymentMethod);
        var prepared = await PrepareStudentsAsync(r.Students, null, ct);
        var course = await LoadBookableCourseAsync(r.CourseId, ct);

        var existing = prepared.Where(p => p.CustomerId.HasValue).Select(p => p.CustomerId!.Value).ToList();
        var names = new List<string>();
        foreach (var p in prepared)
        {
            if (p.CustomerId is int id)
            {
                var c = await db.Customers.AsNoTracking().FirstOrDefaultAsync(x => x.CustomerId == id && !x.IsDeleted, ct)
                    ?? throw AppException.BadRequest("Selected student does not exist.", "STUDENT_NOT_FOUND");
                if (!c.IsActive) throw AppException.BadRequest($"{c.FullName} is inactive.", "STUDENT_INACTIVE");
                if (await db.Enrollments.AnyAsync(e => e.CustomerId == id && e.CourseId == course.CourseId && e.Status == EnrollmentStatus.Active, ct))
                    throw AppException.Conflict($"{c.FullName} is already registered in this course.", "ENROLLMENT_EXISTS");
                names.Add(c.FullName);
            }
            else names.Add(p.FullName!);
        }

        var left = course.MaxCapacity - await SeatsTakenAsync(course.CourseId, ct);
        if (prepared.Count > left)
            throw AppException.Conflict(left <= 0 ? "This course is full." : $"Only {left} seat(s) are left in this course.", "COURSE_FULL");

        var money = Calculate(course.Price, prepared.Count, r.DiscountPercent);
        var paid = Math.Round(r.AmountPaid, 2, MidpointRounding.AwayFromZero);
        if (paid < 0) throw AppException.BadRequest("Amount paid cannot be negative.", "AMOUNT_PAID");
        if (paid > money.Total) throw AppException.BadRequest($"Amount paid cannot be more than the grand total ({money.Total:0.##}).", "OVERPAYMENT");

        return new InvoicePreviewDto(r.Type, course.CourseId, course.CourseCode, course.CourseName, prepared.Count, course.Price, money.Subtotal,
            money.Percent, money.DiscountAmount, money.Total, paid, money.Total - paid, StatusFor(paid, money.Total),
            paid > 0 ? r.PaymentMethod : null, null, DateTime.Now, names);
    }

    // ------------------------------------------------------------------ create

    /// <summary>Saves the students (new ones are created), their enrollments, ONE invoice and its payment. Returns the invoice id.</summary>
    public async Task<int> CreateAsync(InvoiceCreateRequest r, IFormFile? proof, int userId, CancellationToken ct)
    {
        ValidateType(r.Type, r.Students.Count);
        RequireMethod(r.PaymentMethod);
        var paid = Math.Round(r.AmountPaid, 2, MidpointRounding.AwayFromZero);
        var proofAllowed = r.PaymentMethod == "InstaPay";
        if (proof != null && !proofAllowed) throw AppException.BadRequest("A payment proof can only be attached to InstaPay payments.", "PROOF_METHOD");
        if (proof != null && paid <= 0) throw AppException.BadRequest("Enter the amount paid before attaching a payment proof.", "PROOF_NO_PAYMENT");

        await guard.EnsureAsync(ct);
        var prepared = await PrepareStudentsAsync(r.Students, null, ct);
        var course = await LoadBookableCourseAsync(r.CourseId, ct);
        var money = Calculate(course.Price, prepared.Count, r.DiscountPercent);
        if (paid < 0) throw AppException.BadRequest("Amount paid cannot be negative.", "AMOUNT_PAID");
        if (paid > money.Total) throw AppException.BadRequest($"Amount paid cannot be more than the grand total ({money.Total:0.##}).", "OVERPAYMENT");
        var status = StatusFor(paid, money.Total);
        string? otherText = null; // the free-text "Other" method no longer exists for new payments

        ProofStorage.SavedProof? saved = null;
        if (proof != null) saved = await proofs.SaveAsync(proof, ct);

        await using var tx = await db.Database.BeginTransactionAsync(ct);
        try
        {
            await db.LockCourseAsync(course.CourseId, ct);
            var taken = await SeatsTakenAsync(course.CourseId, ct);
            if (taken + prepared.Count > course.MaxCapacity)
                throw AppException.Conflict(taken >= course.MaxCapacity ? "This course is full." : $"Only {course.MaxCapacity - taken} seat(s) are left in this course.", "COURSE_FULL");

            var customerIds = new List<int>();
            foreach (var p in prepared)
            {
                if (p.CustomerId is int existingId)
                {
                    var c = await db.Customers.FirstOrDefaultAsync(x => x.CustomerId == existingId && !x.IsDeleted, ct)
                        ?? throw AppException.BadRequest("Selected student does not exist.", "STUDENT_NOT_FOUND");
                    if (!c.IsActive) throw AppException.BadRequest($"{c.FullName} is inactive.", "STUDENT_INACTIVE");
                    if (await db.Enrollments.AnyAsync(e => e.CustomerId == existingId && e.CourseId == course.CourseId && e.Status == EnrollmentStatus.Active, ct))
                        throw AppException.Conflict($"{c.FullName} is already registered in this course.", "ENROLLMENT_EXISTS");
                    customerIds.Add(existingId);
                }
                else
                {
                    var created = new Customer { FullName = p.FullName!, Phone = p.Phone!, Email = p.Email, Area = p.Area, IsActive = true };
                    db.Customers.Add(created);
                    await db.SaveOrFailAsync(log, "Student could not be created.", ct);
                    customerIds.Add(created.CustomerId);
                }
            }

            var share = Math.Round(money.Total / customerIds.Count, 2, MidpointRounding.AwayFromZero);
            var newEnrollments = new List<Enrollment>();
            foreach (var id in customerIds)
            {
                var enrollment = new Enrollment { CustomerId = id, CourseId = course.CourseId, EnrollmentDate = DateTime.Today, TotalAmount = share, Status = EnrollmentStatus.Active };
                db.Enrollments.Add(enrollment);
                newEnrollments.Add(enrollment);
            }
            await db.SaveOrFailAsync(log, "Registration could not be saved.", ct);
            await notifications.NotifyCourseFullIfNeededAsync(course.CourseId, newEnrollments.Max(e => e.EnrollmentId), ct); // same transaction as the seats

            var now = DateTime.Now;
            var number = await NextInvoiceNumberAsync(now, ct);
            var invoiceId = await db.InsertAsync(
                @"INSERT INTO Invoices (invoice_number, issue_date, subtotal, discount_percent, discount_amount, total_amount, status, created_by, due_date, discount, tax)
                  VALUES (@number, @issued, @subtotal, @percent, @discountAmount, @total, @status, @by, NULL, @discountLegacy, 0);
                  SELECT CAST(SCOPE_IDENTITY() AS int);", ct,
                ("@number", number), ("@issued", now), ("@subtotal", money.Subtotal), ("@percent", money.Percent),
                ("@discountAmount", money.DiscountAmount), ("@total", money.Total), ("@status", status), ("@by", userId),
                ("@discountLegacy", money.DiscountAmount));

            foreach (var id in customerIds)
                await db.ExecuteAsync("INSERT INTO InvoiceCustomers (invoice_id, customer_id) VALUES (@i, @c)", ct, ("@i", invoiceId), ("@c", id));

            await InsertDetailAsync(invoiceId, course.CourseId, customerIds.Count, course.Price, money.Subtotal, ct);

            if (paid > 0)
            {
                var paymentId = await db.InsertAsync(
                    @"INSERT INTO Payments (payment_date, amount, payment_method, user_id, reference, payment_method_other, proof_file_name, proof_stored_name, proof_content_type)
                      VALUES (@date, @amount, @method, @by, NULL, @other, @proofName, @proofStored, @proofType);
                      SELECT CAST(SCOPE_IDENTITY() AS int);", ct,
                    ("@date", now), ("@amount", paid), ("@method", r.PaymentMethod), ("@by", userId), ("@other", otherText),
                    ("@proofName", saved?.OriginalName), ("@proofStored", saved?.StoredName), ("@proofType", saved?.ContentType));
                await db.ExecuteAsync("INSERT INTO PaymentAllocations (payment_id, invoice_id, allocated_amount) VALUES (@p, @i, @a)", ct,
                    ("@p", paymentId), ("@i", invoiceId), ("@a", paid));
                await db.ExecuteAsync("INSERT INTO Transactions (transaction_type, amount, related_payment_id, related_expense_id, transaction_date) VALUES ('INCOME', @a, @p, NULL, @d)", ct,
                    ("@a", paid), ("@p", paymentId), ("@d", now));
                // same events as an additional payment (same dedupe keys, so a payment is announced exactly once)
                await notifications.NotifyPaymentReceivedAsync(paymentId, number, paid, r.PaymentMethod, money.Total - paid, ct);
                if (status == PayStatus.Paid) await notifications.NotifyInvoicePaidAsync(invoiceId, paymentId, number, ct);
            }

            await tx.CommitAsync(ct);
            return invoiceId;
        }
        catch
        {
            proofs.Delete(saved?.StoredName);
            throw;
        }
    }

    private Task InsertDetailAsync(int invoiceId, int courseId, int quantity, decimal unitPrice, decimal subtotal, CancellationToken ct)
        => guard.InvoiceDetailSubtotalIsComputed
            ? db.ExecuteAsync("INSERT INTO InvoiceDetails (invoice_id, course_id, quantity, unit_price) VALUES (@i, @c, @q, @u)", ct,
                ("@i", invoiceId), ("@c", courseId), ("@q", quantity), ("@u", unitPrice))
            : db.ExecuteAsync("INSERT INTO InvoiceDetails (invoice_id, course_id, quantity, unit_price, subtotal) VALUES (@i, @c, @q, @u, @s)", ct,
                ("@i", invoiceId), ("@c", courseId), ("@q", quantity), ("@u", unitPrice), ("@s", subtotal));

    /// <summary>
    /// INV-2026-00001, INV-2026-00002... per year, from a COUNTER table (script 013): the counter only ever goes up, so a number that was
    /// issued once is never issued again, even if the newest invoice is deleted later (the old MAX() method could reuse it).
    /// The UPDATE locks the counter row until this transaction ends, so two simultaneous saves never receive the same number.
    /// </summary>
    private async Task<string> NextInvoiceNumberAsync(DateTime now, CancellationToken ct)
    {
        var year = now.Year;
        try
        {
            for (var attempt = 0; attempt < 3; attempt++)
            {
                var next = await db.QueryAsync("UPDATE dbo.InvoiceNumberCounters WITH (UPDLOCK, ROWLOCK) SET last_number = last_number + 1 OUTPUT inserted.last_number WHERE counter_year = @y",
                    r => r.GetInt32(0), ct, ("@y", year));
                if (next.Count == 1) return $"INV-{year}-{next[0]:D5}";
                try
                {
                    // first invoice of a new year: start from the highest number already used in that year (normally none)
                    await db.ExecuteAsync(
                        @"INSERT INTO dbo.InvoiceNumberCounters (counter_year, last_number)
                          SELECT @y, ISNULL(MAX(TRY_CAST(SUBSTRING(invoice_number, 10, 20) AS int)), 0) FROM Invoices WHERE invoice_number LIKE @p", ct,
                        ("@y", year), ("@p", $"INV-{year}-%"));
                }
                catch (Exception ex) when (SqlErrors.IsUniqueViolation(ex)) { /* another request created the row first: try again */ }
            }
        }
        catch (Microsoft.Data.SqlClient.SqlException e) when (e.Number == 208)
        {
            throw new AppException(500, "SCHEMA_OUTDATED", "The database needs one update before invoices can be saved. Run database/Scripts/013_system_features.sql, then restart the API.");
        }
        throw new AppException(500, "INVOICE_NUMBER", "The invoice number could not be created. Please try again.");
    }

    // ------------------------------------------------------------------ edit (same invoice)

    public async Task<InvoiceDetailsDto> UpdateAsync(int invoiceId, InvoiceUpdateRequest r, CancellationToken ct)
    {
        await guard.EnsureAsync(ct);
        var prepared = await PrepareStudentsForEditAsync(r.Students, invoiceId, ct);

        await using var tx = await db.Database.BeginTransactionAsync(ct);

        var head = await db.QueryAsync("SELECT status FROM Invoices WITH (UPDLOCK, ROWLOCK) WHERE invoice_id = @id", x => x.GetString(0), ct, ("@id", invoiceId));
        if (head.Count == 0) throw AppException.NotFound("Invoice not found.");
        if (head[0] == "Cancelled") throw AppException.Conflict("A cancelled invoice cannot be edited.", "INVOICE_CANCELLED");

        var items = await db.QueryAsync("SELECT invoice_detail_id, course_id, unit_price FROM InvoiceDetails WHERE invoice_id = @id",
            x => (DetailId: x.GetInt32(0), CourseId: x.GetInt32(1), UnitPrice: x.GetDecimal(2)), ct, ("@id", invoiceId));
        if (items.Count != 1) throw AppException.Conflict("This invoice contains several items and cannot be edited here.", "INVOICE_MULTI_ITEM");
        var oldCourseId = items[0].CourseId;
        var currentIds = await db.QueryAsync("SELECT customer_id FROM InvoiceCustomers WHERE invoice_id = @id", x => x.GetInt32(0), ct, ("@id", invoiceId));

        var oldCourse = await db.Courses.AsNoTracking().FirstAsync(c => c.CourseId == oldCourseId, ct);
        if (oldCourse.IsCompleted || oldCourse.IsDeleted)
            throw AppException.Conflict("The course of this invoice is completed, so the invoice is read-only.", "COURSE_COMPLETED");

        var courseChanged = r.CourseId != oldCourseId;
        var course = courseChanged ? await LoadBookableCourseAsync(r.CourseId, ct) : oldCourse;
        var unitPrice = courseChanged ? course.Price : items[0].UnitPrice; // an unchanged course keeps the price already on the invoice

        // resolve the final student list (create the new students)
        var desired = new List<int>();
        foreach (var p in prepared)
        {
            if (p.CustomerId is int existingId)
            {
                var c = await db.Customers.FirstOrDefaultAsync(x => x.CustomerId == existingId && !x.IsDeleted, ct)
                    ?? throw AppException.BadRequest("Selected student does not exist.", "STUDENT_NOT_FOUND");
                if (!currentIds.Contains(existingId))
                {
                    if (!c.IsActive) throw AppException.BadRequest($"{c.FullName} is inactive.", "STUDENT_INACTIVE");
                    if (await db.Enrollments.AnyAsync(e => e.CustomerId == existingId && e.CourseId == course.CourseId && e.Status == EnrollmentStatus.Active, ct))
                        throw AppException.Conflict($"{c.FullName} is already registered in this course.", "ENROLLMENT_EXISTS");
                }
                desired.Add(existingId);
            }
            else
            {
                var created = new Customer { FullName = p.FullName!, Phone = p.Phone!, Email = p.Email, Area = p.Area, IsActive = true };
                db.Customers.Add(created);
                await db.SaveOrFailAsync(log, "Student could not be created.", ct);
                desired.Add(created.CustomerId);
            }
        }

        var money = Calculate(unitPrice, desired.Count, r.DiscountPercent);
        var paid = await db.ScalarAsync<decimal>("SELECT ISNULL(SUM(allocated_amount), 0) FROM PaymentAllocations WHERE invoice_id = @id", ct, ("@id", invoiceId));
        if (paid > money.Total)
            throw AppException.BadRequest($"This invoice already has payments of {paid:0.##}, which is more than the new grand total ({money.Total:0.##}).", "TOTAL_BELOW_PAID");

        // enrollments follow the invoice
        await db.LockCourseAsync(course.CourseId, ct);
        var removed = currentIds.Except(desired).ToList();
        var leaving = courseChanged ? removed.Concat(currentIds.Intersect(desired)).ToList() : removed;
        foreach (var id in leaving)
        {
            var old = await db.Enrollments.FirstOrDefaultAsync(e => e.CustomerId == id && e.CourseId == oldCourseId && e.Status == EnrollmentStatus.Active, ct);
            if (old != null) old.Status = EnrollmentStatus.Cancelled;
        }
        await db.SaveOrFailAsync(log, "Registration could not be updated.", ct);

        var share = Math.Round(money.Total / desired.Count, 2, MidpointRounding.AwayFromZero);
        foreach (var id in desired)
        {
            var active = await db.Enrollments.FirstOrDefaultAsync(e => e.CustomerId == id && e.CourseId == course.CourseId && e.Status == EnrollmentStatus.Active, ct);
            if (active == null)
                db.Enrollments.Add(new Enrollment { CustomerId = id, CourseId = course.CourseId, EnrollmentDate = DateTime.Today, TotalAmount = share, Status = EnrollmentStatus.Active });
            else active.TotalAmount = share;
        }
        await db.SaveOrFailAsync(log, "Registration could not be updated.", ct);
        var taken = await SeatsTakenAsync(course.CourseId, ct);
        if (taken > course.MaxCapacity) throw AppException.Conflict($"This course is full ({taken} / {course.MaxCapacity}).", "COURSE_FULL");
        var lastEnrollmentId = await db.Enrollments.Where(e => e.CourseId == course.CourseId && e.Status == EnrollmentStatus.Active).MaxAsync(e => (int?)e.EnrollmentId, ct);
        if (lastEnrollmentId.HasValue) await notifications.NotifyCourseFullIfNeededAsync(course.CourseId, lastEnrollmentId.Value, ct);

        // the SAME invoice row is updated
        await db.ExecuteAsync(
            @"UPDATE Invoices SET subtotal = @sub, discount_percent = @pct, discount_amount = @da, total_amount = @total, discount = @da, status = @st
              WHERE invoice_id = @id", ct,
            ("@sub", money.Subtotal), ("@pct", money.Percent), ("@da", money.DiscountAmount), ("@total", money.Total), ("@st", StatusFor(paid, money.Total)), ("@id", invoiceId));
        if (guard.InvoiceDetailSubtotalIsComputed)
            await db.ExecuteAsync("UPDATE InvoiceDetails SET course_id = @c, quantity = @q, unit_price = @u WHERE invoice_detail_id = @d", ct,
                ("@c", course.CourseId), ("@q", desired.Count), ("@u", unitPrice), ("@d", items[0].DetailId));
        else
            await db.ExecuteAsync("UPDATE InvoiceDetails SET course_id = @c, quantity = @q, unit_price = @u, subtotal = @s WHERE invoice_detail_id = @d", ct,
                ("@c", course.CourseId), ("@q", desired.Count), ("@u", unitPrice), ("@s", money.Subtotal), ("@d", items[0].DetailId));
        foreach (var id in removed)
            await db.ExecuteAsync("DELETE FROM InvoiceCustomers WHERE invoice_id = @i AND customer_id = @c", ct, ("@i", invoiceId), ("@c", id));
        foreach (var id in desired.Except(currentIds))
            await db.ExecuteAsync("INSERT INTO InvoiceCustomers (invoice_id, customer_id) VALUES (@i, @c)", ct, ("@i", invoiceId), ("@c", id));

        await tx.CommitAsync(ct);
        return await GetAsync(invoiceId, ct);
    }

    /// <summary>Like PrepareStudentsAsync, but students already on the invoice keep their record (only new cards are checked for duplicates).</summary>
    private Task<List<Prepared>> PrepareStudentsForEditAsync(List<InvoiceStudentInput> input, int invoiceId, CancellationToken ct)
        => PrepareStudentsAsync(input, invoiceId, ct);

    // ------------------------------------------------------------------ read

    public async Task<PagedResult<InvoiceListItemDto>> ListAsync(InvoiceQuery q, CancellationToken ct)
    {
        if (q.FromDate.HasValue && q.ToDate.HasValue && q.FromDate.Value.Date > q.ToDate.Value.Date)
            throw AppException.BadRequest("The start date must not be after the end date.", "DATE_RANGE");

        var clauses = new List<string>();
        var args = new List<(string, object?)>();
        if (!string.IsNullOrWhiteSpace(q.Search))
        {
            clauses.Add(@"(i.invoice_number LIKE @like ESCAPE '\'
                         OR EXISTS (SELECT 1 FROM InvoiceCustomers x JOIN Customers c ON c.customer_id = x.customer_id WHERE x.invoice_id = i.invoice_id AND c.full_name LIKE @like ESCAPE '\')
                         OR EXISTS (SELECT 1 FROM InvoiceDetails d JOIN Courses co ON co.course_id = d.course_id WHERE d.invoice_id = i.invoice_id AND (co.course_code LIKE @like ESCAPE '\' OR co.course_name LIKE @like ESCAPE '\')))");
            args.Add(("@like", SqlText.LikePattern(q.Search)));
        }
        if (q.FromDate.HasValue) { clauses.Add("i.issue_date >= @from"); args.Add(("@from", q.FromDate.Value.Date)); }
        if (q.ToDate.HasValue) { clauses.Add("i.issue_date < @toExclusive"); args.Add(("@toExclusive", q.ToDate.Value.Date.AddDays(1))); }
        if (!string.IsNullOrWhiteSpace(q.Status))
        {
            var status = q.Status.Trim().ToLowerInvariant() switch { "paid" => PayStatus.Paid, "partial" or "partially paid" => PayStatus.Partial, "unpaid" => PayStatus.Unpaid, _ => null };
            if (status != null) { clauses.Add("i.status = @status"); args.Add(("@status", status)); }
        }
        var filter = clauses.Count > 0 ? "WHERE " + string.Join(" AND ", clauses) : "";

        var total = await db.ScalarAsync<int>($"SELECT COUNT(*) FROM Invoices i {filter}", ct, args.ToArray());

        var dir = q.Desc ? "DESC" : "ASC";
        var order = q.SortBy?.ToLowerInvariant() switch
        {
            "number" => $"i.invoice_number {dir}, i.invoice_id {dir}",
            "total" => $"i.total_amount {dir}, i.invoice_id {dir}",
            "date" => $"i.issue_date {dir}, i.invoice_id {dir}",
            _ => "i.issue_date DESC, i.invoice_id DESC" // newest first by default
        };
        args.Add(("@skip", q.Skip));
        args.Add(("@take", q.Take));

        var items = await db.QueryAsync(
            $@"SELECT i.invoice_id, i.invoice_number, i.issue_date, i.subtotal, i.discount_amount, i.total_amount, i.status,
                      ISNULL((SELECT SUM(a.allocated_amount) FROM PaymentAllocations a WHERE a.invoice_id = i.invoice_id), 0),
                      (SELECT COUNT(*) FROM InvoiceCustomers x WHERE x.invoice_id = i.invoice_id),
                      (SELECT TOP 1 c.full_name FROM InvoiceCustomers x JOIN Customers c ON c.customer_id = x.customer_id WHERE x.invoice_id = i.invoice_id ORDER BY x.invoice_customer_id),
                      (SELECT TOP 1 co.course_code + ' - ' + co.course_name FROM InvoiceDetails d JOIN Courses co ON co.course_id = d.course_id WHERE d.invoice_id = i.invoice_id ORDER BY d.invoice_detail_id)
               FROM Invoices i {filter}
               ORDER BY {order}
               OFFSET @skip ROWS FETCH NEXT @take ROWS ONLY",
            r =>
            {
                var count = r.GetInt32(8);
                var first = r.GetStringOrNull(9) ?? "-";
                return new InvoiceListItemDto(r.GetInt32(0), r.GetString(1), r.GetDateTime(2), count > 1 ? "Offer" : "Student", count,
                    count > 1 ? $"{first} +{count - 1}" : first, r.GetStringOrNull(10) ?? "-",
                    r.GetDecimal(3), r.GetDecimal(4), r.GetDecimal(5), r.GetDecimal(7), r.GetString(6));
            }, ct, args.ToArray());

        return new PagedResult<InvoiceListItemDto>(items, total, q.PageNumber, q.Take);
    }

    public async Task<InvoiceDetailsDto> GetAsync(int invoiceId, CancellationToken ct)
    {
        var head = await db.QueryAsync(
            @"SELECT i.invoice_number, i.issue_date, i.subtotal, i.discount_percent, i.discount_amount, i.total_amount, i.status, u.full_name
              FROM Invoices i LEFT JOIN Users u ON u.user_id = i.created_by WHERE i.invoice_id = @id",
            r => (Number: r.GetString(0), Date: r.GetDateTime(1), Subtotal: r.GetDecimal(2), Percent: r.GetDecimal(3), Discount: r.GetDecimal(4),
                  Total: r.GetDecimal(5), Status: r.GetString(6), By: r.GetStringOrNull(7)), ct, ("@id", invoiceId));
        if (head.Count == 0) throw AppException.NotFound("Invoice not found.");
        var h = head[0];

        var students = await db.QueryAsync(
            "SELECT c.customer_id, c.full_name FROM InvoiceCustomers ic JOIN Customers c ON c.customer_id = ic.customer_id WHERE ic.invoice_id = @id ORDER BY ic.invoice_customer_id",
            r => new InvoiceStudentDto(r.GetInt32(0), r.GetString(1)), ct, ("@id", invoiceId));

        var items = await db.QueryAsync(
            @"SELECT d.course_id, co.course_code, co.course_name, d.quantity, d.unit_price, d.quantity * d.unit_price, co.is_completed, co.is_deleted
              FROM InvoiceDetails d JOIN Courses co ON co.course_id = d.course_id WHERE d.invoice_id = @id ORDER BY d.invoice_detail_id",
            r => (Item: new InvoiceItemDto(r.GetInt32(0), r.GetString(1), r.GetString(2), r.GetInt32(3), r.GetDecimal(4), r.GetDecimal(5)), Locked: r.GetBoolean(6) || r.GetBoolean(7)),
            ct, ("@id", invoiceId));

        var payments = await db.QueryAsync(
            @"SELECT p.payment_id, p.payment_date, a.allocated_amount, p.payment_method, p.payment_method_other, p.proof_stored_name
              FROM PaymentAllocations a JOIN Payments p ON p.payment_id = a.payment_id WHERE a.invoice_id = @id ORDER BY p.payment_date, p.payment_id",
            r => new InvoicePaymentDto(r.GetInt32(0), r.GetDateTime(1), r.GetDecimal(2), r.GetString(3), r.GetStringOrNull(4), !r.IsDBNull(5)), ct, ("@id", invoiceId));

        var paid = payments.Sum(p => p.Amount);
        var canEdit = h.Status != "Cancelled" && items.Count == 1 && !items[0].Locked;
        return new InvoiceDetailsDto(invoiceId, h.Number, h.Date, students.Count > 1 ? "Offer" : "Student", h.Subtotal, h.Percent, h.Discount, h.Total,
            paid, h.Total - paid, h.Status, h.By, canEdit, students, items.Select(i => i.Item).ToList(), payments);
    }
}
