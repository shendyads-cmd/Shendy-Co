using GermanCenter.Api.Authentication;
using GermanCenter.Api.Data;
using GermanCenter.Api.DTOs;
using GermanCenter.Api.Middleware;
using GermanCenter.Api.Utilities;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;

namespace GermanCenter.Api.Services;

/// <summary>
/// SQL Server backup and restore of the application database.
///  * Backups are written by SQL SERVER to ITS backup folder (Backup:Directory in appsettings, otherwise SQL Server's default backup path).
///    The history comes from msdb, so only backups SQL Server itself made are offered.
///  * The browser never sends a file path: restore takes the id of a backup from that history.
///  * Restore is destructive. It needs: Admin, the typed word RESTORE, the admin's account password, a successful RESTORE VERIFYONLY
///    and it first takes an automatic "pre_restore" backup of the current data so the step can be undone.
///  * It runs from the master database (a database cannot restore itself while in use) and needs a SQL login allowed to restore.
/// </summary>
public class BackupService(AppDbContext db, IConfiguration config, ILogger<BackupService> log)
{
    private const string BackupSql =
        @"DECLARE @sql nvarchar(max) = N'BACKUP DATABASE ' + QUOTENAME(DB_NAME()) + N' TO DISK = @p WITH INIT, CHECKSUM';
          EXEC sp_executesql @sql, N'@p nvarchar(400)', @p = @path;";

    private const string VerifySql =
        @"DECLARE @sql nvarchar(max) = N'RESTORE VERIFYONLY FROM DISK = @p WITH CHECKSUM';
          EXEC sp_executesql @sql, N'@p nvarchar(400)', @p = @path;";

    private const string RestoreSql =
        @"DECLARE @q nvarchar(300) = QUOTENAME(@db);
          DECLARE @s nvarchar(max);
          BEGIN TRY
              SET @s = N'ALTER DATABASE ' + @q + N' SET SINGLE_USER WITH ROLLBACK IMMEDIATE';
              EXEC (@s);
              SET @s = N'RESTORE DATABASE ' + @q + N' FROM DISK = @p WITH REPLACE, CHECKSUM, RECOVERY';
              EXEC sp_executesql @s, N'@p nvarchar(400)', @p = @path;
              SET @s = N'ALTER DATABASE ' + @q + N' SET MULTI_USER';
              EXEC (@s);
          END TRY
          BEGIN CATCH
              BEGIN TRY
                  SET @s = N'ALTER DATABASE ' + @q + N' SET MULTI_USER';
                  EXEC (@s);
              END TRY
              BEGIN CATCH
              END CATCH
              THROW;
          END CATCH";

    private string DatabaseName()
        => new SqlConnectionStringBuilder(db.Database.GetConnectionString()).InitialCatalog is { Length: > 0 } n
            ? n : throw new AppException(500, "BACKUP_FAILED", "The database name is not configured.");

    // ------------------------------------------------------------------ history

    public Task<List<BackupInfoDto>> ListAsync(CancellationToken ct, int? onlyId = null)
        => db.QueryAsync(
            @"SELECT TOP (30) bs.backup_set_id, bs.backup_finish_date, CAST(bs.backup_size AS bigint), bmf.physical_device_name
              FROM msdb.dbo.backupset bs
              JOIN msdb.dbo.backupmediafamily bmf ON bmf.media_set_id = bs.media_set_id
              WHERE bs.database_name = DB_NAME() AND bs.type = 'D' AND bmf.device_type = 2 AND (@id IS NULL OR bs.backup_set_id = @id)
              ORDER BY bs.backup_finish_date DESC",
            r => new BackupInfoDto(r.GetInt32(0), r.GetDateTime(1), r.GetInt64(2), r.GetString(3)), ct, ("@id", onlyId));

    // ------------------------------------------------------------------ backup

    public async Task<BackupInfoDto> CreateAsync(string kind, CancellationToken ct)
    {
        var dbName = DatabaseName();
        var dir = config["Backup:Directory"];
        if (string.IsNullOrWhiteSpace(dir))
            dir = await db.ScalarAsync<string>("SELECT CAST(SERVERPROPERTY('InstanceDefaultBackupPath') AS nvarchar(400))", ct);
        if (string.IsNullOrWhiteSpace(dir))
            throw new AppException(500, "BACKUP_PATH", "No backup folder is configured. Set Backup:Directory in the API settings to a folder SQL Server may write to.");

        var sep = dir.Contains('\\') ? "\\" : "/";
        var path = dir.TrimEnd('\\', '/') + sep + $"{dbName}_{kind}_{DateTime.Now:yyyyMMdd_HHmmss}.bak";
        try
        {
            db.Database.SetCommandTimeout(TimeSpan.FromMinutes(30));
            await db.Database.ExecuteSqlRawAsync(BackupSql, new object[] { new SqlParameter("@path", path) }, ct);
            await db.Database.ExecuteSqlRawAsync(VerifySql, new object[] { new SqlParameter("@path", path) }, ct);
        }
        catch (SqlException ex)
        {
            log.LogError(ex, "Backup to {Path} failed.", path); // technical details stay in the log
            throw new AppException(500, "BACKUP_FAILED", "The backup could not be created. Check that SQL Server may write to the backup folder and that there is free space.");
        }
        finally { db.Database.SetCommandTimeout((TimeSpan?)null); }

        var made = (await ListAsync(ct)).FirstOrDefault(b => string.Equals(b.FilePath, path, StringComparison.OrdinalIgnoreCase));
        return made ?? new BackupInfoDto(0, DateTime.Now, 0, path);
    }

    // ------------------------------------------------------------------ restore

    public async Task<RestoreResultDto> RestoreAsync(int adminUserId, int backupId, RestoreRequest r, CancellationToken ct)
    {
        if (!string.Equals(r.ConfirmText?.Trim(), "RESTORE", StringComparison.Ordinal))
            throw AppException.BadRequest("Type RESTORE exactly to confirm.", "CONFIRM_TEXT");
        var admin = await db.Users.AsNoTracking().FirstOrDefaultAsync(u => u.UserId == adminUserId, ct) ?? throw AppException.NotFound("User not found.");
        if (!PasswordHasher.Verify(r.AdminPassword, admin.PasswordHash))
            throw AppException.BadRequest("Your account password is incorrect.", "ACCOUNT_PASSWORD_INVALID");

        var backup = (await ListAsync(ct, backupId)).FirstOrDefault() ?? throw AppException.NotFound("Backup not found.");
        var dbName = DatabaseName();
        var connectionString = db.Database.GetConnectionString()!;

        try
        {
            await db.Database.ExecuteSqlRawAsync(VerifySql, new object[] { new SqlParameter("@path", backup.FilePath) }, ct);
        }
        catch (SqlException ex)
        {
            log.LogError(ex, "Backup {Path} failed verification.", backup.FilePath);
            throw AppException.Conflict("This backup file cannot be used (missing or damaged). The current data was not changed.", "BACKUP_INVALID");
        }

        // safety net: the current data is saved first, so the restore itself can be undone
        var safety = await CreateAsync("pre_restore", ct);

        try
        {
            var csb = new SqlConnectionStringBuilder(connectionString) { InitialCatalog = "master" };
            await using var conn = new SqlConnection(csb.ConnectionString);
            await conn.OpenAsync(ct);
            await using var cmd = conn.CreateCommand();
            cmd.CommandText = RestoreSql;
            cmd.CommandTimeout = 0; // a restore must not be cut off half way
            cmd.Parameters.AddWithValue("@db", dbName);
            cmd.Parameters.AddWithValue("@path", backup.FilePath);
            await cmd.ExecuteNonQueryAsync(CancellationToken.None);
        }
        catch (SqlException ex)
        {
            log.LogError(ex, "Restore of {Path} failed.", backup.FilePath);
            throw new AppException(500, "RESTORE_FAILED", $"The restore failed. Your data before the restore was saved in: {safety.FilePath}");
        }
        finally { SqlConnection.ClearAllPools(); } // every pooled connection pointed at the old database state

        return new RestoreResultDto(DateTime.Now, safety.FilePath);
    }
}
