using GermanCenter.Api.Data;
using GermanCenter.Api.Middleware;
using GermanCenter.Api.Utilities;

namespace GermanCenter.Api.Services;

/// <summary>
/// Same idea as PaymentSchemaGuard, for the Step 3 tables (Expenses, Transactions, Payroll). Before the first expense or payroll
/// operation it checks the real database: the columns the code uses must exist (script 012 was run) and no OTHER required column
/// may exist that the code does not fill. It also reads the real text-column lengths so validation never allows a value the table
/// cannot store.
/// </summary>
public class FinanceSchemaGuard(AppDbContext db)
{
    private static volatile bool _verified;
    private static readonly Dictionary<string, int> Lengths = new(StringComparer.OrdinalIgnoreCase);

    private static readonly Dictionary<string, string[]> Used = new()
    {
        ["Expenses"] = new[] { "expense_id", "expense_title", "amount", "category", "expense_date", "description", "user_id", "created_at" },
        ["Transactions"] = new[] { "transaction_id", "transaction_type", "amount", "related_payment_id", "related_expense_id", "related_payroll_id", "transaction_date" },
        ["PayrollEmployees"] = new[] { "employee_id", "full_name", "job_title", "phone", "base_salary", "is_active", "created_at", "created_by" },
        ["PayrollEntries"] = new[] { "payroll_id", "employee_id", "period_year", "period_month", "base_salary", "bonus", "deductions", "net_salary", "status", "notes", "created_at", "created_by", "updated_at", "paid_at", "paid_by" }
    };

    private static readonly Dictionary<string, string[]> Filled = new()
    {
        ["Expenses"] = new[] { "expense_title", "amount", "category", "expense_date", "description", "user_id" },
        ["Transactions"] = new[] { "transaction_type", "amount", "related_payment_id", "related_expense_id", "related_payroll_id", "transaction_date" }
    };

    private sealed record Col(string Table, string Name, bool Nullable, bool Identity, bool Computed, bool HasDefault, string Type, int Chars);

    public async Task EnsureAsync(CancellationToken ct)
    {
        if (_verified) return;
        var tableList = string.Join(", ", Used.Keys.Select(t => $"'{t}'"));
        var cols = await db.QueryAsync(
            $@"SELECT t.name, c.name, c.is_nullable, c.is_identity, c.is_computed,
                      CASE WHEN c.default_object_id <> 0 THEN 1 ELSE 0 END, ty.name,
                      CASE WHEN c.max_length = -1 THEN 2147483647 WHEN ty.name IN ('nvarchar', 'nchar') THEN c.max_length / 2 ELSE c.max_length END
               FROM sys.tables t
               JOIN sys.columns c ON c.object_id = t.object_id
               JOIN sys.types ty ON ty.user_type_id = c.user_type_id
               WHERE t.schema_id = SCHEMA_ID('dbo') AND t.name IN ({tableList})",
            r => new Col(r.GetString(0), r.GetString(1), r.GetBoolean(2), r.GetBoolean(3), r.GetBoolean(4), r.GetInt32(5) == 1, r.GetString(6), Convert.ToInt32(r.GetValue(7))), ct);

        var problems = new List<string>();
        foreach (var (table, used) in Used)
        {
            var existing = cols.Where(c => c.Table == table).ToList();
            if (existing.Count == 0) { problems.Add($"table {table} not found"); continue; }
            var missing = used.Where(u => !existing.Any(c => string.Equals(c.Name, u, StringComparison.OrdinalIgnoreCase))).ToList();
            if (missing.Count > 0) problems.Add($"{table}: missing {string.Join(", ", missing)}");
        }
        if (problems.Count > 0)
            throw new AppException(500, "SCHEMA_OUTDATED",
                "The database needs one update before payments, expenses and payroll can be saved. Run database/Scripts/012_financial_core.sql, then restart the API. (" + string.Join("; ", problems) + ")");

        var unknown = new List<string>();
        foreach (var (table, filled) in Filled)
            foreach (var c in cols.Where(c => c.Table == table))
                if (!c.Nullable && !c.Identity && !c.Computed && !c.HasDefault && c.Type != "timestamp"
                    && !filled.Contains(c.Name, StringComparer.OrdinalIgnoreCase))
                    unknown.Add($"{table}.{c.Name}");
        if (unknown.Count > 0)
            throw new AppException(500, "SCHEMA_UNKNOWN_COLUMN",
                "These required columns exist but the application does not fill them: " + string.Join(", ", unknown) +
                ". Send the table definition so the code can be extended instead of guessing values.");

        lock (Lengths)
            foreach (var c in cols.Where(c => c.Table == "Expenses" && c.Type is "nvarchar" or "varchar" or "nchar" or "char"))
                Lengths[$"Expenses.{c.Name}"] = c.Chars;
        _verified = true;
    }

    /// <summary>The real maximum length of an Expenses text column, never more than <paramref name="wanted"/>.</summary>
    public int MaxLength(string table, string column, int wanted)
    {
        lock (Lengths) return Lengths.TryGetValue($"{table}.{column}", out var n) ? Math.Min(n, wanted) : wanted;
    }
}
