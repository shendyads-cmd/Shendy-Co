using System.Globalization;
using System.Linq.Expressions;
using GermanCenter.Api.Data;
using GermanCenter.Api.DTOs;
using GermanCenter.Api.Middleware;
using GermanCenter.Api.Models;
using GermanCenter.Api.Utilities;
using Microsoft.EntityFrameworkCore;

namespace GermanCenter.Api.Services;

public class CourseService(AppDbContext db, ILogger<CourseService> log)
{
    // Serialises code generation inside this API instance so two simultaneous creates cannot get the same code.
    private static readonly SemaphoreSlim CodeLock = new(1, 1);

    // A seat is taken by an Active registration of a student who is not deleted.
    private static readonly Expression<Func<Course, CourseDto>> ToDto = c => new CourseDto(
        c.CourseId, c.CourseCode, c.CourseName, c.Price, c.MaxCapacity,
        c.Enrollments.Count(e => e.Status == EnrollmentStatus.Active && !e.Customer.IsDeleted), c.IsActive);

    public async Task<PagedResult<CourseDto>> ListAsync(CourseQuery q, CancellationToken ct)
    {
        var query = db.Courses.AsNoTracking().Where(c => !c.IsDeleted && !c.IsCompleted);

        if (!string.IsNullOrWhiteSpace(q.Search))
        {
            var s = q.Search.Trim();
            var codeText = Codes.NormalizeCourseSearch(s); // "A1" / "A001" also find "A-001"
            query = query.Where(c => c.CourseCode.Contains(codeText) || c.CourseName.Contains(s));
        }
        if (q.IsActive.HasValue)
        {
            var active = q.IsActive.Value;
            query = query.Where(c => c.IsActive == active);
        }
        switch (q.Status?.Trim().ToLowerInvariant())
        {
            case "deactivated":
                query = query.Where(c => !c.IsActive);
                break;
            case "full":
                query = query.Where(c => c.IsActive && c.Enrollments.Count(e => e.Status == EnrollmentStatus.Active && !e.Customer.IsDeleted) >= c.MaxCapacity);
                break;
            case "open":
                query = query.Where(c => c.IsActive && c.Enrollments.Count(e => e.Status == EnrollmentStatus.Active && !e.Customer.IsDeleted) < c.MaxCapacity);
                break;
        }
        if (q.AvailableForStudent.HasValue)
        {
            var studentId = q.AvailableForStudent.Value;
            query = query.Where(c => c.IsActive
                && c.Enrollments.Count(e => e.Status == EnrollmentStatus.Active && !e.Customer.IsDeleted) < c.MaxCapacity
                && !c.Enrollments.Any(e => e.CustomerId == studentId && e.Status == EnrollmentStatus.Active));
        }

        IOrderedQueryable<Course> ordered = q.SortBy?.ToLowerInvariant() switch
        {
            "name" => query.Sort(c => c.CourseName, q.Desc),
            "price" => query.Sort(c => c.Price, q.Desc),
            "enrolled" => query.Sort(c => c.Enrollments.Count(e => e.Status == EnrollmentStatus.Active && !e.Customer.IsDeleted), q.Desc),
            _ => query.Sort(c => c.CourseCode, q.Desc)
        };

        var total = await query.CountAsync(ct);
        var items = await ordered.ThenBy(c => c.CourseId).Skip(q.Skip).Take(q.Take).Select(ToDto).ToListAsync(ct);
        return new PagedResult<CourseDto>(items, total, q.PageNumber, q.Take);
    }

    public static readonly Expression<Func<Course, CompletedCourseDto>> ToCompletedDto = c => new CompletedCourseDto(
        c.CourseId, c.CourseCode, c.CourseName, c.Price, c.MaxCapacity, c.CompletedAt,
        c.Enrollments.Count(e => e.Status != EnrollmentStatus.Cancelled && !e.Customer.IsDeleted));

    public async Task<CourseDto> GetAsync(int id, CancellationToken ct)
        => await db.Courses.AsNoTracking().Where(c => c.CourseId == id && !c.IsDeleted && !c.IsCompleted).Select(ToDto).FirstOrDefaultAsync(ct)
        ?? throw AppException.NotFound("Course not found.");

    public async Task<CourseDetailsDto> GetDetailsAsync(int id, CancellationToken ct)
    {
        var course = await GetAsync(id, ct);
        var enrollments = await db.Enrollments.AsNoTracking()
            .Where(e => e.CourseId == id && !e.Customer.IsDeleted)
            .OrderByDescending(e => e.Status == EnrollmentStatus.Active).ThenBy(e => e.Customer.FullName)
            .Select(EnrollmentService.ToDto).ToListAsync(ct);
        return new CourseDetailsDto(course, enrollments);
    }

    public async Task<CourseDto> CreateAsync(CourseRequest r, CancellationToken ct)
    {
        await CodeLock.WaitAsync(ct);
        try
        {
            var course = new Course
            {
                CourseCode = await NextCodeAsync(ct),
                CourseName = r.CourseName.Trim(),
                Price = r.Price,
                MaxCapacity = r.MaxCapacity,
                IsActive = true
            };
            db.Courses.Add(course);
            await db.SaveOrFailAsync(log, "Course could not be created.", ct);
            return await GetAsync(course.CourseId, ct);
        }
        finally { CodeLock.Release(); }
    }

    public async Task<CourseDto> UpdateAsync(int id, CourseRequest r, CancellationToken ct)
    {
        var course = await db.Courses.FirstOrDefaultAsync(c => c.CourseId == id && !c.IsDeleted && !c.IsCompleted, ct)
            ?? throw AppException.NotFound("Course not found.");

        var enrolled = await db.Enrollments.CountAsync(e => e.CourseId == id && e.Status == EnrollmentStatus.Active && !e.Customer.IsDeleted, ct);
        if (r.MaxCapacity < enrolled)
            throw AppException.BadRequest($"Capacity cannot be lower than the {enrolled} students currently registered.", "CAPACITY_TOO_LOW");

        // The course code never changes once generated.
        course.CourseName = r.CourseName.Trim();
        course.Price = r.Price;
        course.MaxCapacity = r.MaxCapacity;
        await db.SaveOrFailAsync(log, "Course could not be updated.", ct);
        return await GetAsync(id, ct);
    }

    /// <summary>Activate / Deactivate is a manual switch only. A full course shows as "Full" by itself and is never deactivated.</summary>
    public async Task<CourseDto> SetActiveAsync(int id, bool isActive, CancellationToken ct)
    {
        var course = await db.Courses.FirstOrDefaultAsync(c => c.CourseId == id && !c.IsDeleted && !c.IsCompleted, ct)
            ?? throw AppException.NotFound("Course not found.");
        course.IsActive = isActive;
        await db.SaveOrFailAsync(log, "Course status could not be changed.", ct);
        return await GetAsync(id, ct);
    }

    /// <summary>
    /// Administrative action: the course has finished. Nothing is deleted - students, registrations and (later) invoices stay.
    /// The course stops accepting students, leaves the live Courses list and appears under Data.
    /// </summary>
    public async Task<CompletedCourseDto> CompleteAsync(int id, CancellationToken ct)
    {
        var course = await db.Courses.FirstOrDefaultAsync(c => c.CourseId == id && !c.IsDeleted && !c.IsCompleted, ct)
            ?? throw AppException.NotFound("Course not found.");
        course.IsCompleted = true;
        course.CompletedAt = DateTime.Now;
        await db.SaveOrFailAsync(log, "Course could not be completed.", ct);
        return await db.Courses.AsNoTracking().Where(c => c.CourseId == id).Select(ToCompletedDto).FirstAsync(ct);
    }

    /// <summary>Undo of "complete": the course goes back to the live Courses list.</summary>
    public async Task<CourseDto> ReopenAsync(int id, CancellationToken ct)
    {
        var course = await db.Courses.FirstOrDefaultAsync(c => c.CourseId == id && !c.IsDeleted && c.IsCompleted, ct)
            ?? throw AppException.NotFound("Completed course not found.");
        course.IsCompleted = false;
        course.CompletedAt = null;
        await db.SaveOrFailAsync(log, "Course could not be reopened.", ct);
        return await GetAsync(id, ct);
    }

    /// <summary>Delete = move to "Deleted courses". Registrations are kept as history and never block a delete.</summary>
    public async Task DeleteAsync(int id, string reason, CancellationToken ct)
    {
        var course = await db.Courses.FirstOrDefaultAsync(c => c.CourseId == id && !c.IsDeleted && !c.IsCompleted, ct)
            ?? throw AppException.NotFound("Course not found.");
        course.IsDeleted = true;
        course.DeletedAt = DateTime.Now;
        course.DeletionReason = reason.Trim();
        await db.SaveOrFailAsync(log, "Course could not be deleted.", ct);
    }

    public async Task<CourseDto> RestoreAsync(int id, CancellationToken ct)
    {
        var course = await db.Courses.FirstOrDefaultAsync(c => c.CourseId == id && c.IsDeleted, ct)
            ?? throw AppException.NotFound("Deleted course not found.");
        course.IsDeleted = false;
        course.DeletedAt = null;
        course.DeletionReason = null;
        await db.SaveOrFailAsync(log, "Course could not be restored.", ct);
        return await GetAsync(id, ct);
    }

    public async Task<PagedResult<DeletedCourseDto>> ListDeletedAsync(ListQuery q, CancellationToken ct)
    {
        var query = db.Courses.AsNoTracking().Where(c => c.IsDeleted);
        if (!string.IsNullOrWhiteSpace(q.Search))
        {
            var s = q.Search.Trim();
            var codeText = Codes.NormalizeCourseSearch(s); // "A1" / "A001" also find "A-001"
            query = query.Where(c => c.CourseCode.Contains(codeText) || c.CourseName.Contains(s));
        }
        var total = await query.CountAsync(ct);
        var items = await query.OrderByDescending(c => c.DeletedAt).ThenByDescending(c => c.CourseId).Skip(q.Skip).Take(q.Take)
            .Select(c => new DeletedCourseDto(c.CourseId, c.CourseCode, c.CourseName, c.Price, c.MaxCapacity,
                c.Enrollments.Count(e => e.Status == EnrollmentStatus.Active && !e.Customer.IsDeleted), c.IsActive, c.DeletedAt, c.DeletionReason))
            .ToListAsync(ct);
        return new PagedResult<DeletedCourseDto>(items, total, q.PageNumber, q.Take);
    }

    /// <summary>Next code in the A-001, A-002, A-003... sequence. Deleted courses are included so a code is never reused.
    /// Codes still in the old format (A001) are read too, so the sequence continues correctly even before script 010 has run.</summary>
    private async Task<string> NextCodeAsync(CancellationToken ct)
    {
        var codes = await db.Courses.AsNoTracking().Where(c => c.CourseCode.StartsWith("A")).Select(c => c.CourseCode).ToListAsync(ct);
        var max = 0;
        foreach (var code in codes)
            if (Codes.TryParseCourseNumber(code, out var n) && n > max)
                max = n;
        return Codes.Course(max + 1);
    }
}
