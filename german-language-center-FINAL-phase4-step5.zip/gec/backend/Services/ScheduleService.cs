using System.Text.RegularExpressions;
using GermanCenter.Api.Data;
using GermanCenter.Api.DTOs;
using GermanCenter.Api.Middleware;
using GermanCenter.Api.Utilities;
using Microsoft.Data.SqlClient;

namespace GermanCenter.Api.Services;

/// <summary>
/// Personal schedule. Every entry belongs to ONE user. The user id comes from the JWT and is part of every WHERE clause, so a user can
/// neither read, change nor delete another user's entries (such an id simply answers "not found"). Administrators do not see them either.
/// </summary>
public class ScheduleService(AppDbContext db)
{
    private static readonly Regex TimeRx = new(@"^([01]\d|2[0-3]):[0-5]\d$", RegexOptions.Compiled);

    private static (string Title, DateTime Date, TimeSpan Time, string? Description) Validate(ScheduleRequest r)
    {
        var title = r.Title?.Trim() ?? "";
        if (title.Length < 2 || title.Length > 150) throw AppException.BadRequest("Enter a title (2-150 characters).", "TITLE");
        if (r.EntryDate == default || r.EntryDate.Year < 2000 || r.EntryDate.Year > 2100) throw AppException.BadRequest("Choose a valid date.", "DATE");
        var time = r.EntryTime?.Trim() ?? "";
        if (!TimeRx.IsMatch(time)) throw AppException.BadRequest("Choose a valid time.", "TIME");
        var description = r.Description.NullIfBlank();
        if (description != null && description.Length > 500) throw AppException.BadRequest("The details are too long (maximum 500 characters).", "DESCRIPTION");
        return (title, r.EntryDate.Date, TimeSpan.Parse(time), description);
    }

    private static ScheduleEntryDto Map(System.Data.Common.DbDataReader r)
        => new(r.GetInt32(0), r.GetString(1), r.GetDateTime(2), r.GetFieldValue<TimeSpan>(3).ToString(@"hh\:mm"), r.GetStringOrNull(4));

    public async Task<List<ScheduleEntryDto>> ListAsync(int userId, DateTime? from, DateTime? to, CancellationToken ct)
    {
        if (from.HasValue && to.HasValue && from.Value.Date > to.Value.Date) throw AppException.BadRequest("The start date must not be after the end date.", "DATE_RANGE");
        var sql = "SELECT entry_id, title, entry_date, entry_time, description FROM ScheduleEntries WHERE user_id = @u";
        var args = new List<(string, object?)> { ("@u", userId) };
        if (from.HasValue) { sql += " AND entry_date >= @from"; args.Add(("@from", from.Value.Date)); }
        if (to.HasValue) { sql += " AND entry_date <= @to"; args.Add(("@to", to.Value.Date)); }
        return await db.QueryAsync(sql + " ORDER BY entry_date, entry_time, entry_id", Map, ct, args.ToArray());
    }

    private async Task<ScheduleEntryDto> GetAsync(int userId, int id, CancellationToken ct)
    {
        var rows = await db.QueryAsync("SELECT entry_id, title, entry_date, entry_time, description FROM ScheduleEntries WHERE entry_id = @id AND user_id = @u", Map, ct, ("@id", id), ("@u", userId));
        return rows.Count > 0 ? rows[0] : throw AppException.NotFound("Schedule entry not found.");
    }

    public async Task<ScheduleEntryDto> CreateAsync(int userId, ScheduleRequest r, CancellationToken ct)
    {
        var v = Validate(r);
        try
        {
            var id = await db.InsertAsync(
                @"INSERT INTO ScheduleEntries (user_id, title, entry_date, entry_time, description) VALUES (@u, @t, @d, @tm, @desc);
                  SELECT CAST(SCOPE_IDENTITY() AS int);", ct, ("@u", userId), ("@t", v.Title), ("@d", v.Date), ("@tm", v.Time), ("@desc", v.Description));
            return await GetAsync(userId, id, ct);
        }
        catch (SqlException e) when (e.Number == 208) { throw SchemaOutdated(); }
        catch (Exception ex) when (SqlErrors.IsUniqueViolation(ex)) { throw AppException.Conflict("This entry already exists in your schedule.", "SCHEDULE_DUPLICATE"); }
    }

    public async Task<ScheduleEntryDto> UpdateAsync(int userId, int id, ScheduleRequest r, CancellationToken ct)
    {
        var v = Validate(r);
        try
        {
            var n = await db.ExecuteAsync(
                "UPDATE ScheduleEntries SET title = @t, entry_date = @d, entry_time = @tm, description = @desc, updated_at = SYSDATETIME() WHERE entry_id = @id AND user_id = @u", ct,
                ("@t", v.Title), ("@d", v.Date), ("@tm", v.Time), ("@desc", v.Description), ("@id", id), ("@u", userId));
            if (n == 0) throw AppException.NotFound("Schedule entry not found.");
            return await GetAsync(userId, id, ct);
        }
        catch (Exception ex) when (SqlErrors.IsUniqueViolation(ex)) { throw AppException.Conflict("This entry already exists in your schedule.", "SCHEDULE_DUPLICATE"); }
    }

    public async Task DeleteAsync(int userId, int id, CancellationToken ct)
    {
        var n = await db.ExecuteAsync("DELETE FROM ScheduleEntries WHERE entry_id = @id AND user_id = @u", ct, ("@id", id), ("@u", userId));
        if (n == 0) throw AppException.NotFound("Schedule entry not found.");
    }

    private static AppException SchemaOutdated()
        => new(500, "SCHEMA_OUTDATED", "The database needs one update before the schedule can be used. Run database/Scripts/013_system_features.sql, then restart the API.");
}
