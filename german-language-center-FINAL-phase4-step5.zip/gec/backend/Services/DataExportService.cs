using System.Data;
using System.Data.Common;
using System.Globalization;
using System.Text;
using GermanCenter.Api.Data;
using GermanCenter.Api.Utilities;
using Microsoft.EntityFrameworkCore;

namespace GermanCenter.Api.Services;

/// <summary>
/// Read-only export of the business data to a .sql script or an .xlsx workbook.
/// The tables and columns are read from the real database (sys.columns), so the export always matches the actual schema
/// (including tables the application does not map yet, such as Invoices and Payments).
/// Only SELECT statements are ever executed here. The Users table is deliberately not exported (password hashes).
/// </summary>
public class DataExportService(AppDbContext db, ILogger<DataExportService> log)
{
    private static readonly (string Table, string Sheet)[] Tables =
    {
        ("Customers", "Students"),
        ("Courses", "Courses"),
        ("Enrollments", "Enrollments"),
        ("Invoices", "Invoices"),
        ("InvoiceCustomers", "Invoice Students"),
        ("InvoiceDetails", "Invoice Details"),
        ("Payments", "Payments"),
        ("PaymentAllocations", "Payment Allocations"),
        ("PaymentGuarantees", "Payment Guarantees"),
        ("Expenses", "Expenses"),
        ("PayrollEmployees", "Payroll Employees"),
        ("PayrollEntries", "Payroll"),
        ("Transactions", "Transactions")
    };

    private static readonly HashSet<string> UnsupportedTypes = new(StringComparer.OrdinalIgnoreCase)
    {
        "timestamp", "geography", "geometry", "hierarchyid", "sql_variant"
    };

    private sealed record ColumnInfo(string Name, string TypeName, bool IsIdentity);

    private sealed class TableData
    {
        public string Table = "";
        public string Sheet = "";
        public List<ColumnInfo> Columns = new();
        public List<object?[]> Rows = new();
    }

    public async Task<byte[]> ExportSqlAsync(CancellationToken ct)
    {
        var tables = await LoadAsync(ct);
        var sb = new StringBuilder();
        sb.AppendLine("-- German Language Center - data export");
        sb.AppendLine($"-- Generated: {DateTime.Now:yyyy-MM-dd HH:mm:ss}");
        sb.AppendLine("-- DATA ONLY (INSERT statements, parents before children). Create the application tables first,");
        sb.AppendLine("-- then run this script against EMPTY tables. The Users table is not exported (it holds password hashes).");
        sb.AppendLine();
        sb.AppendLine("SET NOCOUNT ON;");
        sb.AppendLine("SET XACT_ABORT ON;");
        sb.AppendLine("BEGIN TRANSACTION;");
        sb.AppendLine();

        foreach (var t in tables)
        {
            sb.AppendLine($"-- {t.Table} ({t.Rows.Count} rows)");
            if (t.Rows.Count > 0)
            {
                var qualified = $"[dbo].[{t.Table}]";
                var hasIdentity = t.Columns.Any(c => c.IsIdentity);
                var columnList = string.Join(", ", t.Columns.Select(c => $"[{c.Name}]"));
                if (hasIdentity) sb.AppendLine($"SET IDENTITY_INSERT {qualified} ON;");
                for (var start = 0; start < t.Rows.Count; start += 100)
                {
                    var chunk = t.Rows.Skip(start).Take(100).ToList();
                    sb.AppendLine($"INSERT INTO {qualified} ({columnList}) VALUES");
                    for (var k = 0; k < chunk.Count; k++)
                    {
                        var row = chunk[k];
                        var values = string.Join(", ", t.Columns.Select((c, i) => SqlLiteral(row[i], c.TypeName)));
                        sb.Append("  (").Append(values).AppendLine(k == chunk.Count - 1 ? ");" : "),");
                    }
                }
                if (hasIdentity) sb.AppendLine($"SET IDENTITY_INSERT {qualified} OFF;");
            }
            sb.AppendLine();
        }

        sb.AppendLine("COMMIT TRANSACTION;");
        var preamble = Encoding.UTF8.GetPreamble();
        var body = Encoding.UTF8.GetBytes(sb.ToString());
        return preamble.Concat(body).ToArray();
    }

    public async Task<byte[]> ExportExcelAsync(CancellationToken ct)
    {
        var tables = await LoadAsync(ct);
        var sheets = tables.Select(t => new XlsxWriter.Sheet(t.Sheet, t.Columns.Select(c => c.Name).ToList(), t.Rows)).ToList();
        if (sheets.Count == 0) sheets.Add(new XlsxWriter.Sheet("Data", new[] { "Info" }, new List<object?[]> { new object?[] { "No data tables were found." } }));
        return XlsxWriter.Build(sheets);
    }

    // ---------------------------------------------------------------- reading (SELECT only)

    private async Task<List<TableData>> LoadAsync(CancellationToken ct)
    {
        var conn = db.Database.GetDbConnection();
        var openedHere = false;
        if (conn.State != ConnectionState.Open) { await conn.OpenAsync(ct); openedHere = true; }
        try
        {
            var existing = new HashSet<string>(
                await ReadStringsAsync(conn, "SELECT name FROM sys.tables WHERE schema_id = SCHEMA_ID('dbo')", ct),
                StringComparer.OrdinalIgnoreCase);

            var result = new List<TableData>();
            foreach (var (table, sheet) in Tables)
            {
                if (!existing.Contains(table)) continue;
                var data = new TableData { Table = table, Sheet = sheet, Columns = await ReadColumnsAsync(conn, table, ct) };
                if (data.Columns.Count == 0) continue;
                data.Rows = await ReadRowsAsync(conn, table, data.Columns, ct);
                result.Add(data);
            }
            var foreignKeys = await ReadForeignKeysAsync(conn, ct);
            log.LogInformation("Data export read {Tables} tables.", result.Count);
            return OrderByDependencies(result, foreignKeys);
        }
        finally
        {
            if (openedHere) await conn.CloseAsync();
        }
    }

    private static async Task<List<string>> ReadStringsAsync(DbConnection conn, string sql, CancellationToken ct)
    {
        var list = new List<string>();
        await using var cmd = conn.CreateCommand();
        cmd.CommandText = sql;
        await using var reader = await cmd.ExecuteReaderAsync(ct);
        while (await reader.ReadAsync(ct)) list.Add(reader.GetString(0));
        return list;
    }

    private static async Task<List<ColumnInfo>> ReadColumnsAsync(DbConnection conn, string table, CancellationToken ct)
    {
        var columns = new List<ColumnInfo>();
        await using var cmd = conn.CreateCommand();
        cmd.CommandText = @"SELECT c.name, t.name, c.is_identity
                            FROM sys.columns c JOIN sys.types t ON t.user_type_id = c.user_type_id
                            WHERE c.object_id = OBJECT_ID(@obj) AND c.is_computed = 0
                            ORDER BY c.column_id";
        var p = cmd.CreateParameter();
        p.ParameterName = "@obj";
        p.Value = $"[dbo].[{table}]";
        cmd.Parameters.Add(p);
        await using var reader = await cmd.ExecuteReaderAsync(ct);
        while (await reader.ReadAsync(ct))
        {
            var type = reader.GetString(1);
            if (UnsupportedTypes.Contains(type)) continue;
            columns.Add(new ColumnInfo(reader.GetString(0), type, reader.GetBoolean(2)));
        }
        return columns;
    }

    private static async Task<List<object?[]>> ReadRowsAsync(DbConnection conn, string table, List<ColumnInfo> columns, CancellationToken ct)
    {
        var rows = new List<object?[]>();
        await using var cmd = conn.CreateCommand();
        cmd.CommandText = $"SELECT {string.Join(", ", columns.Select(c => $"[{c.Name}]"))} FROM [dbo].[{table}] ORDER BY 1";
        await using var reader = await cmd.ExecuteReaderAsync(ct);
        while (await reader.ReadAsync(ct))
        {
            var row = new object?[columns.Count];
            for (var i = 0; i < columns.Count; i++) row[i] = await reader.IsDBNullAsync(i, ct) ? null : reader.GetValue(i);
            rows.Add(row);
        }
        return rows;
    }

    private static async Task<List<(string Child, string Parent)>> ReadForeignKeysAsync(DbConnection conn, CancellationToken ct)
    {
        var list = new List<(string, string)>();
        await using var cmd = conn.CreateCommand();
        cmd.CommandText = "SELECT OBJECT_NAME(parent_object_id), OBJECT_NAME(referenced_object_id) FROM sys.foreign_keys WHERE parent_object_id <> referenced_object_id";
        await using var reader = await cmd.ExecuteReaderAsync(ct);
        while (await reader.ReadAsync(ct)) list.Add((reader.GetString(0), reader.GetString(1)));
        return list;
    }

    /// <summary>Parents first, so the generated INSERTs satisfy the foreign keys.</summary>
    private static List<TableData> OrderByDependencies(List<TableData> items, List<(string Child, string Parent)> foreignKeys)
    {
        var present = new HashSet<string>(items.Select(i => i.Table), StringComparer.OrdinalIgnoreCase);
        var needs = items.ToDictionary(
            i => i.Table,
            i => foreignKeys.Where(f => string.Equals(f.Child, i.Table, StringComparison.OrdinalIgnoreCase) && present.Contains(f.Parent))
                            .Select(f => f.Parent).ToHashSet(StringComparer.OrdinalIgnoreCase),
            StringComparer.OrdinalIgnoreCase);

        var ordered = new List<TableData>();
        var remaining = new List<TableData>(items);
        while (remaining.Count > 0)
        {
            var ready = remaining.Where(t => needs[t.Table].All(d => ordered.Any(o => string.Equals(o.Table, d, StringComparison.OrdinalIgnoreCase)))).ToList();
            if (ready.Count == 0) ready = new List<TableData> { remaining[0] }; // circular reference: continue in a stable order
            foreach (var t in ready) { ordered.Add(t); remaining.Remove(t); }
        }
        return ordered;
    }

    // ---------------------------------------------------------------- SQL literals

    private static string SqlLiteral(object? value, string typeName)
    {
        switch (value)
        {
            case null: return "NULL";
            case string s: return "N'" + s.Replace("'", "''") + "'";
            case bool b: return b ? "1" : "0";
            case byte or sbyte or short or ushort or int or uint or long or ulong:
                return Convert.ToString(value, CultureInfo.InvariantCulture)!;
            case decimal d: return d.ToString(CultureInfo.InvariantCulture);
            case double d: return d.ToString("R", CultureInfo.InvariantCulture);
            case float f: return f.ToString("R", CultureInfo.InvariantCulture);
            case DateTime dt:
            {
                var format = typeName.Equals("date", StringComparison.OrdinalIgnoreCase) ? "yyyy-MM-dd"
                    : typeName.Equals("datetime", StringComparison.OrdinalIgnoreCase) || typeName.Equals("smalldatetime", StringComparison.OrdinalIgnoreCase)
                        ? "yyyy-MM-dd'T'HH:mm:ss.fff"
                        : "yyyy-MM-dd'T'HH:mm:ss.fffffff";
                return "'" + dt.ToString(format, CultureInfo.InvariantCulture) + "'";
            }
            case DateTimeOffset dto: return "'" + dto.ToString("yyyy-MM-dd'T'HH:mm:ss.fffffffzzz", CultureInfo.InvariantCulture) + "'";
            case TimeSpan ts: return "'" + ts.ToString(@"hh\:mm\:ss\.fffffff", CultureInfo.InvariantCulture) + "'";
            case Guid g: return "'" + g.ToString() + "'";
            case byte[] bytes: return bytes.Length == 0 ? "0x" : "0x" + Convert.ToHexString(bytes);
            default: return "N'" + (Convert.ToString(value, CultureInfo.InvariantCulture) ?? "").Replace("'", "''") + "'";
        }
    }
}
