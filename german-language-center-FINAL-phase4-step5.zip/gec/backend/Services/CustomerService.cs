using System.Linq.Expressions;
using GermanCenter.Api.Data;
using GermanCenter.Api.DTOs;
using GermanCenter.Api.Middleware;
using GermanCenter.Api.Models;
using GermanCenter.Api.Utilities;
using Microsoft.EntityFrameworkCore;

namespace GermanCenter.Api.Services;

public class CustomerService(AppDbContext db, NotificationService notifications, ILogger<CustomerService> log)
{
    private sealed record DuplicateRow(int CustomerId, bool IsDeleted);

    // EnrollmentCount = courses the student is registered in right now (deleted courses are not counted).
    private static readonly Expression<Func<Customer, CustomerDto>> ToDto = c => new CustomerDto(
        c.CustomerId, c.FullName, c.Phone, c.Email, c.Address, c.IsActive, c.CreatedAt,
        c.Enrollments.Count(e => e.Status == EnrollmentStatus.Active && !e.Course.IsDeleted && !e.Course.IsCompleted)) { Area = c.Area };

    // Search: Student ID (STU-0001 / 1), name or phone.
    private static IQueryable<Customer> ApplySearch(IQueryable<Customer> query, string? search)
    {
        if (string.IsNullOrWhiteSpace(search)) return query;
        var s = search.Trim();
        var isId = Codes.TryParseStudent(s, out var searchId);
        return query.Where(c => c.FullName.Contains(s) || c.Phone.Contains(s) || (isId && c.CustomerId == searchId));
    }

    public async Task<PagedResult<CustomerDto>> ListAsync(CustomerQuery q, CancellationToken ct)
    {
        var query = ApplySearch(db.Customers.AsNoTracking().Where(c => !c.IsDeleted), q.Search);
        if (q.IsActive.HasValue)
        {
            var active = q.IsActive.Value;
            query = query.Where(c => c.IsActive == active);
        }
        if (q.FromDate.HasValue && q.ToDate.HasValue && q.FromDate.Value.Date > q.ToDate.Value.Date)
            throw AppException.BadRequest("The start date must not be after the end date.", "DATE_RANGE");
        if (q.FromDate.HasValue)
        {
            var fromDate = q.FromDate.Value.Date;
            query = query.Where(c => c.CreatedAt >= fromDate);
        }
        if (q.ToDate.HasValue)
        {
            var toExclusive = q.ToDate.Value.Date.AddDays(1);
            query = query.Where(c => c.CreatedAt < toExclusive);
        }

        IOrderedQueryable<Customer> ordered = q.SortBy?.ToLowerInvariant() switch
        {
            "id" => query.Sort(c => c.CustomerId, q.Desc),
            "phone" => query.Sort(c => c.Phone, q.Desc),
            "email" => query.Sort(c => c.Email, q.Desc),
            "created" => query.Sort(c => c.CreatedAt, q.Desc),
            "enrollments" => query.Sort(c => c.Enrollments.Count(e => e.Status == EnrollmentStatus.Active && !e.Course.IsDeleted && !e.Course.IsCompleted), q.Desc),
            _ => query.Sort(c => c.FullName, q.Desc)
        };

        var total = await query.CountAsync(ct);
        var items = await ordered.ThenBy(c => c.CustomerId).Skip(q.Skip).Take(q.Take).Select(ToDto).ToListAsync(ct);

        // Attach the actual course codes (not just a number) for the rows on this page.
        var ids = items.Select(i => i.CustomerId).ToList();
        var codes = await db.Enrollments.AsNoTracking()
            .Where(e => ids.Contains(e.CustomerId) && e.Status == EnrollmentStatus.Active && !e.Course.IsDeleted && !e.Course.IsCompleted)
            .OrderBy(e => e.Course.CourseCode)
            .Select(e => new { e.CustomerId, e.Course.CourseCode }).ToListAsync(ct);
        var byStudent = codes.ToLookup(x => x.CustomerId, x => x.CourseCode);
        var withCodes = items.Select(i => i with { CourseCodes = byStudent[i.CustomerId].ToList() }).ToList();

        return new PagedResult<CustomerDto>(withCodes, total, q.PageNumber, q.Take);
    }

    public async Task<CustomerStatsDto> StatsAsync(CancellationToken ct)
    {
        var total = await db.Customers.CountAsync(c => !c.IsDeleted, ct);
        var active = await db.Customers.CountAsync(c => !c.IsDeleted && c.IsActive, ct);
        var deleted = await db.Customers.CountAsync(c => c.IsDeleted, ct);
        return new CustomerStatsDto(total, active, total - active, deleted);
    }

    public async Task<CustomerDto> GetAsync(int id, CancellationToken ct)
        => await db.Customers.AsNoTracking().Where(c => c.CustomerId == id && !c.IsDeleted).Select(ToDto).FirstOrDefaultAsync(ct)
        ?? throw AppException.NotFound("Student not found.");

    public async Task<CustomerDetailsDto> GetDetailsAsync(int id, CancellationToken ct)
    {
        var customer = await GetAsync(id, ct);
        // The complete history stays visible, including courses that have since been completed.
        var enrollments = await db.Enrollments.AsNoTracking()
            .Where(e => e.CustomerId == id && !e.Course.IsDeleted)
            .OrderByDescending(e => e.Status == EnrollmentStatus.Active).ThenByDescending(e => e.EnrollmentDate).ThenByDescending(e => e.EnrollmentId)
            .Select(EnrollmentService.ToDto).ToListAsync(ct);

        // Type per course: an invoice shared with other students is an Offer, otherwise the student registered alone.
        try
        {
            var links = await db.QueryAsync(
                @"SELECT d.course_id, i.invoice_number,
                         CASE WHEN (SELECT COUNT(*) FROM InvoiceCustomers x WHERE x.invoice_id = i.invoice_id) > 1 THEN 1 ELSE 0 END
                  FROM InvoiceCustomers ic
                  JOIN Invoices i ON i.invoice_id = ic.invoice_id
                  JOIN InvoiceDetails d ON d.invoice_id = i.invoice_id
                  WHERE ic.customer_id = @c AND i.status <> 'Cancelled'
                  ORDER BY i.invoice_id",
                r => (CourseId: r.GetInt32(0), Number: r.GetString(1), Offer: r.GetInt32(2) == 1), ct, ("@c", id));
            var latest = links.GroupBy(l => l.CourseId).ToDictionary(g => g.Key, g => g.Last());
            enrollments = enrollments.Select(e => latest.TryGetValue(e.CourseId, out var l)
                ? e with { Type = l.Offer ? "Offer" : "Student", InvoiceNumber = l.Number } : e).ToList();
        }
        catch (Exception ex) { log.LogWarning(ex, "Course types could not be read for student {Id}.", id); }

        return new CustomerDetailsDto(customer, enrollments);
    }

    public async Task<CustomerDto> CreateAsync(CustomerRequest r, CancellationToken ct)
    {
        var phone = r.Phone.Trim();
        var email = r.Email.NullIfBlank();
        await EnsureUniqueAsync(null, phone, email, ct);

        var customer = new Customer
        {
            FullName = r.FullName.Trim(), Phone = phone, Email = email,
            Address = r.Address.NullIfBlank(), Area = r.Area.NullIfBlank(), IsActive = true
        };
        db.Customers.Add(customer);
        await db.SaveOrFailAsync(log, "Student could not be created.", ct);
        return await GetAsync(customer.CustomerId, ct);
    }

    public async Task<CustomerDto> UpdateAsync(int id, CustomerRequest r, CancellationToken ct)
    {
        var customer = await db.Customers.FirstOrDefaultAsync(c => c.CustomerId == id && !c.IsDeleted, ct)
            ?? throw AppException.NotFound("Student not found.");

        var phone = r.Phone.Trim();
        var email = r.Email.NullIfBlank();
        await EnsureUniqueAsync(id, phone, email, ct);

        customer.FullName = r.FullName.Trim();
        customer.Phone = phone;
        customer.Email = email;
        customer.Address = r.Address.NullIfBlank();
        customer.Area = r.Area.NullIfBlank();
        await db.SaveOrFailAsync(log, "Student could not be updated.", ct);
        return await GetAsync(id, ct);
    }

    public async Task<CustomerDto> SetActiveAsync(int id, bool isActive, CancellationToken ct)
    {
        var customer = await db.Customers.FirstOrDefaultAsync(c => c.CustomerId == id && !c.IsDeleted, ct)
            ?? throw AppException.NotFound("Student not found.");
        customer.IsActive = isActive;
        await db.SaveOrFailAsync(log, "Student status could not be changed.", ct);
        return await GetAsync(id, ct);
    }

    /// <summary>
    /// Delete = move to "Deleted students". Nothing is destroyed: the student row, the registrations and any future
    /// invoices stay in the database for history. Registrations stop taking seats while the student is deleted.
    /// Registrations never block a delete. Active / Inactive is not touched.
    /// </summary>
    public async Task DeleteAsync(int id, string reason, CancellationToken ct)
    {
        var customer = await db.Customers.FirstOrDefaultAsync(c => c.CustomerId == id && !c.IsDeleted, ct)
            ?? throw AppException.NotFound("Student not found.");
        customer.IsDeleted = true;
        customer.DeletedAt = DateTime.Now;
        customer.DeletionReason = reason.Trim();
        await db.SaveOrFailAsync(log, "Student could not be deleted.", ct);
    }

    /// <summary>Brings a deleted student (same Student ID, same history) back to the normal list.</summary>
    public async Task<CustomerDto> RestoreAsync(int id, CancellationToken ct)
    {
        await using var tx = await db.Database.BeginTransactionAsync(ct);
        var customer = await db.Customers.FirstOrDefaultAsync(c => c.CustomerId == id && c.IsDeleted, ct)
            ?? throw AppException.NotFound("Deleted student not found.");

        // The student's active registrations take their seats again, so every course must still have room.
        var courseIds = await db.Enrollments.Where(e => e.CustomerId == id && e.Status == EnrollmentStatus.Active && !e.Course.IsDeleted && !e.Course.IsCompleted)
            .Select(e => e.CourseId).Distinct().OrderBy(x => x).ToListAsync(ct);
        foreach (var courseId in courseIds)
        {
            await db.LockCourseAsync(courseId, ct);
            var course = await db.Courses.AsNoTracking().FirstAsync(c => c.CourseId == courseId, ct);
            var taken = await db.Enrollments.CountAsync(e => e.CourseId == courseId && e.Status == EnrollmentStatus.Active && !e.Customer.IsDeleted, ct);
            if (taken >= course.MaxCapacity)
                throw AppException.Conflict($"Cannot restore: course {course.CourseCode} is full ({taken} / {course.MaxCapacity}). Increase its capacity or free a seat first.", "COURSE_FULL");
        }

        customer.IsDeleted = false;
        customer.DeletedAt = null;
        customer.DeletionReason = null;
        await db.SaveOrFailAsync(log, "Student could not be restored.", ct);
        foreach (var courseId in courseIds)
        {
            var enrollmentId = await db.Enrollments.Where(e => e.CustomerId == id && e.CourseId == courseId && e.Status == EnrollmentStatus.Active).MaxAsync(e => (int?)e.EnrollmentId, ct);
            if (enrollmentId.HasValue) await notifications.NotifyCourseFullIfNeededAsync(courseId, enrollmentId.Value, ct);
        }
        await tx.CommitAsync(ct);
        return await GetAsync(id, ct);
    }

    public async Task<PagedResult<DeletedCustomerDto>> ListDeletedAsync(ListQuery q, CancellationToken ct)
    {
        var query = ApplySearch(db.Customers.AsNoTracking().Where(c => c.IsDeleted), q.Search);
        var total = await query.CountAsync(ct);
        var items = await query.OrderByDescending(c => c.DeletedAt).ThenByDescending(c => c.CustomerId).Skip(q.Skip).Take(q.Take)
            .Select(c => new DeletedCustomerDto(c.CustomerId, c.FullName, c.Phone, c.Email, c.Address, c.IsActive, c.CreatedAt, c.DeletedAt, c.DeletionReason) { Area = c.Area })
            .ToListAsync(ct);

        var ids = items.Select(i => i.CustomerId).ToList();
        var rows = await db.Enrollments.AsNoTracking().Where(e => ids.Contains(e.CustomerId))
            .OrderBy(e => e.EnrollmentDate).ThenBy(e => e.EnrollmentId)
            .Select(e => new { e.CustomerId, Summary = new EnrollmentSummaryDto(e.Course.CourseCode, e.Course.CourseName, e.Status, e.EnrollmentDate, e.TotalAmount, e.Course.IsDeleted) })
            .ToListAsync(ct);
        var byStudent = rows.ToLookup(x => x.CustomerId, x => x.Summary);
        var withHistory = items.Select(i => i with { Enrollments = byStudent[i.CustomerId].ToList() }).ToList();

        return new PagedResult<DeletedCustomerDto>(withHistory, total, q.PageNumber, q.Take);
    }

    // Business rule: phone and email identify a student, so exact duplicates are rejected.
    // Deleted students are included, otherwise restoring one later could create a duplicate.
    public async Task EnsureUniqueAsync(int? excludeId, string? phone, string? email, CancellationToken ct)
    {
        var exclude = excludeId ?? 0;
        if (phone != null)
        {
            var dup = await db.Customers.AsNoTracking().Where(c => c.CustomerId != exclude && c.Phone == phone)
                .Select(c => new DuplicateRow(c.CustomerId, c.IsDeleted)).FirstOrDefaultAsync(ct);
            if (dup != null)
                throw AppException.Conflict(dup.IsDeleted
                    ? $"This phone number belongs to a deleted student ({Codes.Student(dup.CustomerId)}). Restore that student instead."
                    : "A student with this phone number already exists.", "DUPLICATE_PHONE");
        }
        if (email != null)
        {
            var dup = await db.Customers.AsNoTracking().Where(c => c.CustomerId != exclude && c.Email == email)
                .Select(c => new DuplicateRow(c.CustomerId, c.IsDeleted)).FirstOrDefaultAsync(ct);
            if (dup != null)
                throw AppException.Conflict(dup.IsDeleted
                    ? $"This email belongs to a deleted student ({Codes.Student(dup.CustomerId)}). Restore that student instead."
                    : "A student with this email address already exists.", "DUPLICATE_EMAIL");
        }
    }
}
