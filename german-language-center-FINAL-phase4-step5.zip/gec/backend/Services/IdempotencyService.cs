using GermanCenter.Api.Data;
using GermanCenter.Api.Utilities;

namespace GermanCenter.Api.Services;

public enum ReserveOutcome { Reserved, Replay, InProgress, KeyReused }

public sealed record ReserveResult(ReserveOutcome Outcome, int? ResponseStatus = null, string? ResponseBody = null);

/// <summary>
/// Stores Idempotency-Key reservations in dbo.IdempotencyKeys. The reservation is an INSERT protected by the UNIQUE index
/// (user_id, operation, idem_key): whichever of two simultaneous identical requests inserts first owns the operation,
/// the other one never reaches the code that creates records.
/// </summary>
public class IdempotencyService(AppDbContext db, ILogger<IdempotencyService> log)
{
    private static volatile bool _ready;

    /// <summary>A reservation that is still "Processing" after this many minutes belongs to a request that died; it may be taken over.</summary>
    private const int StaleMinutes = 30;

    public async Task<bool> IsAvailableAsync(CancellationToken ct)
    {
        if (_ready) return true;
        var n = await db.ScalarAsync<int>("SELECT COUNT(*) FROM sys.tables WHERE schema_id = SCHEMA_ID('dbo') AND name = 'IdempotencyKeys'", ct);
        if (n == 1) _ready = true;
        return n == 1;
    }

    public async Task<ReserveResult> ReserveAsync(int userId, string operation, string key, string hash, CancellationToken ct)
    {
        for (var attempt = 0; attempt < 3; attempt++)
        {
            try
            {
                await db.ExecuteAsync(
                    "INSERT INTO IdempotencyKeys (user_id, operation, idem_key, request_hash, status) VALUES (@u, @o, @k, @h, 'Processing')", ct,
                    ("@u", userId), ("@o", operation), ("@k", key), ("@h", hash));
                return new ReserveResult(ReserveOutcome.Reserved);
            }
            catch (Exception ex) when (SqlErrors.IsUniqueViolation(ex))
            {
                // The key already exists: decide below what the earlier request left behind.
            }

            var rows = await db.QueryAsync(
                @"SELECT request_hash, status, response_status, response_body, DATEDIFF(MINUTE, created_at, SYSDATETIME())
                  FROM IdempotencyKeys WHERE user_id = @u AND operation = @o AND idem_key = @k",
                r => (Hash: r.GetString(0), Status: r.GetString(1), Code: r.IsDBNull(2) ? (int?)null : r.GetInt32(2),
                      Body: r.GetStringOrNull(3), AgeMinutes: r.GetInt32(4)),
                ct, ("@u", userId), ("@o", operation), ("@k", key));

            if (rows.Count == 0) continue;               // the earlier attempt failed and released the key: reserve again
            var row = rows[0];
            if (!string.Equals(row.Hash.Trim(), hash, StringComparison.OrdinalIgnoreCase)) return new ReserveResult(ReserveOutcome.KeyReused);
            if (row.Status == "Completed") return new ReserveResult(ReserveOutcome.Replay, row.Code ?? 200, row.Body);

            if (row.AgeMinutes >= StaleMinutes)
            {
                // Abandoned reservation (the server stopped while handling it). Free it and try again.
                await db.ExecuteAsync("DELETE FROM IdempotencyKeys WHERE user_id = @u AND operation = @o AND idem_key = @k AND status = 'Processing'", ct,
                    ("@u", userId), ("@o", operation), ("@k", key));
                continue;
            }
            return new ReserveResult(ReserveOutcome.InProgress);
        }
        return new ReserveResult(ReserveOutcome.InProgress);
    }

    public Task CompleteAsync(int userId, string operation, string key, int status, string? body, CancellationToken ct)
        => db.ExecuteAsync(
            @"UPDATE IdempotencyKeys SET status = 'Completed', response_status = @s, response_body = @b, completed_at = SYSDATETIME()
              WHERE user_id = @u AND operation = @o AND idem_key = @k", ct,
            ("@s", status), ("@b", body), ("@u", userId), ("@o", operation), ("@k", key));

    /// <summary>The request failed (validation, conflict, error): nothing was created, so the key is freed and can be used again.</summary>
    public async Task ReleaseAsync(int userId, string operation, string key)
    {
        try
        {
            await db.ExecuteAsync("DELETE FROM IdempotencyKeys WHERE user_id = @u AND operation = @o AND idem_key = @k AND status = 'Processing'", CancellationToken.None,
                ("@u", userId), ("@o", operation), ("@k", key));
        }
        catch (Exception ex) { log.LogWarning(ex, "Idempotency key {Key} could not be released.", key); }
    }

    /// <summary>Housekeeping at start-up: finished keys older than 14 days and dead reservations are removed.</summary>
    public async Task PurgeAsync(CancellationToken ct)
    {
        if (!await IsAvailableAsync(ct)) return;
        await db.ExecuteAsync(
            "DELETE FROM IdempotencyKeys WHERE created_at < DATEADD(DAY, -14, SYSDATETIME()) OR (status = 'Processing' AND created_at < DATEADD(HOUR, -24, SYSDATETIME()))", ct);
    }
}
