using GermanCenter.Api.Data;
using GermanCenter.Api.DTOs;
using GermanCenter.Api.Middleware;
using GermanCenter.Api.Utilities;

namespace GermanCenter.Api.Services;

/// <summary>
/// The audit trail (dbo.AuditLogs). Records are written ONLY here, from authenticated backend actions (see AuditFilter and the login
/// endpoint); the user id always comes from the JWT, never from a request, so an entry cannot be forged. There is no update or delete
/// code, and a database trigger refuses both. Writing an audit record never makes the audited operation fail.
/// </summary>
public class AuditService(AppDbContext db, ILogger<AuditService> log)
{
    public static readonly string[] ActionTypes = { "Auth", "Create", "Update", "Delete", "Restore", "Financial", "Data", "Admin" };

    public async Task LogAsync(int? userId, string? username, string action, string actionType, string entity, string? reference, string? details, string? ip, CancellationToken ct = default)
    {
        try
        {
            if (username == null && userId.HasValue)
                username = await db.ScalarAsync<string>("SELECT username FROM Users WHERE user_id = @u", ct, ("@u", userId.Value));
            await db.ExecuteAsync(
                @"INSERT INTO AuditLogs (user_id, username, action, action_type, entity, reference, details, ip_address)
                  VALUES (@u, @name, @action, @type, @entity, @ref, @details, @ip)", ct,
                ("@u", userId), ("@name", Cut(username, 100)), ("@action", Cut(action, 100)!), ("@type", Cut(actionType, 30)!), ("@entity", Cut(entity, 60)!),
                ("@ref", Cut(reference, 100)), ("@details", Cut(details, 1000)), ("@ip", Cut(ip, 45)));
        }
        catch (Exception ex)
        {
            // an audit problem is logged for the administrator but never shown to the user and never blocks the work
            log.LogError(ex, "Audit record {Action} could not be written.", action);
        }
    }

    private static string? Cut(string? s, int max) => s is null ? null : s.Length <= max ? s : s[..max];

    public async Task<PagedResult<AuditRowDto>> ListAsync(AuditQuery q, CancellationToken ct)
    {
        if (q.FromDate.HasValue && q.ToDate.HasValue && q.FromDate.Value.Date > q.ToDate.Value.Date)
            throw AppException.BadRequest("The start date must not be after the end date.", "DATE_RANGE");
        if (q.ActionType != null && !ActionTypes.Contains(q.ActionType)) throw AppException.BadRequest("The action type is not valid.", "ACTION_TYPE");

        var clauses = new List<string>();
        var args = new List<(string, object?)>();
        if (q.FromDate.HasValue) { clauses.Add("a.created_at >= @from"); args.Add(("@from", q.FromDate.Value.Date)); }
        if (q.ToDate.HasValue) { clauses.Add("a.created_at < @toEx"); args.Add(("@toEx", q.ToDate.Value.Date.AddDays(1))); }
        if (q.ActionType != null) { clauses.Add("a.action_type = @type"); args.Add(("@type", q.ActionType)); }
        if (!string.IsNullOrWhiteSpace(q.Search))
        {
            clauses.Add(@"(a.username LIKE @like ESCAPE '\' OR a.action LIKE @like ESCAPE '\' OR a.reference LIKE @like ESCAPE '\' OR a.details LIKE @like ESCAPE '\')");
            args.Add(("@like", SqlText.LikePattern(q.Search)));
        }
        var where = clauses.Count > 0 ? "WHERE " + string.Join(" AND ", clauses) : "";
        var total = await db.ScalarAsync<int>($"SELECT COUNT(*) FROM AuditLogs a {where}", ct, args.ToArray());
        args.Add(("@skip", q.Skip)); args.Add(("@take", q.Take));
        var items = await db.QueryAsync(
            $@"SELECT a.audit_id, a.created_at, a.user_id, a.username, a.action, a.action_type, a.entity, a.reference, a.details
               FROM AuditLogs a {where} ORDER BY a.created_at DESC, a.audit_id DESC OFFSET @skip ROWS FETCH NEXT @take ROWS ONLY",
            r => new AuditRowDto(r.GetInt64(0), r.GetDateTime(1), r.IsDBNull(2) ? null : r.GetInt32(2), r.GetStringOrNull(3), r.GetString(4), r.GetString(5), r.GetString(6), r.GetStringOrNull(7), r.GetStringOrNull(8)),
            ct, args.ToArray());
        return new PagedResult<AuditRowDto>(items, total, q.PageNumber, q.Take);
    }
}
