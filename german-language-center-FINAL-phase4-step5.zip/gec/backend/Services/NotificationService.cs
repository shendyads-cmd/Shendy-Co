using System.Text.Json;
using GermanCenter.Api.Data;
using GermanCenter.Api.DTOs;
using GermanCenter.Api.Models;
using GermanCenter.Api.Utilities;
using Microsoft.EntityFrameworkCore;

namespace GermanCenter.Api.Services;

/// <summary>
/// Notifications. One row per EVENT in dbo.Notifications; who has read it lives in dbo.NotificationReads (one row per user),
/// so read state is user-specific. The same event can never be stored twice: every event has a dedupe key that is protected
/// by a filtered UNIQUE index (UX_Notifications_dedupe_key).
/// </summary>
public class NotificationService(AppDbContext db, ILogger<NotificationService> log)
{
    public static class Types
    {
        public const string CourseFull = "CourseFull";
        public const string PaymentReceived = "PaymentReceived";
        public const string InvoicePaid = "InvoicePaid";
        public const string ExpenseCreated = "ExpenseCreated";
        public const string PayrollPaid = "PayrollPaid";
    }

    private static volatile bool _ready;

    // A notification is visible to a user when it targets everyone / their role / them personally.
    private const string Visible = @"(n.target_role IS NULL OR n.target_role = @role) AND (n.target_user_id IS NULL OR n.target_user_id = @uid)";

    /// <summary>False until script 008 has been run. Notifications are never allowed to break the operation that raised them.</summary>
    private async Task<bool> ReadyAsync(CancellationToken ct)
    {
        if (_ready) return true;
        var tables = await db.ScalarAsync<int>(
            "SELECT COUNT(*) FROM sys.tables WHERE schema_id = SCHEMA_ID('dbo') AND name IN ('Notifications', 'NotificationReads')", ct);
        if (tables == 2) { _ready = true; return true; }
        log.LogWarning("Notification tables are missing. Run database/Scripts/008_notifications.sql, then restart the API.");
        return false;
    }

    // ------------------------------------------------------------------ create (called inside the caller's transaction)

    /// <summary>
    /// Raises "Course full" when the course has no free seat left. It runs inside the transaction that took the seat, so the
    /// notification exists if and only if the registration was saved. The dedupe key contains the id of the registration that
    /// filled the last seat: a retry of the same operation cannot create it again, while a genuine second time the course fills
    /// (after a cancellation) is a new event.
    /// </summary>
    public async Task NotifyCourseFullIfNeededAsync(int courseId, int triggerEnrollmentId, CancellationToken ct)
    {
        try
        {
            if (!await ReadyAsync(ct)) return;
            var course = await db.Courses.AsNoTracking().FirstOrDefaultAsync(c => c.CourseId == courseId, ct);
            if (course == null || course.IsDeleted || course.IsCompleted) return;

            var taken = await db.Enrollments.CountAsync(e => e.CourseId == courseId && e.Status == EnrollmentStatus.Active && !e.Customer.IsDeleted, ct);
            if (taken < course.MaxCapacity) return;

            var values = JsonSerializer.Serialize(new
            {
                courseId, courseCode = course.CourseCode, courseName = course.CourseName, enrolled = taken, capacity = course.MaxCapacity
            });
            await InsertOnceAsync(Types.CourseFull, "Courses", "Course full",
                $"{course.CourseCode} - {course.CourseName} has reached its maximum capacity ({taken}/{course.MaxCapacity}).",
                values, $"/courses/{courseId}", $"COURSE_FULL:{courseId}:{triggerEnrollmentId}", ct);
        }
        catch (OperationCanceledException) { throw; }
        catch (Exception ex)
        {
            // Never fail the registration because a notification could not be written.
            log.LogError(ex, "Course-full notification could not be created for course {CourseId}.", courseId);
        }
    }

    // ------------------------------------------------------------------ financial events (Step 3)
    // Each event has its own Notification Dedupe Key built from the id of the record that caused it, for example PAYMENT_RECEIVED:57.
    // This is NOT the Idempotency Key: that one stops a duplicate OPERATION, this one stops a duplicate NOTIFICATION.
    // They are raised inside the caller's transaction and can never make the financial operation fail. Admins only (the staff
    // member who entered the money already sees the result on screen).

    private async Task RaiseAsync(string type, string source, string title, string message, object parameters, string link, string dedupeKey, CancellationToken ct)
    {
        try
        {
            if (!await ReadyAsync(ct)) return;
            await InsertOnceAsync(type, source, title, message, JsonSerializer.Serialize(parameters), link, dedupeKey, ct, Roles.Admin);
        }
        catch (Exception ex)
        {
            log.LogError(ex, "Notification {Key} could not be created.", dedupeKey);
        }
    }

    public Task NotifyPaymentReceivedAsync(int paymentId, string invoiceNumber, decimal amount, string method, decimal remaining, CancellationToken ct)
        => RaiseAsync(Types.PaymentReceived, "Payments", "Payment received",
            $"{amount:0.##} received by {method} for invoice {invoiceNumber}. Remaining: {remaining:0.##}.",
            new { invoiceNumber, amount, method, remaining }, "/invoices", $"PAYMENT_RECEIVED:{paymentId}", ct);

    public Task NotifyInvoicePaidAsync(int invoiceId, int paymentId, string invoiceNumber, CancellationToken ct)
        => RaiseAsync(Types.InvoicePaid, "Invoices", "Invoice fully paid",
            $"Invoice {invoiceNumber} is now fully paid.",
            new { invoiceNumber }, "/invoices", $"INVOICE_PAID:{invoiceId}:{paymentId}", ct);

    public Task NotifyExpenseCreatedAsync(int expenseId, string title, decimal amount, string category, CancellationToken ct)
        => RaiseAsync(Types.ExpenseCreated, "Expenses", "New expense",
            $"Expense \"{title}\" ({category}) of {amount:0.##} was recorded.",
            new { title, amount, category }, "/expenses", $"EXPENSE_CREATED:{expenseId}", ct);

    public Task NotifyPayrollPaidAsync(int payrollId, string employee, decimal net, int year, int month, CancellationToken ct)
        => RaiseAsync(Types.PayrollPaid, "Payroll", "Salary paid",
            $"Salary of {employee} for {year}-{month:00} was paid: {net:0.##}.",
            new { employee, net, year, month }, "/payroll", $"PAYROLL_PAID:{payrollId}", ct);

    /// <summary>Inserts the notification unless one with the same dedupe key exists (checked here AND enforced by the unique index).</summary>
    private async Task InsertOnceAsync(string type, string source, string title, string message, string? paramsJson, string? link, string dedupeKey, CancellationToken ct, string? targetRole = null)
    {
        try
        {
            await db.ExecuteAsync(
                @"INSERT INTO Notifications (notification_type, source, title, message, params_json, link_path, dedupe_key, target_role)
                  SELECT @type, @source, @title, @message, @params, @link, @key, @role
                  WHERE NOT EXISTS (SELECT 1 FROM Notifications WHERE dedupe_key = @key)", ct,
                ("@type", type), ("@source", source), ("@title", title), ("@message", message),
                ("@params", paramsJson), ("@link", link), ("@key", dedupeKey), ("@role", targetRole));
        }
        catch (Exception ex) when (SqlErrors.IsUniqueViolation(ex))
        {
            // Another request stored the same event a moment earlier: that is exactly what the index is for.
            log.LogInformation("Notification {Key} already exists.", dedupeKey);
        }
    }

    // ------------------------------------------------------------------ read (per user)

    public async Task<NotificationListDto> ListAsync(int userId, string role, int take, CancellationToken ct)
    {
        if (!await ReadyAsync(ct)) return new NotificationListDto(new List<NotificationDto>(), 0);
        take = Math.Clamp(take, 1, 100);

        var items = await db.QueryAsync(
            $@"SELECT n.notification_id, n.notification_type, n.source, n.title, n.message, n.params_json, n.link_path, n.created_at,
                      CASE WHEN r.notification_id IS NULL THEN 0 ELSE 1 END
               FROM Notifications n
               LEFT JOIN NotificationReads r ON r.notification_id = n.notification_id AND r.user_id = @uid
               WHERE {Visible}
               ORDER BY n.created_at DESC, n.notification_id DESC
               OFFSET 0 ROWS FETCH NEXT @take ROWS ONLY",
            r => new NotificationDto(r.GetInt32(0), r.GetString(1), r.GetString(2), r.GetString(3), r.GetString(4),
                r.GetStringOrNull(5), r.GetStringOrNull(6), r.GetDateTime(7), r.GetInt32(8) == 1),
            ct, ("@uid", userId), ("@role", role), ("@take", take));

        return new NotificationListDto(items, await UnreadCountAsync(userId, role, ct));
    }

    /// <summary>The real number of unread notifications for THIS user (shown in the red badge on the bell).</summary>
    public async Task<int> UnreadCountAsync(int userId, string role, CancellationToken ct)
    {
        if (!await ReadyAsync(ct)) return 0;
        return await db.ScalarAsync<int>(
            $@"SELECT COUNT(*) FROM Notifications n
               WHERE {Visible}
                 AND NOT EXISTS (SELECT 1 FROM NotificationReads r WHERE r.notification_id = n.notification_id AND r.user_id = @uid)", ct,
            ("@uid", userId), ("@role", role));
    }

    // ------------------------------------------------------------------ mark as read (only for this user)

    public async Task<int> MarkReadAsync(int notificationId, int userId, string role, CancellationToken ct)
    {
        if (!await ReadyAsync(ct)) return 0;
        await InsertReadsAsync($"AND n.notification_id = @id", ct, userId, role, ("@id", notificationId));
        return await UnreadCountAsync(userId, role, ct);
    }

    public async Task<int> MarkAllReadAsync(int userId, string role, CancellationToken ct)
    {
        if (!await ReadyAsync(ct)) return 0;
        await InsertReadsAsync("", ct, userId, role);
        return await UnreadCountAsync(userId, role, ct);
    }

    private async Task InsertReadsAsync(string extraFilter, CancellationToken ct, int userId, string role, params (string, object?)[] extra)
    {
        var args = new List<(string, object?)> { ("@uid", userId), ("@role", role) };
        args.AddRange(extra);
        try
        {
            await db.ExecuteAsync(
                $@"INSERT INTO NotificationReads (notification_id, user_id)
                   SELECT n.notification_id, @uid FROM Notifications n
                   WHERE {Visible} {extraFilter}
                     AND NOT EXISTS (SELECT 1 FROM NotificationReads r WHERE r.notification_id = n.notification_id AND r.user_id = @uid)", ct,
                args.ToArray());
        }
        catch (Exception ex) when (SqlErrors.IsUniqueViolation(ex))
        {
            // A double click marked it read a moment earlier. Already read = the goal is reached.
        }
    }
}
