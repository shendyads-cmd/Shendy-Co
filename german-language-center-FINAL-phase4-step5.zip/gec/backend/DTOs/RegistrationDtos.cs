using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace GermanCenter.Api.DTOs;

/// <summary>
/// "New Student" (or "Add Course" for an existing student): student + enrollment + invoice + payment in one request.
/// Sent as multipart/form-data so an optional payment proof can travel with it. The course price is never sent:
/// the server reads it from the course.
/// </summary>
public class RegisterStudentForm
{
    /// <summary>When set, the student already exists (Add Course). Otherwise a new student is created from the fields below.</summary>
    public int? CustomerId { get; set; }

    [StringLength(150, ErrorMessage = "Full name is too long.")] public string? FullName { get; set; }
    [RegularExpression(@"^[0-9+()\-\s]{6,30}$", ErrorMessage = "Phone number is not valid.")] public string? Phone { get; set; }
    [EmailAddress(ErrorMessage = "Email address is not valid."), StringLength(150)] public string? Email { get; set; }
    [StringLength(250, ErrorMessage = "Address is too long.")] public string? Address { get; set; }
    [StringLength(100, ErrorMessage = "Area is too long.")] public string? Area { get; set; }

    [Range(1, int.MaxValue, ErrorMessage = "Select a course.")] public int CourseId { get; set; }
    [Range(0, 100, ErrorMessage = "Discount must be between 0 and 100 percent.")] public decimal DiscountPercent { get; set; }
    [Range(0, 10000000, ErrorMessage = "Amount paid is not valid.")] public decimal AmountPaid { get; set; }

    /// <summary>Cash or InstaPay (new payments only).</summary>
    [Required(ErrorMessage = "Select a payment method.")] public string PaymentMethod { get; set; } = "";
    /// <summary>Optional free text, only used when PaymentMethod is Other.</summary>
    [StringLength(100, ErrorMessage = "Other payment method is too long.")] public string? PaymentMethodOther { get; set; }

    /// <summary>Optional proof (JPG, JPEG, PNG, PDF) for InstaPay.</summary>
    [JsonIgnore] public IFormFile? Proof { get; set; }
}

public record RegistrationResultDto(
    int CustomerId, string StudentCode, string StudentName, int EnrollmentId,
    int InvoiceId, string InvoiceNumber, DateTime IssueDate,
    int CourseId, string CourseCode, string CourseName,
    decimal CoursePrice, decimal DiscountPercent, decimal DiscountAmount, decimal FinalAmount,
    decimal AmountPaid, decimal Remaining, string PaymentStatus,
    int? PaymentId, string? PaymentMethod, string? PaymentMethodOther, DateTime? PaymentDate, bool HasProof);
