namespace GermanCenter.Api.DTOs;

// ---------------------------------------------------------------- shared

/// <summary>Date window + paging for report tabs. Both dates are optional (inclusive). From > To is refused with 400.</summary>
public class ReportQuery : ListQuery
{
    public DateTime? FromDate { get; set; }
    public DateTime? ToDate { get; set; }
}

public class DashboardQuery
{
    public DateTime? FromDate { get; set; }
    public DateTime? ToDate { get; set; }
}

/// <summary>
/// THE financial source of truth: Dashboard and the Reports "Financial summary" tab both return exactly this object.
///   Sales        = grand total of the (not cancelled) invoices ISSUED in the period
///   Collected    = payments RECEIVED in the period (PaymentAllocations by payment date)
///   Outstanding  = what is still unpaid on the invoices issued in the period (from the real payments)
///   Expenses     = expenses dated in the period
///   Payroll      = salaries PAID in the period (by payment date); PayrollPending = unpaid salaries of the months in the period
///   CashIn / CashOut = Transactions (INCOME / EXPENSE) dated in the period; CashOut contains expenses AND paid payroll
///   NetResult    = CashIn - CashOut (cash basis)
/// The two Difference fields must be 0: they compare Cash In with Collected and Cash Out with Expenses + Payroll, so a missing cash row is visible.
/// </summary>
public record FinancialSummaryDto(
    DateTime? FromDate, DateTime? ToDate,
    decimal Sales, int InvoiceCount, decimal Collected, int PaymentCount, decimal Outstanding, int OutstandingCount,
    decimal Expenses, int ExpenseCount, decimal Payroll, decimal PayrollPending,
    decimal CashIn, decimal CashOut, decimal NetResult, decimal CashInDifference, decimal CashOutDifference);

public record CourseRowDto(
    int CourseId, string Code, string Name, int Capacity, int Enrolled, decimal OccupancyPercent,
    decimal Revenue, decimal Paid, decimal Remaining, string Status, int Rank);

public record CourseReportDto(List<CourseRowDto> Items, decimal TotalRevenue, decimal TotalPaid, decimal TotalRemaining);

// ---------------------------------------------------------------- dashboard

/// <summary>One point of the trend charts. Label is yyyy-MM-dd (daily) or yyyy-MM (monthly).</summary>
public record TrendPointDto(string Label, decimal Sales, decimal Collected, decimal CashIn, decimal CashOut);

public record DashboardDto(
    FinancialSummaryDto Summary, string Granularity, List<TrendPointDto> Trend,
    List<CourseRowDto> TopCourses, List<CourseRowDto> Occupancy, int OpenCourses, int ActiveStudents);

// ---------------------------------------------------------------- report tabs

public record SalesRowDto(
    int InvoiceId, string InvoiceNumber, DateTime IssueDate, string Type, string StudentLabel, string CourseLabel,
    decimal Subtotal, decimal Discount, decimal GrandTotal, decimal Paid, string PaymentStatus);
public record SalesReportDto(List<SalesRowDto> Items, int Total, int Page, int PageSize, decimal TotalSubtotal, decimal TotalDiscount, decimal TotalSales);

public record PaymentRowDto(
    int PaymentId, DateTime PaymentDate, int InvoiceId, string InvoiceNumber, string StudentLabel,
    string PaymentMethod, string? PaymentMethodOther, decimal Amount, bool HasProof, string InvoiceStatus);
public record MethodTotalDto(string Method, int Count, decimal Total);
public record PaymentsReportDto(List<PaymentRowDto> Items, int Total, int Page, int PageSize, decimal TotalAmount, List<MethodTotalDto> ByMethod);

public record ExpenseReportRowDto(
    int ExpenseId, DateTime ExpenseDate, string Category, string Title, string? Description, decimal Amount, string? CreatedBy, int? CashOutId);
public record CategoryTotalDto(string Category, int Count, decimal Total);
public record ExpenseReportDto(List<ExpenseReportRowDto> Items, int Total, int Page, int PageSize, decimal TotalAmount, int WithoutCashOut, List<CategoryTotalDto> ByCategory);

public record OutstandingRowDto(
    int InvoiceId, string InvoiceNumber, DateTime IssueDate, string Type, string StudentLabel, string CourseLabel,
    decimal GrandTotal, decimal Paid, decimal Remaining, string PaymentStatus);
public record OutstandingReportDto(List<OutstandingRowDto> Items, int Total, int Page, int PageSize, decimal TotalGrand, decimal TotalPaid, decimal TotalRemaining);
