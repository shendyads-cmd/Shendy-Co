namespace GermanCenter.Api.DTOs;

/// <summary>Uniform error body: { code, message, traceId? }.</summary>
public record ApiError(string Code, string Message, string? TraceId = null);
