using System.ComponentModel.DataAnnotations;

namespace GermanCenter.Api.DTOs;

// ---------------------------------------------------------------- audit log (read-only)

public class AuditQuery : ListQuery
{
    public DateTime? FromDate { get; set; }
    public DateTime? ToDate { get; set; }
    /// <summary>Auth, Create, Update, Delete, Restore, Financial, Data or Admin.</summary>
    public string? ActionType { get; set; }
}

public record AuditRowDto(long AuditId, DateTime CreatedAt, int? UserId, string? Username, string Action, string ActionType, string Entity, string? Reference, string? Details);

// ---------------------------------------------------------------- personal schedule

public class ScheduleRequest
{
    public string Title { get; set; } = "";
    public DateTime EntryDate { get; set; }
    /// <summary>HH:mm, 24 hours.</summary>
    public string EntryTime { get; set; } = "";
    public string? Description { get; set; }
}

public class ScheduleQuery
{
    public DateTime? FromDate { get; set; }
    public DateTime? ToDate { get; set; }
}

public record ScheduleEntryDto(int EntryId, string Title, DateTime EntryDate, string EntryTime, string? Description);

// ---------------------------------------------------------------- backup / restore

public record BackupInfoDto(int BackupId, DateTime CreatedAt, long SizeBytes, string FilePath);

public class RestoreRequest
{
    [Required(ErrorMessage = "Type RESTORE exactly to confirm.")]
    public string ConfirmText { get; set; } = "";

    [Required(ErrorMessage = "Your account password is required.")]
    [StringLength(200)]
    public string AdminPassword { get; set; } = "";
}

public record RestoreResultDto(DateTime RestoredAt, string SafetyBackupPath);
