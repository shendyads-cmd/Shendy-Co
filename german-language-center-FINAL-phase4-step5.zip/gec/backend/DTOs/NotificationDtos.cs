namespace GermanCenter.Api.DTOs;

/// <summary>
/// One notification as seen by ONE user (IsRead is that user's own state).
/// Title / Message are English fallbacks; the screen translates them from Type + ParamsJson.
/// </summary>
public record NotificationDto(
    int NotificationId, string Type, string Source, string Title, string Message,
    string? ParamsJson, string? LinkPath, DateTime CreatedAt, bool IsRead);

public record NotificationListDto(List<NotificationDto> Items, int UnreadCount);

public record UnreadCountDto(int UnreadCount);
