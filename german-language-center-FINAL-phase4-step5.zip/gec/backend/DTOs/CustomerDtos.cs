using System.ComponentModel.DataAnnotations;

namespace GermanCenter.Api.DTOs;

/// <summary>EnrollmentCount = courses the student is currently registered in (active enrollments).</summary>
public record CustomerDto(int CustomerId, string FullName, string? Phone, string? Email, string? Address,
                          bool IsActive, DateTime CreatedAt, int EnrollmentCount)
{
    public string StudentCode => Utilities.Codes.Student(CustomerId);
    public string? Area { get; init; }
    /// <summary>Codes of the courses the student is currently registered in (A-001, A-002...).</summary>
    public List<string> CourseCodes { get; init; } = new();
}

public record EnrollmentSummaryDto(string CourseCode, string CourseName, string Status, DateTime EnrollmentDate, decimal TotalAmount, bool CourseDeleted);

/// <summary>A deleted student with the history that is kept for analysis.</summary>
public record DeletedCustomerDto(int CustomerId, string FullName, string? Phone, string? Email, string? Address,
                                 bool IsActive, DateTime CreatedAt, DateTime? DeletedAt, string? DeletionReason)
{
    public string StudentCode => Utilities.Codes.Student(CustomerId);
    public string? Area { get; init; }
    public List<EnrollmentSummaryDto> Enrollments { get; init; } = new();
}

public record CustomerDetailsDto(CustomerDto Customer, List<EnrollmentDto> Enrollments);

public record CustomerRequest(
    [param: Required(ErrorMessage = "Full name is required."), StringLength(150, MinimumLength = 2, ErrorMessage = "Full name must be 2-150 characters.")] string FullName,
    [param: Required(ErrorMessage = "Phone number is required."), RegularExpression(@"^[0-9+()\-\s]{6,30}$", ErrorMessage = "Phone number is not valid.")] string Phone,
    [param: EmailAddress(ErrorMessage = "Email address is not valid."), StringLength(150, ErrorMessage = "Email is too long.")] string? Email,
    [param: StringLength(250, ErrorMessage = "Address is too long.")] string? Address,
    [param: StringLength(100, ErrorMessage = "Area is too long.")] string? Area = null);

public record ActiveStatusRequest(bool IsActive);

public record CustomerStatsDto(int Total, int Active, int Inactive, int Deleted);
