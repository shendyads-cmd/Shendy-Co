namespace GermanCenter.Api.DTOs;

/// <summary>A student on an invoice: an existing student (CustomerId) or a new one (name, phone, ...).</summary>
public class InvoiceStudentInput
{
    public int? CustomerId { get; set; }
    public string? FullName { get; set; }
    public string? Email { get; set; }
    public string? Phone { get; set; }
    public string? Area { get; set; }
}

/// <summary>Student or Offer registration. The price is never sent: it always comes from the course.</summary>
public class InvoiceCreateRequest
{
    /// <summary>"Student" (exactly one student) or "Offer" (two or more students on ONE invoice).</summary>
    public string Type { get; set; } = "Student";
    public List<InvoiceStudentInput> Students { get; set; } = new();
    public int CourseId { get; set; }
    public decimal DiscountPercent { get; set; }
    public decimal AmountPaid { get; set; }
    public string PaymentMethod { get; set; } = "Cash";
    public string? PaymentMethodOther { get; set; }
}

/// <summary>Edit of an existing invoice (same invoice id). Payments are not changed here.</summary>
public class InvoiceUpdateRequest
{
    public int CourseId { get; set; }
    public decimal DiscountPercent { get; set; }
    /// <summary>The complete list of students that should be on the invoice afterwards.</summary>
    public List<InvoiceStudentInput> Students { get; set; } = new();
}

/// <summary>Server-side calculation shown before saving. Nothing is written.</summary>
public record InvoicePreviewDto(
    string Type, int CourseId, string CourseCode, string CourseName, int Quantity, decimal UnitPrice, decimal Subtotal,
    decimal DiscountPercent, decimal DiscountAmount, decimal GrandTotal, decimal AmountPaid, decimal Remaining, string PaymentStatus,
    string? PaymentMethod, string? PaymentMethodOther, DateTime PreviewDate, List<string> StudentNames);

public record InvoiceListItemDto(
    int InvoiceId, string InvoiceNumber, DateTime IssueDate, string Type, int StudentCount, string StudentLabel, string CourseLabel,
    decimal Subtotal, decimal DiscountAmount, decimal GrandTotal, decimal AmountPaid, string PaymentStatus);

public record InvoiceStudentDto(int CustomerId, string FullName)
{
    public string StudentCode => Utilities.Codes.Student(CustomerId);
}

public record InvoiceItemDto(int CourseId, string CourseCode, string CourseName, int Quantity, decimal UnitPrice, decimal Subtotal);

public record InvoicePaymentDto(int PaymentId, DateTime PaymentDate, decimal Amount, string PaymentMethod, string? PaymentMethodOther, bool HasProof);

public record InvoiceDetailsDto(
    int InvoiceId, string InvoiceNumber, DateTime IssueDate, string Type,
    decimal Subtotal, decimal DiscountPercent, decimal DiscountAmount, decimal GrandTotal, decimal AmountPaid, decimal Remaining,
    string PaymentStatus, string? CreatedBy, bool CanEdit,
    List<InvoiceStudentDto> Students, List<InvoiceItemDto> Items, List<InvoicePaymentDto> Payments);

public record ExpenseDto(int ExpenseId, string Title, decimal Amount, string Category, DateTime ExpenseDate, string? Description, string? CreatedBy);

/// <summary>TotalAmount is the sum of ALL expenses matching the filters (not just this page).</summary>
public record ExpensePageDto(List<ExpenseDto> Items, int Total, int Page, int PageSize, decimal TotalAmount);
