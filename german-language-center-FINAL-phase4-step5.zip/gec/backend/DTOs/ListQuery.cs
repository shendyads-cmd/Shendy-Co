namespace GermanCenter.Api.DTOs;

/// <summary>Common server-side search / sort / pagination parameters.</summary>
public class ListQuery
{
    public string? Search { get; set; }
    public int Page { get; set; } = 1;
    public int PageSize { get; set; } = 15;
    public string? SortBy { get; set; }
    public string? SortDir { get; set; }

    public int PageNumber => Math.Max(Page, 1);
    public int Take => Math.Clamp(PageSize, 1, 100);
    public int Skip => (PageNumber - 1) * Take;
    public bool Desc => string.Equals(SortDir, "desc", StringComparison.OrdinalIgnoreCase);
}

public class CustomerQuery : ListQuery
{
    public bool? IsActive { get; set; }
    /// <summary>Registration date range (inclusive). Handled in SQL, never in the browser.</summary>
    public DateTime? FromDate { get; set; }
    public DateTime? ToDate { get; set; }
}

public class InvoiceQuery : ListQuery
{
    public DateTime? FromDate { get; set; }
    public DateTime? ToDate { get; set; }
    /// <summary>Paid, Partially Paid or Unpaid.</summary>
    public string? Status { get; set; }
}

public class ExpenseQuery : ListQuery
{
    public DateTime? FromDate { get; set; }
    public DateTime? ToDate { get; set; }
}

public class PayrollQuery : ListQuery
{
    public int? Year { get; set; }
    public int? Month { get; set; }
    /// <summary>Pending or Paid.</summary>
    public string? Status { get; set; }
    public int? EmployeeId { get; set; }
}

public class PayrollEmployeeQuery : ListQuery
{
    public bool? IsActive { get; set; }
}

public class CourseQuery : ListQuery
{
    public bool? IsActive { get; set; }
    /// <summary>Open, Complete or Deactivated.</summary>
    public string? Status { get; set; }
    /// <summary>Only courses this student can still be registered in (active, not full, not already registered).</summary>
    public int? AvailableForStudent { get; set; }
}

public class EnrollmentQuery : ListQuery
{
    public string? Status { get; set; }
    public int? CustomerId { get; set; }
    public int? CourseId { get; set; }
    public DateTime? From { get; set; }
    public DateTime? To { get; set; }
}

public record PagedResult<T>(List<T> Items, int Total, int Page, int PageSize);
