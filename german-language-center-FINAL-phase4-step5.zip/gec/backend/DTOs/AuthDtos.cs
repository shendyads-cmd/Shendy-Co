using System.ComponentModel.DataAnnotations;

namespace GermanCenter.Api.DTOs;

public record LoginRequest(
    [param: Required(ErrorMessage = "Username is required.")]
    [param: StringLength(100)]
    string Username,

    [param: Required(ErrorMessage = "Password is required.")]
    [param: StringLength(200)]
    string Password
);

public record UserDto(
    int UserId,
    string Username,
    string? FullName,
    string Role,
    bool IsActive,
    DateTime CreatedAt
);

public record LoginResponse(
    string Token,
    DateTime ExpiresAtUtc,
    UserDto User
);

public record CreateUserRequest(
    [param: Required(ErrorMessage = "Username is required.")]
    [param: StringLength(
        100,
        MinimumLength = 3,
        ErrorMessage = "Username must be 3-100 characters."
    )]
    string Username,

    [param: StringLength(150)]
    string? FullName,

    [param: Required]
    [param: RegularExpression(
        "^(Admin|Employee)$",
        ErrorMessage = "Role must be Admin or Employee."
    )]
    string Role,

    [param: Required(ErrorMessage = "Password is required.")]
    [param: StringLength(
        200,
        MinimumLength = 8,
        ErrorMessage = "Password must be at least 8 characters."
    )]
    string Password
);

public record UpdateUserRequest(
    [param: StringLength(150)]
    string? FullName,

    [param: Required]
    [param: RegularExpression(
        "^(Admin|Employee)$",
        ErrorMessage = "Role must be Admin or Employee."
    )]
    string Role,

    bool IsActive
);

public record ResetPasswordRequest(
    [param: Required(ErrorMessage = "Password is required.")]
    [param: StringLength(
        200,
        MinimumLength = 8,
        ErrorMessage = "Password must be at least 8 characters."
    )]
    string NewPassword
);