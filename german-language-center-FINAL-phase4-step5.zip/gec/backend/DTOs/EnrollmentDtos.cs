using System.ComponentModel.DataAnnotations;

namespace GermanCenter.Api.DTOs;

public record EnrollmentDto(int EnrollmentId, int CustomerId, string StudentName,
                            int CourseId, string CourseCode, string CourseName,
                            DateTime EnrollmentDate, DateTime? StartDate, DateTime? EndDate,
                            decimal TotalAmount, string Status)
{
    public string StudentCode => Utilities.Codes.Student(CustomerId);
    /// <summary>True when the course has been marked Completed (history).</summary>
    public bool CourseCompleted { get; init; }
    /// <summary>"Student" (own invoice) or "Offer" (invoice shared with other students). Filled for student details.</summary>
    public string Type { get; init; } = "Student";
    public string? InvoiceNumber { get; init; }
}

public record CreateEnrollmentRequest(
    [param: Range(1, int.MaxValue, ErrorMessage = "Student is required.")] int CustomerId,
    [param: Range(1, int.MaxValue, ErrorMessage = "Course is required.")] int CourseId,
    DateTime? EnrollmentDate,
    DateTime? StartDate,
    DateTime? EndDate,
    [param: Range(0, 10000000, ErrorMessage = "Total amount cannot be negative.")] decimal? TotalAmount);

public record UpdateEnrollmentRequest(
    [param: Required(ErrorMessage = "Enrollment date is required.")] DateTime? EnrollmentDate,
    DateTime? StartDate,
    DateTime? EndDate,
    [param: Range(0, 10000000, ErrorMessage = "Total amount cannot be negative.")] decimal TotalAmount,
    [param: Required(ErrorMessage = "Status is required."), RegularExpression("^(Active|Completed|Cancelled)$", ErrorMessage = "Status must be Active, Completed or Cancelled.")] string Status);

public record EnrollmentStatusRequest(
    [param: Required(ErrorMessage = "Status is required."), RegularExpression("^(Active|Completed|Cancelled)$", ErrorMessage = "Status must be Active, Completed or Cancelled.")] string Status);
