namespace GermanCenter.Api.DTOs;

public record CourseFinancialSummaryDto(
    decimal TotalAmount, decimal TotalPaid, decimal TotalRemaining, int PaidCount, int PartialCount, int UnpaidCount);

/// <summary>A finished course shown under Data.</summary>
public record CompletedCourseDto(int CourseId, string CourseCode, string CourseName, decimal Price, int MaxCapacity,
                                 DateTime? CompletedAt, int StudentCount)
{
    public string Status => "Completed";
    /// <summary>Null when the invoicing tables are not available yet.</summary>
    public CourseFinancialSummaryDto? Financial { get; init; }
}

/// <summary>PaymentStatus: Paid, Partially Paid, Unpaid, or "No invoice" for a registration made before invoicing existed.</summary>
public record HistoricalStudentDto(int CustomerId, string FullName, DateTime EnrollmentDate, string EnrollmentStatus,
                                   string PaymentStatus, string? InvoiceNumber)
{
    public string StudentCode => Utilities.Codes.Student(CustomerId);
}

public record CompletedCourseDetailsDto(CompletedCourseDto Course, List<HistoricalStudentDto> Students);

public record HistoricalPaymentDto(int PaymentId, DateTime PaymentDate, decimal Amount, string PaymentMethod, string? PaymentMethodOther,
                                   bool HasProof, string? ProofFileName, string? ProofContentType);

public record HistoricalInvoiceDto(int InvoiceId, string InvoiceNumber, DateTime IssueDate, decimal CoursePrice, decimal DiscountPercent,
                                   decimal DiscountAmount, decimal FinalAmount, decimal AmountPaid, decimal Remaining, string Status);

/// <summary>Read-only history of one student in one completed course.</summary>
public record HistoricalStudentDetailsDto(
    int CustomerId, string StudentCode, string FullName, string? Phone, string? Email, string? Address, string? Area,
    int CourseId, string CourseCode, string CourseName, DateTime EnrollmentDate, string EnrollmentStatus,
    HistoricalInvoiceDto? Invoice, List<HistoricalPaymentDto> Payments);

public record DeleteCourseDataRequest(string Confirmation);

public record DeleteCourseDataResultDto(int CourseId, string CourseCode, int InvoicesDeleted, int PaymentsDeleted, int PaymentsKept,
                                        int AllocationsDeleted, int EnrollmentsDeleted);
