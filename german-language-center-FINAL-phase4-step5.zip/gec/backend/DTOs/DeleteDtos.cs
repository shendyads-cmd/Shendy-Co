using System.ComponentModel.DataAnnotations;

namespace GermanCenter.Api.DTOs;

/// <summary>Body of a delete request. The reason is kept with the deleted record for later analysis.</summary>
public record DeleteRequest(
    [param: Required(ErrorMessage = "Please enter a reason."), StringLength(500, MinimumLength = 2, ErrorMessage = "The reason must be 2-500 characters.")] string Reason);
