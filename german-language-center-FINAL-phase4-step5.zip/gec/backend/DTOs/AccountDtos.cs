using System.ComponentModel.DataAnnotations;

namespace GermanCenter.Api.DTOs;

/// <summary>Account Settings, every user: the display name is the only thing a normal staff member may change.</summary>
public record UpdateProfileRequest(
    [param: Required(ErrorMessage = "Display name is required.")]
    [param: StringLength(150, MinimumLength = 2, ErrorMessage = "Display name must be 2-150 characters.")]
    string FullName
);

/// <summary>Account Settings, Admin only: changes the admin's own login password (the current password must be confirmed).</summary>
public record ChangeOwnPasswordRequest(
    [param: Required(ErrorMessage = "Current password is required.")]
    [param: StringLength(200)]
    string CurrentPassword,

    [param: Required(ErrorMessage = "New password is required.")]
    [param: StringLength(200, MinimumLength = 8, ErrorMessage = "Password must be at least 8 characters.")]
    string NewPassword
);

// ---------------------------------------------------------------- Data access (the fixed Data password)

public record DataUnlockRequest(
    [param: Required(ErrorMessage = "Password is required.")]
    [param: StringLength(200)]
    string Password
);

/// <summary>Token is null for an Admin (direct access, nothing to unlock). Staff send it back in the X-Data-Token header.</summary>
public record DataUnlockResponse(string? Token, DateTime? ExpiresAtUtc);

public record DataAccessStatusDto(bool RequiresPassword, bool PasswordConfigured);

/// <summary>Admin only. The admin's own account password confirms the change.</summary>
public record ChangeDataPasswordRequest(
    [param: Required(ErrorMessage = "Your account password is required.")]
    [param: StringLength(200)]
    string AccountPassword,

    [param: Required(ErrorMessage = "New Data password is required.")]
    [param: StringLength(200, MinimumLength = 8, ErrorMessage = "The Data password must be at least 8 characters.")]
    string NewDataPassword
);
