using System.ComponentModel.DataAnnotations;

namespace GermanCenter.Api.DTOs;

// ---------------------------------------------------------------- standalone payment

/// <summary>An additional payment on an EXISTING invoice. Cash or InstaPay only. Sent as JSON text in the multipart field "payload".</summary>
public class InvoicePaymentRequest
{
    public decimal Amount { get; set; }
    public string PaymentMethod { get; set; } = "Cash";
}

public record PaymentResultDto(
    int PaymentId, int InvoiceId, string InvoiceNumber, decimal Amount, string PaymentMethod, DateTime PaymentDate,
    decimal GrandTotal, decimal AmountPaid, decimal Remaining, string PaymentStatus);

// ---------------------------------------------------------------- expenses

public class ExpenseRequest
{
    public string Title { get; set; } = "";
    public string Category { get; set; } = "";
    public decimal Amount { get; set; }
    public DateTime ExpenseDate { get; set; }
    public string? Description { get; set; }
}

// ---------------------------------------------------------------- payroll

public class PayrollEmployeeRequest
{
    public string FullName { get; set; } = "";
    public string? JobTitle { get; set; }
    public string? Phone { get; set; }
    public decimal BaseSalary { get; set; }
    public bool IsActive { get; set; } = true;
}

public record PayrollEmployeeDto(int EmployeeId, string FullName, string? JobTitle, string? Phone, decimal BaseSalary, bool IsActive);

/// <summary>NetSalary is never sent: the server always calculates Base + Bonus - Deductions.</summary>
public class PayrollRequest
{
    public int EmployeeId { get; set; }
    public int Year { get; set; }
    public int Month { get; set; }
    public decimal BaseSalary { get; set; }
    public decimal Bonus { get; set; }
    public decimal Deductions { get; set; }
    public string? Notes { get; set; }
}

public record PayrollEntryDto(
    int PayrollId, int EmployeeId, string EmployeeName, int Year, int Month,
    decimal BaseSalary, decimal Bonus, decimal Deductions, decimal NetSalary, string Status, string? Notes, DateTime? PaidAt);

/// <summary>Totals cover ALL entries matching the filters, not only this page.</summary>
public record PayrollPageDto(List<PayrollEntryDto> Items, int Total, int Page, int PageSize, decimal TotalNet, decimal TotalPaid, decimal TotalPending);
