namespace GermanCenter.Api.Models;

public class Customer
{
    public int CustomerId { get; set; }

    public string FullName { get; set; } = string.Empty;

    public string Phone { get; set; } = string.Empty;

    public string? Email { get; set; }

    public DateTime CreatedAt { get; set; } = DateTime.Now;

    public bool IsActive { get; set; } = true;

    public string? Address { get; set; }

    /// <summary>Area / region of the student (for example Girga).</summary>
    public string? Area { get; set; }

    /// <summary>Soft delete: the row is kept for history and analysis but hidden from normal screens.</summary>
    public bool IsDeleted { get; set; }

    public DateTime? DeletedAt { get; set; }

    public string? DeletionReason { get; set; }

    public ICollection<Enrollment> Enrollments { get; set; }
        = new List<Enrollment>();
}