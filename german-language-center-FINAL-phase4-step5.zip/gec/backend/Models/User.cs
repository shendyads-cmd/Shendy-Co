namespace GermanCenter.Api.Models;

public static class Roles
{
    public const string Admin = "Admin";
    public const string Employee = "Employee";
    public const string AdminOrEmployee = "Admin,Employee";
    public static readonly string[] All = { Admin, Employee };
}

/// <summary>Maps to dbo.Users (columns: user_id, username, password_hash, full_name, role, is_active, created_at).</summary>
public class User
{
    public int UserId { get; set; }
    public string Username { get; set; } = "";
    public string PasswordHash { get; set; } = "";
    public string? FullName { get; set; }
    public string Role { get; set; } = Roles.Employee;
    public bool IsActive { get; set; } = true;
    public DateTime CreatedAt { get; set; }
}
