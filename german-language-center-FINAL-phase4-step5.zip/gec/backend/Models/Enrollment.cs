namespace GermanCenter.Api.Models;

public static class EnrollmentStatus
{
    public const string Active = "Active";
    public const string Completed = "Completed";
    public const string Cancelled = "Cancelled";
    public static readonly string[] All = { Active, Completed, Cancelled };
}

public class Enrollment
{
    public int EnrollmentId { get; set; }

    public int CustomerId { get; set; }

    public int CourseId { get; set; }

    public DateTime EnrollmentDate { get; set; } = DateTime.Now;

    public DateTime? StartDate { get; set; }

    public DateTime? EndDate { get; set; }

    public string Status { get; set; } = "Active";

    public decimal TotalAmount { get; set; }

    public Customer Customer { get; set; } = null!;

    public Course Course { get; set; } = null!;
}