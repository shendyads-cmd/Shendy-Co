namespace GermanCenter.Api.Models;

public class Course
{
    public int CourseId { get; set; }

    public string CourseCode { get; set; } = string.Empty;

    public string CourseName { get; set; } = string.Empty;

    public decimal Price { get; set; }

    /// <summary>Maximum number of students that can be registered at the same time (max_capacity).</summary>
    public int MaxCapacity { get; set; } = 30;

    public bool IsActive { get; set; } = true;

    /// <summary>Soft delete: the row is kept for history and analysis but hidden from normal screens.</summary>
    public bool IsDeleted { get; set; }

    /// <summary>Set by an administrator when the course has finished. Completed courses are history only (see Data).</summary>
    public bool IsCompleted { get; set; }

    public DateTime? CompletedAt { get; set; }

    public DateTime? DeletedAt { get; set; }

    public string? DeletionReason { get; set; }

    public ICollection<Enrollment> Enrollments { get; set; }
        = new List<Enrollment>();
}