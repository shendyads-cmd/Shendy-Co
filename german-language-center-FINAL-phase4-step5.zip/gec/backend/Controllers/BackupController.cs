using System.Security.Claims;
using GermanCenter.Api.DTOs;
using GermanCenter.Api.Filters;
using GermanCenter.Api.Models;
using GermanCenter.Api.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace GermanCenter.Api.Controllers;

/// <summary>Backup and restore. Admin only, enforced here; staff who unlocked Data with the password still get 403.</summary>
[ApiController]
[Route("api/data/backups")]
[Authorize(Roles = Roles.Admin)]
[DataAccess]
public class BackupController(BackupService backups) : ControllerBase
{
    private int UserId => int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);

    [HttpGet]
    public async Task<ActionResult<List<BackupInfoDto>>> List(CancellationToken ct) => Ok(await backups.ListAsync(ct));

    /// <summary>Takes a full database backup now (needs an Idempotency-Key so a double click makes one backup).</summary>
    [HttpPost]
    [Idempotent("data.backup")]
    public async Task<ActionResult<BackupInfoDto>> Create(CancellationToken ct)
        => StatusCode(StatusCodes.Status201Created, await backups.CreateAsync("manual", ct));

    /// <summary>DESTRUCTIVE: replaces ALL current data with the chosen backup. Needs the typed word RESTORE and the admin's account password.</summary>
    [HttpPost("{id:int}/restore")]
    public async Task<ActionResult<RestoreResultDto>> Restore(int id, [FromBody] RestoreRequest request, CancellationToken ct)
        => Ok(await backups.RestoreAsync(UserId, id, request, ct));
}
