using GermanCenter.Api.DTOs;
using GermanCenter.Api.Models;
using GermanCenter.Api.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace GermanCenter.Api.Controllers;

/// <summary>Read-only audit trail. Admin only (enforced here). There is deliberately no endpoint that changes or deletes a record.</summary>
[ApiController]
[Route("api/audit")]
[Authorize(Roles = Roles.Admin)]
public class AuditController(AuditService audit) : ControllerBase
{
    [HttpGet]
    public async Task<ActionResult<PagedResult<AuditRowDto>>> List([FromQuery] AuditQuery query, CancellationToken ct) => Ok(await audit.ListAsync(query, ct));

    [HttpGet("types")]
    public ActionResult<string[]> Types() => Ok(AuditService.ActionTypes);
}
