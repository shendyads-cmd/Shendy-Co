using System.Security.Claims;
using GermanCenter.Api.DTOs;
using GermanCenter.Api.Filters;
using GermanCenter.Api.Models;
using GermanCenter.Api.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace GermanCenter.Api.Controllers;

/// <summary>New Student: student + enrollment + invoice + payment (+ optional proof) in one transaction.</summary>
[ApiController]
[Route("api/registrations")]
[Authorize(Roles = Roles.AdminOrEmployee)]
public class RegistrationsController(RegistrationService registrations) : ControllerBase
{
    [HttpPost]
    [Idempotent("registrations.create")]
    [Consumes("multipart/form-data")]
    [RequestSizeLimit(8 * 1024 * 1024)]
    public async Task<ActionResult<RegistrationResultDto>> Register([FromForm] RegisterStudentForm form, CancellationToken ct)
    {
        var userId = int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);
        var result = await registrations.RegisterAsync(form, userId, ct);
        return StatusCode(StatusCodes.Status201Created, result);
    }
}
