using GermanCenter.Api.DTOs;
using GermanCenter.Api.Filters;
using GermanCenter.Api.Models;
using GermanCenter.Api.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace GermanCenter.Api.Controllers;

/// <summary>
/// Data: history of completed courses, exports and the permanent clean-up. Enforced here, not just in the UI:
/// Admin = direct access; Employee = only with a valid Data token (see DataAccessController); the permanent delete stays Admin only.
/// </summary>
[ApiController]
[Route("api/data")]
[Authorize(Roles = Roles.AdminOrEmployee)]
[DataAccess]
public class DataController(DataService data, DataExportService export) : ControllerBase
{
    private const string XlsxType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";

    [HttpGet("courses")]
    public async Task<ActionResult<PagedResult<CompletedCourseDto>>> ListCompleted([FromQuery] ListQuery query, CancellationToken ct)
        => Ok(await data.ListCompletedAsync(query, ct));

    /// <summary>paymentStatus (optional): paid, partial or unpaid.</summary>
    [HttpGet("courses/{id:int}")]
    public async Task<ActionResult<CompletedCourseDetailsDto>> GetCompleted(int id, [FromQuery] string? paymentStatus, CancellationToken ct)
        => Ok(await data.GetCompletedAsync(id, paymentStatus, ct));

    /// <summary>Read-only history of one student in a completed course (student, invoice, payments).</summary>
    [HttpGet("courses/{courseId:int}/students/{customerId:int}")]
    public async Task<ActionResult<HistoricalStudentDetailsDto>> GetStudentHistory(int courseId, int customerId, CancellationToken ct)
        => Ok(await data.GetStudentHistoryAsync(courseId, customerId, ct));

    [HttpGet("payments/{paymentId:int}/proof")]
    public async Task<IActionResult> GetProof(int paymentId, CancellationToken ct)
    {
        var (stream, contentType, fileName) = await data.OpenProofAsync(paymentId, ct);
        Response.Headers.ContentDisposition = "inline; filename*=UTF-8''" + Uri.EscapeDataString(fileName);
        return File(stream, contentType);
    }

    /// <summary>Permanent clean-up of one completed course. Requires the body {"confirmation":"DELETE"}.</summary>
    [HttpDelete("courses/{id:int}")]
    [Authorize(Roles = Roles.Admin)]
    public async Task<ActionResult<DeleteCourseDataResultDto>> DeleteCourseData(int id, DeleteCourseDataRequest request, CancellationToken ct)
        => Ok(await data.DeleteCourseDataAsync(id, request.Confirmation, ct));

    /// <summary>Downloads a .sql script with INSERT statements. Read-only: nothing is changed in the database.</summary>
    [HttpGet("export/sql")]
    public async Task<IActionResult> ExportSql(CancellationToken ct)
        => File(await export.ExportSqlAsync(ct), "application/sql", $"german_center_export_{DateTime.Now:yyyyMMdd_HHmm}.sql");

    /// <summary>Downloads an .xlsx workbook with one sheet per table. Read-only.</summary>
    [HttpGet("export/excel")]
    public async Task<IActionResult> ExportExcel(CancellationToken ct)
        => File(await export.ExportExcelAsync(ct), XlsxType, $"german_center_export_{DateTime.Now:yyyyMMdd_HHmm}.xlsx");
}
