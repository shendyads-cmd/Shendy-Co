using System.Security.Claims;
using GermanCenter.Api.Data;
using GermanCenter.Api.DTOs;
using GermanCenter.Api.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace GermanCenter.Api.Controllers;

[ApiController]
[Route("api/auth")]
public class AuthController(AuthService auth, AppDbContext db, AuditService audit) : ControllerBase
{
    [HttpPost("login"), AllowAnonymous]
    public async Task<IActionResult> Login(LoginRequest request, CancellationToken ct)
    {
        var result = await auth.LoginAsync(request, ct);
        var ip = HttpContext.Connection.RemoteIpAddress?.ToString();
        if (result.Status == LoginStatus.Success)
            await audit.LogAsync(result.Response!.User.UserId, result.Response.User.Username, "Auth.Login", "Auth", "Auth", result.Response.User.UserId.ToString(), null, ip, CancellationToken.None);
        else
            await audit.LogAsync(null, request.Username.Trim(), result.Status == LoginStatus.AccountDisabled ? "Auth.LoginDisabled" : "Auth.LoginFailed", "Auth", "Auth", null, null, ip, CancellationToken.None);
        return result.Status switch
        {
            LoginStatus.Success => Ok(result.Response),
            LoginStatus.AccountDisabled => StatusCode(403, new ApiError("ACCOUNT_DISABLED", "This account is disabled. Please contact the administrator.")),
            _ => Unauthorized(new ApiError("INVALID_CREDENTIALS", "Invalid username or password."))
        };
    }

    /// <summary>Only records the logout in the audit trail (JWTs are stateless); the browser then forgets its token.</summary>
    [HttpPost("logout"), Authorize]
    public IActionResult Logout() => NoContent();

    [HttpGet("me"), Authorize]
    public async Task<ActionResult<UserDto>> Me(CancellationToken ct)
    {
        var id = int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);
        var user = await db.Users.AsNoTracking().FirstOrDefaultAsync(u => u.UserId == id, ct);
        return user is null ? Unauthorized() : Ok(AuthService.ToDto(user));
    }
}
