using GermanCenter.Api.DTOs;
using GermanCenter.Api.Filters;
using GermanCenter.Api.Models;
using GermanCenter.Api.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace GermanCenter.Api.Controllers;

/// <summary>Students. Admin and Employee can read/create/edit; only Admin can delete or restore.</summary>
[ApiController]
[Route("api/customers")]
[Authorize(Roles = Roles.AdminOrEmployee)]
public class CustomersController(CustomerService customers) : ControllerBase
{
    [HttpGet]
    public async Task<ActionResult<PagedResult<CustomerDto>>> List([FromQuery] CustomerQuery query, CancellationToken ct)
        => Ok(await customers.ListAsync(query, ct));

    [HttpGet("stats")]
    public async Task<ActionResult<CustomerStatsDto>> Stats(CancellationToken ct)
        => Ok(await customers.StatsAsync(ct));

    [HttpGet("{id:int}")]
    public async Task<ActionResult<CustomerDetailsDto>> Get(int id, CancellationToken ct)
        => Ok(await customers.GetDetailsAsync(id, ct));

    [HttpPost]
    [Idempotent("customers.create")]
    public async Task<ActionResult<CustomerDto>> Create(CustomerRequest request, CancellationToken ct)
    {
        var created = await customers.CreateAsync(request, ct);
        return Created($"/api/customers/{created.CustomerId}", created);
    }

    [HttpPut("{id:int}")]
    public async Task<ActionResult<CustomerDto>> Update(int id, CustomerRequest request, CancellationToken ct)
        => Ok(await customers.UpdateAsync(id, request, ct));

    [HttpPatch("{id:int}/status")]
    public async Task<ActionResult<CustomerDto>> SetStatus(int id, ActiveStatusRequest request, CancellationToken ct)
        => Ok(await customers.SetActiveAsync(id, request.IsActive, ct));

    /// <summary>Moves the student to "Deleted students" (kept for history). A reason is required.</summary>
    [HttpDelete("{id:int}")]
    [Authorize(Roles = Roles.Admin)]
    public async Task<IActionResult> Delete(int id, DeleteRequest request, CancellationToken ct)
    {
        await customers.DeleteAsync(id, request.Reason, ct);
        return NoContent();
    }

    [HttpGet("deleted")]
    [Authorize(Roles = Roles.Admin)]
    public async Task<ActionResult<PagedResult<DeletedCustomerDto>>> ListDeleted([FromQuery] ListQuery query, CancellationToken ct)
        => Ok(await customers.ListDeletedAsync(query, ct));

    [HttpPost("{id:int}/restore")]
    [Authorize(Roles = Roles.Admin)]
    public async Task<ActionResult<CustomerDto>> Restore(int id, CancellationToken ct)
        => Ok(await customers.RestoreAsync(id, ct));
}
