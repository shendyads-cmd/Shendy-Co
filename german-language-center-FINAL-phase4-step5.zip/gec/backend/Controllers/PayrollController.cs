using System.Security.Claims;
using GermanCenter.Api.DTOs;
using GermanCenter.Api.Filters;
using GermanCenter.Api.Models;
using GermanCenter.Api.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace GermanCenter.Api.Controllers;

/// <summary>Payroll is Admin only (enforced here, not only in the screen). Creating and paying need an Idempotency-Key.</summary>
[ApiController]
[Route("api/payroll")]
[Authorize(Roles = Roles.Admin)]
public class PayrollController(PayrollService payroll) : ControllerBase
{
    private int UserId => int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);

    // ---- employees
    [HttpGet("employees")]
    public async Task<ActionResult<PagedResult<PayrollEmployeeDto>>> Employees([FromQuery] PayrollEmployeeQuery query, CancellationToken ct)
        => Ok(await payroll.ListEmployeesAsync(query, ct));

    [HttpPost("employees")]
    [Idempotent("payroll.employee.create")]
    public async Task<ActionResult<PayrollEmployeeDto>> CreateEmployee([FromBody] PayrollEmployeeRequest request, CancellationToken ct)
        => StatusCode(StatusCodes.Status201Created, await payroll.CreateEmployeeAsync(request, UserId, ct));

    [HttpPut("employees/{id:int}")]
    public async Task<ActionResult<PayrollEmployeeDto>> UpdateEmployee(int id, [FromBody] PayrollEmployeeRequest request, CancellationToken ct)
        => Ok(await payroll.UpdateEmployeeAsync(id, request, ct));

    // ---- salary entries
    [HttpGet]
    public async Task<ActionResult<PayrollPageDto>> List([FromQuery] PayrollQuery query, CancellationToken ct)
        => Ok(await payroll.ListAsync(query, ct));

    [HttpPost]
    [Idempotent("payroll.create")]
    public async Task<ActionResult<PayrollEntryDto>> Create([FromBody] PayrollRequest request, CancellationToken ct)
        => StatusCode(StatusCodes.Status201Created, await payroll.CreateAsync(request, UserId, ct));

    [HttpPut("{id:int}")]
    public async Task<ActionResult<PayrollEntryDto>> Update(int id, [FromBody] PayrollRequest request, CancellationToken ct)
        => Ok(await payroll.UpdateAsync(id, request, ct));

    [HttpDelete("{id:int}")]
    public async Task<IActionResult> Delete(int id, CancellationToken ct)
    {
        await payroll.DeleteAsync(id, ct);
        return NoContent();
    }

    /// <summary>Pays the salary: Pending -> Paid and the Cash Out, in one transaction. A second call never pays again.</summary>
    [HttpPost("{id:int}/pay")]
    [Idempotent("payroll.pay")]
    public async Task<ActionResult<PayrollEntryDto>> Pay(int id, CancellationToken ct)
        => Ok(await payroll.PayAsync(id, UserId, ct));
}
