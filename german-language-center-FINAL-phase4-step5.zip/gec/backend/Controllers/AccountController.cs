using System.Security.Claims;
using GermanCenter.Api.DTOs;
using GermanCenter.Api.Models;
using GermanCenter.Api.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace GermanCenter.Api.Controllers;

/// <summary>Account Settings of the logged-in user. The user id always comes from the JWT, never from the request.</summary>
[ApiController]
[Route("api/account")]
[Authorize]
public class AccountController(UserService users) : ControllerBase
{
    private int UserId => int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);

    /// <summary>Every user may change their own display name (nothing else about the account).</summary>
    [HttpPut("profile")]
    public async Task<ActionResult<UserDto>> UpdateProfile(UpdateProfileRequest request, CancellationToken ct)
        => Ok(await users.UpdateOwnProfileAsync(UserId, request, ct));

    /// <summary>Admin only: change the own login password.</summary>
    [HttpPost("change-password")]
    [Authorize(Roles = Roles.Admin)]
    public async Task<IActionResult> ChangePassword(ChangeOwnPasswordRequest request, CancellationToken ct)
    {
        await users.ChangeOwnPasswordAsync(UserId, request, ct);
        return NoContent();
    }
}
