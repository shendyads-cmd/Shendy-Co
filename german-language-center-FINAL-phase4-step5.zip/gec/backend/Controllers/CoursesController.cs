using GermanCenter.Api.DTOs;
using GermanCenter.Api.Filters;
using GermanCenter.Api.Models;
using GermanCenter.Api.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace GermanCenter.Api.Controllers;

/// <summary>Courses. Admin and Employee can read/create/edit; only Admin can delete.</summary>
[ApiController]
[Route("api/courses")]
[Authorize(Roles = Roles.AdminOrEmployee)]
public class CoursesController(CourseService courses) : ControllerBase
{
    [HttpGet]
    public async Task<ActionResult<PagedResult<CourseDto>>> List([FromQuery] CourseQuery query, CancellationToken ct)
        => Ok(await courses.ListAsync(query, ct));

    [HttpGet("{id:int}")]
    public async Task<ActionResult<CourseDetailsDto>> Get(int id, CancellationToken ct)
        => Ok(await courses.GetDetailsAsync(id, ct));

    [HttpPost]
    [Idempotent("courses.create")]
    public async Task<ActionResult<CourseDto>> Create(CourseRequest request, CancellationToken ct)
    {
        var created = await courses.CreateAsync(request, ct);
        return Created($"/api/courses/{created.CourseId}", created);
    }

    [HttpPut("{id:int}")]
    public async Task<ActionResult<CourseDto>> Update(int id, CourseRequest request, CancellationToken ct)
        => Ok(await courses.UpdateAsync(id, request, ct));

    [HttpPatch("{id:int}/status")]
    public async Task<ActionResult<CourseDto>> SetStatus(int id, ActiveStatusRequest request, CancellationToken ct)
        => Ok(await courses.SetActiveAsync(id, request.IsActive, ct));

    /// <summary>Marks the course as finished (Admin). History moves to Data; nothing is deleted.</summary>
    [HttpPost("{id:int}/complete")]
    [Authorize(Roles = Roles.Admin)]
    public async Task<ActionResult<CompletedCourseDto>> Complete(int id, CancellationToken ct)
        => Ok(await courses.CompleteAsync(id, ct));

    [HttpPost("{id:int}/reopen")]
    [Authorize(Roles = Roles.Admin)]
    public async Task<ActionResult<CourseDto>> Reopen(int id, CancellationToken ct)
        => Ok(await courses.ReopenAsync(id, ct));

    /// <summary>Moves the course to "Deleted courses" (kept for history). Registered students do not block this.</summary>
    [HttpDelete("{id:int}")]
    [Authorize(Roles = Roles.Admin)]
    public async Task<IActionResult> Delete(int id, DeleteRequest request, CancellationToken ct)
    {
        await courses.DeleteAsync(id, request.Reason, ct);
        return NoContent();
    }

    [HttpGet("deleted")]
    [Authorize(Roles = Roles.Admin)]
    public async Task<ActionResult<PagedResult<DeletedCourseDto>>> ListDeleted([FromQuery] ListQuery query, CancellationToken ct)
        => Ok(await courses.ListDeletedAsync(query, ct));

    [HttpPost("{id:int}/restore")]
    [Authorize(Roles = Roles.Admin)]
    public async Task<ActionResult<CourseDto>> Restore(int id, CancellationToken ct)
        => Ok(await courses.RestoreAsync(id, ct));
}
