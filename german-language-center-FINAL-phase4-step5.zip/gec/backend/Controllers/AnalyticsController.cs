using GermanCenter.Api.DTOs;
using GermanCenter.Api.Models;
using GermanCenter.Api.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace GermanCenter.Api.Controllers;

/// <summary>One aggregated call for the whole Dashboard (KPIs, trends, courses). Admin only, enforced here.</summary>
[ApiController]
[Route("api/dashboard")]
[Authorize(Roles = Roles.Admin)]
public class DashboardController(AnalyticsService analytics) : ControllerBase
{
    [HttpGet]
    public async Task<ActionResult<DashboardDto>> Get([FromQuery] DashboardQuery query, CancellationToken ct)
        => Ok(await analytics.DashboardAsync(query.FromDate, query.ToDate, ct));
}

/// <summary>Detailed reports with From / To filtering. Admin only, enforced here (hiding the screen is not the protection).</summary>
[ApiController]
[Route("api/reports")]
[Authorize(Roles = Roles.Admin)]
public class ReportsController(AnalyticsService analytics) : ControllerBase
{
    [HttpGet("summary")]
    public async Task<ActionResult<FinancialSummaryDto>> Summary([FromQuery] DashboardQuery query, CancellationToken ct)
        => Ok(await analytics.SummaryAsync(query.FromDate, query.ToDate, ct));

    [HttpGet("sales")]
    public async Task<ActionResult<SalesReportDto>> Sales([FromQuery] ReportQuery query, CancellationToken ct) => Ok(await analytics.SalesAsync(query, ct));

    [HttpGet("payments")]
    public async Task<ActionResult<PaymentsReportDto>> Payments([FromQuery] ReportQuery query, CancellationToken ct) => Ok(await analytics.PaymentsAsync(query, ct));

    [HttpGet("expenses")]
    public async Task<ActionResult<ExpenseReportDto>> Expenses([FromQuery] ReportQuery query, CancellationToken ct) => Ok(await analytics.ExpensesAsync(query, ct));

    [HttpGet("outstanding")]
    public async Task<ActionResult<OutstandingReportDto>> Outstanding([FromQuery] ReportQuery query, CancellationToken ct) => Ok(await analytics.OutstandingAsync(query, ct));

    [HttpGet("payroll")]
    public async Task<ActionResult<PayrollPageDto>> Payroll([FromQuery] ReportQuery query, CancellationToken ct) => Ok(await analytics.PayrollAsync(query, ct));

    [HttpGet("courses")]
    public async Task<ActionResult<CourseReportDto>> Courses([FromQuery] DashboardQuery query, CancellationToken ct)
        => Ok(await analytics.CoursesAsync(query.FromDate, query.ToDate, ct));
}
