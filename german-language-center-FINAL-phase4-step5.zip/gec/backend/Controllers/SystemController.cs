using GermanCenter.Api.Data;
using GermanCenter.Api.DTOs;
using GermanCenter.Api.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace GermanCenter.Api.Controllers;

[ApiController]
[Route("api/system")]
public class SystemController(AppDbContext db, SchemaChecker checker) : ControllerBase
{
    [HttpGet("health"), AllowAnonymous]
    public async Task<IActionResult> Health(CancellationToken ct)
        => await db.Database.CanConnectAsync(ct)
            ? Ok(new { status = "ok" })
            : StatusCode(503, new ApiError("DB_UNAVAILABLE", "The database is not reachable."));

    /// <summary>Read-only comparison of the EF model with the real SQL Server schema.</summary>
    [HttpGet("schema-check"), Authorize(Roles = Roles.Admin)]
    public async Task<IActionResult> SchemaCheck(CancellationToken ct) => Ok(await checker.CheckAsync(ct));
}
