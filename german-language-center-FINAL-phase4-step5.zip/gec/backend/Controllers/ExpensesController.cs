using System.Security.Claims;
using GermanCenter.Api.DTOs;
using GermanCenter.Api.Filters;
using GermanCenter.Api.Models;
using GermanCenter.Api.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace GermanCenter.Api.Controllers;

/// <summary>Expenses are Admin only (enforced here). Create and edit also write the Cash Out row in the same transaction.</summary>
[ApiController]
[Route("api/expenses")]
[Authorize(Roles = Roles.Admin)]
public class ExpensesController(ExpenseService expenses) : ControllerBase
{
    [HttpGet]
    public async Task<ActionResult<ExpensePageDto>> List([FromQuery] ExpenseQuery query, CancellationToken ct)
        => Ok(await expenses.ListAsync(query, ct));

    /// <summary>The fixed category list the form offers (salaries are paid through Payroll, not as an expense).</summary>
    [HttpGet("categories")]
    public ActionResult<string[]> Categories() => Ok(ExpenseService.Categories);

    [HttpPost]
    [Idempotent("expenses.create")]
    public async Task<ActionResult<ExpenseDto>> Create([FromBody] ExpenseRequest request, CancellationToken ct)
    {
        var userId = int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);
        return StatusCode(StatusCodes.Status201Created, await expenses.CreateAsync(request, userId, ct));
    }

    [HttpPut("{id:int}")]
    public async Task<ActionResult<ExpenseDto>> Update(int id, [FromBody] ExpenseRequest request, CancellationToken ct)
        => Ok(await expenses.UpdateAsync(id, request, ct));
}
