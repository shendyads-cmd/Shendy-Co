using System.Security.Claims;
using GermanCenter.Api.DTOs;
using GermanCenter.Api.Models;
using GermanCenter.Api.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace GermanCenter.Api.Controllers;

/// <summary>The gate in front of Data. The Data password itself is never returned by any of these endpoints.</summary>
[ApiController]
[Route("api/data-access")]
[Authorize(Roles = Roles.AdminOrEmployee)]
public class DataAccessController(DataAccessService access) : ControllerBase
{
    private int UserId => int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);

    /// <summary>Does this user have to enter the password? (Admin: no.) Is a Data password configured at all?</summary>
    [HttpGet]
    public async Task<ActionResult<DataAccessStatusDto>> Status(CancellationToken ct)
        => Ok(new DataAccessStatusDto(!User.IsInRole(Roles.Admin), await access.IsConfiguredAsync(ct)));

    /// <summary>Checks the Data password. Success returns a 30-minute token for the X-Data-Token header. An Admin gets no token because none is needed.</summary>
    [HttpPost("unlock")]
    public async Task<ActionResult<DataUnlockResponse>> Unlock(DataUnlockRequest request, CancellationToken ct)
        => User.IsInRole(Roles.Admin)
            ? Ok(new DataUnlockResponse(null, null))
            : Ok(await access.UnlockAsync(UserId, request.Password, ct));

    /// <summary>Admin only: sets a new fixed Data password (confirmed with the admin's own account password). Tokens issued before are no longer accepted.</summary>
    [HttpPut("password")]
    [Authorize(Roles = Roles.Admin)]
    public async Task<IActionResult> ChangePassword(ChangeDataPasswordRequest request, CancellationToken ct)
    {
        await access.ChangePasswordAsync(UserId, request, ct);
        return NoContent();
    }
}
