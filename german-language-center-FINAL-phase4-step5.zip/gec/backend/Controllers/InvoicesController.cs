using System.Security.Claims;
using System.Text.Json;
using GermanCenter.Api.DTOs;
using GermanCenter.Api.Filters;
using GermanCenter.Api.Middleware;
using GermanCenter.Api.Models;
using GermanCenter.Api.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace GermanCenter.Api.Controllers;

/// <summary>Invoices for a Student or an Offer (one invoice, many students). Admin and Employee.</summary>
[ApiController]
[Route("api/invoices")]
[Authorize(Roles = Roles.AdminOrEmployee)]
public class InvoicesController(InvoiceService invoices, PaymentService payments) : ControllerBase
{
    /// <summary>Server-side search (invoice number, student, course), date range and status filter.</summary>
    [HttpGet]
    public async Task<ActionResult<PagedResult<InvoiceListItemDto>>> List([FromQuery] InvoiceQuery query, CancellationToken ct)
        => Ok(await invoices.ListAsync(query, ct));

    [HttpGet("{id:int}")]
    public async Task<ActionResult<InvoiceDetailsDto>> Get(int id, CancellationToken ct)
        => Ok(await invoices.GetAsync(id, ct));

    /// <summary>Validates the draft and returns the server's calculation. Nothing is saved.</summary>
    [HttpPost("preview")]
    public async Task<ActionResult<InvoicePreviewDto>> Preview([FromBody] InvoiceCreateRequest request, CancellationToken ct)
        => Ok(await invoices.PreviewAsync(request, ct));

    /// <summary>Saves a Student or Offer invoice. multipart/form-data: "payload" (JSON) + optional "proof" file.</summary>
    [HttpPost]
    [Idempotent("invoices.create")]
    [Consumes("multipart/form-data")]
    [RequestSizeLimit(8 * 1024 * 1024)]
    public async Task<ActionResult<InvoiceDetailsDto>> Create([FromForm] string payload, IFormFile? proof, CancellationToken ct)
    {
        InvoiceCreateRequest? request;
        try { request = JsonSerializer.Deserialize<InvoiceCreateRequest>(payload, new JsonSerializerOptions(JsonSerializerDefaults.Web)); }
        catch (JsonException) { request = null; }
        if (request == null) throw AppException.BadRequest("The invoice data is not valid.", "PAYLOAD");

        var userId = int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);
        var id = await invoices.CreateAsync(request, proof, userId, ct);
        return StatusCode(StatusCodes.Status201Created, await invoices.GetAsync(id, ct));
    }

    /// <summary>Edits the SAME invoice (students, course, discount). Totals are recalculated here.</summary>
    [HttpPut("{id:int}")]
    public async Task<ActionResult<InvoiceDetailsDto>> Update(int id, [FromBody] InvoiceUpdateRequest request, CancellationToken ct)
        => Ok(await invoices.UpdateAsync(id, request, ct));

    /// <summary>
    /// Records an additional payment on an existing invoice (Cash or InstaPay). multipart/form-data: "payload" (JSON) + optional "proof" file (InstaPay only).
    /// Needs an Idempotency-Key header, so a double click or a network retry can never record the payment twice.
    /// </summary>
    [HttpPost("{id:int}/payments")]
    [Idempotent("invoices.payment")]
    [Consumes("multipart/form-data")]
    [RequestSizeLimit(8 * 1024 * 1024)]
    public async Task<ActionResult<PaymentResultDto>> AddPayment(int id, [FromForm] string payload, IFormFile? proof, CancellationToken ct)
    {
        InvoicePaymentRequest? request;
        try { request = JsonSerializer.Deserialize<InvoicePaymentRequest>(payload, new JsonSerializerOptions(JsonSerializerDefaults.Web)); }
        catch (JsonException) { request = null; }
        if (request == null) throw AppException.BadRequest("The payment data is not valid.", "PAYLOAD");

        var userId = int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);
        return StatusCode(StatusCodes.Status201Created, await payments.AddAsync(id, request, proof, userId, ct));
    }
}
