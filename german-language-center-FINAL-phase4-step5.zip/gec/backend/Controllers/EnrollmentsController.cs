using GermanCenter.Api.DTOs;
using GermanCenter.Api.Filters;
using GermanCenter.Api.Models;
using GermanCenter.Api.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace GermanCenter.Api.Controllers;

/// <summary>Enrollments. Admin and Employee. Enrollments are never deleted; set the status to Cancelled instead.</summary>
[ApiController]
[Route("api/enrollments")]
[Authorize(Roles = Roles.AdminOrEmployee)]
public class EnrollmentsController(EnrollmentService enrollments) : ControllerBase
{
    [HttpGet]
    public async Task<ActionResult<PagedResult<EnrollmentDto>>> List([FromQuery] EnrollmentQuery query, CancellationToken ct)
        => Ok(await enrollments.ListAsync(query, ct));

    [HttpGet("{id:int}")]
    public async Task<ActionResult<EnrollmentDto>> Get(int id, CancellationToken ct)
        => Ok(await enrollments.GetAsync(id, ct));

    [HttpPost]
    [Idempotent("enrollments.create")]
    public async Task<ActionResult<EnrollmentDto>> Create(CreateEnrollmentRequest request, CancellationToken ct)
    {
        var created = await enrollments.CreateAsync(request, ct);
        return Created($"/api/enrollments/{created.EnrollmentId}", created);
    }

    [HttpPut("{id:int}")]
    public async Task<ActionResult<EnrollmentDto>> Update(int id, UpdateEnrollmentRequest request, CancellationToken ct)
        => Ok(await enrollments.UpdateAsync(id, request, ct));

    [HttpPatch("{id:int}/status")]
    public async Task<ActionResult<EnrollmentDto>> SetStatus(int id, EnrollmentStatusRequest request, CancellationToken ct)
        => Ok(await enrollments.SetStatusAsync(id, request.Status, ct));
}
