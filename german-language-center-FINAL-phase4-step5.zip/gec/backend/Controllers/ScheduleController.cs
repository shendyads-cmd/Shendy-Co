using System.Security.Claims;
using GermanCenter.Api.DTOs;
using GermanCenter.Api.Models;
using GermanCenter.Api.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace GermanCenter.Api.Controllers;

/// <summary>The logged-in user's own schedule. The user id is taken from the JWT only.</summary>
[ApiController]
[Route("api/schedule")]
[Authorize(Roles = Roles.AdminOrEmployee)]
public class ScheduleController(ScheduleService schedule) : ControllerBase
{
    private int UserId => int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);

    [HttpGet]
    public async Task<ActionResult<List<ScheduleEntryDto>>> List([FromQuery] ScheduleQuery query, CancellationToken ct)
        => Ok(await schedule.ListAsync(UserId, query.FromDate, query.ToDate, ct));

    [HttpPost]
    public async Task<ActionResult<ScheduleEntryDto>> Create([FromBody] ScheduleRequest request, CancellationToken ct)
        => StatusCode(StatusCodes.Status201Created, await schedule.CreateAsync(UserId, request, ct));

    [HttpPut("{id:int}")]
    public async Task<ActionResult<ScheduleEntryDto>> Update(int id, [FromBody] ScheduleRequest request, CancellationToken ct)
        => Ok(await schedule.UpdateAsync(UserId, id, request, ct));

    [HttpDelete("{id:int}")]
    public async Task<IActionResult> Delete(int id, CancellationToken ct)
    {
        await schedule.DeleteAsync(UserId, id, ct);
        return NoContent();
    }
}
