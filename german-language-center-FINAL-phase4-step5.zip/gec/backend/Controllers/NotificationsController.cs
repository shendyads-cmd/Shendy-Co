using System.Security.Claims;
using GermanCenter.Api.DTOs;
using GermanCenter.Api.Models;
using GermanCenter.Api.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace GermanCenter.Api.Controllers;

/// <summary>
/// The signed-in user's notifications. The user is always taken from the token, never from the request, so nobody can
/// read or change another user's read state.
/// </summary>
[ApiController]
[Route("api/notifications")]
[Authorize(Roles = Roles.AdminOrEmployee)]
public class NotificationsController(NotificationService notifications) : ControllerBase
{
    private int UserId => int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);
    private string Role => User.FindFirstValue(ClaimTypes.Role) ?? Roles.Employee;

    /// <summary>Newest first, with this user's read state and unread count.</summary>
    [HttpGet]
    public async Task<ActionResult<NotificationListDto>> List([FromQuery] int take = 50, CancellationToken ct = default)
        => Ok(await notifications.ListAsync(UserId, Role, take, ct));

    [HttpGet("unread-count")]
    public async Task<ActionResult<UnreadCountDto>> UnreadCount(CancellationToken ct)
        => Ok(new UnreadCountDto(await notifications.UnreadCountAsync(UserId, Role, ct)));

    /// <summary>Marks one notification as read for the current user only. Repeating it is harmless.</summary>
    [HttpPost("{id:int}/read")]
    public async Task<ActionResult<UnreadCountDto>> MarkRead(int id, CancellationToken ct)
        => Ok(new UnreadCountDto(await notifications.MarkReadAsync(id, UserId, Role, ct)));

    /// <summary>Marks every unread notification as read for the current user only.</summary>
    [HttpPost("read-all")]
    public async Task<ActionResult<UnreadCountDto>> MarkAllRead(CancellationToken ct)
        => Ok(new UnreadCountDto(await notifications.MarkAllReadAsync(UserId, Role, ct)));
}
