using GermanCenter.Api.DTOs;

namespace GermanCenter.Api.Middleware;

public class ExceptionHandlingMiddleware(RequestDelegate next, ILogger<ExceptionHandlingMiddleware> logger)
{
    public async Task InvokeAsync(HttpContext ctx)
    {
        try { await next(ctx); }
        catch (AppException ex)
        {
            ctx.Response.StatusCode = ex.Status;
            await ctx.Response.WriteAsJsonAsync(new ApiError(ex.Code, ex.Message, ctx.TraceIdentifier));
        }
        catch (OperationCanceledException) when (ctx.RequestAborted.IsCancellationRequested)
        {
            ctx.Response.StatusCode = 499;
        }
        catch (Exception ex)
        {
            // Technical details are logged only; users never see raw SQL Server errors.
            logger.LogError(ex, "Unhandled exception. TraceId {TraceId}", ctx.TraceIdentifier);
            ctx.Response.StatusCode = 500;
            await ctx.Response.WriteAsJsonAsync(new ApiError("SERVER_ERROR",
                "Something went wrong on the server. Please try again or contact the administrator.", ctx.TraceIdentifier));
        }
    }
}
