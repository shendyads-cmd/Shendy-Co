namespace GermanCenter.Api.Middleware;

/// <summary>Expected business error; the message is safe to show to users.</summary>
public class AppException(int status, string code, string message) : Exception(message)
{
    public int Status { get; } = status;
    public string Code { get; } = code;

    public static AppException BadRequest(string message, string code = "BAD_REQUEST") => new(400, code, message);
    public static AppException NotFound(string message) => new(404, "NOT_FOUND", message);
    public static AppException Conflict(string message, string code = "CONFLICT") => new(409, code, message);
}
