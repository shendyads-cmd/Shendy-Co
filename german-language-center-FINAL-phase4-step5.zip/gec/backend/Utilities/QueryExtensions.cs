using System.Linq.Expressions;
using GermanCenter.Api.Middleware;
using Microsoft.EntityFrameworkCore;

namespace GermanCenter.Api.Utilities;

public static class QueryExtensions
{
    public static IOrderedQueryable<T> Sort<T, TKey>(this IQueryable<T> query, Expression<Func<T, TKey>> key, bool desc)
        => desc ? query.OrderByDescending(key) : query.OrderBy(key);

    /// <summary>Saves changes; technical details are logged, the user gets a friendly message.</summary>
    public static async Task SaveOrFailAsync(this DbContext db, ILogger log, string friendlyMessage, CancellationToken ct, string code = "SAVE_FAILED")
    {
        try { await db.SaveChangesAsync(ct); }
        catch (DbUpdateException ex)
        {
            log.LogError(ex, "{Message}", friendlyMessage);
            // A unique index rejected the row: the same record already exists (double click, retry, ...).
            throw new AppException(409, SqlErrors.IsUniqueViolation(ex) ? "DUPLICATE_RECORD" : code, friendlyMessage);
        }
    }

    /// <summary>Locks the course row until the surrounding transaction ends (serialises seat changes per course).</summary>
    public static Task LockCourseAsync(this DbContext db, int courseId, CancellationToken ct)
        => db.Database.ExecuteSqlInterpolatedAsync($"SELECT course_id FROM Courses WITH (UPDLOCK, ROWLOCK) WHERE course_id = {courseId}", ct);

    public static string? NullIfBlank(this string? value)
        => string.IsNullOrWhiteSpace(value) ? null : value.Trim();
}
