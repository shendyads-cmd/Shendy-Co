using Microsoft.Data.SqlClient;

namespace GermanCenter.Api.Utilities;

public static class SqlErrors
{
    /// <summary>True for "duplicate key" errors from SQL Server (2601 = unique index, 2627 = unique/primary key constraint).</summary>
    public static bool IsUniqueViolation(Exception? ex)
    {
        for (var e = ex; e != null; e = e.InnerException)
            if (e is SqlException s && (s.Number == 2601 || s.Number == 2627)) return true;
        return false;
    }
}
