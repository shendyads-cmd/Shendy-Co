using System.Text.RegularExpressions;

namespace GermanCenter.Api.Utilities;

/// <summary>Human-friendly identifiers derived from database keys (no extra column needed).</summary>
public static class Codes
{
    /// <summary>Student ID shown to users, e.g. STU-0001. It is always derived from the unique customer_id.</summary>
    public static string Student(int customerId) => $"STU-{customerId:D4}";

    private static readonly Regex StudentPattern = new(@"^(?:STU-?)?(\d{1,9})$", RegexOptions.IgnoreCase | RegexOptions.Compiled);

    /// <summary>Accepts "STU-0001", "STU0001", "0001" or "1".</summary>
    public static bool TryParseStudent(string input, out int customerId)
    {
        customerId = 0;
        var m = StudentPattern.Match(input.Trim());
        return m.Success && int.TryParse(m.Groups[1].Value, out customerId) && customerId > 0;
    }

    // ---------------------------------------------------------------- course codes: A-001, A-002, ...

    /// <summary>Course code shown everywhere: A-001, A-002 ... (A-1000 and above simply grow).</summary>
    public static string Course(int number) => $"A-{number:D3}";

    private static readonly Regex CoursePattern = new(@"^A-?(\d{1,9})$", RegexOptions.IgnoreCase | RegexOptions.Compiled);

    /// <summary>Reads the number of "A-007" and of the old format "A007".</summary>
    public static bool TryParseCourseNumber(string? code, out int number)
    {
        number = 0;
        if (string.IsNullOrWhiteSpace(code)) return false;
        var m = CoursePattern.Match(code.Trim());
        return m.Success && int.TryParse(m.Groups[1].Value, out number) && number > 0;
    }

    /// <summary>Search text such as "A1", "A001" or "a-001" becomes "A-001" so it matches the stored code; anything else is returned trimmed.</summary>
    public static string NormalizeCourseSearch(string input)
    {
        var t = input.Trim();
        return TryParseCourseNumber(t, out var n) && t.Length > 1 && !t.Contains(' ') ? Course(n) : t;
    }
}
