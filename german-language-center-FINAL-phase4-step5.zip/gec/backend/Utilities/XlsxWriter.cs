using System.Globalization;
using System.IO.Compression;
using System.Text;

namespace GermanCenter.Api.Utilities;

/// <summary>Minimal, dependency-free .xlsx writer (header row, frozen header, dates and numbers kept typed for pivots / Power BI).</summary>
public static class XlsxWriter
{
    public sealed record Sheet(string Name, IReadOnlyList<string> Headers, IReadOnlyList<object?[]> Rows);

    public static byte[] Build(IReadOnlyList<Sheet> sheets)
    {
        var names = UniqueNames(sheets.Select(s => s.Name).ToList());
        using var ms = new MemoryStream();
        using (var zip = new ZipArchive(ms, ZipArchiveMode.Create, leaveOpen: true))
        {
            Add(zip, "[Content_Types].xml", ContentTypes(sheets.Count));
            Add(zip, "_rels/.rels", "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"xl/workbook.xml\"/></Relationships>");
            Add(zip, "xl/workbook.xml", Workbook(names));
            Add(zip, "xl/_rels/workbook.xml.rels", WorkbookRels(sheets.Count));
            Add(zip, "xl/styles.xml", Styles);
            for (var i = 0; i < sheets.Count; i++) Add(zip, $"xl/worksheets/sheet{i + 1}.xml", Worksheet(sheets[i]));
        }
        return ms.ToArray();
    }

    private const string Styles =
        "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><styleSheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\">" +
        "<numFmts count=\"1\"><numFmt numFmtId=\"164\" formatCode=\"yyyy\\-mm\\-dd\\ hh:mm\"/></numFmts>" +
        "<fonts count=\"2\"><font><sz val=\"11\"/><name val=\"Calibri\"/></font><font><b/><sz val=\"11\"/><name val=\"Calibri\"/></font></fonts>" +
        "<fills count=\"2\"><fill><patternFill patternType=\"none\"/></fill><fill><patternFill patternType=\"gray125\"/></fill></fills>" +
        "<borders count=\"1\"><border><left/><right/><top/><bottom/><diagonal/></border></borders>" +
        "<cellStyleXfs count=\"1\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\"/></cellStyleXfs>" +
        "<cellXfs count=\"3\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\" xfId=\"0\"/>" +
        "<xf numFmtId=\"0\" fontId=\"1\" fillId=\"0\" borderId=\"0\" xfId=\"0\" applyFont=\"1\"/>" +
        "<xf numFmtId=\"164\" fontId=\"0\" fillId=\"0\" borderId=\"0\" xfId=\"0\" applyNumberFormat=\"1\"/></cellXfs>" +
        "<cellStyles count=\"1\"><cellStyle name=\"Normal\" xfId=\"0\" builtinId=\"0\"/></cellStyles></styleSheet>";

    private static string ContentTypes(int sheetCount)
    {
        var sb = new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">");
        sb.Append("<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/><Default Extension=\"xml\" ContentType=\"application/xml\"/>");
        sb.Append("<Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/>");
        sb.Append("<Override PartName=\"/xl/styles.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml\"/>");
        for (var i = 1; i <= sheetCount; i++)
            sb.Append($"<Override PartName=\"/xl/worksheets/sheet{i}.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>");
        return sb.Append("</Types>").ToString();
    }

    private static string Workbook(IReadOnlyList<string> names)
    {
        var sb = new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><workbook xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\"><sheets>");
        for (var i = 0; i < names.Count; i++) sb.Append($"<sheet name=\"{Esc(names[i])}\" sheetId=\"{i + 1}\" r:id=\"rId{i + 1}\"/>");
        return sb.Append("</sheets></workbook>").ToString();
    }

    private static string WorkbookRels(int count)
    {
        var sb = new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">");
        for (var i = 1; i <= count; i++)
            sb.Append($"<Relationship Id=\"rId{i}\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet{i}.xml\"/>");
        sb.Append($"<Relationship Id=\"rId{count + 1}\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles\" Target=\"styles.xml\"/>");
        return sb.Append("</Relationships>").ToString();
    }

    private static string Worksheet(Sheet sheet)
    {
        var sb = new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\">");
        sb.Append("<sheetViews><sheetView workbookViewId=\"0\"><pane ySplit=\"1\" topLeftCell=\"A2\" activePane=\"bottomLeft\" state=\"frozen\"/></sheetView></sheetViews><sheetData>");
        sb.Append("<row r=\"1\">");
        for (var c = 0; c < sheet.Headers.Count; c++)
            sb.Append($"<c r=\"{Ref(c, 1)}\" t=\"inlineStr\" s=\"1\"><is><t>{Esc(sheet.Headers[c])}</t></is></c>");
        sb.Append("</row>");
        for (var r = 0; r < sheet.Rows.Count; r++)
        {
            var row = sheet.Rows[r];
            sb.Append($"<row r=\"{r + 2}\">");
            for (var c = 0; c < row.Length; c++) AppendCell(sb, Ref(c, r + 2), row[c]);
            sb.Append("</row>");
        }
        return sb.Append("</sheetData></worksheet>").ToString();
    }

    private static void AppendCell(StringBuilder sb, string reference, object? v)
    {
        switch (v)
        {
            case null: return;
            case bool b: sb.Append($"<c r=\"{reference}\" t=\"b\"><v>{(b ? 1 : 0)}</v></c>"); return;
            case byte or sbyte or short or ushort or int or uint or long or ulong:
                sb.Append($"<c r=\"{reference}\"><v>{Convert.ToString(v, CultureInfo.InvariantCulture)}</v></c>"); return;
            case decimal d: sb.Append($"<c r=\"{reference}\"><v>{d.ToString(CultureInfo.InvariantCulture)}</v></c>"); return;
            case double d: sb.Append($"<c r=\"{reference}\"><v>{d.ToString("R", CultureInfo.InvariantCulture)}</v></c>"); return;
            case float f: sb.Append($"<c r=\"{reference}\"><v>{f.ToString("R", CultureInfo.InvariantCulture)}</v></c>"); return;
            case DateTime dt: sb.Append($"<c r=\"{reference}\" s=\"2\"><v>{dt.ToOADate().ToString("R", CultureInfo.InvariantCulture)}</v></c>"); return;
            case byte[] bytes: AppendText(sb, reference, "0x" + Convert.ToHexString(bytes)); return;
            default: AppendText(sb, reference, Convert.ToString(v, CultureInfo.InvariantCulture) ?? ""); return;
        }
    }

    private static void AppendText(StringBuilder sb, string reference, string text)
        => sb.Append($"<c r=\"{reference}\" t=\"inlineStr\"><is><t xml:space=\"preserve\">{Esc(text)}</t></is></c>");

    private static string Ref(int column, int row)
    {
        var name = "";
        for (var n = column + 1; n > 0; n = (n - 1) / 26) name = (char)('A' + (n - 1) % 26) + name;
        return name + row.ToString(CultureInfo.InvariantCulture);
    }

    private static string Esc(string s)
    {
        var sb = new StringBuilder(s.Length);
        foreach (var ch in s)
        {
            if (ch < 0x20 && ch != '\t' && ch != '\n' && ch != '\r') continue; // invalid in XML 1.0
            switch (ch)
            {
                case '&': sb.Append("&amp;"); break;
                case '<': sb.Append("&lt;"); break;
                case '>': sb.Append("&gt;"); break;
                case '"': sb.Append("&quot;"); break;
                default: sb.Append(ch); break;
            }
        }
        return sb.ToString();
    }

    private static List<string> UniqueNames(List<string> raw)
    {
        var used = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        var result = new List<string>();
        foreach (var name in raw)
        {
            var clean = new string(name.Where(ch => "[]:*?/\\".IndexOf(ch) < 0).ToArray());
            if (clean.Length == 0) clean = "Sheet";
            if (clean.Length > 31) clean = clean[..31];
            var candidate = clean; var i = 2;
            while (!used.Add(candidate)) candidate = clean[..Math.Min(clean.Length, 28)] + " " + i++;
            result.Add(candidate);
        }
        return result;
    }

    private static void Add(ZipArchive zip, string path, string content)
    {
        var entry = zip.CreateEntry(path, CompressionLevel.Optimal);
        using var stream = entry.Open();
        var bytes = new UTF8Encoding(false).GetBytes(content);
        stream.Write(bytes, 0, bytes.Length);
    }
}
