using System.Data;
using System.Data.Common;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Storage;

namespace GermanCenter.Api.Utilities;

/// <summary>
/// Parameterised raw SQL for the invoicing tables (Invoices, Payments, PaymentAllocations...), which are not EF entities.
/// Every command joins the EF transaction that is currently open, so a registration or a delete is all-or-nothing.
/// </summary>
public static class DbHelper
{
    public static Task<int> ExecuteAsync(this DbContext db, string sql, CancellationToken ct, params (string Name, object? Value)[] args)
        => RunAsync(db, async cmd => { Prepare(cmd, sql, args); return await cmd.ExecuteNonQueryAsync(ct); });

    /// <summary>Runs an INSERT that ends with "SELECT CAST(SCOPE_IDENTITY() AS int)" and returns the new identity value.</summary>
    public static Task<int> InsertAsync(this DbContext db, string sql, CancellationToken ct, params (string Name, object? Value)[] args)
        => RunAsync(db, async cmd =>
        {
            Prepare(cmd, sql, args);
            var value = await cmd.ExecuteScalarAsync(ct);
            return value is null or DBNull ? throw new InvalidOperationException("The INSERT did not return an identity value.") : Convert.ToInt32(value);
        });

    public static Task<T?> ScalarAsync<T>(this DbContext db, string sql, CancellationToken ct, params (string Name, object? Value)[] args)
        => RunAsync(db, async cmd =>
        {
            Prepare(cmd, sql, args);
            var value = await cmd.ExecuteScalarAsync(ct);
            return value is null or DBNull ? default : (T?)Convert.ChangeType(value, Nullable.GetUnderlyingType(typeof(T)) ?? typeof(T));
        });

    public static Task<List<T>> QueryAsync<T>(this DbContext db, string sql, Func<DbDataReader, T> map, CancellationToken ct, params (string Name, object? Value)[] args)
        => RunAsync(db, async cmd =>
        {
            Prepare(cmd, sql, args);
            var rows = new List<T>();
            await using var reader = await cmd.ExecuteReaderAsync(ct);
            while (await reader.ReadAsync(ct)) rows.Add(map(reader));
            return rows;
        });

    private static void Prepare(DbCommand cmd, string sql, (string Name, object? Value)[] args)
    {
        cmd.CommandText = sql;
        foreach (var (name, value) in args)
        {
            var p = cmd.CreateParameter();
            p.ParameterName = name;
            p.Value = value ?? DBNull.Value;
            cmd.Parameters.Add(p);
        }
    }

    private static async Task<TResult> RunAsync<TResult>(DbContext db, Func<DbCommand, Task<TResult>> action)
    {
        var connection = db.Database.GetDbConnection();
        var openedHere = false;
        if (connection.State != ConnectionState.Open) { await connection.OpenAsync(); openedHere = true; }
        try
        {
            await using var cmd = connection.CreateCommand();
            var tx = db.Database.CurrentTransaction?.GetDbTransaction();
            if (tx != null) cmd.Transaction = tx;
            return await action(cmd);
        }
        finally
        {
            if (openedHere) await connection.CloseAsync();
        }
    }

    public static decimal? GetDecimalOrNull(this DbDataReader r, int i) => r.IsDBNull(i) ? null : r.GetDecimal(i);
    public static string? GetStringOrNull(this DbDataReader r, int i) => r.IsDBNull(i) ? null : r.GetString(i);
    public static DateTime? GetDateTimeOrNull(this DbDataReader r, int i) => r.IsDBNull(i) ? null : r.GetDateTime(i);
}

public static class SqlText
{
    /// <summary>Builds a LIKE pattern (use with ESCAPE '\') so that user input such as 50% or [a] is matched literally.</summary>
    public static string LikePattern(string input)
        => "%" + input.Trim().Replace("\\", "\\\\").Replace("%", "\\%").Replace("_", "\\_").Replace("[", "\\[") + "%";
}
